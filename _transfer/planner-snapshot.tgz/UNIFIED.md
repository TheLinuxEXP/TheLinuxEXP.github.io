# Serveur unique : Task Planner + Gestion fiscale EI

## Lancer

    pip install -r requirements.txt
    python3 run.py              # http://127.0.0.1:8765  (Task Planner + section FINANCES)

Les données fiscales restent dans `~/.local/share/gestion-fiscale-ei/data.json`
(fichier partagé avec l'application KDE ; variable `EI_DATA_FILE` pour changer).
Les données du Task Planner restent dans SQLite (`~/.local/share/taskplanner/`).
Ne modifiez pas les mêmes factures en même temps dans l'application KDE et dans le
navigateur : le serveur relit `data.json` à chaque action, l'application KDE non.

## Comment c'est branché

| Élément | Où |
|---|---|
| Montage du module | `app/__init__.py` : `gestion_ei_web.register(app, url_prefix="/fiscal")` (désactivé proprement si le paquet manque) |
| Sidebar | `templates/index.html` (bloc `#financeBlock`), `app/static/js/finances.js` (`renderFinanceNav`, `openFiscalView`, `renderFiscalView`) |
| Chargement | à la première ouverture d'une section FINANCES : `/fiscal/static/ds/ds.css`, `/fiscal/static/ei.css`, `/fiscal/static/ei.js` |
| Affichage | `GestionEI.mount(el, {layout:"embedded", section, onTitle})` : pas de barre latérale ni de titre propres, le titre et le sous-titre sont ceux de la page du Task Planner |
| Sections | Factures (Émises / Achats / Importer capture), Graphique, Déclarations (URSSAF / Impôt-revenu / TVA) |
| État | chaque section est montée une fois et conservée : onglet choisi, courbes masquées… survivent à la navigation ; les données sont relues à chaque retour |
| Style | Planner Design System : `gestion_ei_web/static/ds/ds.css` (démo : `/fiscal/static/ds/ds.html`) |
| Sécurité | requêtes modifiantes du module : en-tête `X-Requested-With: gestion-ei` ; le garde « réseau local » du Task Planner s'applique aussi à `/fiscal` |

La page autonome du module reste disponible : `/fiscal/` (7 onglets, barre latérale propre).

## Docker (Synology)

Le `Dockerfile` copie `gestion_ei_web/` et `gestion_fiscale_ei.py` ; tesseract (OCR) est déjà
dans l'image. Copiez votre `data.json` fiscal dans `./data/gestion-fiscale-ei/` avant le premier
démarrage (`EI_DATA_FILE` pointe dessus).

## Synchronisation avec le projet « Gestion EI »

`gestion_fiscale_ei.py` et `gestion_ei_web/` sont ici des **copies** de ceux du projet
« Gestion EI » (l'application KDE reste développée là-bas). Après une évolution du côté KDE,
recopier ces deux éléments ; l'interface web suit automatiquement les calculs.
