#!/bin/sh
# Container entrypoint: make sure /data is writable by the unprivileged "planner" user, then run the server as it.
set -e
mkdir -p /data/home 2>/dev/null || true
if [ "$(id -u)" = "0" ]; then
    # a bind-mounted folder (the NAS's ./data) is usually owned by root or by a DSM user: hand over what isn't ours
    find /data ! -user planner -exec chown planner:planner {} + 2>/dev/null || true
    exec setpriv --reuid=planner --regid=planner --init-groups "$@"
fi
if [ ! -w /data ]; then
    echo "ERROR: /data is not writable by uid $(id -u). Fix the ownership of the mounted folder, or remove 'user:' from the compose file." >&2
    exit 1
fi
exec "$@"
