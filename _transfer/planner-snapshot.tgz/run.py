#!/usr/bin/env python3
"""Run the Task Planner web app.

    python3 run.py            # serves on http://127.0.0.1:8765
    python3 run.py --port 9000 --host 0.0.0.0

Data is stored in SQLite under ~/.local/share/taskplanner/taskplanner.db
(override with the XDG_DATA_HOME environment variable). Attachments are
stored under ~/.local/share/taskplanner/attachments/.
"""
import argparse
import time
import webbrowser
from threading import Timer

from werkzeug.serving import make_server

from app import create_app


def _make_server_with_retry(host, port, app, attempts=15, delay=0.3):
    """Bind the dev server socket, retrying briefly if the port is still held
    by a just-exited previous instance of this same process (see the
    /api/restart endpoint — it closes its own socket before re-exec'ing, but
    the OS can take a moment to actually release the port)."""
    last_err = None
    for _ in range(attempts):
        try:
            return make_server(host, port, app, threaded=True)
        except OSError as e:
            last_err = e
            time.sleep(delay)
    raise last_err


def main():
    parser = argparse.ArgumentParser(description="Task Planner — local task manager + calendar")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true",
                         help="Don't automatically open a browser tab on start")
    args = parser.parse_args()

    app = create_app()

    # Weekly (Sunday) and monthly (the 1st) AI insights of the Time report are
    # generated in the background, via the Claude Code CLI (see app/insights.py).
    from app import insights
    from app.ai import call_claude
    insights.start_scheduler(app.db, call_claude)

    # Sponsor invoices: at the end of each month / quarter a task "Invoices <period>" is created in
    # "The Linux EXP / Tasks" (see app/dbparts/billing.py). Checked now, then every hour.
    import threading

    def _billing_loop():
        while True:
            try:
                made = app.db.run_billing()
                if made:
                    print("[billing] created:", ", ".join(made), flush=True)
            except Exception as e:  # noqa: BLE001 -- background job: never crash the server
                print(f"[billing] error: {e}", flush=True)
            time.sleep(3600)
    threading.Thread(target=_billing_loop, name="billing", daemon=True).start()

    # threaded=True: an AI button can take a while (it shells out to the
    # Claude Code CLI), and with a single-threaded server that one slow
    # request would block every other request/page load until it finished.
    # The Database class (see app/database.py) serializes all its own method
    # calls behind a lock, so this is safe even though every request shares
    # one sqlite3 connection. We build the server by hand (instead of
    # app.run()) so the "Reload server" sidebar link can reach the actual
    # listening socket and close it cleanly before re-exec'ing — see
    # app/api.py's /restart route.
    srv = _make_server_with_retry(args.host, args.port, app)
    app.config["_DEV_SERVER"] = srv

    if not args.no_browser:
        url = f"http://{args.host if args.host != '0.0.0.0' else '127.0.0.1'}:{args.port}/"
        Timer(1.0, lambda: webbrowser.open(url)).start()

    srv.serve_forever()


if __name__ == "__main__":
    main()
