"""Browser smoke test (Playwright + Chromium, optional): boots the app on a throw-away database, opens every main view and
fails on any JavaScript error, failed request or empty view.

    python3 -m tests.ui_smoke            (set PLAYWRIGHT_CHROMIUM=/path/to/chromium if it is not auto-detected)
"""
import os
import sys
from pathlib import Path
import tempfile
import threading
from datetime import date, timedelta

from tests.base import ROOT  # noqa: F401


def main() -> int:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed: skipped")
        return 0
    tmp = tempfile.mkdtemp(prefix="planner-ui-")
    os.environ["XDG_DATA_HOME"] = tmp
    os.environ["NOTES_DIR"] = os.path.join(tmp, "notes")
    os.makedirs(os.environ["NOTES_DIR"])
    with open(os.path.join(tmp, "notes", "Demo.md"), "w", encoding="utf-8") as f:
        f.write("# Demo\n\n## Content\nHello\n")
    for name, age_days in (("Zz Oldest", 400), ("Aa Middle", 40)):          # sorted by date, not by name
        fp = os.path.join(tmp, "notes", name + ".md")
        with open(fp, "w", encoding="utf-8") as f:
            f.write("# " + name + "\n")
        old = __import__("time").time() - age_days * 86400
        os.utime(fp, (old, old))
    from werkzeug.serving import make_server
    from app import create_app
    app = create_app()
    c = app.test_client()
    today = date.today()
    lst = c.get("/api/todolists").get_json()[0]
    proj = c.get("/api/projects").get_json()[0]
    t = c.post("/api/tasks", json={"todo_list_id": lst["id"], "title": "Task A", "due_date": today.isoformat(), "urgent": True}).get_json()
    c.post(f"/api/tasks/{t['id']}/subtasks", json={"title": "Sub 1"})
    v = c.post("/api/templates/warhammer_video", json={"todo_list_id": lst["id"]}).get_json()
    wh_id = v.get("id") or v.get("task_id") or (v.get("task") or {}).get("id")
    if wh_id:                              # the Warhammer template has no main day: give it a date so the project view lists it
        c.patch(f"/api/tasks/{wh_id}", json={"due_date": (today + timedelta(days=9)).isoformat()})
        subs = sorted(c.get(f"/api/tasks/{wh_id}").get_json()["subtasks"], key=lambda s: s["sort_order"])
        c.patch(f"/api/subtasks/{subs[0]['id']}", json={"due_date": (today + timedelta(days=40)).isoformat()})     # first step dated last,
        c.patch(f"/api/subtasks/{subs[-1]['id']}", json={"due_date": (today - timedelta(days=40)).isoformat()})    # last step dated first
    wh_titles = [s["title"] for s in next(t for t in c.get("/api/templates").get_json() if t["key"] == "warhammer_video")["subtasks"]]
    vid = c.post("/api/tasks", json={"todo_list_id": lst["id"], "title": "Vid", "due_date": (today + timedelta(days=3)).isoformat(), "is_video": True}).get_json()
    c.post("/api/tasks", json={"todo_list_id": lst["id"], "title": "Vid 2", "due_date": (today + timedelta(days=5)).isoformat(), "is_video": True})
    c.patch(f"/api/tasks/{vid['id']}", json={"notes_file": os.path.join(os.environ["NOTES_DIR"], "Demo.md")})
    srv = make_server("127.0.0.1", 0, app, threaded=True)
    port = srv.server_port
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    errors, bad = [], []
    exe = os.environ.get("PLAYWRIGHT_CHROMIUM") or ("/opt/pw-browsers/chromium" if os.path.exists("/opt/pw-browsers/chromium") else None)
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=exe, args=["--no-sandbox"]) if exe else p.chromium.launch()
        pg = b.new_page(viewport={"width": 1300, "height": 850})
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.on("console", lambda m: errors.append("console: " + m.text) if m.type == "error" else None)
        pg.on("response", lambda r: bad.append(f"{r.status} {r.url}") if r.status >= 400 and "/fiscal" not in r.url else None)
        pg.goto(f"http://127.0.0.1:{port}/")
        if "/login" not in pg.url:
            errors.append("not redirected to the login page")
        pg.fill("#identifier", "nicolas")
        pg.fill("#password", "wrong")
        pg.click("button[type=submit]")
        pg.wait_for_selector(".err", timeout=5000)
        bad.clear(); errors.clear()      # the 401 above is expected
        pg.fill("#identifier", "nicolas")
        pg.fill("#password", "1234")
        pg.click("button[type=submit]")
        # the default password has to be replaced before anything else opens
        pg.wait_for_selector("#pw1", timeout=5000)
        if "/change-password" not in pg.url:
            errors.append("default password: not sent to the change-password page")
        pg.goto(f"http://127.0.0.1:{port}/")
        if "/change-password" not in pg.url:
            errors.append("default password: the app opened anyway")
        bad.clear(); errors.clear()
        pg.fill("#cur", "1234"); pg.fill("#pw1", "1234"); pg.fill("#pw2", "1234")
        pg.click("button[type=submit]")
        pg.wait_for_selector(".err:has-text('at least')", timeout=5000)        # the default password is refused as the new one
        pg.fill("#pw1", "a-new-password"); pg.fill("#pw2", "a-new-password")
        pg.click("button[type=submit]")
        pg.wait_for_selector("#utilitiesToggle", timeout=10000)
        bad.clear(); errors.clear()      # the 400 / 403 above are expected
        pg.wait_for_timeout(1500)
        if errors:
            print("load-time errors:", errors[:5])
        steps = [
            ("smart inbox", "openSmartView('inbox')"), ("smart today", "openSmartView('today')"),
            ("smart tomorrow", "openSmartView('tomorrow')"), ("smart urgent", "openSmartView('urgent')"),
            ("calendar", "openCalendar()"), ("sponsors", "openSponsorsView()"), ("video project", "openVideoProject()"),
            ("notes", "openNotes()"), ("time report", "openTimeReport()"), ("templates", "openTemplatesView()"),
            ("backups", "openBackupsView()"), ("revenue", "openRevenue()"),
            ("task detail", f"openTaskDetail('{t['id']}')"), ("video task detail", f"openTaskDetail('{v['id']}')"),
            ("quick add modal", "openQuickAddModal()"), ("project dialog", "openProjectDialog()"),
        ]
        for label, js in steps:
            try:
                pg.evaluate(f"(async () => {{ await {js}; }})()")
            except Exception as e:  # noqa: BLE001
                errors.append(f"{label}: {e}")
            pg.wait_for_timeout(500)
            pg.evaluate("typeof closeModal === 'function' && closeModal(); typeof closeTaskDetail === 'function' && closeTaskDetail()")
            print("ok  " if not errors else "ERR ", label)
        # widget bridge: the page must jump to a task the Plasma widget asked for, through its heartbeat
        c.post("/api/tab/open-request", json={"task_id": t["id"]})
        pg.wait_for_timeout(3500)
        if "hidden" in (pg.locator("#taskDetailOverlay").get_attribute("class") or ""):
            errors.append("widget open-request did not open the task")
        top = pg.evaluate("document.getElementById('taskDetailOverlay').getBoundingClientRect().top")
        hdr = pg.evaluate("document.querySelector('.app-header').getBoundingClientRect().bottom")
        if abs(top - hdr) > 1:
            errors.append(f"task detail overlaps the page header (overlay top {top}, header bottom {hdr})")
        pg.evaluate("closeTaskDetail()")
        pg.locator("#resourcesBtn").click()
        pg.wait_for_timeout(500)
        if pg.locator(".res-menu").count() == 0:
            errors.append("Useful Resources menu did not open")
        elif pg.evaluate("(() => { const v = document.querySelectorAll('.res-video'); return v.length >= 2 && getComputedStyle(v[1]).borderTopWidth !== '0px'; })()") is False:
            errors.append("Useful Resources: no separator between videos")
        elif "🎥 Vid" not in pg.locator(".res-menu .res-title").first.inner_text():
            errors.append("Useful Resources: the video type icon is missing")
        elif "Demo" not in " ".join(pg.locator(".res-menu .res-note").all_inner_texts()):
            errors.append("Useful Resources: the linked note's name is not shown")
        pg.evaluate("openVideoProject()")
        pg.wait_for_timeout(800)
        pg.evaluate(f"state.videoProject.taskId = {wh_id!r}; loadVideoProject()")
        pg.wait_for_selector(".vp-step-title", timeout=5000)
        shown = pg.locator(".vp-step-title").all_inner_texts()
        if not wh_id or shown != wh_titles:
            errors.append(f"Current Video project: subtasks not in template order: {shown} vs {wh_titles}")
        pg.evaluate("openVideoProject()")
        pg.wait_for_timeout(600)
        if pg.locator(".vp-project-filter").count() == 0:
            errors.append("project filter missing in the Current Video project view")
        if pg.locator(".vp-no-sponsor").count() == 0 or pg.locator(".vp-mention").count() != 0:
            errors.append("Current Video project: a video without sponsor should show 'No sponsor' and no mention button")
        # notes editor: a sub-list nested the way the browser's Tab/indent builds it must survive being saved as Markdown
        md = pg.evaluate("""(() => { const d = document.createElement("div");
            d.innerHTML = "<ul><li>a</li><ul><li>b</li><li>c</li></ul><li>d</li></ul>";
            return NotesApp._internals.blockEl(d.firstChild); })()""")
        if md != "- a\n  - b\n  - c\n- d":
            errors.append(f"nested bullets lost when saving a note: {md!r}")
        sig = pg.evaluate("""(() => { const I = NotesApp._internals; const a = document.createElement("div"), b = document.createElement("div");
            a.innerHTML = "<p>x</p><ul><li>a</li><li></li></ul><pre></pre>"; b.innerHTML = "<p>x</p><ul><li>a</li></ul>";
            return [I.structSig(a), I.structSig(b)]; })()""")
        if sig[0] != sig[1]:
            errors.append(f"an empty bullet / code block (just typed) must not count as lost content: {sig}")
        md = pg.evaluate("""(() => { const I = NotesApp._internals; const d = document.createElement("div");
            I.sanitizeInto(d, I.md().render("- [ ] a\\n\\n- [x] b\\n", { noMap: true })); return I.blockEl(d.firstChild); })()""")
        if md != "- [ ] a\n\n- [x] b":
            errors.append(f"checkboxes of a loose task list lost when saving a note: {md!r}")
        for sel in ("#themeToggle", "#pageTitle", "#headerActions", "#resourcesBtn", "#statusIndicators"):
            if pg.locator(f".app-header {sel}").count() != 1:
                errors.append(f"page header: {sel} is not in the top header")
        pg.evaluate("closeModal()")
        pg.keyboard.press("Escape")
        pg.mouse.click(5, 400)               # closes the Useful Resources dropdown
        pg.evaluate("openSmartView('today')")
        pg.wait_for_selector(".other-tasks-row", timeout=5000)
        pg.fill(".other-tasks-row .time-edit-input", "25")
        pg.press(".other-tasks-row .time-edit-input", "Tab")
        pg.wait_for_selector('.other-tasks-row .timer-elapsed:has-text("25m")', timeout=5000)
        pg.click(".other-tasks-row .t-start")
        pg.wait_for_selector(".other-tasks-row .t-stop", timeout=5000)
        if pg.locator(".other-tasks-row .timer-controls.fx-start").count() != 1:
            errors.append("starting a timer: no start animation on the rebuilt controls")
        pg.click(".other-tasks-row .t-stop")
        pg.wait_for_selector(".other-tasks-row .t-start", timeout=5000)
        if pg.locator(".other-tasks-row .timer-controls.fx-stop").count() != 1:
            errors.append("stopping a timer: no stop animation on the rebuilt controls")
        # The projects' permanent "Other tasks": in Today (named project) and at the top of the project view
        pg.evaluate("openSmartView('today')")
        pg.wait_for_selector(".project-other-row", timeout=5000)
        if pg.locator(".project-other-row").count() != len(c.get("/api/projects").get_json()):
            errors.append("Today: not one 'Other tasks' row per project")
        if not pg.locator(".project-other-row").first.inner_text().count("·"):
            errors.append("Today: a project's Other tasks row does not name its project")
        pg.evaluate("openProjectView(state.projects[0])")
        pg.wait_for_selector(".project-other-row", timeout=5000)
        if pg.locator(".project-other-row").count() != 1:
            errors.append("project view: Other tasks row missing or duplicated")
        pg.click(".project-other-row .t-start")
        pg.wait_for_selector(".project-other-row .t-stop", timeout=5000)
        pg.click(".project-other-row .t-stop")
        pg.wait_for_selector(".project-other-row .t-start", timeout=5000)
        # Utilities: a gear menu in the header (no longer in the sidebar), animated open/closed
        if pg.locator(".sidebar #utilitiesToggle, .sidebar .sidebar-footer").count():
            errors.append("Utilities are still in the sidebar")
        if pg.locator(".app-header #utilitiesToggle").count() != 1:
            errors.append("the Utilities gear is not in the page header")
        if pg.locator("#utilitiesList").evaluate("e => getComputedStyle(e).visibility") != "hidden":
            errors.append("Utilities menu is open at load")
        pg.click("#utilitiesToggle")
        pg.wait_for_timeout(500)
        if pg.locator("#utilitiesList").evaluate("e => getComputedStyle(e).visibility") != "visible" or pg.locator("#utilitiesList .row-item").count() != 6:
            errors.append("Utilities menu did not open with its 6 entries")
        pg.screenshot(path=str(Path(__file__).resolve().parent / "utilities_menu.png")) if os.environ.get("UI_SHOTS") else None
        pg.click("#backupsBtn")
        pg.wait_for_timeout(500)
        if pg.locator("#utilitiesList").evaluate("e => getComputedStyle(e).visibility") != "hidden":
            errors.append("Utilities menu did not close after choosing an entry")
        pg.wait_for_selector(".backups-wrap, #viewRoot *", timeout=5000)
        if pg.evaluate("state.view.type") != "backups":
            errors.append("Utilities > Backups did not open the Backups view")
        pg.click("#utilitiesToggle"); pg.wait_for_timeout(300)
        pg.mouse.click(400, 400); pg.wait_for_timeout(400)
        if pg.locator("#utilitiesList").evaluate("e => getComputedStyle(e).visibility") != "hidden":
            errors.append("Utilities menu did not close on an outside click")
        # Show completed: the switch animates before the view is rebuilt
        pg.evaluate("openSmartView('today')")
        pg.wait_for_selector(".completed-toggle", timeout=5000)
        pg.click(".completed-toggle")
        pg.wait_for_timeout(60)
        if "on" not in (pg.locator(".completed-toggle").first.get_attribute("class") or ""):
            errors.append("Show completed: the switch did not flip at once")
        pg.wait_for_timeout(600)
        if not pg.evaluate("state.showCompleted"):
            errors.append("Show completed: not applied")
        pg.click(".completed-toggle")
        pg.wait_for_timeout(500)
        pg.evaluate("openNotes()")
        pg.wait_for_selector(".notes-note", timeout=5000)
        order = [t.split("\n")[0].strip() for t in pg.locator(".notes-note").all_inner_texts()]
        last = {n: len(order) - 1 - order[::-1].index(n) for n in ("Demo", "Aa Middle", "Zz Oldest") if n in order}
        if not (len(last) == 3 and last["Demo"] < last["Aa Middle"] < last["Zz Oldest"]):
            errors.append(f"notes of a folder are not sorted from the most to the least recent: {order}")
        pg.evaluate("openAccountView()")
        pg.wait_for_selector(".account-wrap", timeout=5000)
        if pg.query_selector(".account-warn"):
            errors.append("account page still nags after the password was changed")
        pg.evaluate("openAiSettings()")
        pg.wait_for_selector("#modalBody select", timeout=5000)
        pg.select_option("#modalBody select", "ollama")
        if not pg.input_value("#modalBody input[list=aiModelList]") == "" or "11434" not in pg.input_value("#modalBody input[placeholder='http://localhost:11434/v1']"):
            errors.append("AI settings window: Ollama preset not filled in")
        pg.screenshot(path=str(Path(__file__).resolve().parent / "ai_settings.png")) if os.environ.get("UI_SHOTS") else None
        # --- data safety -------------------------------------------------------------------------------------------
        # 1. the task panel's Notes field is saved while typing, and when the page is hidden/closed (it used to be saved only
        #    when the field lost focus: text typed just before reloading or closing the tab was lost)
        pg.evaluate("closeModal()")
        pg.evaluate(f"openTaskDetail('{t['id']}')")
        pg.wait_for_selector("#taskPanel textarea", timeout=5000)
        pg.click("#taskPanel textarea")
        pg.keyboard.type("typed notes")
        pg.wait_for_timeout(1800)
        if c.get(f"/api/tasks/{t['id']}").get_json().get("notes") != "typed notes":
            errors.append("task notes not saved while typing")
        pg.keyboard.type(" and more")
        pg.evaluate("window.dispatchEvent(new Event('pagehide'))")
        pg.wait_for_timeout(500)
        if c.get(f"/api/tasks/{t['id']}").get_json().get("notes") != "typed notes and more":
            errors.append("task notes typed just before the page is hidden were not saved")
        pg.evaluate("closeTaskDetail()")
        # 2. a lost session must not throw the page (and what is being typed in it) away
        cookies = pg.context.cookies()
        pg.context.clear_cookies()
        url_before = pg.url
        pg.evaluate("fetch('/api/auth/me')")
        pg.wait_for_selector("[role=alert]", timeout=5000)
        if pg.url != url_before:
            errors.append("a 401 navigated away from the page")
        pg.context.add_cookies(cookies)
        pg.evaluate("fetch('/api/auth/me')")
        pg.wait_for_selector("[role=alert]", state="detached", timeout=5000)
        bad.clear(); errors_before = list(errors); errors[:] = [e for e in errors_before if "401" not in e]
        # 3. notes editor: editing a list that is followed by a paragraph must keep the blank line between them
        pg.evaluate("openNotes()")
        pg.wait_for_timeout(1200)
        pg.evaluate("NotesApp.openNote('Demo.md')")
        pg.wait_for_selector(".md-editor", state="visible", timeout=5000)
        pg.evaluate("""(() => { const i = NotesApp._internals.instance(); i.load("# T\\n\\n- a\\n- b\\n\\nAfter\\n\\n| x | y |\\n|---|---|\\n| 1 | 2 |\\n"); })()""")
        pg.evaluate("""(() => { const li = document.querySelectorAll('.md-editor li')[1]; const r = document.createRange();
            r.selectNodeContents(li); r.collapse(false); const s = getSelection(); s.removeAllRanges(); s.addRange(r); })()""")
        pg.keyboard.type("X")
        out = pg.evaluate("NotesApp._internals.instance().build_markdown()")
        if out != "# T\n\n- a\n- bX\n\nAfter\n\n| x | y |\n|---|---|\n| 1 | 2 |\n":
            errors.append(f"editing a list glued the next block to it: {out!r}")
        # 4. safety net: text that cannot be written back as Markdown (here a line that Markdown reads as a link definition and
        #    hides) must not be saved silently - the file stays as it is, a warning offers to keep the text
        notes_dir = Path(os.environ["NOTES_DIR"])
        before_disk = (notes_dir / "Demo.md").read_text()
        pg.evaluate("""(() => { const i = NotesApp._internals.instance(); i.load("# Demo\\n\\nhello\\n"); i.text = ""; })()""")
        pg.evaluate("""(() => { const p = document.querySelector('.md-editor p'); const r = document.createRange();
            r.selectNodeContents(p); r.collapse(false); const s = getSelection(); s.removeAllRanges(); s.addRange(r); })()""")
        pg.keyboard.press("Enter")
        pg.keyboard.type('[foo]: /url "precious text"')
        pg.wait_for_selector(".note-warn:not(.hidden)", timeout=6000)
        if (notes_dir / "Demo.md").read_text() != before_disk:
            errors.append("a note that cannot be saved faithfully was written to disk anyway")
        pg.click(".note-warn button:has-text('new note')")
        pg.wait_for_timeout(800)
        rescued = list(notes_dir.glob("Demo (recovered text)*.md"))
        if not rescued or "precious text" not in rescued[0].read_text():
            errors.append("the rescue copy of the visible text was not created")
        pg.click(".note-warn button:has-text('Save anyway')")
        pg.wait_for_selector(".note-warn", state="hidden", timeout=6000)
        if "precious text" not in (notes_dir / "Demo.md").read_text():
            errors.append("'Save anyway' did not save")
        b.close()
    srv.shutdown()
    for e in errors + bad:
        print("PROBLEM:", e)
    print("UI smoke:", "FAILED" if (errors or bad) else "OK")
    return 1 if (errors or bad) else 0


if __name__ == "__main__":
    sys.exit(main())
