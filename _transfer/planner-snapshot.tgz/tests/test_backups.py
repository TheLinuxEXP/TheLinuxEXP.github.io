"""Backup retention: bursts of identical changes collapse, old backups are thinned to one per day (not just deleted)."""
import json
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

from app import backups
from app.backups import BackupStore


def conn_with(rows):
    c = sqlite3.connect(":memory:")
    c.row_factory = sqlite3.Row
    c.execute("CREATE TABLE tasks (id TEXT, title TEXT)")
    c.executemany("INSERT INTO tasks VALUES (?, ?)", rows)
    return c


class BackupRetentionTest(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix="bk-"))
        self.store = BackupStore(self.dir)

    def count(self):
        return len(list(self.dir.glob("*.meta.json")))

    def test_identical_changes_in_a_burst_replace_each_other(self):
        c = conn_with([("1", "a")])
        self.store.create(c, "Task edited: T (notes)")
        for i in range(5):
            c.execute("UPDATE tasks SET title=?", (f"v{i}",))
            self.store.create(c, "Task edited: T (notes)")
        self.assertEqual(self.count(), 1)                                        # one backup, holding the last state
        data = self.store.load(self.store.list()[0]["id"])
        self.assertEqual(data["tables"]["tasks"][0]["title"], "v4")
        c.execute("UPDATE tasks SET title='other'")
        self.store.create(c, "Task completed: T")                                 # another kind of change: kept apart
        self.assertEqual(self.count(), 2)

    def test_a_long_burst_still_leaves_one_backup_per_minute(self):
        c = conn_with([("1", "a")])
        first = self.store.create(c, "Task edited: T (notes)")
        meta_path = self.dir / f"{first['id']}.meta.json"
        meta = json.loads(meta_path.read_text())
        old = (datetime.now() - timedelta(seconds=backups.COALESCE_SECONDS + 5)).isoformat(timespec="seconds")
        meta.update(created_at=old, burst=old)
        meta_path.write_text(json.dumps(meta))
        c.execute("UPDATE tasks SET title='b'")
        self.store.create(c, "Task edited: T (notes)")
        self.assertEqual(self.count(), 2)                                         # the first one is not eaten by an endless burst

    def test_forced_backups_are_never_merged(self):
        c = conn_with([("1", "a")])
        self.store.create(c, "Manual backup", force=True)
        self.store.create(c, "Manual backup", force=True)
        self.assertEqual(self.count(), 2)

    def test_old_backups_are_thinned_to_one_per_day(self):
        old_max, old_days = backups.MAX_BACKUPS, backups.KEEP_DAILY_DAYS
        backups.MAX_BACKUPS, backups.KEEP_DAILY_DAYS = 3, 30
        try:
            today = datetime.now().date()
            names = []
            for days_ago, n in ((5, 4), (4, 2), (60, 3)):                         # 4 backups 5 days ago, 2 four days ago, 3 two months ago
                day = (today - timedelta(days=days_ago)).strftime("%Y%m%d")
                for k in range(n):
                    bid = f"{day}-1{k}0000-000-aaa{k}"
                    (self.dir / f"{bid}.meta.json").write_text("{}")
                    (self.dir / f"{bid}.json.gz").write_bytes(b"x")
                    names.append(bid)
            for k in range(3):                                                    # the 3 newest ones fill the "full resolution" window
                bid = f"{today.strftime('%Y%m%d')}-2{k}0000-000-bbb{k}"
                (self.dir / f"{bid}.meta.json").write_text("{}")
                (self.dir / f"{bid}.json.gz").write_bytes(b"x")
            self.store._prune()
            left = sorted(p.name[: -len(".meta.json")] for p in self.dir.glob("*.meta.json"))
            day5 = (today - timedelta(days=5)).strftime("%Y%m%d")
            day4 = (today - timedelta(days=4)).strftime("%Y%m%d")
            self.assertEqual([b for b in left if b.startswith(day5)], [f"{day5}-130000-000-aaa3"])   # the last of that day
            self.assertEqual(len([b for b in left if b.startswith(day4)]), 1)
            self.assertFalse(any(b.startswith((today - timedelta(days=60)).strftime("%Y%m%d")) for b in left))   # beyond KEEP_DAILY_DAYS
            self.assertEqual(len([b for b in left if b.startswith(today.strftime("%Y%m%d"))]), 3)    # the newest are untouched
            self.assertFalse((self.dir / f"{day5}-100000-000-aaa0.json.gz").exists())               # data files go with their meta
        finally:
            backups.MAX_BACKUPS, backups.KEEP_DAILY_DAYS = old_max, old_days


if __name__ == "__main__":
    unittest.main()
