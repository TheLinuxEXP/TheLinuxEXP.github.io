"""Shared test setup: a throw-away data folder + notes folder, and a Flask test client on a fresh database."""
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class AppCase(unittest.TestCase):
    """Each test class gets its own data dir (XDG_DATA_HOME), notes dir (NOTES_DIR) and app."""

    max_upload_mb = None

    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.mkdtemp(prefix="planner-test-")
        cls._env = {k: os.environ.get(k) for k in ("XDG_DATA_HOME", "NOTES_DIR", "TASKPLANNER_MAX_UPLOAD_MB")}
        os.environ["XDG_DATA_HOME"] = cls._tmp
        os.environ["NOTES_DIR"] = os.path.join(cls._tmp, "notes")
        if cls.max_upload_mb:
            os.environ["TASKPLANNER_MAX_UPLOAD_MB"] = str(cls.max_upload_mb)
        os.makedirs(os.environ["NOTES_DIR"])
        from app import create_app
        cls.app = create_app()
        cls.c = cls.app.test_client()
        cls.notes = Path(os.environ["NOTES_DIR"])

    @classmethod
    def tearDownClass(cls):
        for k, v in cls._env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(cls._tmp, ignore_errors=True)

    # small helpers -------------------------------------------------------
    def post(self, url, **json):
        return self.c.post(url, json=json)

    def make_task(self, title="T", **extra):
        lst = self.c.get("/api/todolists").get_json()[0]
        r = self.post("/api/tasks", todo_list_id=lst["id"], title=title, **extra)
        self.assertIn(r.status_code, (200, 201), r.get_data(as_text=True))
        return r.get_json()
