"""The AI layer is provider-independent: same prompt + system reach a local/cloud model; keys never leak."""
import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

from tests.base import AppCase


class FakeAI(BaseHTTPRequestHandler):
    seen = []

    def log_message(self, *a):
        pass

    def _send(self, obj):
        raw = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        FakeAI.seen.append(("GET", self.path, None, dict(self.headers)))
        self._send({"data": [{"id": "model-b"}, {"id": "model-a"}]})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        FakeAI.seen.append(("POST", self.path, body, dict(self.headers)))
        if self.path.endswith("/messages"):
            self._send({"content": [{"type": "text", "text": "anthropic says hi"}]})
        else:
            self._send({"choices": [{"message": {"content": "<think>hmm</think>local says hi"}}]})


class ProviderTest(AppCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.srv = HTTPServer(("127.0.0.1", 0), FakeAI)
        cls.base = f"http://127.0.0.1:{cls.srv.server_port}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        super().tearDownClass()

    def setUp(self):
        FakeAI.seen.clear()
        from app import ai_config
        ai_config._path().unlink(missing_ok=True)       # every test starts from the defaults

    @staticmethod
    def hdr(name):
        return {k.lower(): v for k, v in FakeAI.seen[-1][3].items()}.get(name.lower())

    def put(self, **kw):
        return self.c.put("/api/ai/settings", json=kw)

    def test_default_is_claude_subscription(self):
        cfg = self.c.get("/api/ai/settings").get_json()
        self.assertEqual(cfg["active"], "claude_cli")
        self.assertIn("ollama", [p["id"] for p in cfg["providers"]])

    def test_local_model_gets_same_prompt_and_system(self):
        r = self.put(active="ollama", profile={"id": "ollama", "model": "qwen", "base_url": self.base + "/v1"})
        self.assertEqual(r.status_code, 200)
        from app import ai
        out = ai.call_claude("PROMPT-X", system="SYSTEM-Y", max_tokens=123)
        self.assertEqual(out, "local says hi")                      # reasoning block stripped
        method, path, body, _h = FakeAI.seen[-1]
        self.assertEqual(path, "/v1/chat/completions")
        self.assertEqual(body["model"], "qwen")
        self.assertEqual(body["max_tokens"], 123)
        self.assertEqual(body["messages"][1], {"role": "user", "content": "PROMPT-X"})
        self.assertTrue(body["messages"][0]["content"].startswith("SYSTEM-Y"))

    def test_cloud_key_is_sent_but_never_returned(self):
        r = self.put(active="openai", profile={"id": "openai", "model": "m", "base_url": self.base + "/v1", "api_key": "sk-secret"})
        self.assertNotIn("sk-secret", r.get_data(as_text=True))
        self.assertTrue(r.get_json()["profiles"]["openai"]["has_key"])
        self.assertNotIn("sk-secret", self.c.get("/api/ai/settings").get_data(as_text=True))
        from app import ai
        ai.call_claude("hi")
        self.assertEqual(self.hdr("Authorization"), "Bearer sk-secret")
        # saving again without a key keeps it
        self.put(profile={"id": "openai", "model": "m2"})
        ai.call_claude("hi")
        self.assertEqual(self.hdr("Authorization"), "Bearer sk-secret")
        self.assertEqual(FakeAI.seen[-1][2]["model"], "m2")

    def test_missing_key_or_model_is_a_plain_error(self):
        from app import ai
        self.put(active="mistral", profile={"id": "mistral", "base_url": self.base + "/v1", "model": "x", "clear_key": True})
        with self.assertRaises(ai.AIError) as cm:
            ai.call_claude("hi")
        self.assertIn("API key", str(cm.exception))
        self.put(active="ollama", profile={"id": "ollama", "model": "", "base_url": self.base + "/v1"})
        with self.assertRaises(ai.AIError) as cm:
            ai.call_claude("hi")
        self.assertIn("model", str(cm.exception).lower())

    def test_anthropic_api_and_models_and_test_route(self):
        self.put(active="anthropic", profile={"id": "anthropic", "base_url": self.base, "model": "claude-x", "api_key": "k"})
        from app import ai
        self.assertEqual(ai.call_claude("P", system="S"), "anthropic says hi")
        _m, path, body, h = FakeAI.seen[-1]
        self.assertEqual(path, "/v1/messages")
        self.assertEqual(body["system"][:1], "S")
        self.assertEqual(self.hdr("x-api-key"), "k")
        self.assertEqual(self.c.post("/api/ai/test", json={}).get_json()["ok"], True)
        self.put(active="ollama", profile={"id": "ollama", "model": "q", "base_url": self.base + "/v1"})
        self.assertEqual(self.c.get("/api/ai/models?provider=ollama").get_json()["models"], ["model-a", "model-b"])

    def test_unreachable_server_message(self):
        self.put(active="ollama", profile={"id": "ollama", "model": "q", "base_url": "http://127.0.0.1:9/v1"})
        r = self.c.post("/api/ai/test", json={}).get_json()
        self.assertFalse(r["ok"])
        self.assertIn("reach", r["error"])

    def test_bad_settings_are_400(self):
        self.assertEqual(self.put(active="nope").status_code, 400)
        self.assertEqual(self.put(profile={"id": "custom", "base_url": "ftp://x"}).status_code, 400)

    def test_button_route_uses_configured_model(self):
        self.put(active="ollama", profile={"id": "ollama", "model": "q", "base_url": self.base + "/v1"})
        (self.notes / "v.md").write_text("## Timestamps\n0:00 a\n\n## Links\nx\n\n## Content\ny\n", encoding="utf-8")
        t = self.make_task("Vid")
        self.c.patch(f"/api/tasks/{t['id']}", json={"notes_file": str(self.notes / "v.md")})
        s = self.c.post(f"/api/tasks/{t['id']}/subtasks", json={"title": "Order topics"}).get_json()
        r = self.c.post(f"/api/subtasks/{s['id']}/ai/order-topics", json={})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        _m, path, body, _h = FakeAI.seen[-1]
        self.assertEqual(path, "/v1/chat/completions")
        self.assertIn("The Linux Experiment", body["messages"][0]["content"])


if __name__ == "__main__":
    unittest.main()
