"""Notes: what keeps an edited note recoverable (version copies), concurrent saves, and AI-button rewrites that must not damage bytes."""
import os
import threading
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path

from tests.base import AppCase


class NotesSafetyTest(AppCase):
    def versions(self, rel="N.md"):
        from app.database import data_dir
        d = data_dir() / "notes_backups" / (Path(rel).stem + ".versions")
        return sorted(d.glob("*.md")) if d.exists() else []

    def put(self, content, path="N.md", **extra):
        return self.c.put("/api/notes/file", json={"path": path, "content": content, **extra})

    def setUp(self):
        for f in list(self.notes.glob("*.md")):
            f.unlink()
        from app.database import data_dir
        import shutil
        shutil.rmtree(data_dir() / "notes_backups", ignore_errors=True)

    def test_version_copies_are_spaced_but_a_big_shrink_is_always_kept(self):
        self.assertEqual(self.put("first " * 100).status_code, 200)            # creates the file: nothing to copy yet
        self.assertEqual(len(self.versions()), 0)
        self.put("second " * 100)
        self.assertEqual(len(self.versions()), 1)                               # the first text is kept
        self.put("third " * 100)
        self.put("fourth " * 100)
        self.assertEqual(len(self.versions()), 1)                               # autosave bursts don't use up the history
        self.put("x")                                                           # but a save that wipes the note keeps what was there
        v = self.versions()
        self.assertEqual(len(v), 2)
        self.assertEqual(v[-1].read_text(), "fourth " * 100)

    def test_identical_text_is_not_copied_twice(self):
        self.put("a" * 500)
        self.put("b" * 500)
        for v in self.versions():
            os.utime(v, (time.time() - 3600, time.time() - 3600))               # pretend the copy is old
        self.put("b" * 500)                                                     # unchanged content, saved again
        self.put("c" * 500)
        self.assertEqual([v.read_text() for v in self.versions()], ["a" * 500, "b" * 500])

    def test_old_versions_are_thinned_not_just_dropped(self):
        from app import notes_api
        self.put("seed")
        self.put("seed 2")
        d = self.versions()[0].parent
        for v in d.glob("*.md"):
            v.unlink()
        now = datetime.now()
        names = []
        for hours_ago in list(range(1, 40)):                                    # one per hour for 39 h = 39 files
            names.append((now - timedelta(hours=hours_ago, minutes=5)).strftime("%Y%m%d-%H%M%S"))
        for days_ago in (10, 10, 20, 200):
            names.append((now - timedelta(days=days_ago, minutes=len(names))).strftime("%Y%m%d-%H%M%S"))
        for n in set(names):
            (d / f"{n}.md").write_text(n)
        notes_api._prune_versions(d)
        left = sorted(d.glob("*.md"))
        self.assertTrue(len(left) >= notes_api.KEEP_VERSIONS)
        self.assertFalse(any(v.stem.startswith((now - timedelta(days=200)).strftime("%Y%m%d")) for v in left))   # beyond 90 days: gone
        self.assertEqual(len([v for v in left if v.stem.startswith((now - timedelta(days=10)).strftime("%Y%m%d")[:8])]) <= 1, True)

    def test_concurrent_saves_never_mix(self):
        self.put("start")
        big = [("A" * 200000) + "\n", ("B" * 200000) + "\n"]
        errors = []

        def worker(text):
            try:
                for _ in range(8):
                    r = self.app.test_client().put("/api/notes/file", json={"path": "N.md", "content": text, "force": True})
                    if r.status_code != 200:
                        errors.append(r.status_code)
            except Exception as e:  # noqa: BLE001
                errors.append(repr(e))
        ts = [threading.Thread(target=worker, args=(t,)) for t in big]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errors, [])
        final = (self.notes / "N.md").read_text()
        self.assertIn(final, big)                                               # one whole text or the other, never a blend
        self.assertEqual([f.name for f in self.notes.iterdir() if f.name.startswith(".")], [])    # no leftover temp files

    def test_ai_buttons_do_not_destroy_odd_bytes(self):
        from app.notesfile import read_note_text, save_note_text
        raw = "## Titles\n\ncafé crème\n\n## Timestamps\n\n".encode("latin-1")       # a note saved by an old editor
        p = self.notes / "Latin.md"
        p.write_bytes(raw)
        text = read_note_text(p)
        self.assertIn("café crème", text)                                       # decoded, not U+FFFD
        self.assertNotIn("�", text)
        bk = self.notes.parent / "bk"
        save_note_text(p, text, text + "added\n", bk)
        self.assertEqual(next(bk.iterdir()).read_bytes(), raw)                  # the backup is the file's exact original bytes
        save_note_text(p, text, text + "again\n", bk)
        save_note_text(p, text, text + "and again\n", bk)
        self.assertEqual(len(list(bk.iterdir())), 3)                            # same-second saves don't overwrite each other's backup

    def test_bom_is_stripped_only_in_reading(self):
        from app.notesfile import read_note_text
        p = self.notes / "Bom.md"
        p.write_bytes(b"\xef\xbb\xbf# Title\r\nline\r\n")
        self.assertEqual(read_note_text(p), "# Title\nline\n")


if __name__ == "__main__":
    unittest.main()
