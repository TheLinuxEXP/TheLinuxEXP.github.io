"""Deleted attachments and contracts go to a trash folder (and are purged after a while) instead of being erased."""
import io
import os
import unittest
from datetime import datetime, timedelta

from tests.base import AppCase


class TrashTest(AppCase):
    def trashed(self):
        from app import trash
        root = trash.trash_root()
        return [p for p in root.rglob("*") if p.is_file()] if root.exists() else []

    def upload(self, tid, name, data):
        return self.c.post(f"/api/tasks/{tid}/attachment", data={"file": (io.BytesIO(data), name)}, content_type="multipart/form-data")

    def test_replaced_and_removed_attachments_are_kept(self):
        t = self.make_task("with file")
        before = sorted(p.read_bytes() for p in self.trashed())
        self.assertEqual(self.upload(t["id"], "one.pdf", b"first").status_code, 201)
        self.assertEqual(self.upload(t["id"], "two.pdf", b"second").status_code, 201)         # replaces the first
        now = sorted(p.read_bytes() for p in self.trashed())
        self.assertEqual(now, sorted(before + [b"first"]))
        self.assertEqual(self.c.delete(f"/api/tasks/{t['id']}/attachment").status_code, 200)
        now = sorted(p.read_bytes() for p in self.trashed())
        self.assertEqual(now, sorted(before + [b"first", b"second"]))

    def test_deleting_a_task_keeps_its_attachment(self):
        t = self.make_task("to delete")
        self.upload(t["id"], "doc.pdf", b"precious")
        before = len(self.trashed())
        self.assertEqual(self.c.delete(f"/api/tasks/{t['id']}").status_code, 200)
        new = self.trashed()
        self.assertEqual(len(new), before + 1)
        self.assertIn(b"precious", [p.read_bytes() for p in new])

    def test_purge_only_removes_old_days(self):
        from app import trash
        root = trash.trash_root()
        old = root / (datetime.now() - timedelta(days=trash.KEEP_DAYS + 5)).strftime("%Y%m%d")
        recent = root / (datetime.now() - timedelta(days=3)).strftime("%Y%m%d")
        for d in (old, recent):
            d.mkdir(parents=True, exist_ok=True)
            (d / "x.txt").write_text("x")
        trash.purge()
        self.assertFalse(old.exists())
        self.assertTrue(recent.exists())


if __name__ == "__main__":
    unittest.main()
