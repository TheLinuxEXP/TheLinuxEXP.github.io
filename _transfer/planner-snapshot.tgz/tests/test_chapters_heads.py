import unittest
from app import chapters


class HeadingTests(unittest.TestCase):
    def test_links_heading_variants(self):
        for h in ("## Links", "Links", "Links:", "## **Links**", "**Links**", "## 🔗 Links (sources)", "​## Links"):
            self.assertTrue(chapters._LINKS_HEAD.match(h), h)
        for h in ("Links to read", "https://x.org/links", "## Linksys"):
            self.assertFalse(chapters._LINKS_HEAD.match(h), h)

    def test_apply_chapters_with_bold_links_heading(self):
        note = "## Timestamps\n\nIntro\nA\nB\n\n## **Links**\nA\nhttps://x.org/a\n\nB\nhttps://x.org/b\n\n## Content\ntext\n"
        new, rep = chapters.apply_chapters(note, ["0:05", "1:10"])
        self.assertEqual(len(rep["links"]), 2)
        self.assertIn("1:10 B", new)


if __name__ == "__main__":
    unittest.main()
