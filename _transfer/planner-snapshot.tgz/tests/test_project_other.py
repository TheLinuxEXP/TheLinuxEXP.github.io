"""The "Other tasks" of each project: a permanent task per project, with a time bucket per day that counts for that project."""
from datetime import date, timedelta

from tests.base import AppCase


class ProjectOtherTasksTest(AppCase):
    def setUp(self):
        self.today = date.today().isoformat()
        self.pid = self.c.get("/api/projects").get_json()[0]["id"]

    def bucket(self, pid=None):
        rows = self.c.get("/api/project-other-tasks").get_json()
        return next(r for r in rows if r["project_id"] == (pid or self.pid))

    def test_every_project_has_one(self):
        other = self.c.post("/api/projects", json={"name": "Second", "color": "#e91e63"}).get_json()
        rows = self.c.get("/api/project-other-tasks").get_json()
        ids = [r["project_id"] for r in rows]
        self.assertEqual(sorted(ids), sorted(p["id"] for p in self.c.get("/api/projects").get_json()))
        self.assertIn(other["id"], ids)
        r = self.bucket(other["id"])
        self.assertEqual((r["project_name"], r["color"], r["time_spent_seconds"], r["timer_state"]), ("Second", "#e91e63", 0, "idle"))

    def test_type_time_and_timer(self):
        r = self.c.patch(f"/api/project-other-tasks/{self.pid}/{self.today}", json={"time_spent_seconds": 1800})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.bucket()["time_spent_seconds"], 1800)
        for bad in ({"time_spent_seconds": -5}, {"time_spent_seconds": 10**7}, {"time_spent_seconds": "x"}, {}):
            self.assertEqual(self.c.patch(f"/api/project-other-tasks/{self.pid}/{self.today}", json=bad).status_code, 400)
        self.assertEqual(self.c.patch(f"/api/project-other-tasks/{self.pid}/nope", json={"time_spent_seconds": 1}).status_code, 400)
        self.assertEqual(self.c.patch(f"/api/project-other-tasks/{'0' * 16}/{self.today}", json={"time_spent_seconds": 1}).status_code, 404)
        self.assertEqual(self.c.post(f"/api/project-other-tasks/{'0' * 16}/timer", json={"action": "start"}).status_code, 404)
        self.assertEqual(self.c.post(f"/api/project-other-tasks/{self.pid}/timer", json={"action": "boom"}).status_code, 400)
        self.assertEqual(self.c.post(f"/api/project-other-tasks/{self.pid}/timer", json={"action": "start"}).get_json()["timer_state"], "running")
        self.assertIn(self.pid, [t.get("project_id") for t in self.c.get("/api/timers/active").get_json()])
        self.assertEqual(self.c.post(f"/api/project-other-tasks/{self.pid}/{self.today}/timer", json={"action": "pause"}).get_json()["timer_state"], "paused")
        self.assertEqual(self.c.post(f"/api/project-other-tasks/{self.pid}/timer", json={"action": "resume"}).get_json()["timer_state"], "running")
        self.assertEqual(self.c.post(f"/api/project-other-tasks/{self.pid}/timer", json={"action": "stop"}).get_json()["timer_state"], "idle")
        self.assertGreaterEqual(self.bucket()["time_spent_seconds"], 1800)

    def test_counts_for_the_project_in_the_time_report(self):
        other = self.c.post("/api/projects", json={"name": "Reported", "color": "#2ecc71"}).get_json()
        day = (date.today() - timedelta(days=1)).isoformat()
        self.c.patch(f"/api/project-other-tasks/{other['id']}/{day}", json={"time_spent_seconds": 3600})
        rows = [e for e in self.c.get(f"/api/reports/time?start={day}&end={day}").get_json() if e["company"] == "Reported"]
        self.assertEqual([(e["activity"], e["seconds"], e["date"]) for e in rows], [("Other tasks", 3600, day)])
        # the calendar's daily total and its detail include it too
        self.assertEqual(self.c.get(f"/api/calendar/time-by-day?start={day}&end={day}").get_json().get(day), 3600)
        detail = self.c.get(f"/api/calendar/time-day?day={day}").get_json()
        self.assertTrue(any(i["kind"] == "other" and i["parent_title"] == "Reported" for i in detail["items"]))
        # and the range endpoint (week view) lists it
        rng = self.c.get(f"/api/project-other-tasks?start={day}&end={day}").get_json()
        self.assertEqual([(x["project_name"], x["time_spent_seconds"]) for x in rng[day]], [("Reported", 3600)])

    def test_deleting_the_project_removes_it(self):
        other = self.c.post("/api/projects", json={"name": "Temp", "color": "#795548"}).get_json()
        self.c.patch(f"/api/project-other-tasks/{other['id']}/{self.today}", json={"time_spent_seconds": 60})
        self.assertEqual(self.c.delete(f"/api/projects/{other['id']}").status_code, 200)
        self.assertNotIn(other["id"], [r["project_id"] for r in self.c.get("/api/project-other-tasks").get_json()])
        self.assertEqual(self.c.get(f"/api/project-other-tasks?start={self.today}&end={self.today}").get_json().get(self.today, []), [x for x in self.c.get(f"/api/project-other-tasks?start={self.today}&end={self.today}").get_json().get(self.today, []) if x["project_id"] != other["id"]])
