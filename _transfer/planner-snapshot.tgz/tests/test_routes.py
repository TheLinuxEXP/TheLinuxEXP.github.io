"""Guard against a refactor silently dropping or renaming an API route: the list of /api routes is pinned in
tests/routes.txt (regenerate with `python3 -m tests.test_routes --update` after adding a route on purpose)."""
import sys
import unittest
from pathlib import Path

from tests.base import AppCase

SNAPSHOT = Path(__file__).with_name("routes.txt")


def current_routes(app):
    rows = []
    for r in app.url_map.iter_rules():
        if r.rule.startswith("/fiscal") or r.endpoint == "static":
            continue
        rows.append(f"{','.join(sorted(r.methods - {'HEAD', 'OPTIONS'}))} {r.rule}")
    return sorted(rows)


class RoutesTest(AppCase):
    def test_routes_unchanged(self):
        got = current_routes(self.app)
        want = SNAPSHOT.read_text(encoding="utf-8").splitlines()
        self.assertEqual(sorted(set(want) - set(got)), [], "routes removed")
        self.assertEqual(sorted(set(got) - set(want)), [], "routes added (update tests/routes.txt)")


if __name__ == "__main__":
    if "--update" in sys.argv:
        class _C(AppCase):
            def runTest(self): pass
        _C.setUpClass()
        SNAPSHOT.write_text("\n".join(current_routes(_C.app)) + "\n", encoding="utf-8")
        _C.tearDownClass()
        print("updated", SNAPSHOT)
    else:
        unittest.main()
