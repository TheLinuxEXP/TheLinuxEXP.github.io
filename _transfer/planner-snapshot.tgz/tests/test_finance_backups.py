"""Finance data.json copies: the recent ones stay, older ones thin out to one per day instead of vanishing."""
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

from tests.base import ROOT  # noqa: F401


class FinanceBackupTest(unittest.TestCase):
    def test_thinning(self):
        from gestion_ei_web import adapter
        core = adapter.core
        old_file, old_dir = core.DATA_FILE, core.DATA_DIR
        old_keep, old_days, old_gap = adapter.BACKUP_KEEP, adapter.BACKUP_DAILY_DAYS, adapter.BACKUP_MIN_INTERVAL
        tmp = Path(tempfile.mkdtemp(prefix="fin-"))
        core.DATA_DIR, core.DATA_FILE = tmp, tmp / "data.json"
        adapter.BACKUP_KEEP, adapter.BACKUP_DAILY_DAYS, adapter.BACKUP_MIN_INTERVAL = 2, 30, 0
        try:
            core.DATA_FILE.write_text("{}")
            bdir = tmp / "backups"
            bdir.mkdir()
            today = datetime.now()
            for days_ago, hours in ((5, (9, 12, 18)), (4, (8,)), (90, (10, 11))):
                day = (today - timedelta(days=days_ago)).strftime("%Y%m%d")
                for h in hours:
                    (bdir / f"data-{day}-{h:02d}0000.json").write_text("{}")
            adapter._backup_current()
            names = sorted(p.name for p in bdir.glob("data-*.json"))
            d5, d4, d90 = ((today - timedelta(days=n)).strftime("%Y%m%d") for n in (5, 4, 90))
            self.assertEqual([n for n in names if d5 in n], [f"data-{d5}-180000.json"])      # the last copy of that day
            self.assertEqual(len([n for n in names if d4 in n]), 1)
            self.assertEqual([n for n in names if d90 in n], [])                              # beyond a year-ish window: gone
            self.assertTrue(any(today.strftime("%Y%m%d") in n for n in names))               # the fresh copy exists
        finally:
            core.DATA_FILE, core.DATA_DIR = old_file, old_dir
            adapter.BACKUP_KEEP, adapter.BACKUP_DAILY_DAYS, adapter.BACKUP_MIN_INTERVAL = old_keep, old_days, old_gap


if __name__ == "__main__":
    unittest.main()
