import json, os, tempfile, unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("PLANNER_DATA_DIR", tempfile.mkdtemp())
from app import create_app


def _kinds(sub):
    return [b["kind"] for b in sub["ai_buttons"]]


class SetupEditTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.c = self.app.test_client()

    def _weekly(self):
        return next(t for t in self.c.get("/api/templates").get_json() if t["key"] == "weekly_news")

    def test_weekly_news_buttons(self):
        subs = {s["title"]: s for s in self._weekly()["subtasks"]}
        self.assertEqual(_kinds(subs.get("Edit A Roll") or {"ai_buttons": []}), [])
        self.assertEqual(_kinds(subs.get("Edit podcast and main video") or subs["Edit A Roll and Podcast"]), ["chapters", "setup_edit"])
        pub = next(s for t, s in subs.items() if t.startswith("Publish video on YT"))
        self.assertEqual(_kinds(pub), ["prompt", "timestamps"])

    def test_existing_database_is_migrated_once(self):
        from app.dbparts.core import _AI_CAPTURES, _AI_BASE_EDIT, _AI_CHAPTERS, _AI_TAGS, _AI_TIMESTAMPS
        db = self.app.db
        def setb(title, lst):
            db.conn.execute("UPDATE video_template_subtasks SET ai_buttons=? WHERE template_key='weekly_news' AND title LIKE ?",
                            (json.dumps(lst), title))
        setb("Edit A Roll", [_AI_CHAPTERS]); setb("Edit podcast%", [_AI_CAPTURES, _AI_BASE_EDIT])
        setb("Publish video on YT%", [_AI_TAGS, _AI_TIMESTAMPS])
        db.conn.execute("DELETE FROM app_flags WHERE name='weekly_news_setup_edit_v2'"); db.conn.commit()
        self.assertEqual(db.seed_weekly_news_setup_edit(), 1)
        subs = {s["title"]: s for s in self._weekly()["subtasks"]}
        self.assertEqual(_kinds(subs.get("Edit A Roll") or {"ai_buttons": []}), [])
        self.assertEqual(_kinds(subs.get("Edit podcast and main video") or subs["Edit A Roll and Podcast"]), ["chapters", "setup_edit"])
        self.assertEqual(_kinds(next(s for t, s in subs.items() if t.startswith("Publish video on YT"))), ["prompt", "timestamps"])
        self.assertEqual(db.seed_weekly_news_setup_edit(), 0)          # once only

    def test_migration_finds_the_merged_edit_subtask(self):
        from app.dbparts.core import _AI_CAPTURES, _AI_BASE_EDIT, _AI_CHAPTERS
        db = self.app.db
        db.conn.execute("UPDATE video_template_subtasks SET title='Edit A Roll and Podcast', ai_buttons=? "
                        "WHERE template_key='weekly_news' AND title='Edit podcast and main video'",
                        (json.dumps([_AI_CAPTURES, _AI_BASE_EDIT]),))
        db.conn.execute("DELETE FROM video_template_subtasks WHERE template_key='weekly_news' AND title='Edit A Roll'")
        db.conn.execute("DELETE FROM app_flags WHERE name='weekly_news_setup_edit_v2'"); db.conn.commit()
        db.seed_weekly_news_setup_edit()
        subs = {s["title"]: s for s in self._weekly()["subtasks"]}
        self.assertEqual(_kinds(subs["Edit A Roll and Podcast"]), ["chapters", "setup_edit"])

    def test_template_accepts_the_new_kind(self):
        tpl = self._weekly()
        r = self.c.put("/api/templates/weekly_news", json=tpl)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))

    def test_chain_order_and_stop_at_first_failure(self):
        from app.api import ai_routes
        from app import montage
        from app.ai import AIError
        calls = []
        task = {"id": "t1", "video_note_file": "/x/n-VIDEO.md"}
        with mock.patch.object(ai_routes, "_ensure_video_note", lambda t: (calls.append("note") or (t, "note ok"))), \
             mock.patch.object(ai_routes, "_valid_notes_path", lambda p: True), \
             mock.patch.object(montage, "take_captures", lambda p: (calls.append("cap") or "cap ok")), \
             mock.patch.object(montage, "base_edit", lambda p: calls.append("edit")), \
             self.app.test_request_context():
            r = ai_routes._setup_for_editing(task)
            self.assertEqual(calls, ["note", "cap", "edit"])
            self.assertIn("cap ok", r.get_json()["result"])
            calls.clear()
            with mock.patch.object(montage, "take_captures", lambda p: (_ for _ in ()).throw(AIError("boom"))):
                with self.assertRaises(AIError) as cm:
                    ai_routes._setup_for_editing(task)
            self.assertIn("Take captures", str(cm.exception))
            self.assertIn("note ok", str(cm.exception))
            self.assertNotIn("edit", calls)


if __name__ == "__main__":
    unittest.main()
