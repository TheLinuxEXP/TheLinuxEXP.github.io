"""Capture agent: pure helpers, and (when Chromium + news_capture.py are available) the whole observe -> decide -> apply loop
on local pages, with a scripted stand-in for the model."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from app import ai, capture_agent as ca
from app.chapters import script_path

SCRIPT = Path(os.environ.get("NEWS_CAPTURE_SCRIPT") or (script_path().parent / "news_capture.py"))

NOTE = """## Timestamps

0 Intro
60 Epic news

## Links

01:00 Epic news
{url}

## Content

October 14

Epic has a native Linux client. Kernel developer gaming release open support, community desktop update project patch.

{url}
"""


class HelperTests(unittest.TestCase):
    def test_note_text_for_url(self):
        note = NOTE.format(url="https://x.org/a")
        self.assertIn("Epic has a native Linux client", ca.note_text_for(note, ["https://x.org/a"]))
        self.assertEqual(ca.note_text_for(note, ["https://other.org"]), "")

    def test_assess_flags_furniture_and_low_coverage(self):
        c = {"text": 5000, "body_text": "Related articles\nSubscribe\n" + "word " * 50, "strategy": "score", "colW": 700, "embeds": {"page": 2, "kept": 1}}
        flags = ca.assess(c, "")
        self.assertTrue(any("furniture" in f for f in flags))
        self.assertTrue(any("embed" in f for f in flags))
        ok = {"text": 5000, "body_text": "Linux kernel community desktop release " * 30, "strategy": "score", "colW": 700, "embeds": {"page": 0, "kept": 0}}
        self.assertEqual(ca.assess(ok, ""), [])

    def test_outline_ids_map_to_paths(self):
        o = {"title": "t", "h1": "", "units": [
            {"i": 0, "path": "body > article > p:nth-of-type(1)", "tag": "p", "kind": "block", "cls": "", "chars": 300, "links": 0, "text": "aaa", "match": 0.5},
            {"i": 1, "path": "body > article > p:nth-of-type(2)", "tag": "p", "kind": "block", "cls": "", "chars": 300, "links": 0, "text": "bbb", "match": 0.5},
            {"i": 2, "path": "d2", "tag": "div", "kind": "container", "cls": "promo", "chars": 80, "links": 0.9, "text": "buy now"}],
             "cands": [{"path": "art", "tag": "article", "cls": "", "chars": 900, "why": "current"}], "hidden": []}
        txt, paths = ca._outline_text(o)
        self.assertIn("u0-u1", txt)
        self.assertEqual(ca._expand(["u0-u1", "u2", "zzz"], paths, o["units"]), ["body > article > p:nth-of-type(1)", "body > article > p:nth-of-type(2)", "d2"])


def _page(extra_block: str) -> str:
    words = "linux kernel open source desktop release feature support driver wayland gaming distro security update patch community project developer".split()
    para = lambda k: "<p>" + " ".join(words[(i * 7 + k) % len(words)] for i in range(60)) + ".</p>"
    return (f"<!doctype html><html><head><meta charset=utf-8><title>Fixture</title><style>body{{font:18px Georgia;margin:0}}"
            f"article{{max-width:700px;margin:0 auto}}.bx{{background:#fe9;padding:8px}}</style></head><body><article>"
            + "".join(para(k) for k in range(6)) + extra_block + "".join(para(k) for k in range(6, 12)) + "</article></body></html>")


@unittest.skipUnless(SCRIPT.is_file(), "news_capture.py not found")
class LoopTests(unittest.TestCase):
    def test_agent_hides_a_block_the_script_cannot_recognise(self):
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                pw.chromium.launch().close()
        except Exception as e:  # noqa: BLE001
            self.skipTest(f"no Chromium: {e}")
        tmp = Path(tempfile.mkdtemp())
        html = tmp / "page.html"
        html.write_text(_page('<div class="bx"><p>Check out our partner offer! Get 20 percent off hosting today, click here to subscribe to the plan.</p></div>'), encoding="utf-8")
        url = html.as_uri()
        note = tmp / "n-VIDEO.md"
        note.write_text(NOTE.format(url=url), encoding="utf-8")
        out = tmp / "caps"
        r = subprocess.run([sys.executable, str(SCRIPT), str(note), str(out)], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr + r.stdout)
        plan = json.loads((out / "plan.json").read_text())
        topic = next(t for t in plan["topics"] if t["links"])
        self.assertIn("partner offer", topic["capture_info"][0]["body_text"])        # the script alone leaves the promo in

        prompts = []

        def fake_ai(prompt, system=None, max_tokens=0, read_dirs=None):
            prompts.append(prompt)
            if "partner offer" in prompt:
                line = next(ln for ln in prompt.splitlines() if "partner offer" in ln)
                uid = line.split()[0]
                return json.dumps({"verdict": "fix", "hide": [uid], "reason": "promo box"})
            return json.dumps({"verdict": "accept", "reason": "clean"})

        def run_step(sf):
            rr = subprocess.run([sys.executable, str(SCRIPT), str(note), str(out), "--agent-step", str(sf)], capture_output=True, text=True)
            self.assertEqual(rr.returncode, 0, rr.stderr + rr.stdout)

        with mock.patch.object(ai, "call_claude", fake_ai), mock.patch.object(ai, "vision_available", lambda: False), \
             mock.patch.dict(os.environ, {"PLANNER_CAPTURE_AGENT": "all"}):
            lines = ca.run(str(note), out, plan, run_step)
        self.assertTrue(any("fixed" in ln for ln in lines), lines)
        self.assertEqual(len(prompts), 2)                                       # observe -> fix -> verify
        step1 = json.loads((out / "_agent" / "step1.out.json").read_text())["results"][0]
        self.assertNotIn("partner offer", step1["info"]["body_text"])
        self.assertTrue(all(Path(f).is_file() for f in step1["files"]))


if __name__ == "__main__":
    unittest.main()
