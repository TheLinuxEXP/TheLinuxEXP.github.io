"""Behaviour tests of the REST API on a throw-away database (no network, no Claude)."""
import io
import unittest
from datetime import date, timedelta

from tests.base import AppCase


class CrudTest(AppCase):
    def test_project_list_task_subtask_flow(self):
        p = self.post("/api/projects", name="Alpha", color="#ff0000").get_json()
        lst = self.post("/api/todolists", project_id=p["id"], name="L1").get_json()
        t = self.post("/api/tasks", todo_list_id=lst["id"], title="Write", due_date="2026-10-20", urgent=True).get_json()
        self.assertEqual(t["title"], "Write")
        self.assertTrue(t["urgent"])
        s = self.post(f"/api/tasks/{t['id']}/subtasks", title="Step").get_json()
        self.assertEqual(s["title"], "Step")
        r = self.c.patch(f"/api/tasks/{t['id']}", json={"title": "Write more", "due_date": "2026-10-21"})
        self.assertEqual(r.get_json()["title"], "Write more")
        self.post(f"/api/subtasks/{s['id']}/toggle", checked=True)
        got = self.c.get(f"/api/tasks/{t['id']}").get_json()
        self.assertTrue(got["subtasks"][0]["checked"])
        self.assertEqual(self.c.delete(f"/api/tasks/{t['id']}").status_code, 200)
        self.assertEqual(self.c.get(f"/api/tasks/{t['id']}").status_code, 404)

    def test_validation(self):
        t = self.make_task()
        for body in ({"title": "  "}, {"due_date": "2026-13-45"}, {"start_time": "25:99"}, {"duration_minutes": -5}):
            self.assertEqual(self.c.patch(f"/api/tasks/{t['id']}", json=body).status_code, 400, body)
        self.assertEqual(self.c.post("/api/tasks", data="[1,2]", content_type="application/json").status_code, 400)

    def test_unknown_fields_are_ignored(self):
        t = self.make_task()
        r = self.c.patch(f"/api/tasks/{t['id']}", json={"id": "x", "checked; DROP TABLE tasks": 1, "title": "ok"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.c.get(f"/api/tasks/{t['id']}").get_json()["title"], "ok")

    def test_timer_cycle(self):
        t = self.make_task()
        for action in ("start", "pause", "resume", "stop"):
            self.assertEqual(self.post(f"/api/tasks/{t['id']}/timer", action=action).status_code, 200, action)
        self.assertEqual(self.post(f"/api/tasks/{t['id']}/timer", action="explode").status_code, 400)
        self.assertEqual(self.c.get("/api/timers/active").status_code, 200)

    def test_smart_views(self):
        today = date.today().isoformat()
        self.make_task("Today one", due_date=today)
        counts = self.c.get(f"/api/smartcounts?today={today}&tomorrow={(date.today() + timedelta(days=1)).isoformat()}").get_json()
        self.assertGreaterEqual(counts["today"], 1)

    def test_backup_roundtrip(self):
        self.make_task("before backup")
        r = self.post("/api/backups", reason="test")
        self.assertEqual(r.status_code, 201)
        self.assertTrue(any(b["id"] == r.get_json()["id"] for b in self.c.get("/api/backups").get_json()))


class VideoTemplateTest(AppCase):
    def test_template_creates_video_task_with_subtasks(self):
        lst = self.c.get("/api/todolists").get_json()[0]
        keys = [t["key"] for t in self.c.get("/api/templates").get_json()]
        self.assertTrue({"weekly_news", "normal_video", "warhammer_video"} <= set(keys))
        t = self.post("/api/templates/warhammer_video", todo_list_id=lst["id"]).get_json()
        self.assertTrue(t["is_video"])
        titles = [s["title"] for s in t["subtasks"]]
        self.assertIn("Create powerpoint", titles)
        buttons = next(s for s in t["subtasks"] if s["title"] == "Create powerpoint")
        full = self.c.get(f"/api/templates").get_json()
        wh = next(x for x in full if x["key"] == "warhammer_video")
        kinds = {b["kind"] for s in wh["subtasks"] for b in s.get("ai_buttons") or []}
        self.assertEqual(kinds, {"powerpoint", "list_to_ppt"})

    def test_current_video_project_and_project_filter(self):
        pa = self.post("/api/projects", name="Linux", color="#111111").get_json()
        pb = self.post("/api/projects", name="Warhammer", color="#222222").get_json()
        for p, title, due in ((pa, "V-linux", "2026-10-20"), (pb, "V-wh", "2026-10-13")):
            lst = self.post("/api/todolists", project_id=p["id"], name="Videos").get_json()
            self.post("/api/tasks", todo_list_id=lst["id"], title=title, due_date=due, is_video=True)
        cur = self.c.get("/api/video-project/current?today=2026-10-12").get_json()
        self.assertEqual(cur["task"]["title"], "V-wh")
        cur = self.c.get(f"/api/video-project/current?today=2026-10-12&project_id={pa['id']}").get_json()
        self.assertEqual(cur["task"]["title"], "V-linux")
        up = self.c.get("/api/video-tasks/upcoming?today=2026-10-12&days=14").get_json()
        self.assertEqual({u["title"] for u in up}, {"V-linux", "V-wh"})


class NotesTest(AppCase):
    def test_notes_crud_and_traversal(self):
        r = self.post("/api/notes/new", folder="", name="Hello", content="# Hi")
        self.assertEqual(r.status_code, 201)
        path = r.get_json()["path"]
        self.assertEqual(self.c.get(f"/api/notes/file?path={path}").get_json()["content"], "# Hi")
        w = self.c.put("/api/notes/file", json={"path": path, "content": "# Changed"})
        self.assertEqual(w.status_code, 200)
        stale = self.c.put("/api/notes/file", json={"path": path, "content": "x", "mtime": 1})
        self.assertEqual(stale.status_code, 409)
        for bad in ("../outside.md", "/etc/passwd.md", ".hidden/x.md", "a/../../b.md"):
            self.assertIn(self.c.get(f"/api/notes/file?path={bad}").status_code, (400, 404), bad)   # never 200
        self.assertEqual(self.c.delete(f"/api/notes/file?path={path}").status_code, 200)
        self.assertTrue((self.notes / ".trash").is_dir())

    def test_non_object_bodies_are_400(self):
        for u in ("pin", "touch", "new", "rename", "move", "folder"):
            self.assertEqual(self.c.post(f"/api/notes/{u}", json=[1]).status_code, 400, u)
        self.assertEqual(self.c.put("/api/notes/file", json={"path": "a.md", "content": "y", "mtime": "abc"}).status_code, 400)

    def test_task_notes_file_must_be_inside_notes_folder(self):
        (self.notes / "ok.md").write_text("## Content\nx", encoding="utf-8")
        outside = self.notes.parent / "secret.md"
        outside.write_text("secret", encoding="utf-8")
        (self.notes / "link.md").symlink_to(outside)
        t = self.make_task()
        patch = lambda p: self.c.patch(f"/api/tasks/{t['id']}", json={"notes_file": str(p)}).status_code
        self.assertEqual(patch(self.notes / "ok.md"), 200)
        for bad in (outside, "/etc/hosts.txt", str(self.notes) + "/../secret.md", self.notes / "link.md", self.notes / "x.pdf"):
            self.assertEqual(patch(bad), 400, bad)


class OtherTasksTest(AppCase):
    def test_type_time_and_timer(self):
        from datetime import date
        today = date.today().isoformat()
        r = self.c.patch(f"/api/other-tasks/{today}", json={"time_spent_seconds": 1800})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["time_spent_seconds"], 1800)
        for bad in ({"time_spent_seconds": -5}, {"time_spent_seconds": 10**7}, {"time_spent_seconds": "x"}, {}):
            self.assertEqual(self.c.patch(f"/api/other-tasks/{today}", json=bad).status_code, 400, bad)
        self.assertEqual(self.c.patch("/api/other-tasks/nope", json={"time_spent_seconds": 1}).status_code, 400)
        started = self.c.post(f"/api/other-tasks/{today}/timer", json={"action": "start"}).get_json()
        self.assertEqual(started["timer_state"], "running")
        self.assertEqual(self.c.patch(f"/api/other-tasks/{today}", json={"time_spent_seconds": 600}).get_json()["timer_state"], "running")
        self.assertEqual(self.c.post("/api/other-tasks/timer", json={"action": "stop"}).get_json()["timer_state"], "idle")
        self.assertGreaterEqual(self.c.get("/api/other-tasks").get_json()["time_spent_seconds"], 600)


class AttachmentTest(AppCase):
    max_upload_mb = 1

    def test_attachment_replace_and_limit(self):
        t = self.make_task()
        up = lambda name, size: self.c.post(f"/api/tasks/{t['id']}/attachment",
                                            data={"file": (io.BytesIO(b"x" * size), name)}, content_type="multipart/form-data")
        self.assertEqual(up("one.txt", 100).status_code, 201)
        self.assertEqual(up("two.txt", 100).get_json()["attachment_name"], "two.txt")
        self.assertEqual(self.c.get(f"/api/tasks/{t['id']}/attachment").data, b"x" * 100)
        r = up("big.bin", 2 * 1024 * 1024)
        self.assertEqual(r.status_code, 413)
        self.assertEqual(self.c.get(f"/api/tasks/{t['id']}").get_json()["attachment_name"], "two.txt")   # untouched
        self.assertEqual(self.c.delete(f"/api/tasks/{t['id']}/attachment").status_code, 200)


class TabBridgeTest(AppCase):
    def test_heartbeat_hands_back_the_pending_task_once(self):
        self.assertEqual(self.post("/api/tab/open-request", task_id="abc").get_json(), {"had_open_tab": False})
        self.assertTrue(self.c.get("/api/tab/status").status_code == 200)
        first = self.c.post("/api/tab/heartbeat").get_json()
        self.assertEqual(first["task_id"], "abc")
        self.assertIsNone(self.c.post("/api/tab/heartbeat").get_json()["task_id"])       # consumed
        self.assertTrue(self.c.get("/api/tab/status").get_json()["open"])
        self.post("/api/tab/open-request", task_id="def")
        self.assertEqual(self.c.get("/api/tab/pending").get_json()["task_id"], "def")    # the older route still works


class StorageTest(AppCase):
    def test_wal_and_indexes(self):
        db = self.app.db
        self.assertEqual(db.conn.execute("PRAGMA journal_mode").fetchone()[0].lower(), "wal")
        have = {r["name"] for r in db.conn.execute("SELECT name FROM sqlite_master WHERE type='index'")}
        for name, _table, _cols in db.INDEXES:
            self.assertIn(name, have)

    def test_hydrate_many_matches_single(self):
        a = self.make_task("A")
        self.post(f"/api/tasks/{a['id']}/subtasks", title="s1")
        b = self.make_task("B")
        db = self.app.db
        rows = db.conn.execute("SELECT * FROM tasks WHERE id IN (?,?) ORDER BY id", (a["id"], b["id"])).fetchall()
        self.assertEqual(db._hydrate_many(rows), [db._hydrate(r) for r in rows])


class BrowserGuardTest(AppCase):
    def test_cross_site_writes_and_odd_hosts_are_refused(self):
        self.assertEqual(self.c.post("/api/projects", json={"name": "x"}, headers={"Origin": "https://evil.example"}).status_code, 403)
        self.assertEqual(self.c.post("/api/projects", json={"name": "x"}, headers={"Sec-Fetch-Site": "cross-site"}).status_code, 403)
        self.assertEqual(self.c.get("/api/projects", headers={"Host": "evil.example.com"}).status_code, 403)
        self.assertEqual(self.c.get("/api/projects").status_code, 200)

    def test_list_ppt_routes_validate(self):
        t = self.make_task()
        lst = self.c.get("/api/todolists").get_json()[0]
        task = self.post("/api/templates/warhammer_video", todo_list_id=lst["id"]).get_json()
        sid = task["subtasks"][0]["id"]
        self.assertEqual(self.post(f"/api/subtasks/{sid}/ai/list-to-ppt", text="  ").status_code, 400)
        self.assertEqual(self.c.get(f"/api/subtasks/{sid}/ai/list-to-ppt/download").status_code, 404)
        self.assertEqual(self.post(f"/api/subtasks/{sid}/ai/list-to-ppt/open-folder").status_code, 404)
        self.assertEqual(self.c.get("/api/subtasks/..%2Fx/ai/list-to-ppt/download").status_code, 404)


if __name__ == "__main__":
    unittest.main()
