"""Rough timing of the heavy endpoints on a synthetic database (not a unit test):  python3 -m tests.bench [n_tasks]"""
import os
import random
import sys
import tempfile
import time
from datetime import date, timedelta

from tests.base import ROOT  # noqa: F401


def build(n_tasks):
    tmp = tempfile.mkdtemp(prefix="planner-bench-")
    os.environ["XDG_DATA_HOME"] = tmp
    os.environ["NOTES_DIR"] = os.path.join(tmp, "notes")
    os.makedirs(os.environ["NOTES_DIR"])
    from app import database
    database.BACKUP_TRIGGERS = set()          # no automatic backup per insert while seeding
    t0 = time.time()
    from app import create_app
    app = create_app()
    startup = time.time() - t0
    db = app.db
    random.seed(1)
    today = date.today()
    projects = [db.add_project(f"P{i}", "#3daee9") for i in range(6)]
    lists = [db.add_todo_list(p, f"L{j}") for p in projects for j in range(3)]
    tags = [db.add_tag(f"tag{i}", "#ff8800") for i in range(8)]
    for i in range(n_tasks):
        due = (today + timedelta(days=random.randint(-30, 60))).isoformat() if random.random() < 0.8 else None
        tid = db.add_task(random.choice(lists), f"Task {i}", due_date=due, urgent=random.random() < 0.1, is_video=random.random() < 0.1)
        for k in range(random.randint(0, 5)):
            db.add_subtask(tid, f"Sub {k}", due_date=due)
        if random.random() < 0.4:
            db.set_task_tags(tid, [random.choice(tags)])
    return app, app.test_client(), startup, today


def timeit(c, url, n=5):
    best = 1e9
    for _ in range(n):
        t0 = time.perf_counter()
        r = c.get(url)
        assert r.status_code == 200, (url, r.status_code)
        best = min(best, time.perf_counter() - t0)
    return best * 1000


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 800
    t0 = time.time()
    app, c, startup, today = build(n)
    print(f"{n} tasks built in {time.time() - t0:.1f}s; empty-db create_app: {startup * 1000:.0f} ms")
    iso = today.isoformat()
    lst = c.get("/api/todolists").get_json()[0]["id"]
    for label, url in [("GET /api/tasks (all)", "/api/tasks"), (f"GET /api/tasks?todo_list_id", f"/api/tasks?todo_list_id={lst}"),
                       ("smart today", f"/api/tasks/smart?due_date={iso}&include_overdue=1"),
                       ("smart urgent", "/api/tasks/smart?urgent=1"),
                       ("smartcounts", f"/api/smartcounts?today={iso}&tomorrow={(today + timedelta(days=1)).isoformat()}"),
                       ("calendar month", f"/api/calendar?year={today.year}&month={today.month}"),
                       ("video-project/current", f"/api/video-project/current?today={iso}"),
                       ("timers/active", "/api/timers/active"), ("tab/pending", "/api/tab/pending")]:
        print(f"{label:28s} {timeit(c, url):8.1f} ms")
    # restart cost with an existing database
    from app import create_app
    t0 = time.time()
    create_app()
    print(f"{'create_app on existing db':28s} {(time.time() - t0) * 1000:8.0f} ms")
