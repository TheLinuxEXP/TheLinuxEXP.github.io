"""Login: browsers must sign in, local non-browser clients are let through, throttling, password change."""
import unittest

from tests.base import AppCase

BROWSER = {"Sec-Fetch-Site": "same-origin"}        # what a real browser always adds


class AuthTest(AppCase):
    def setUp(self):
        from app import auth
        auth.reset_to_defaults()
        auth._fails.clear()
        self.b = self.app.test_client()             # a "browser": no cookie yet
        self.login_ok = lambda c=None, ident="nicolas", pw="1234": (c or self.b).post(
            "/login", data={"identifier": ident, "password": pw}, headers=BROWSER)

    def test_default_credentials_and_guard(self):
        self.assertEqual(self.b.get("/api/tasks", headers=BROWSER).status_code, 401)
        r = self.b.get("/", headers=BROWSER)
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])
        self.assertEqual(self.b.get("/login", headers=BROWSER).status_code, 200)
        self.assertEqual(self.login_ok(ident="nicolas", pw="nope").status_code, 401)
        self.assertEqual(self.login_ok(ident="x", pw="1234").status_code, 401)
        self.assertEqual(self.login_ok().status_code, 302)
        self.assertEqual(self.b.get("/api/auth/me", headers=BROWSER).get_json()["must_change"], True)
        self.assertEqual(self.login_ok(ident=" NICOLAS ").status_code, 302)         # case / spaces forgiven

    def test_default_password_must_be_changed_first(self):
        r = self.login_ok()
        self.assertIn("/change-password", r.headers["Location"])
        r = self.b.get("/", headers=BROWSER)                                         # pages -> the change page
        self.assertEqual(r.status_code, 302)
        self.assertIn("/change-password", r.headers["Location"])
        self.assertEqual(self.b.get("/change-password", headers=BROWSER).status_code, 200)
        r = self.b.get("/api/tasks", headers=BROWSER)                                # data stays closed
        self.assertEqual(r.status_code, 403)
        self.assertTrue(r.get_json()["must_change"])
        self.assertEqual(r.headers.get("X-Must-Change"), "1")
        self.assertEqual(self.b.get("/fiscal/api/anything", headers=BROWSER).status_code, 403)
        self.assertEqual(self.b.post("/api/tasks", json={"title": "x"}, headers=BROWSER).status_code, 403)
        self.assertEqual(self.b.get("/static/css/none.css", headers=BROWSER).status_code, 404)   # static not blocked
        self.assertEqual(self.c.get("/api/tasks").status_code, 200)                  # local widget unaffected
        r = self.b.post("/api/auth/change", json={"current_password": "1234", "new_password": "1234"}, headers=BROWSER)
        self.assertEqual(r.status_code, 400)                                         # still the default: refused
        r = self.b.post("/api/auth/change", json={"current_password": "1234", "new_password": "a-better-one"}, headers=BROWSER)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.b.get("/api/tasks", headers=BROWSER).status_code, 200)
        self.assertEqual(self.b.get("/", headers=BROWSER).status_code, 200)
        self.assertEqual(self.b.get("/change-password", headers=BROWSER).status_code, 302)   # nothing left to change
        self.assertEqual(self.login_ok(self.app.test_client()).status_code, 401)     # 1234 no longer works

    def test_local_non_browser_clients_pass(self):
        self.assertEqual(self.c.get("/api/tasks").status_code, 200)                  # widget / curl on this machine
        import os
        os.environ["TASKPLANNER_AUTH_TRUST_LOCAL"] = "0"
        try:
            self.assertEqual(self.c.get("/api/tasks").status_code, 401)
            self.assertEqual(self.c.get("/api/tasks", environ_base={"REMOTE_ADDR": "192.168.1.5"}).status_code, 401)
        finally:
            del os.environ["TASKPLANNER_AUTH_TRUST_LOCAL"]
        self.assertEqual(self.c.get("/api/tasks", environ_base={"REMOTE_ADDR": "192.168.1.5"}).status_code, 401)

    def test_throttle(self):
        for _ in range(5):
            self.assertEqual(self.login_ok(pw="bad").status_code, 401)
        self.assertEqual(self.login_ok().status_code, 429)                           # even the right password is refused

    def test_change_password(self):
        self.login_ok()
        ch = lambda **k: self.b.post("/api/auth/change", json=k, headers=BROWSER)
        self.assertEqual(ch(current_password="wrong", new_password="longenough1").status_code, 400)
        self.assertEqual(ch(current_password="1234", new_password="short").status_code, 400)
        self.assertEqual(ch(current_password="1234").status_code, 400)               # nothing to change
        other = self.app.test_client()
        self.login_ok(other)
        r = ch(current_password="1234", identifier="nick@example.com", new_password="longenough1")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        self.assertEqual(self.b.get("/api/tasks", headers=BROWSER).status_code, 200)   # this session survives
        self.assertEqual(other.get("/api/tasks", headers=BROWSER).status_code, 401)    # the others are cut off
        self.assertFalse(self.b.get("/api/auth/me", headers=BROWSER).get_json()["must_change"])
        fresh = self.app.test_client()
        self.assertEqual(self.login_ok(fresh, "nicolas", "1234").status_code, 401)
        self.assertEqual(self.login_ok(fresh, "nick@example.com", "longenough1").status_code, 302)
        self.assertNotIn("longenough1", open(__import__("app.auth", fromlist=["x"])._path()).read())   # hashed on disk

    def test_logout(self):
        self.login_ok()
        self.b.post("/logout", headers=BROWSER)
        self.assertEqual(self.b.get("/api/tasks", headers=BROWSER).status_code, 401)

    def test_cross_site_post_refused(self):
        r = self.b.post("/login", data={"identifier": "nicolas", "password": "1234"}, headers={"Sec-Fetch-Site": "cross-site"})
        self.assertEqual(r.status_code, 403)


if __name__ == "__main__":
    unittest.main()
