"""List to PPT: army list parsing, slide plan, and the "Décontracté du C'Tan" cards (no Wahapedia / Claude involved)."""
import tempfile
import unittest
import zipfile
from pathlib import Path

from tests.base import ROOT  # noqa: F401 -- puts the project on sys.path

FIXTURE = Path(__file__).with_name("fixtures") / "army_list.txt"


def fake_rules(parsed, units, progress=None):
    def unit(u):
        return {"found": True, "name": u["name"], "faction_line": "Deathwatch · Infanterie", "composition_short": "5 figurines",
                "stats": {"M": '6"', "T": "4", "Sv": "3+", "Inv": "5+", "W": "2", "Ld": "6+", "OC": "1"},
                "weapons": [{"type": "ranged", "name": "Bolter", "range": '24"', "A": "2", "skill": "3+", "S": "4", "AP": "0", "D": "1", "keywords": ["Rapide"]}],
                "abilities": [{"name": "Règle", "bullets": ["Relance les 1", "Touches Fatales 5+"]}],
                "core": [], "faction_abilities": [], "keywords": ["Infanterie"], "recap": ["Bon partout"],
                "enhancement": {"name": u["enhancement"], "cost": 20, "bullets": ["Effet"]} if u["enhancement"] else None}
    det = {d["name"]: {"found": True, "name": d["name"], "rule": {"name": "Règle", "bullets": ["a", "b"]}, "rule_recap": ["a"],
                       "stratagems": [{"name": f"S{i}", "cp": 1, "when": "Votre phase", "target": "Une unité", "effect": ["x", "y"],
                                       "restrictions": "", "recap": "court"} for i in range(4)]} for d in parsed["detachments"]}
    return {"det": det, "disp": {"found": True, "items": [{"name": n, "missions": [{"vs": "Autre", "mission": "Purge"}]} for n in parsed["dispositions"]]},
            "units": {id(u): unit(u) for u in units}, "errors": []}


class ArmyListTest(unittest.TestCase):
    def test_parse(self):
        from app import army_list
        p = army_list.parse_army_list(FIXTURE.read_text(encoding="utf-8"))
        self.assertTrue(p["detachments"])
        self.assertTrue(p["units"] if "units" in p else True)

    def test_deck_and_images_only(self):
        from app import army_list, army_rules
        orig = army_rules.fetch_all
        army_rules.fetch_all = fake_rules
        try:
            with tempfile.TemporaryDirectory() as d:
                text = FIXTURE.read_text(encoding="utf-8")
                res2 = army_list.generate_deck(text, Path(d) / "x.zip", d, images_only=True)
                self.assertGreater(res2["slide_count"], 5)
                names = zipfile.ZipFile(Path(d) / "x.zip").namelist()
                self.assertEqual(len(names), res2["slide_count"])
                try:                      # the PowerPoint needs the user's template (presentation.pptx / TASKPLANNER_PPTX_TEMPLATE)
                    from app import pptx_gen
                    pptx_gen.find_template_path()
                except Exception:
                    pptx_gen = None
                if pptx_gen:
                    res = army_list.generate_deck(text, Path(d) / "x.pptx", d)
                    self.assertEqual(res["slide_count"], res2["slide_count"])
                    self.assertGreater((Path(d) / "x.pptx").stat().st_size, 10_000)
                self.assertTrue(all(n.endswith(".png") for n in names))
                self.assertTrue(names[0].startswith("01 - "))
        finally:
            army_rules.fetch_all = orig


class TermsTest(unittest.TestCase):
    def test_official_terms(self):
        from app.army_rules import _fix_terms
        out = _fix_terms({"a": ["Frappe fatale 5+", "touches létales", "Touche soutenue 1", "Frappes soutenues"]})
        self.assertEqual(out["a"], ["Touches Fatales 5+", "Touches Fatales", "Touches Soutenues 1", "Touches Soutenues"])


class CardsTest(unittest.TestCase):
    def test_cards_render_without_logo(self):
        from app import army_cards as K
        unit = {"name": "Test", "stats": {"M": '6"', "T": "4", "Sv": "3+", "W": "2", "Ld": "6+", "OC": "1"}, "weapons": [],
                "abilities": [{"name": "A", "text": "Une phrase. Une autre phrase."}]}
        for img in (K.render_datasheets([{"data": unit, "info": {"points": 90}}]), K.render_rule({"rule": {"name": "R", "text": "t"}}, "D"),
                    K.render_stratagems([{"name": "S", "cp": 1, "effect": "e"}], "D"),
                    K.render_dispositions({"items": [{"name": "X", "missions": [{"vs": "Y", "mission": "Z"}]}]})):
            self.assertEqual(img.size, (K.CARD_W, K.CARD_H))

    def test_bullets_helper(self):
        from app.army_cards import _as_bullets
        self.assertEqual(_as_bullets(["a", " ", "b"]), ["a", "b"])
        self.assertEqual(_as_bullets("Un. Deux."), ["Un.", "Deux."])
        self.assertEqual(_as_bullets(None), [])


if __name__ == "__main__":
    unittest.main()
