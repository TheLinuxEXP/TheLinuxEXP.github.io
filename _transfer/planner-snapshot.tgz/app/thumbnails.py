"""« Create thumbnails » : 3 miniatures YouTube 1920x1080 dans le style de la chaîne (fonds, bordure blanche et bandeau
« Linux Weekly News » extraits du fichier GIMP SplashNEWSWEEKLY.xcf, dossier thumb_assets/).

  1. les idées viennent du bouton « Generate ideas » (appelé par la route) ;
  2. Claude (avec recherche web) en tire le texte de 2 miniatures et les logos à utiliser, avec l'adresse d'image de chacun ;
  3. les logos sont TÉLÉCHARGÉS (jamais générés) : l'adresse donnée par Claude, sinon Wikimedia Commons / Wikipédia ;
  4. Pillow compose : fond, logos (ombre douce), texte Inter Black blanc (ombre), bandeau noir, bordure blanche.
Une miniature a toujours le texte « LINUX & OPEN SOURCE NEWS » (sans bandeau) avec les logos des projets de la semaine."""
from __future__ import annotations
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import urllib.parse
import urllib.request
from pathlib import Path

from .ai import AIError

ASSETS = Path(__file__).resolve().parent / "thumb_assets"
W, H = 1920, 1080
TEXT_RIGHT = 1818                      # bord droit du texte (comme dans le fichier XCF)
PILL_POS = (757, 843)                  # position du bandeau « Linux Weekly News » dans l'image finale
GENERIC_TEXT = "LINUX\n& OPEN\nSOURCE\nNEWS"
UA = "Mozilla/5.0 (X11; Linux x86_64) PlannerThumbnails/1.0 (logo fetch)"
BACKGROUNDS = ["bg_b.jpg", "bg_c.jpg", "bg_e.jpg"]       # choisis dans le XCF pour leur contraste avec le texte blanc


# ------------------------------------------------------------------ police
def find_font() -> tuple[str | None, str]:
    """Chemin d'Inter Black (la police du texte du XCF) ; (None, message) si introuvable."""
    env = os.environ.get("PLANNER_THUMB_FONT")
    cands = [env] if env else []
    try:
        for q in ("Inter:style=Black", "Inter:weight=210", "Inter Black"):
            p = subprocess.run(["fc-match", "-f", "%{family}|%{file}", q], capture_output=True, text=True, timeout=10)
            fam, _, f = p.stdout.partition("|")
            if p.returncode == 0 and f and "inter" in fam.lower() and "interface" not in fam.lower():
                cands.append(f)
    except Exception:
        pass
    for root in ("/usr/share/fonts", "/usr/local/share/fonts", str(Path.home() / ".local/share/fonts"), str(Path.home() / ".fonts")):
        if Path(root).is_dir():
            for pat in ("Inter*Black*.ttf", "Inter*Black*.otf", "Inter*.ttf", "Inter*.otf"):
                cands += [str(x) for x in Path(root).rglob(pat)][:6]
    for c in cands:
        if c and Path(c).is_file():
            return c, ""
    fallback = next((p for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                                 "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf") if Path(p).is_file()), None)
    return fallback, ("Police Inter Black introuvable : une police de remplacement a été utilisée. Installez Inter (fonts-inter) "
                      "ou indiquez le fichier avec PLANNER_THUMB_FONT.")


_FONT_MODE = {"variations": True, "stroke": 0.0}     # réglé par make_all (voir probe_font)


def load_font(path: str, size: int):
    from PIL import ImageFont
    f = ImageFont.truetype(path, size)
    if not _FONT_MODE["variations"]:
        return f
    try:                                           # police variable (Inter[opsz,wght].ttf) : on demande le graisse « Black »
        names = [n.decode() if isinstance(n, bytes) else n for n in f.get_variation_names()]
        if "Black" in names:
            f.set_variation_by_name("Black")
        else:
            axes = f.get_variation_axes()
            f.set_variation_by_axes([900 if (a.get("name") or b"").lower() in (b"weight", "weight") else a.get("default", 0) for a in axes])
    except Exception:
        pass
    return f


_PROBE = """
import sys
from PIL import ImageFont, Image, ImageDraw
f = ImageFont.truetype(sys.argv[1], 120)
if sys.argv[2] == "1":
    try:                                   # une exception Python (police non variable) est normale ; seul un plantage compte
        names = [n.decode() if isinstance(n, bytes) else n for n in f.get_variation_names()]
        if "Black" in names:
            f.set_variation_by_name("Black")
        else:
            ax = f.get_variation_axes()
            f.set_variation_by_axes([900 if (a.get("name") or b"").lower() in (b"weight", "weight") else a.get("default", 0) for a in ax])
    except Exception:
        pass
f.getbbox("LINUX & OPEN SOURCE NEWS")
d = ImageDraw.Draw(Image.new("RGBA", (900, 300)))
d.text((10, 10), "LINUX & OPEN", font=f, fill=(255, 255, 255, 255), stroke_width=4)
"""


def probe_font(path: str) -> tuple[str | None, str]:
    """Essaie la police dans un processus jetable (un plantage natif de FreeType ne doit pas toucher le serveur).
    Renvoie (mode, message) : « var » = graisse Black via les variations, « plain » = police telle quelle (la graisse
    est simulée par un contour), None = police inutilisable."""
    import sys
    for mode, flag in (("var", "1"), ("plain", "0")):
        try:
            r = subprocess.run([sys.executable, "-c", _PROBE, path, flag], capture_output=True, text=True, timeout=60)
        except Exception:
            continue
        if r.returncode == 0:
            return mode, "" if mode == "var" else "Les variations de la police plantent sur cette machine : graisse Black simulée par un contour."
    return None, ""


# ------------------------------------------------------------------ téléchargement des logos
def _http_get(url: str, timeout: int = 25) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "image/*,application/json;q=0.9,*/*;q=0.5"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(25_000_000)
    return data


def _svg_to_png(data: bytes):
    """SVG -> PIL via cairosvg, rsvg-convert, inkscape ou ImageMagick, s'il y en a un ; sinon None."""
    from PIL import Image
    try:
        import cairosvg
        return Image.open(io.BytesIO(cairosvg.svg2png(bytestring=data, output_width=1000))).convert("RGBA")
    except Exception:
        pass
    import tempfile
    with tempfile.TemporaryDirectory() as t:
        src, dst = Path(t, "a.svg"), Path(t, "a.png")
        src.write_bytes(data)
        for cmd in (["rsvg-convert", "-w", "1000", "-o", str(dst), str(src)],
                    ["inkscape", str(src), "-w", "1000", "-o", str(dst)],
                    ["magick", "-background", "none", "-density", "300", str(src), "-resize", "1000x", str(dst)],
                    ["convert", "-background", "none", "-density", "300", str(src), "-resize", "1000x", str(dst)]):
            if shutil.which(cmd[0]):
                try:
                    subprocess.run(cmd, capture_output=True, timeout=60, check=True)
                    return Image.open(dst).convert("RGBA")
                except Exception:
                    continue
    return None


def image_from_bytes(data: bytes):
    from PIL import Image
    head = data[:600].lstrip().lower()
    if head.startswith(b"<?xml") or head.startswith(b"<svg") or b"<svg" in head:
        im = _svg_to_png(data)
        if im is None:
            raise ValueError("SVG sans convertisseur disponible")
        return im
    im = Image.open(io.BytesIO(data))
    im.load()
    return im.convert("RGBA")


def commons_candidates(name: str, fetch=None) -> list[str]:
    """Adresses d'images (PNG de préférence) trouvées pour « <name> logo » sur Wikimedia Commons, puis Wikipédia."""
    fetch = fetch or _http_get
    urls = []
    q = urllib.parse.urlencode({"action": "query", "format": "json", "generator": "search", "gsrnamespace": "6", "gsrlimit": "10",
                                "gsrsearch": f"{name} logo", "prop": "imageinfo", "iiprop": "url|mime|size", "iiurlwidth": "1000"})
    try:
        pages = (json.loads(fetch("https://commons.wikimedia.org/w/api.php?" + q)).get("query") or {}).get("pages") or {}
        toks = [t for t in re.split(r"\W+", name.lower()) if len(t) > 2]
        scored = []
        for p in pages.values():
            ii = (p.get("imageinfo") or [{}])[0]
            title = (p.get("title") or "").lower()
            if ii.get("mime") not in ("image/png", "image/svg+xml", "image/jpeg", "image/webp"):
                continue
            if not toks or not any(t in title for t in toks):
                continue
            if re.search(r"wordmark|banner|screenshot|flag|text|horizontal|old|icon of|diagram", title):
                continue
            ar = (ii.get("width") or 1) / max(1, ii.get("height") or 1)
            s = (3 if "logo" in title else 0) + (2 if 0.6 <= ar <= 1.8 else 0) + (1 if ii.get("mime") != "image/jpeg" else 0) \
                + (1 if re.search(r"\b" + re.escape(toks[0]) + r"\b", title) else 0) - (p.get("index", 0) or 0) * 0.05
            scored.append((s, ii.get("thumburl") or ii.get("url")))
        urls += [u for _, u in sorted(scored, key=lambda x: -x[0]) if u][:3]
    except Exception:
        pass
    try:
        j = json.loads(fetch("https://en.wikipedia.org/api/rest_v1/page/summary/" + urllib.parse.quote(name.replace(" ", "_"))))
        u = (j.get("originalimage") or j.get("thumbnail") or {}).get("source")
        if u:
            urls.append(u)
    except Exception:
        pass
    return urls


def get_logo(item: dict, cache_dir: Path, fetch=None, warnings: list | None = None):
    """(image PIL RGBA, adresse utilisée) pour {"name", "url"} ; None si rien d'exploitable. Jamais d'image générée."""
    fetch = fetch or _http_get
    warnings = warnings if warnings is not None else []
    name = (item.get("name") or "").strip()
    tried = []
    urls = [u for u in [item.get("url")] if u and re.match(r"^https?://", u)]
    for phase in (0, 1):
        if phase == 1:
            urls = commons_candidates(name, fetch) if name else []
        for u in urls:
            if u in tried:
                continue
            tried.append(u)
            key = cache_dir / (hashlib.sha1(u.encode()).hexdigest() + ".bin")
            try:
                data = key.read_bytes() if key.is_file() else fetch(u)
                im = image_from_bytes(data)
                if min(im.size) < 80:
                    raise ValueError("image trop petite")
                try:
                    cache_dir.mkdir(parents=True, exist_ok=True)
                    key.write_bytes(data)
                except OSError:
                    pass
                if phase == 1:
                    warnings.append(f"Logo « {name} » : l'adresse proposée ne marchait pas, image prise sur Wikimedia/Wikipédia : {u}")
                return im, u
            except Exception as e:
                warnings.append(f"Logo « {name} » : {u[:90]} inutilisable ({str(e)[:60]})")
    return None


# ------------------------------------------------------------------ images
def prep_logo(im):
    """Fond uni (JPEG, PNG sans transparence) retiré, marges transparentes rognées."""
    from PIL import Image, ImageDraw
    im = im.convert("RGBA")
    a = im.getchannel("A")
    if a.getextrema()[0] >= 250:
        rgb = im.convert("RGB")
        corners = [rgb.getpixel(p) for p in ((0, 0), (rgb.width - 1, 0), (0, rgb.height - 1), (rgb.width - 1, rgb.height - 1))]
        if max(max(c) - min(c) for c in zip(*corners)) < 24:                # les 4 coins ont la même couleur : c'est un fond
            mask = Image.new("L", rgb.size, 0)
            tmp = rgb.copy()
            for p in ((0, 0), (rgb.width - 1, 0), (0, rgb.height - 1), (rgb.width - 1, rgb.height - 1)):
                ImageDraw.floodfill(tmp, p, (255, 0, 255), thresh=40)
            from PIL import ImageChops
            r, g, b = tmp.split()
            m = ImageChops.multiply(ImageChops.multiply(r.point(lambda v: 255 if v == 255 else 0), g.point(lambda v: 255 if v == 0 else 0)),
                                    b.point(lambda v: 255 if v == 255 else 0))        # zones remplies de magenta = fond
            alpha = m.point(lambda v: 0 if v else 255)
            im.putalpha(alpha)
    bb = im.getchannel("A").point(lambda v: 255 if v > 12 else 0).getbbox()
    return im.crop(bb) if bb else im


def _luma(im) -> float:
    """Luminosité moyenne (0-1) des pixels opaques du logo."""
    from PIL import ImageStat
    rgba = im.convert("RGBA")
    mask = rgba.getchannel("A").point(lambda v: 255 if v > 128 else 0)
    if not mask.getbbox():
        return 1.0
    return ImageStat.Stat(rgba.convert("L"), mask).mean[0] / 255


def with_shadow(im, blur=16, offset=(0, 9), alpha=0.5, outline=0):
    """Logo + ombre portée douce (+ contour blanc si le logo est très sombre). Renvoie (image, marge ajoutée)."""
    from PIL import Image, ImageFilter
    pad = blur * 3 + outline
    base = Image.new("RGBA", (im.width + 2 * pad, im.height + 2 * pad), (0, 0, 0, 0))
    a = Image.new("L", base.size, 0)
    a.paste(im.getchannel("A"), (pad, pad))
    out = Image.new("RGBA", base.size, (0, 0, 0, 0))
    sh = Image.new("RGBA", base.size, (0, 0, 0, 0))
    grown = a.filter(ImageFilter.MaxFilter(2 * outline + 1)) if outline else a      # (MaxFilter(1) plante Pillow sur certaines machines)
    sh.putalpha(grown.filter(ImageFilter.GaussianBlur(blur)).point(lambda v: int(v * alpha)))
    out.alpha_composite(sh, offset)
    if outline:
        ol = Image.new("RGBA", base.size, (255, 255, 255, 0))
        ol.putalpha(a.filter(ImageFilter.MaxFilter(2 * outline + 1)))
        out.alpha_composite(ol)
    base.paste(im, (pad, pad))
    out.alpha_composite(base)
    return out, pad


def fit_into(im, box_w, box_h):
    s = min(box_w / im.width, box_h / im.height)
    return im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), __import__("PIL.Image", fromlist=["Image"]).LANCZOS)


def draw_text_block(canvas, lines, font_path, with_pill):
    """Texte blanc en gras, aligné à droite (bord 1818), taille réduite jusqu'à tenir ; renvoie le bord gauche du texte."""
    from PIL import Image, ImageDraw, ImageFilter
    lines = [l.strip().upper() for l in lines if l.strip()]
    top_lim, bot_lim = 105, (830 if with_pill else 985)
    size = 140
    while True:
        font = load_font(font_path, size)
        sw = int(size * _FONT_MODE["stroke"])
        widths = [font.getbbox(l, stroke_width=sw)[2] - font.getbbox(l, stroke_width=sw)[0] for l in lines]
        pitch = int(size * 1.2)
        block_h = pitch * (len(lines) - 1) + size
        if (max(widths) <= 1090 and block_h <= bot_lim - top_lim) or size <= 48:
            break
        size -= 4
    y0 = top_lim + (bot_lim - top_lim - block_h) // 2
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for i, l in enumerate(lines):
        bb = font.getbbox(l, stroke_width=sw)
        d.text((TEXT_RIGHT - (bb[2] - bb[0]) - bb[0], y0 + i * pitch - bb[1] + int(size * 0.08)), l, font=font, fill=(255, 255, 255, 255),
               stroke_width=sw, stroke_fill=(255, 255, 255, 255))
    sh = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    sh.putalpha(layer.getchannel("A").filter(ImageFilter.GaussianBlur(12)).point(lambda v: int(v * 0.55)))
    canvas.alpha_composite(sh, (0, 7))
    canvas.alpha_composite(layer)
    return TEXT_RIGHT - max(widths), size


def place_logos(canvas, logos, text_left, with_pill):
    """Disposition façon miniatures de la chaîne : 1 logo centré ; 2 = grand + petit qui le chevauche ; 3 = grand + deux empilés."""
    from PIL import Image
    zr = text_left - 70
    zone_a = (95, 105, min(zr, 735), 985)                  # colonne gauche, descend jusqu'en bas (à gauche du bandeau)
    zone_b = (95, 105, zr, 820)                            # au-dessus du bandeau
    zone = zone_a
    if with_pill:
        area = lambda z: max(0, z[2] - z[0]) * (z[3] - z[1])
        zone = zone_b if area(zone_b) > area(zone_a) * 1.08 else zone_a
    else:
        zone = (95, 105, zr, 985)
    x0, y0, x1, y1 = zone
    zw, zh = x1 - x0, y1 - y0
    items = []
    for im in logos:
        dark = _luma(im) < 0.22
        items.append((im, dark))

    def put(item, bx, by, bw, bh, anchor="c"):
        im, dark = item
        f = fit_into(im, bw, bh)
        sh, pad = with_shadow(f, outline=9 if dark else 0)
        px = bx + {"c": (bw - f.width) // 2, "l": 0, "r": bw - f.width}[anchor[0]] - pad
        py = by + {"c": (bh - f.height) // 2, "t": 0, "b": bh - f.height}[anchor[1] if len(anchor) > 1 else "c"] - pad
        canvas.alpha_composite(sh, (int(px), int(py)))

    n = len(items)
    if n == 1:
        put(items[0], x0, y0, zw, zh)
    elif n == 2:
        put(items[0], x0, y0, int(zw * 0.82), int(zh * 0.82), "lt")
        put(items[1], x0 + int(zw * 0.48), y0 + int(zh * 0.52), int(zw * 0.52), int(zh * 0.48), "rb")
    elif n >= 3:
        mw = int(zw * 0.58)
        put(items[0], x0, y0, mw, zh)
        sw = zw - mw - 20
        put(items[1], x0 + mw + 20, y0, sw, zh // 2 - 20, "cb")
        put(items[2], x0 + mw + 20, y0 + zh // 2 + 20, sw, zh // 2 - 20, "ct")


def render_thumbnail(text: str, logos: list, out_path: Path, bg_name: str, with_pill: bool, font_path: str):
    from PIL import Image
    lines = text.split("\n")
    text_left, _ = draw_text_block(Image.new("RGBA", (W, H), (0, 0, 0, 0)), lines, font_path, with_pill)   # mesure seulement
    base = Image.open(ASSETS / bg_name).convert("RGBA").resize((W, H))
    place_logos(base, logos, text_left, with_pill)                       # fond, puis logos
    text_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw_text_block(text_layer, lines, font_path, with_pill)             # texte au-dessus des logos
    base.alpha_composite(text_layer)
    if with_pill:
        base.alpha_composite(Image.open(ASSETS / "pill.png").convert("RGBA"), PILL_POS)
    base.alpha_composite(Image.open(ASSETS / "frame.png").convert("RGBA"))   # bordure blanche telle quelle, par-dessus
    out_path.parent.mkdir(parents=True, exist_ok=True)
    base.convert("RGB").save(out_path, "PNG", optimize=True)
    return out_path


# ------------------------------------------------------------------ Claude : texte et logos
SPEC_PROMPT = """You are preparing 3 YouTube thumbnails for the channel "{channel}" (Linux / open-source news).

Video: {title}
Topics covered in the video:
{topics}

Thumbnail ideas generated earlier for this video:
{ideas}

Use web search to find REAL, EXISTING logo image files. Never invent or generate images; every URL must be a direct link to
an image file that exists online (official project site, Wikimedia Commons, etc.). Prefer PNG with a transparent background
(for a Wikimedia SVG use its rendered PNG thumbnail, e.g. https://upload.wikimedia.org/wikipedia/commons/thumb/.../1000px-Name.svg.png).

Reply with ONLY a JSON object (no markdown fence, no comments) of this shape:
{{
  "generic_logos": [ {{"name": "Arch Linux", "url": "https://..."}}, ... exactly 3 well-known projects/companies featured in this video, most recognizable first ],
  "thumbnails": [
    {{"idea": 1, "text": "FIREFOX\\nREDESIGN,\\nFLATPAK FOR\\nCLI & DEV\\nTOOLS",
      "logos": [ {{"name": "Firefox", "url": "https://...", "role": "project"}}, {{"name": "terminal", "url": "https://...", "role": "icon"}} ]}},
    {{ ... second thumbnail ... }}
  ]
}}
Rules:
- Pick the 2 strongest of the 3 ideas (different topics). "text" is the thumbnail headline taken from that idea: UPPERCASE, 3 to 5 lines,
  at most 14 characters per line, lines separated by \\n.
- "logos": 1 or 2 logos of the projects named in the headline (role "project"), optionally followed by ONE illustrative icon (role "icon")
  that reinforces the topic (e.g. a terminal icon). Project logos first.
"""


def _extract_json(text: str) -> dict:
    t = text.strip()
    m = re.search(r"\{.*\}", t, re.S)
    if not m:
        raise AIError("Claude n'a pas renvoyé de JSON exploitable pour les miniatures.")
    try:
        return json.loads(m.group(0))
    except ValueError as e:
        raise AIError(f"JSON des miniatures illisible : {e}")


def build_specs(call, channel: str, title: str, topics: list[str], ideas_md: str) -> dict:
    prompt = SPEC_PROMPT.format(channel=channel, title=title or "(untitled)",
                                topics="\n".join("- " + t for t in topics) or "(not available)", ideas=ideas_md.strip())
    spec = _extract_json(call(prompt))
    th = [t for t in (spec.get("thumbnails") or []) if isinstance(t, dict) and str(t.get("text") or "").strip()]
    if not th:
        raise AIError("Claude n'a proposé aucun texte de miniature.")
    spec["thumbnails"] = th[:2]
    spec["generic_logos"] = [g for g in (spec.get("generic_logos") or []) if isinstance(g, dict)][:3]
    return spec


def make_all(spec: dict, out_dir: Path, cache_dir: Path, fetch=None) -> dict:
    """Compose les 3 miniatures. Renvoie {"files": [...], "notes": [...], "warnings": [...]}."""
    try:
        import PIL  # noqa: F401
    except ImportError:
        raise AIError("Pillow est nécessaire : pip install pillow")
    font_path, font_warn = find_font()
    if not font_path:
        raise AIError(font_warn)
    warnings = [font_warn] if font_warn else []
    mode, mode_msg = probe_font(font_path)
    if mode is None:
        fb = next((p for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf")
                   if Path(p).is_file() and p != font_path), None)
        if fb and probe_font(fb)[0]:
            warnings.append(f"La police {Path(font_path).name} fait planter le rendu : police de remplacement utilisée.")
            font_path = fb
            mode = probe_font(fb)[0]
        else:
            raise AIError(f"La police {font_path} fait planter le rendu et aucune police de remplacement n'est disponible. "
                          "Indiquez une autre police Inter (fichier .ttf statique) avec la variable PLANNER_THUMB_FONT.")
    _FONT_MODE["variations"] = mode == "var"
    _FONT_MODE["stroke"] = 0.0 if (mode == "var" or "black" in Path(font_path).name.lower() or "bold" in Path(font_path).name.lower()) else 0.045
    if mode_msg:
        warnings.append(mode_msg)
    notes, files = [], []
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("miniature-*.png"):
        old.unlink()

    def logos_for(items, label):
        got = []
        for it in items:
            r = get_logo(it, cache_dir, fetch, warnings)
            if r:
                got.append(prep_logo(r[0]))
                notes.append(f"{label} · {it.get('name')} : {r[1]}")
            else:
                warnings.append(f"{label} : aucun logo trouvé pour « {it.get('name')} » (miniature faite sans)")
        return got

    jobs = [("Linux & Open Source News", GENERIC_TEXT, spec.get("generic_logos") or [], False)]
    for i, t in enumerate(spec["thumbnails"], 1):
        jobs.append((f"Idée {t.get('idea', i)}", str(t["text"]).replace("\\n", "\n"), t.get("logos") or [], True))
    for k, (label, text, items, pill) in enumerate(jobs, 1):
        logos = logos_for(items[:3], label)
        if not logos:
            warnings.append(f"{label} : aucun logo utilisable, miniature non créée.")
            continue
        p = render_thumbnail(text, logos, out_dir / f"miniature-{k}.png", BACKGROUNDS[(k - 1) % len(BACKGROUNDS)], pill, font_path)
        files.append(str(p))
    return {"files": files, "notes": notes, "warnings": warnings}


# ------------------------------------------------------------------ exécution isolée
def make_all_isolated(spec: dict, out_dir: Path, cache_dir: Path, timeout: int = 420) -> dict:
    """Comme make_all, mais dans un processus Python séparé : un plantage natif (Pillow, FreeType, polices) ne peut
    pas arrêter le serveur du Planner ; l'erreur est renvoyée comme AIError lisible."""
    import sys
    import tempfile
    root = str(Path(__file__).resolve().parent.parent)
    code = ("import sys, json, faulthandler; faulthandler.enable(); sys.path.insert(0, sys.argv[1]); "
            "from pathlib import Path; from app import thumbnails as t; "
            "a = json.load(open(sys.argv[2], encoding='utf-8')); "
            "r = t.make_all(a['spec'], Path(a['out']), Path(a['cache'])); "
            "print('@@RESULT@@' + json.dumps(r, ensure_ascii=False))")
    with tempfile.TemporaryDirectory() as td:
        arg = Path(td, "in.json")
        arg.write_text(json.dumps({"spec": spec, "out": str(out_dir), "cache": str(cache_dir)}, ensure_ascii=False), encoding="utf-8")
        try:
            p = subprocess.run([sys.executable, "-X", "faulthandler", "-c", code, root, str(arg)],
                               capture_output=True, text=True, timeout=timeout, cwd=td)
        except subprocess.TimeoutExpired:
            raise AIError("La création des miniatures a dépassé le délai (téléchargement de logos trop lent ?).")
    out = p.stdout or ""
    if "@@RESULT@@" in out:
        return json.loads(out.rsplit("@@RESULT@@", 1)[1])
    err = (p.stderr or "").strip()
    if p.returncode < 0:
        head = f"Le processus de création des miniatures a planté (signal {-p.returncode})"
    else:
        head = f"La création des miniatures a échoué (code {p.returncode})"
    m = re.search(r"AIError: (.*)", err)
    if m:
        raise AIError(m.group(1))
    py = [l.strip() for l in err.splitlines() if l.strip().startswith("File ")]      # lignes Python (la plus récente d'abord)
    last = "\n".join(py[:6] or err.splitlines()[-6:])
    raise AIError(f"{head}. {last}"[:1500])
