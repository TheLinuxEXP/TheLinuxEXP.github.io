"""Building blocks of the Database class (see app/database.py)."""
