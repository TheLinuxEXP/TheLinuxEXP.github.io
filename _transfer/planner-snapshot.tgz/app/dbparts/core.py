"""Shared pieces of the SQLite storage layer: schema, constants, helpers and the
transaction-aware connection wrapper. (The Database class itself is in database.py.)

Original overview: SQLite storage layer for the task planner.

Model: projects -> todo_lists -> tasks, with a user-managed tag taxonomy
(tags <-> tasks is many-to-many). One sqlite3 connection, guarded by a lock
since Flask's dev server can touch it from more than one thread.
"""
from __future__ import annotations
import json
import os
import re
import sqlite3
import threading
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    color TEXT NOT NULL DEFAULT '#3daee9',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS todo_lists (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS tags (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    color TEXT NOT NULL DEFAULT '#3daee9'
);
CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    todo_list_id TEXT NOT NULL REFERENCES todo_lists(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    notes TEXT NOT NULL DEFAULT '',
    due_date TEXT,
    urgent INTEGER NOT NULL DEFAULT 0,
    duration_minutes INTEGER,
    is_video INTEGER NOT NULL DEFAULT 0,
    recurrence TEXT,
    occurrence_no INTEGER NOT NULL DEFAULT 1,
    attachment_path TEXT,
    attachment_name TEXT,
    checked INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    template_sub_id TEXT
);
-- One row per finished occurrence of a RECURRING task (the task row itself
-- just rolls forward to its next due date when completed, so without this
-- the finished occurrence -- and the time spent on it -- would vanish).
CREATE TABLE IF NOT EXISTS task_completions (
    id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    occurrence_date TEXT,
    completed_at TEXT NOT NULL,
    time_spent_seconds INTEGER NOT NULL DEFAULT 0,
    urgent INTEGER NOT NULL DEFAULT 0
);
-- "Other tasks": a standalone time bucket (one row per day, id = ISO date)
-- for work that belongs to no task list/project. Same timer columns as tasks.
CREATE TABLE IF NOT EXISTS other_time (
    id TEXT PRIMARY KEY,
    time_spent_seconds INTEGER NOT NULL DEFAULT 0,
    timer_started_at TEXT,
    timer_state TEXT NOT NULL DEFAULT 'idle'
);
-- The "Other tasks" of each PROJECT: a permanent task that exists every day in every project. One row per project
-- per day (id = "<project id>:<ISO date>"), created the first time it is used. Same timer columns as tasks.
CREATE TABLE IF NOT EXISTS project_time (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    day TEXT NOT NULL,
    time_spent_seconds INTEGER NOT NULL DEFAULT 0,
    timer_started_at TEXT,
    timer_state TEXT NOT NULL DEFAULT 'idle'
);
CREATE INDEX IF NOT EXISTS idx_project_time_day ON project_time(day);
-- Tracked time per DAY: one row per task/subtask per day it was worked on.
-- This is the history behind the calendar's daily totals and the time
-- report; tasks.time_spent_seconds / subtasks.time_spent_seconds remain the
-- running total of the CURRENT occurrence.
CREATE TABLE IF NOT EXISTS time_log (
    id TEXT PRIMARY KEY,              -- "<entity>:<entity_id>:<day>"
    entity TEXT NOT NULL,             -- 'task' | 'subtask'
    entity_id TEXT NOT NULL,
    task_id TEXT NOT NULL,            -- the main task (itself, or the subtask's parent)
    day TEXT NOT NULL,
    seconds INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_time_log_day ON time_log(day);
-- Stored AI insights per week / month of the time report.
CREATE TABLE IF NOT EXISTS time_insights (
    kind TEXT NOT NULL,               -- 'week' | 'month'
    period_start TEXT NOT NULL,       -- ISO date of the Monday / the 1st
    text TEXT NOT NULL,
    generated_at TEXT NOT NULL,
    PRIMARY KEY (kind, period_start)
);
-- A FUTURE occurrence of a recurring task dragged to another day/time in the
-- calendar: only that occurrence moves (orig_date = where the series has it).
CREATE TABLE IF NOT EXISTS occurrence_moves (
    task_id TEXT NOT NULL,
    orig_date TEXT NOT NULL,
    new_date TEXT NOT NULL,
    new_time TEXT,
    PRIMARY KEY (task_id, orig_date)
);
CREATE TABLE IF NOT EXISTS task_tags (
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    tag_id TEXT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (task_id, tag_id)
);
-- Task templates (the "+" menu): editable from Utilities > Templates. The three
-- built-in ones are seeded from DEFAULT TEMPLATES below when the table is empty.
CREATE TABLE IF NOT EXISTS video_templates (
    key TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    icon TEXT,                       -- shown next to the task title
    menu_icon TEXT,                  -- shown in the "+" menu
    task_title TEXT NOT NULL,
    main_weekday INTEGER,            -- NULL = no automatic due date
    is_video INTEGER NOT NULL DEFAULT 1,
    note_title TEXT,                 -- pattern for the linked note's name
    builtin INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS video_template_subtasks (
    id TEXT PRIMARY KEY,
    template_key TEXT NOT NULL REFERENCES video_templates(key) ON DELETE CASCADE,
    position INTEGER NOT NULL DEFAULT 0,
    title TEXT NOT NULL,
    duration INTEGER,
    offset_days INTEGER,             -- days from the main due date (-1 = the day before)
    start_time TEXT,
    ai_buttons TEXT                  -- JSON list of the AI buttons shown on the subtask
);
CREATE TABLE IF NOT EXISTS tag_contracts (
    tag_id TEXT PRIMARY KEY REFERENCES tags(id) ON DELETE CASCADE,
    file_path TEXT,
    file_name TEXT,
    total_videos INTEGER,
    end_date TEXT,
    uploaded_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS subtasks (
    id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    due_date TEXT,
    duration_minutes INTEGER,
    urgent INTEGER NOT NULL DEFAULT 0,
    checked INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    completed_at TEXT
);
"""

PROJECT_COLORS = ["#3daee9", "#e01b24", "#ff9800", "#2ecc71", "#9b59b6",
                   "#f39c12", "#1abc9c", "#e91e63", "#607d8b", "#795548"]


# -- AI buttons of the built-in templates ------------------------------------
# Same prompts the app used to hard-code; now stored per template subtask and
# editable from Utilities > Templates. Placeholders: {title} (task), {subtask},
# {due_date}. The notes sections / task notes listed in "sources" are appended
# after the instructions automatically.
_CH = "The Linux Experiment"
_SYS_PLAN = f"You help plan YouTube videos for the channel {_CH}, a Linux/open-source tech channel."
_AI_ORDER_TOPICS = {
    "id": "order-topics", "label": "Order topics", "kind": "prompt",
    "system": _SYS_PLAN,
    "instructions": (
        "Below are three sections from a video-planning markdown note. Each one\n"
        "lists the same set of topics, in the same order -- one entry per topic -- under\n"
        "Timestamps, Links and Content respectively.\n\n"
        "Reorder the topics consistently across all three sections, from the one most\n"
        f"likely to interest the audience of the YouTube channel \"{_CH}\" to the\n"
        "least likely. If two topics seem related to each other and are no more than 3\n"
        "positions apart in your ranking, place the lower-ranked one immediately after\n"
        "the higher-ranked one.\n\n"
        "Keep each entry's own text/content as-is -- only change the ORDER of entries,\n"
        "identically across all three sections (so entry N under Timestamps still\n"
        "corresponds to entry N under Links and under Content after reordering).\n\n"
        "Reply with ONLY the three reordered sections, formatted exactly like this\n"
        "(markdown, same three headings, nothing else before or after):\n"
        "## Timestamps\n...\n## Links\n...\n## Content\n..."),
    "sources": {"note_sections": ["Timestamps", "Links", "Content"], "task_notes": False},
    "apply_to_note": True, "post": "none",
}
_AI_TAGS = {
    "id": "generate-tags", "label": "Generate tags", "kind": "prompt",
    "system": f"You write YouTube SEO tags for the channel {_CH}, a Linux/open-source tech channel.",
    "instructions": (
        f"Above is the \"Content\" section from a video-planning note for a video on\n"
        f"the YouTube channel \"{_CH}\" (a Linux/open-source tech channel).\n\n"
        "Generate a comma-separated list of YouTube tags/keywords for this video: a\n"
        "mix of broad (e.g. \"linux\", \"open source\") and specific terms (software names,\n"
        "topics covered, common search phrasings). YouTube allows at most 500\n"
        "characters of tags in total (commas included), so use nearly all of it: the\n"
        "whole list should come to between 460 and 500 characters. Put the most\n"
        "important tags first. Reply with ONLY the comma-separated list, nothing else."),
    "sources": {"note_sections": ["Content"], "task_notes": False},
    "apply_to_note": False, "post": "youtube_tags",
}
_AI_THUMBS = {
    "id": "generate-ideas", "label": "Generate ideas", "kind": "prompt",
    "system": f"You write video titles and thumbnail concepts for the channel {_CH}, a Linux/open-source tech channel.",
    "instructions": (
        f"Below is the \"Content\" section from a video-planning note for a video on\n"
        f"the YouTube channel \"{_CH}\" (a Linux/open-source tech channel).\n\n"
        "Generate:\n"
        "- 3 candidate video titles (punchy and clickable, but accurate -- suited to a\n"
        "  Linux/tech YouTube audience)\n"
        "- 3 thumbnail visual concepts (a sentence or two each: what's shown, any text\n"
        "  overlay, the overall mood/style)\n\n"
        "Reply in markdown with exactly two headed sections:\n"
        "## Titles\n1. ...\n2. ...\n3. ...\n## Thumbnail ideas\n1. ...\n2. ...\n3. ..."),
    "sources": {"note_sections": ["Content"], "task_notes": False},
    "apply_to_note": False, "post": "none",
}
_AI_SCRIPT = {
    "id": "plan-script", "label": "Plan out this script", "kind": "prompt",
    "system": f"You help script videos for the channel {_CH}, a Linux/open-source tech channel.",
    "instructions": (
        f"Below are my notes for a video I'm planning to script, for the YouTube\n"
        f"channel \"{_CH}\" (a Linux/open-source tech channel).\n\n"
        "Based on these notes, draft a structure for the video's script: a sensible\n"
        "ordered list of main points to cover. For each main point, include:\n"
        "- a short description of what to say\n"
        "- any relevant links related to that point (suggest real, well-known\n"
        "  resources where you can; otherwise describe what kind of link to look for)\n"
        "- an idea of what to show on screen to illustrate that point (e.g. a\n"
        "  terminal demo, a diagram, a specific website, settings screen, etc.)\n\n"
        "Reply in markdown, with one \"##\" heading per main point."),
    "sources": {"note_sections": [], "task_notes": True},
    "apply_to_note": False, "post": "none",
}
_AI_PPTX = {
    "id": "generate-pptx", "label": "Generate", "kind": "powerpoint", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}
_AI_LIST_PPT = {
    "id": "list-to-ppt", "label": "List to PPT", "kind": "list_to_ppt", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}
_AI_CHAPTERS = {
    "id": "generate-chapters", "label": "Generate Chapters", "kind": "chapters", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}
_AI_CAPTURES = {
    "id": "take-captures", "label": "Take Captures", "kind": "capture", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}
_AI_THUMBS_MAKE = {
    "id": "make-thumbnails", "label": "Create thumbnails", "kind": "thumbnails", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}
_AI_TIMESTAMPS = {
    "id": "video-timestamps", "label": "Timestamps", "kind": "timestamps", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}
_AI_TEXT_TIMESTAMPS = {
    "id": "generate-timestamps", "label": "Generate Timestamps", "kind": "text_timestamps", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}
_AI_SETUP_EDIT = {
    "id": "setup-edit", "label": "Setup for editing", "kind": "setup_edit", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}
_AI_BASE_EDIT = {
    "id": "base-edit", "label": "Base edit", "kind": "montage", "instructions": "", "system": "",
    "sources": {"note_sections": [], "task_notes": False}, "apply_to_note": False, "post": "none",
}

# -- "+" button video templates --------------------------------------------
# Each template creates one main task (video flag on) plus a fixed set of
# subtasks, scheduled relative to the main task's due date. `main_weekday`
# uses Python's date.weekday() numbering (Monday=0 .. Sunday=6).
TEMPLATES = {
    "weekly_news": {
        "label": "Weekly News Video",
        "icon": "📅", "menu_icon": "📰",
        "note_title": "Linux News Podcast {dd} {month} {yy}",
        "task_title": "Weekly News Video {dd} {month}",
        "main_weekday": 5,  # Saturday
        "subtasks": [
            {"title": "Order topics", "duration": 15, "offset_days": -1, "start_time": "10:30", "ai_buttons": [_AI_ORDER_TOPICS]},
            {"title": "Record A roll with a joke", "duration": 60, "offset_days": -1, "start_time": "11:00"},
            {"title": "Edit A Roll", "duration": 90, "offset_days": -1, "start_time": "12:00"},
            {"title": "Edit podcast and main video", "duration": 60, "offset_days": 0, "start_time": "09:00", "ai_buttons": [_AI_CHAPTERS, _AI_SETUP_EDIT]},
            {"title": "Make 3 thumbnails", "duration": 20, "offset_days": 0, "start_time": "10:30", "ai_buttons": [_AI_THUMBS, _AI_THUMBS_MAKE]},
            {"title": "Publish video on YT, Tilvids and podcast", "duration": 30, "offset_days": 0, "start_time": "11:00", "ai_buttons": [_AI_TAGS, _AI_TIMESTAMPS]},
        ],
    },
    "normal_video": {
        "label": "Normal Video",
        "icon": "🎥", "menu_icon": "🎬",
        "task_title": "New video",
        "main_weekday": 2,  # Wednesday
        "subtasks": [
            {"title": "Write script", "duration": 120, "offset_days": -2, "start_time": "14:00", "ai_buttons": [_AI_SCRIPT]},
            {"title": "Record A roll with jokes", "duration": 60, "offset_days": -1, "start_time": "11:00"},
            {"title": "Edit A roll", "duration": 40, "offset_days": -1},
            {"title": "Edit video", "duration": 180, "offset_days": 0, "start_time": "11:00"},
            {"title": "Make 3 thumbnails", "duration": 20, "offset_days": 0, "start_time": "15:00", "ai_buttons": [_AI_THUMBS]},
            {"title": "Publish video on YT, Tilvids", "duration": 30, "offset_days": 0, "start_time": "15:30", "ai_buttons": [_AI_TAGS, _AI_TEXT_TIMESTAMPS]},
        ],
    },
    "warhammer_video": {
        "label": "Warhammer Video",
        "icon": "🎲", "menu_icon": "🎲",
        "task_title": "Warhammer Video",
        # always created in this list ("project", "list"); the project name is matched loosely
        "target_list": ("Déconnecté du C'Tan", "Videos"),
        # No automatic scheduling for this one -- created with no due date
        # (and its subtasks get none either), unlike the two templates above.
        "main_weekday": None,
        "subtasks": [
            {"title": "Create powerpoint", "duration": 60, "ai_buttons": [_AI_PPTX, _AI_LIST_PPT]},
            {"title": "Record video", "duration": 60},
            {"title": "Edit video", "duration": 60},
            {"title": "Publish video", "duration": 20},
        ],
    },
}


def new_id() -> str:
    return uuid.uuid4().hex[:16]


def data_dir() -> Path:
    base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    d = base / "taskplanner"
    d.mkdir(parents=True, exist_ok=True)
    return d


# Public methods that change tasks/subtasks (or the projects/lists holding
# them): after each one, a backup of the whole database is written.
BACKUP_TRIGGERS = {
    "add_task", "update_task", "delete_task", "toggle_task", "set_task_tags",
    "add_subtask", "update_subtask", "delete_subtask", "toggle_subtask", "set_time_spent",
    "create_from_template", "set_attachment", "clear_attachment", "set_tag_contract",
    "add_project", "update_project", "delete_project",
    "add_todo_list", "update_todo_list", "delete_todo_list",
    "save_template", "add_template", "delete_template", "reset_template", "reorder_templates",
}
_BACKUP_LABELS = {
    "add_task": "Task created", "update_task": "Task edited", "delete_task": "Task deleted",
    "set_task_tags": "Task tags changed", "add_subtask": "Subtask created",
    "update_subtask": "Subtask edited", "delete_subtask": "Subtask deleted",
    "set_time_spent": "Time spent edited", "create_from_template": "Video created from template",
    "set_attachment": "Attachment added", "clear_attachment": "Attachment removed",
    "set_tag_contract": "Sponsor contract added",
    "add_project": "Project created", "update_project": "Project edited", "delete_project": "Project deleted",
    "add_todo_list": "List created", "update_todo_list": "List edited", "delete_todo_list": "List deleted",
    "save_template": "Template edited", "add_template": "Template created", "delete_template": "Template deleted",
    "reset_template": "Template reset to default", "reorder_templates": "Templates reordered",
}


_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")


def _clean_color(value, default=None):
    """Colors end up inside SVG/HTML attributes and style strings in the UI,
    so only plain hex colors are ever stored."""
    if isinstance(value, str) and _COLOR_RE.match(value.strip()):
        return value.strip()
    return default if default is not None else "#3daee9"


class _TxConn:
    """Thin wrapper around the sqlite3 connection. While a public Database
    method is running, commit() only marks the work as pending; the method
    wrapper commits ONCE when the outermost call succeeds, or rolls everything
    back if it raises -- so a failure half-way never leaves half a change."""

    def __init__(self, conn, owner):
        object.__setattr__(self, "_c", conn)
        object.__setattr__(self, "_owner", owner)

    def commit(self):
        if self._owner._call_depth == 0:
            self._c.commit()

    def real_commit(self):
        self._c.commit()

    def __getattr__(self, name):
        return getattr(self._c, name)

    def __setattr__(self, name, value):
        setattr(self._c, name, value)


def _stamp_anchor(rule, due_iso):
    """Month/year rules remember the day-of-month they started on, so a 31st
    that falls on a 30-day month comes back to the 31st afterwards."""
    if isinstance(rule, dict) and rule.get("unit") in ("month", "year") and due_iso:
        try:
            rule = {**rule, "anchor_day": date.fromisoformat(due_iso).day}
        except ValueError:
            pass
    return rule


__all__ = [n for n in list(globals()) if not n.startswith("__")]


def _chunks(items, size=400):
    """Slices of `items` small enough for a SQL `IN (?, ?, ...)` (SQLite caps the number of variables)."""
    for i in range(0, len(items), size):
        yield items[i:i + size]
