"""Start-up migrations and one-time repairs (each guarded by a flag or idempotent)."""
from __future__ import annotations
import json
from datetime import date, datetime, timedelta
from .core import TEMPLATES, _AI_BASE_EDIT, _AI_CAPTURES, _AI_CHAPTERS, _AI_SETUP_EDIT, _AI_LIST_PPT, _AI_TEXT_TIMESTAMPS, _AI_THUMBS_MAKE, _AI_TIMESTAMPS, new_id


class MigrationsMixin:
    def backfill_video_template_types(self):
        """One-time retroactive fix: stamp existing video tasks with the
        template they were created from (video_template = 'weekly_news' or
        'normal_video'), matched by their CURRENT title against each
        template's default task title. This is a best-effort recovery for
        data that predates the video_template column -- a task already
        renamed away from its template's default title by the time this
        runs can't be recovered this way, since nothing else records which
        template it came from. Never overwrites a video_template that's
        already set, and never touches non-video tasks. Runs once (flagged):
        it used to run at every start-up and would re-stamp a task whose
        'Video type' the person had cleared on purpose."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='video_template_types_once'").fetchone():
            return 0
        updated = 0
        for key, tpl in TEMPLATES.items():
            cur = self.conn.execute("""
                UPDATE tasks SET video_template = ?
                WHERE video_template IS NULL AND is_video = 1
                  AND title = ? COLLATE NOCASE
            """, (key, tpl["task_title"]))
            updated += cur.rowcount
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('video_template_types_once')")
        self.conn.commit()
        return updated

    def backfill_edit_a_roll_subtask(self):
        """Retired migration. It used to run on EVERY startup and re-created an
        'Edit A Roll' subtask the person had deleted. It has already been applied
        to every existing database (and new tasks get the subtask from the
        template), so it now only records its flag and does nothing else."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('weekly_news_edit_a_roll_retired')")
        self.conn.commit()
        return 0

    @staticmethod
    def _due_from_rule(rule, main_due):
        """Subtask due date (ISO) for a main-task due date `main_due` (a date),
        or None when the subtask has no rule."""
        if not rule:
            return None
        if rule == "same_day":
            return main_due.isoformat()
        if rule.startswith("weekday_before:"):
            try:
                wd = int(rule.split(":", 1)[1])
            except ValueError:
                return None
            back = (main_due.weekday() - wd) % 7 or 7     # strictly before the main due date
            return (main_due - timedelta(days=back)).isoformat()
        return None

    def apply_patroncast_due_rules(self):
        """One-time (flagged): Patroncast's subtasks follow fixed rules in
        every occurrence -- 'Record patroncast' is due the Thursday before the
        main task's due date, 'Publish patroncast' on the same day. Stores
        the rules and applies them to the current occurrence."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        flag = "patroncast_due_rules_20261007"
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name=?", (flag,)).fetchone():
            return 0
        n = 0
        for t in self.conn.execute(
                "SELECT id, due_date FROM tasks WHERE recurrence IS NOT NULL AND due_date IS NOT NULL "
                "AND lower(trim(title)) = 'patroncast'").fetchall():
            main_due = date.fromisoformat(t["due_date"])
            for x in self.conn.execute("SELECT id, title FROM subtasks WHERE task_id=?", (t["id"],)).fetchall():
                name = x["title"].strip().lower()
                rule = {"record patroncast": "weekday_before:3", "publish patroncast": "same_day"}.get(name)
                if rule:
                    self.conn.execute("UPDATE subtasks SET due_rule=?, due_date=? WHERE id=?",
                                      (rule, self._due_from_rule(rule, main_due), x["id"]))
                    n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES (?)", (flag,))
        self.conn.commit()
        return n

    def make_patroncast_monday_only(self):
        """One-time (flagged): Patroncast recurs on Mondays only (it was set
        up as Thursday + Monday). Fixes the rule and, if the current
        occurrence is on a Thursday, moves it to the next Monday, with its
        rule-based subtasks following."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        flag = "patroncast_monday_only_20261007"
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name=?", (flag,)).fetchone():
            return 0
        n = 0
        for t in self.conn.execute(
                "SELECT * FROM tasks WHERE recurrence IS NOT NULL AND lower(trim(title)) = 'patroncast'").fetchall():
            rule = json.loads(t["recurrence"])
            if rule.get("unit") != "week":
                continue
            rule["weekdays"] = [0]
            due = t["due_date"]
            if due:
                d = date.fromisoformat(due)
                if d.weekday() != 0:
                    d = d + timedelta(days=(7 - d.weekday()) % 7 or 7)    # next Monday
                    due = d.isoformat()
                    for x in self.conn.execute(
                            "SELECT id, due_rule FROM subtasks WHERE task_id=? AND due_rule IS NOT NULL", (t["id"],)).fetchall():
                        self.conn.execute("UPDATE subtasks SET due_date=? WHERE id=?",
                                          (self._due_from_rule(x["due_rule"], d), x["id"]))
            self.conn.execute("UPDATE tasks SET recurrence=?, due_date=? WHERE id=?", (json.dumps(rule), due, t["id"]))
            n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES (?)", (flag,))
        self.conn.commit()
        return n

    def backfill_time_log(self):
        """One-time (flagged): fill the per-day time log from the totals that
        existed before it. Sessions weren't logged then, so each total is put
        on the best-known day: the day a task was last tracked, a subtask's
        completion day (else its due date), a finished occurrence's day."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        flag = "time_log_backfill_v1"
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name=?", (flag,)).fetchone():
            return 0
        n = 0

        def put(entity, eid, task_id, day, seconds):
            nonlocal n
            if seconds and seconds > 0 and day:
                # time can't have been tracked in the future (a due date can be)
                self._log_add(entity, eid, task_id, min(str(day)[:10], date.today().isoformat()), seconds)
                n += 1

        tasks = {r["id"]: r for r in self.conn.execute("SELECT * FROM tasks").fetchall()}
        for t in tasks.values():
            put("task", t["id"], t["id"], t["time_day"] or t["due_date"] or t["completed_at"] or t["created_at"],
                t["time_spent_seconds"])
        for x in self.conn.execute("SELECT * FROM subtasks").fetchall():
            parent = tasks.get(x["task_id"])
            if not parent:
                continue
            day = (x["completed_at"] if x["checked"] else None) or x["due_date"] or parent["time_day"] \
                or parent["due_date"] or x["created_at"]
            put("subtask", x["id"], x["task_id"], day, x["time_spent_seconds"])
        for c in self.conn.execute("SELECT * FROM task_completions").fetchall():
            if c["task_id"] not in tasks:
                continue
            day = c["occurrence_date"] if c["time_only"] else (c["completed_at"] or c["occurrence_date"])
            put("task", c["task_id"], c["task_id"], day, c["time_spent_seconds"])
            try:
                snap = json.loads(c["subtasks_json"] or "[]")
            except (ValueError, TypeError):
                snap = []
            for x in snap:
                put("subtask", x.get("id"), c["task_id"], x.get("due_date") or day, x.get("time_spent_seconds"))
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES (?)", (flag,))
        self.conn.commit()
        return n

    def repair_time_after_early_archive(self):
        """One-time (flagged). An earlier version archived the time of a
        recurring task's STILL OPEN occurrence into a closed-out 'time only'
        record whenever a timer was started on a later day, which reset that
        occurrence's subtasks to 0 and, when time was imported per day,
        dated all of it on the archive day. This (1) puts that time back on
        the open occurrence and removes the archive record, and (2) moves
        imported subtask time that was dated on the archive day back to the
        day the subtask was due."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        flag = "repair_early_archive_20261007"
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name=?", (flag,)).fetchone():
            return 0
        fixed = 0
        for c in self.conn.execute("SELECT * FROM task_completions WHERE time_only=1").fetchall():
            try:
                snap = json.loads(c["subtasks_json"] or "[]")
            except (ValueError, TypeError):
                snap = []
            # (2) re-date imported subtask time to the subtask's due date
            for x in snap:
                due, sec = x.get("due_date"), int(x.get("time_spent_seconds") or 0)
                if not (due and sec and due < c["occurrence_date"]):
                    continue
                src = self.conn.execute("SELECT id, seconds FROM time_log WHERE entity='subtask' AND entity_id=? AND day=?",
                                        (x["id"], c["occurrence_date"])).fetchone()
                if src and src["seconds"] >= sec:
                    self._log_reduce_day("subtask", x["id"], c["occurrence_date"], sec)
                    self._log_add("subtask", x["id"], c["task_id"], due, sec)
            # (1) give the open occurrence its time back
            later = self.conn.execute(
                "SELECT 1 FROM task_completions WHERE task_id=? AND time_only=0 AND date(completed_at) > ?",
                (c["task_id"], c["occurrence_date"])).fetchone()
            task = self.conn.execute("SELECT * FROM tasks WHERE id=?", (c["task_id"],)).fetchone()
            if later or not task:
                continue
            live = {x["id"]: x for x in self.list_subtasks(task["id"])}
            if not (task["time_spent_seconds"] or 0):
                self.conn.execute("UPDATE tasks SET time_spent_seconds=? WHERE id=?", (c["time_spent_seconds"], task["id"]))
            for x in snap:
                lv = live.get(x.get("id"))
                if lv is not None and not (lv["time_spent_seconds"] or 0):
                    self.conn.execute("UPDATE subtasks SET time_spent_seconds=? WHERE id=?",
                                      (int(x.get("time_spent_seconds") or 0), x["id"]))
            self.conn.execute("DELETE FROM task_completions WHERE id=?", (c["id"],))
            fixed += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES (?)", (flag,))
        self.conn.commit()
        return fixed

    def repair_future_time_log(self):
        """One-time (flagged). The first import of the per-day log dated time
        that had no per-day history on the item's DUE date -- which can be a
        day that hasn't happened yet (e.g. a subtask due tomorrow that was
        already worked on today). Time can't be tracked in the future, so
        every such entry is moved to the day its main task was last tracked
        (``time_day``), or today when that is unknown or also in the future."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        flag = "repair_future_time_log_20261008"
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name=?", (flag,)).fetchone():
            return 0
        today = date.today().isoformat()
        moved = 0
        for r in self.conn.execute("SELECT * FROM time_log WHERE day > ? AND seconds > 0", (today,)).fetchall():
            t = self.conn.execute("SELECT time_day FROM tasks WHERE id=?", (r["task_id"],)).fetchone()
            day = str((t["time_day"] if t else None) or today)[:10]
            if day > today:
                day = today
            self._log_add(r["entity"], r["entity_id"], r["task_id"], day, r["seconds"])
            self.conn.execute("DELETE FROM time_log WHERE id=?", (r["id"],))
            moved += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES (?)", (flag,))
        self.conn.commit()
        return moved

    def _log_reduce_day(self, entity, entity_id, day, amount):
        self.conn.execute("UPDATE time_log SET seconds = MAX(0, seconds - ?) WHERE entity=? AND entity_id=? AND day=?",
                          (int(amount), entity, entity_id, day))

    def remove_duplicate_daily_news_hour(self):
        """One-time (flagged), at the user's request: Daily News Show has a
        duplicate hour on 2026-10-06 (a 'time only' record carried over from
        an earlier bug). Removes that record and takes the hour back out of
        the per-day log."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        flag = "remove_duplicate_daily_news_hour_20261007"
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name=?", (flag,)).fetchone():
            return 0
        n = 0
        for c in self.conn.execute(
                "SELECT c.* FROM task_completions c JOIN tasks t ON t.id=c.task_id "
                "WHERE c.time_only=1 AND c.occurrence_date='2026-10-06' AND c.time_spent_seconds=3600 "
                "AND lower(trim(t.title))='daily news show'").fetchall():
            self._log_reduce_day("task", c["task_id"], "2026-10-06", 3600)
            self.conn.execute("DELETE FROM task_completions WHERE id=?", (c["id"],))
            n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES (?)", (flag,))
        self.conn.commit()
        return n

    def reset_subtasks_left_over_from_finished_occurrences(self):
        """One-time repair (flagged): recurring tasks finished before
        subtasks were reset per occurrence still show the PREVIOUS
        occurrence's checked subtasks. Snapshot them onto that occurrence
        (when it has no snapshot) and give the task fresh subtasks:
        unchecked, no time, due dates moved forward with the task."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        flag = "reset_leftover_subtasks_20261007"
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name=?", (flag,)).fetchone():
            return 0
        todo = []
        for t in self.conn.execute(
                "SELECT * FROM tasks WHERE recurrence IS NOT NULL AND checked=0 AND due_date IS NOT NULL").fetchall():
            c = self.conn.execute(
                "SELECT * FROM task_completions WHERE task_id=? AND time_only=0 "
                "ORDER BY completed_at DESC LIMIT 1", (t["id"],)).fetchone()
            if not c or not c["occurrence_date"]:
                continue
            subs = self.list_subtasks(t["id"])
            stale = [x for x in subs if x["checked"] and x["completed_at"]
                     and x["completed_at"] <= (c["completed_at"] or "") ]
            if stale:
                todo.append((t, c, subs))
        if todo:
            self._backups.create(self.conn, "Before resetting leftover subtasks of finished occurrences", force=True)
        for t, c, subs in todo:
            try:
                shift = (date.fromisoformat(t["due_date"]) - date.fromisoformat(c["occurrence_date"])).days
            except ValueError:
                shift = 0
            try:
                has_snap = bool(json.loads(c["subtasks_json"] or "[]"))
            except (ValueError, TypeError):
                has_snap = False
            if not has_snap:
                snap = [{"id": x["id"], "title": x["title"], "checked": bool(x["checked"]),
                         "due_date": x["due_date"], "duration_minutes": x["duration_minutes"],
                         "start_time": x["start_time"], "urgent": bool(x["urgent"]),
                         "time_spent_seconds": x["time_spent_seconds"]} for x in subs]
                self.conn.execute("UPDATE task_completions SET subtasks_json=? WHERE id=?", (json.dumps(snap), c["id"]))
            for x in subs:
                new_due = x["due_date"]
                if new_due and shift:
                    try:
                        new_due = (date.fromisoformat(new_due) + timedelta(days=shift)).isoformat()
                    except ValueError:
                        pass
                self.conn.execute(
                    "UPDATE subtasks SET checked=0, completed_at=NULL, due_date=?, time_spent_seconds=0, "
                    "timer_started_at=NULL, timer_state='idle' WHERE id=?", (new_due, x["id"]))
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES (?)", (flag,))
        self.conn.commit()
        return len(todo)

    def repair_wrongly_finished_occurrence(self):
        """One-time repair (flagged): an occurrence due today that was
        closed as 'completed' by the old start-timer roll-over, because it
        carried leftover time from the previous day. Re-opens it: puts the
        task back on that occurrence's date and files the leftover time under
        the day it was tracked. Only touches an occurrence completed in the
        last 2 days that is the task's immediately preceding one."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        # (also covers a database where an earlier version of this repair ran)
        self.conn.execute(
            "UPDATE task_completions SET time_only=1 WHERE id='f113df12bf874534' "
            "AND occurrence_date='2026-10-06' AND completed_at='2026-10-06T23:59:59'")
        self.conn.commit()
        flag = "fix_start_timer_rollover_20261007"
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name=?", (flag,)).fetchone():
            return 0
        fixed = 0
        row = self.conn.execute(
            "SELECT c.id AS cid, c.occurrence_date, c.task_id, t.due_date, t.occurrence_no, t.recurrence "
            "FROM task_completions c JOIN tasks t ON t.id = c.task_id "
            "WHERE c.id='f113df12bf874534' AND c.task_id='48d313f98f684f86' "
            "AND c.occurrence_date='2026-10-07' AND t.due_date='2026-10-08' AND t.checked=0").fetchone()
        if row:
            self.conn.execute(
                "UPDATE task_completions SET occurrence_date='2026-10-06', completed_at='2026-10-06T23:59:59', time_only=1 WHERE id=?",
                (row["cid"],))
            self.conn.execute(
                "UPDATE tasks SET due_date='2026-10-07', occurrence_no=?, checked=0, completed_at=NULL, time_day=? WHERE id=?",
                (max(1, row["occurrence_no"] - 1), date.today().isoformat(), row["task_id"]))
            fixed = 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES (?)", (flag,))
        self.conn.commit()
        return fixed

    def backfill_normal_video_edit_a_roll(self):
        """One-time retroactive fix: add the 'Edit A roll' subtask (40 min,
        due the day before the video) to every existing Normal Video main
        task, right after its 'Record A roll...' subtask. Runs once (flag
        stored), so deleting the subtask later doesn't bring it back."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='normal_video_edit_a_roll'").fetchone():
            return 0
        added = 0
        for t in self.conn.execute(
                "SELECT id, due_date FROM tasks WHERE video_template = 'normal_video'").fetchall():
            tid = t["id"]
            subs = self.conn.execute(
                "SELECT id, title, sort_order FROM subtasks WHERE task_id=? ORDER BY sort_order", (tid,)).fetchall()
            if any(x["title"].strip().lower() == "edit a roll" for x in subs):
                continue
            rec_row = next((x for x in subs if x["title"].strip().lower().startswith("record a roll")), None)
            if rec_row:
                after = rec_row["sort_order"]
            else:
                edit_row = next((x for x in subs if x["title"].strip().lower() == "edit video"), None)
                after = (edit_row["sort_order"] - 1) if edit_row else (subs[-1]["sort_order"] if subs else 0)
            self.conn.execute("UPDATE subtasks SET sort_order = sort_order + 1 WHERE task_id=? AND sort_order > ?",
                              (tid, after))
            due = None
            if t["due_date"]:
                due = (date.fromisoformat(t["due_date"]) - timedelta(days=1)).isoformat()
            self.conn.execute("""
                INSERT INTO subtasks (id, task_id, title, due_date, duration_minutes, urgent, sort_order, created_at)
                VALUES (?,?,?,?,?,?,?,?)
            """, (new_id(), tid, "Edit A roll", due, 40, 0, after + 1, datetime.now().isoformat()))
            added += 1
        self.conn.execute("INSERT INTO app_flags (name) VALUES ('normal_video_edit_a_roll')")
        self.conn.commit()
        return added

    def backfill_template_subtask_start_times(self):
        """One-time retroactive fix: set a default start time on existing
        subtasks created from a video template before start times existed,
        matched by parent task title + subtask title (titles like "Make 3
        thumbnails" are shared between templates with different default
        times, so the parent task's title disambiguates which one applies).
        Never overwrites a start time that's already set. Runs once (flagged):
        it used to run at every start-up and brought back a start time the
        person had removed."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_subtask_start_times_once'").fetchone():
            return 0
        updated = 0
        for tpl in TEMPLATES.values():
            for s in tpl["subtasks"]:
                if not s.get("start_time"):
                    continue
                cur = self.conn.execute("""
                    UPDATE subtasks SET start_time = ?
                    WHERE start_time IS NULL
                      AND title = ? COLLATE NOCASE
                      AND task_id IN (SELECT id FROM tasks WHERE title = ? COLLATE NOCASE)
                """, (s["start_time"], s["title"], tpl["task_title"]))
                updated += cur.rowcount
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_subtask_start_times_once')")
        self.conn.commit()
        return updated

    def seed_template_ai_buttons(self):
        """One-time: the AI buttons used to be hard-coded by subtask title.
        Give the built-in templates' matching subtasks the equivalent editable
        buttons (only where none was ever stored)."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_ai_buttons_seed_v1'").fetchone():
            return 0
        n = 0
        for key, tpl in TEMPLATES.items():
            for s in tpl["subtasks"]:
                if not s.get("ai_buttons"):
                    continue
                cur = self.conn.execute(
                    "UPDATE video_template_subtasks SET ai_buttons=? WHERE template_key=? AND ai_buttons IS NULL "
                    "AND title = ? COLLATE NOCASE",
                    (json.dumps(s["ai_buttons"], ensure_ascii=False), key, s["title"]))
                n += cur.rowcount
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_ai_buttons_seed_v1')")
        self.conn.commit()
        return n

    def seed_template_edit_buttons(self):
        """One-time: Weekly News's "Edit video" subtask gets "Take Captures" and "Base edit" (the built-in
        "Edit podcast and main video" if there is no "Edit video"). Flagged, so removing them later sticks."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_edit_buttons_v1'").fetchone():
            return 0
        rows = self.conn.execute("SELECT id, title, ai_buttons FROM video_template_subtasks WHERE template_key='weekly_news'").fetchall()
        target = (next((r for r in rows if r["title"].strip().lower() == "edit video"), None)
                  or next((r for r in rows if r["title"].strip().lower() == "edit podcast and main video"), None))
        n = 0
        if target:
            try:
                cur = json.loads(target["ai_buttons"]) if target["ai_buttons"] else []
            except ValueError:
                cur = []
            add = [b for b in (_AI_CAPTURES, _AI_BASE_EDIT) if not any(x.get("id") == b["id"] for x in cur)]
            if add:
                self.conn.execute("UPDATE video_template_subtasks SET ai_buttons=? WHERE id=?",
                                  (json.dumps(cur + add, ensure_ascii=False), target["id"]))
                n = len(add)
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_edit_buttons_v1')")
        self.conn.commit()
        return n

    def seed_template_timestamps_button(self):
        """One-time: Weekly News's "Publish video on YT…" subtask gets the "Timestamps" AI button (flagged, so removing it
        from the template later sticks)."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_timestamps_button_v1'").fetchone():
            return 0
        n = 0
        for r in self.conn.execute(
                "SELECT id, ai_buttons FROM video_template_subtasks WHERE template_key='weekly_news' "
                "AND title LIKE 'Publish video on YT%' COLLATE NOCASE").fetchall():
            try:
                cur = json.loads(r["ai_buttons"]) if r["ai_buttons"] else []
            except ValueError:
                cur = []
            if not any(b.get("id") == _AI_TIMESTAMPS["id"] for b in cur):
                self.conn.execute("UPDATE video_template_subtasks SET ai_buttons=? WHERE id=?",
                                  (json.dumps(cur + [_AI_TIMESTAMPS], ensure_ascii=False), r["id"]))
                n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_timestamps_button_v1')")
        self.conn.commit()
        return n

    def seed_template_thumbnails_button(self):
        """One-time: Weekly News's "Make 3 thumbnails" subtask gets the "Create thumbnails" AI button (flagged)."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_thumbnails_button_v1'").fetchone():
            return 0
        n = 0
        for r in self.conn.execute(
                "SELECT id, ai_buttons FROM video_template_subtasks WHERE template_key='weekly_news' "
                "AND title LIKE 'Make 3 thumbnails%' COLLATE NOCASE").fetchall():
            try:
                cur = json.loads(r["ai_buttons"]) if r["ai_buttons"] else []
            except ValueError:
                cur = []
            if not any(b.get("id") == _AI_THUMBS_MAKE["id"] for b in cur):
                self.conn.execute("UPDATE video_template_subtasks SET ai_buttons=? WHERE id=?",
                                  (json.dumps(cur + [_AI_THUMBS_MAKE], ensure_ascii=False), r["id"]))
                n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_thumbnails_button_v1')")
        self.conn.commit()
        return n

    def seed_template_text_timestamps_button(self):
        """One-time: Normal Video's "Publish video on YT, Tilvids" subtask gets the "Generate Timestamps" AI button (flagged)."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_text_timestamps_button_v1'").fetchone():
            return 0
        n = 0
        for r in self.conn.execute(
                "SELECT id, ai_buttons FROM video_template_subtasks WHERE template_key='normal_video' "
                "AND title LIKE 'Publish video on YT%' COLLATE NOCASE").fetchall():
            try:
                cur = json.loads(r["ai_buttons"]) if r["ai_buttons"] else []
            except ValueError:
                cur = []
            if not any(b.get("id") == _AI_TEXT_TIMESTAMPS["id"] for b in cur):
                self.conn.execute("UPDATE video_template_subtasks SET ai_buttons=? WHERE id=?",
                                  (json.dumps(cur + [_AI_TEXT_TIMESTAMPS], ensure_ascii=False), r["id"]))
                n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_text_timestamps_button_v1')")
        self.conn.commit()
        return n

    def seed_template_list_to_ppt_button(self):
        """One-time: the Warhammer Video template's "Create powerpoint" subtask gets the "List to PPT" AI button (flagged)."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_list_to_ppt_button_v1'").fetchone():
            return 0
        n = 0
        for r in self.conn.execute(
                "SELECT id, ai_buttons FROM video_template_subtasks WHERE template_key='warhammer_video' "
                "AND title LIKE 'Create powerpoint%' COLLATE NOCASE").fetchall():
            try:
                cur = json.loads(r["ai_buttons"]) if r["ai_buttons"] else []
            except ValueError:
                cur = []
            if not any(b.get("id") == _AI_LIST_PPT["id"] for b in cur):
                self.conn.execute("UPDATE video_template_subtasks SET ai_buttons=? WHERE id=?",
                                  (json.dumps(cur + [_AI_LIST_PPT], ensure_ascii=False), r["id"]))
                n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_list_to_ppt_button_v1')")
        self.conn.commit()
        return n

    def seed_weekly_news_setup_edit(self):
        """One-time (flagged): Weekly News's AI buttons are reorganised. "Generate Chapters" moves from "Edit A Roll" to the edit
        subtask ("Edit A Roll and Podcast", else "Edit video" / "Edit podcast and main video"), which then has only it and "Setup for editing" (note +
        captures + base edit in one go)."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='weekly_news_setup_edit_v2'").fetchone():
            return 0
        rows = self.conn.execute("SELECT id, title, ai_buttons FROM video_template_subtasks WHERE template_key='weekly_news'").fetchall()
        if not rows:
            return 0

        def btns(r):
            try:
                return json.loads(r["ai_buttons"]) if r["ai_buttons"] else []
            except ValueError:
                return []

        def put(r, lst):
            self.conn.execute("UPDATE video_template_subtasks SET ai_buttons=? WHERE id=?", (json.dumps(lst, ensure_ascii=False), r["id"]))

        low = lambda r: (r["title"] or "").strip().lower()
        edit = next((r for t in ("edit a roll and podcast", "edit video", "edit podcast and main video")
                     for r in rows if low(r) == t), None)
        if edit is None:
            self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('weekly_news_setup_edit_v2')")
            self.conn.commit()
            return 0
        if getattr(self, "_backups", None):
            try:
                self._backups.create(self.conn, "Before reorganising the Weekly News AI buttons", force=True)
            except Exception:  # noqa: BLE001 -- a failed safety copy must not block start-up
                pass
        chapters = None
        for r in rows:                                   # "Generate Chapters" wherever it is now (keeps a customised title)
            keep = []
            for b in btns(r):
                if b.get("kind") == "chapters":
                    chapters = chapters or b
                else:
                    keep.append(b)
            if len(keep) != len(btns(r)) and r["id"] != edit["id"]:
                put(r, keep)
        put(edit, [chapters or _AI_CHAPTERS, _AI_SETUP_EDIT])
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('weekly_news_setup_edit_v2')")
        self.conn.commit()
        return 1

    def seed_template_title_date(self):
        """One-time: the Weekly News Video template's task title gets the due date ("Weekly News Video 10 October")."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_title_date_v1'").fetchone():
            return 0
        cur = self.conn.execute("UPDATE video_templates SET task_title='Weekly News Video {dd} {month}' "
                                "WHERE key='weekly_news' AND task_title='Weekly News Video'")
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_title_date_v1')")
        self.conn.commit()
        return cur.rowcount

    def link_subtasks_to_templates(self):
        """One-time: tie existing subtasks of template-made tasks to their template subtask (same title, or a
        renamed one that starts with / is a start of the old title), so AI buttons survive renames."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='subtask_template_links_v1'").fetchone():
            return 0
        n = 0
        for t in self.conn.execute("SELECT id, video_template FROM tasks WHERE video_template IS NOT NULL").fetchall():
            tpl = self.get_template(t["video_template"])
            if not tpl:
                continue
            for s in self.conn.execute("SELECT id, title FROM subtasks WHERE task_id=? AND template_sub_id IS NULL",
                                       (t["id"],)).fetchall():
                w = (s["title"] or "").strip().lower()
                hit = [x for x in tpl["subtasks"] if x["title"].strip().lower() == w]
                if not hit:
                    hit = [x for x in tpl["subtasks"] if w and (x["title"].strip().lower().startswith(w)
                                                              or w.startswith(x["title"].strip().lower()))]
                if len(hit) == 1:
                    self.conn.execute("UPDATE subtasks SET template_sub_id=? WHERE id=?", (hit[0]["id"], s["id"]))
                    n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('subtask_template_links_v1')")
        self.conn.commit()
        return n

    def seed_template_chapters_button(self):
        """One-time: Weekly News's "Edit A Roll" subtask gets the "Generate Chapters" AI button (flagged, so removing it
        from the template later sticks)."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS app_flags (name TEXT PRIMARY KEY)")
        if self.conn.execute("SELECT 1 FROM app_flags WHERE name='template_chapters_button_v1'").fetchone():
            return 0
        n = 0
        btn = _AI_CHAPTERS
        for r in self.conn.execute(
                "SELECT id, ai_buttons FROM video_template_subtasks WHERE template_key='weekly_news' "
                "AND title = 'Edit A Roll' COLLATE NOCASE").fetchall():
            try:
                cur = json.loads(r["ai_buttons"]) if r["ai_buttons"] else []
            except ValueError:
                cur = []
            if not any(b.get("id") == btn["id"] for b in cur):
                self.conn.execute("UPDATE video_template_subtasks SET ai_buttons=? WHERE id=?",
                                  (json.dumps(cur + [btn], ensure_ascii=False), r["id"]))
                n += 1
        self.conn.execute("INSERT OR IGNORE INTO app_flags (name) VALUES ('template_chapters_button_v1')")
        self.conn.commit()
        return n
