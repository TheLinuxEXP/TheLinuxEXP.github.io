"""Reading tasks: hydration, smart views, counts and the calendar projection."""
from __future__ import annotations
import json
from datetime import date, timedelta

from .core import _chunks


class TaskQueryMixin:
    # -- tasks ------------------------------------------------------
    def _task_tags(self, task_id):
        return self._tags_many([task_id]).get(task_id, [])

    def _tags_many(self, task_ids):
        """{task_id: [tag, ...]} (sorted by name) in one query per 400 tasks."""
        out: dict[str, list] = {tid: [] for tid in task_ids}
        for chunk in _chunks(list(task_ids)):
            rows = self.conn.execute(
                f"SELECT tt.task_id AS _tid, g.* FROM tags g JOIN task_tags tt ON tt.tag_id = g.id "
                f"WHERE tt.task_id IN ({','.join('?' * len(chunk))}) ORDER BY g.name", chunk).fetchall()
            for r in rows:
                d = dict(r)
                out[d.pop("_tid")].append(d)
        return out

    def _hydrate_context(self, rows):
        """What hydrating `rows` needs, fetched once for all of them: tags, subtasks, and the list / project of each task."""
        ids = [r["id"] for r in rows]
        lists = {r["id"]: r for r in self.conn.execute(
            "SELECT l.id, l.name AS lname, l.project_id, p.name AS pname, p.color AS pcolor "
            "FROM todo_lists l LEFT JOIN projects p ON p.id = l.project_id").fetchall()}
        return {"tags": self._tags_many(ids), "subtasks": self.list_subtasks_many(ids), "lists": lists}

    def _hydrate(self, row, ctx=None):
        if ctx is None:
            ctx = self._hydrate_context([row])
        d = dict(row)
        d["tags"] = ctx["tags"].get(d["id"], [])
        d["recurrence"] = json.loads(d["recurrence"]) if d.get("recurrence") else None
        d["time_spent_seconds"] = self._live_elapsed_seconds(row)
        d["subtasks"] = ctx["subtasks"].get(d["id"], [])
        # Own time stays in time_spent_seconds (what the task's own timer
        # works with); total_time_seconds adds every subtask's time on top.
        d["own_time_seconds"] = d["time_spent_seconds"]
        d["total_time_seconds"] = d["time_spent_seconds"] + sum(x["time_spent_seconds"] or 0 for x in d["subtasks"])
        d["running_timers"] = (1 if row["timer_state"] == "running" else 0) + \
            sum(1 for x in d["subtasks"] if x.get("timer_state") == "running")
        lst = ctx["lists"].get(d["todo_list_id"])
        d["todo_list_name"] = lst["lname"] if lst else ""
        d["project_id"] = lst["project_id"] if lst else None
        d["project_name"] = (lst["pname"] or "") if lst and lst["pname"] is not None else ""
        d["project_color"] = lst["pcolor"] if lst and lst["pcolor"] is not None else "#3daee9"
        return d

    def _hydrate_many(self, rows):
        rows = list(rows)
        if not rows:
            return []
        ctx = self._hydrate_context(rows)
        return [self._hydrate(r, ctx) for r in rows]

    def get_task(self, task_id):
        row = self.conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        return self._hydrate(row) if row else None

    def list_tasks(self, todo_list_id=None, project_id=None, include_done=True,
                    due_date=None, no_due_date=False, urgent_only=False, include_overdue=False):
        base = "SELECT t.* FROM tasks t"
        params = []
        where = []
        if todo_list_id:
            where.append("t.todo_list_id = ?")
            params.append(todo_list_id)
        elif project_id:
            base += " JOIN todo_lists l ON l.id = t.todo_list_id"
            where.append("l.project_id = ?")
            params.append(project_id)
        if due_date:
            where.append(f"t.due_date {'<=' if include_overdue else '='} ?")
            params.append(due_date)
        if no_due_date:
            where.append("t.due_date IS NULL")
        if urgent_only:
            where.append("t.urgent = 1")
        if not include_done:
            where.append("t.checked = 0")
        if where:
            base += " WHERE " + " AND ".join(where)
        base += " ORDER BY t.checked, t.urgent DESC, (t.due_date IS NULL), t.due_date, t.sort_order"
        rows = self.conn.execute(base, params).fetchall()
        return self._hydrate_many(rows)

    def smart_view_tasks(self, due_date=None, urgent_only=False, include_done=False, include_overdue=False):
        """For the Today/Tomorrow/Urgent sidebar views: the matching main
        tasks (as list_tasks would return), with each nested subtask flagged
        `matches_filter` when that subtask itself also matches the same
        due_date/urgent filter (so the UI can auto-expand just the relevant
        ones) -- plus a separate flat list of subtasks that match the filter
        on their own but whose parent task does NOT, since those would
        otherwise never surface in this view at all. include_overdue (used by
        the Today view) widens the due_date match to "on or before", so
        overdue tasks/subtasks surface there too, not just ones due exactly
        that day.
        """
        tasks = self.list_tasks(due_date=due_date, urgent_only=urgent_only, include_done=include_done,
                                 include_overdue=include_overdue)
        # Today view (include_overdue): "show completed" is only for what was
        # completed TODAY, not every older finished task that was due before.
        only_done_on = due_date if (include_overdue and due_date) else None
        if only_done_on:
            tasks = [t for t in tasks
                     if not t.get("checked") or (t.get("completed_at") or "")[:10] == only_done_on]
        matched_task_ids = {t["id"] for t in tasks}

        def sub_matches(s):
            if due_date and s.get("due_date"):
                if include_overdue:
                    if s["due_date"] <= due_date:
                        return True
                elif s["due_date"] == due_date:
                    return True
            if urgent_only and s.get("urgent"):
                return True
            return False

        for t in tasks:
            for s in t["subtasks"]:
                s["matches_filter"] = sub_matches(s)

        where = []
        params = []
        if due_date:
            where.append(f"s.due_date {'<=' if include_overdue else '='} ?")
            params.append(due_date)
        if urgent_only:
            where.append("s.urgent = 1")
        completed_occurrences = self._completed_occurrences(due_date, urgent_only, include_overdue) if include_done else []
        if not where:
            return {"tasks": tasks, "orphan_subtasks": [], "completed_occurrences": completed_occurrences}
        if not include_done:
            where.append("s.checked = 0")
        sql = f"""
            SELECT s.*, t.title AS parent_title, t.is_video AS parent_is_video,
                   t.video_template AS parent_video_template,
                   t.id AS parent_task_id, l.project_id AS project_id
            FROM subtasks s
            JOIN tasks t ON t.id = s.task_id
            JOIN todo_lists l ON l.id = t.todo_list_id
            WHERE {" AND ".join(where)}
            ORDER BY s.checked, s.due_date, s.sort_order
        """
        rows = self.conn.execute(sql, params).fetchall()
        orphans = []
        for row in rows:
            if only_done_on and row["checked"] and (row["completed_at"] or "")[:10] != only_done_on:
                continue  # finished on another day: not part of today's completed list
            if row["parent_task_id"] in matched_task_ids:
                continue  # already visible (and flagged) under its parent task above
            proj = self.conn.execute(
                "SELECT name, color FROM projects WHERE id=?", (row["project_id"],)).fetchone()
            orphans.append({
                "id": row["id"],
                "task_id": row["task_id"],
                "title": row["title"],
                "due_date": row["due_date"],
                "duration_minutes": row["duration_minutes"],
                "start_time": row["start_time"],
                "urgent": bool(row["urgent"]),
                "checked": bool(row["checked"]),
                "is_video": bool(row["parent_is_video"]),
                "parent_video_template": row["parent_video_template"],
                "parent_task_id": row["parent_task_id"],
                "parent_title": row["parent_title"],
                "project_id": row["project_id"],
                "project_name": proj["name"] if proj else "",
                "project_color": proj["color"] if proj else "#3daee9",
                "timer_state": row["timer_state"],
                "time_spent_seconds": self._live_elapsed_seconds(row),
            })
        # The parent (main) task of every orphan subtask, so the UI can list it
        # as a collapsible row with the matching subtasks under it.
        parents, seen = [], set()
        for o in orphans:
            pid = o["parent_task_id"]
            if pid in seen:
                continue
            seen.add(pid)
            parent = self.get_task(pid)
            if not parent:
                continue
            for sub in parent["subtasks"]:
                sub["matches_filter"] = sub_matches(sub)
            parent["context_only"] = True
            parents.append(parent)
        return {"tasks": tasks, "orphan_subtasks": orphans, "orphan_parents": parents,
                "completed_occurrences": completed_occurrences}

    def _completed_occurrences(self, due_date, urgent_only, include_overdue):
        """Finished occurrences of recurring tasks relevant to a smart view,
        for its "Show completed" mode: Today = due or finished today,
        Tomorrow = due tomorrow, Urgent = urgent ones finished today."""
        today = date.today().isoformat()
        where, params = [], []
        if due_date and include_overdue:
            where.append("(c.occurrence_date = ? OR date(c.completed_at) = ?)")
            params += [due_date, due_date]
        elif due_date:
            where.append("c.occurrence_date = ?")
            params.append(due_date)
        if urgent_only:
            where.append("c.urgent = 1 AND date(c.completed_at) = ?")
            params.append(today)
        if not where:
            return []
        rows = self.conn.execute(f"""
            SELECT c.*, t.is_video, t.video_template, l.name AS todo_list_name, l.project_id,
                   p.name AS project_name, p.color AS project_color
            FROM task_completions c
            JOIN tasks t ON t.id = c.task_id
            JOIN todo_lists l ON l.id = t.todo_list_id
            JOIN projects p ON p.id = l.project_id
            WHERE c.time_only = 0 AND {" AND ".join(where)}
            ORDER BY c.completed_at DESC
        """, params).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["subtasks"] = json.loads(d.pop("subtasks_json") or "[]")
            except (ValueError, TypeError):
                d["subtasks"] = []
            out.append(d)
        return out

    def smart_counts(self, today_iso, tomorrow_iso):
        """Open (unchecked) task counts for the Inbox/Today/Tomorrow/Urgent
        sidebar entries, in one round trip. Today/Tomorrow/Urgent also count
        open subtasks matching on their own (even under a parent task that
        doesn't itself match). A main task with subtasks that are all done is left out: nothing remains to do on it."""
        def count(where, params=()):
            return self.conn.execute(f"SELECT COUNT(*) FROM tasks WHERE checked = 0 AND {where}", params).fetchone()[0]

        def count_with_subtasks(task_where, sub_where, params):
            # A main task whose subtasks are all done has nothing left to do (it only waits to be ticked): not counted.
            task_ids = {r[0] for r in self.conn.execute(
                f"SELECT id FROM tasks WHERE checked = 0 AND {task_where} "
                "AND (NOT EXISTS (SELECT 1 FROM subtasks s WHERE s.task_id = tasks.id) "
                "OR EXISTS (SELECT 1 FROM subtasks s WHERE s.task_id = tasks.id AND s.checked = 0))", params).fetchall()}
            n = len(task_ids)
            sub_rows = self.conn.execute(
                f"SELECT task_id FROM subtasks WHERE checked = 0 AND {sub_where}", params).fetchall()
            for r in sub_rows:
                if r[0] not in task_ids:
                    n += 1
            return n

        return {
            "inbox": count("due_date IS NULL"),
            "today": count_with_subtasks("due_date <= ?", "due_date <= ?", (today_iso,)),
            "tomorrow": count_with_subtasks("due_date = ?", "due_date = ?", (tomorrow_iso,)),
            "urgent": count_with_subtasks("urgent = 1", "urgent = 1", ()),
        }

    def tasks_in_range(self, start_iso, end_iso):
        """All tasks (any project/list) due within [start_iso, end_iso] inclusive."""
        rows = self.conn.execute(
            "SELECT * FROM tasks WHERE due_date IS NOT NULL AND due_date >= ? AND due_date <= ? "
            "ORDER BY due_date, urgent DESC",
            (start_iso, end_iso)).fetchall()
        return self._hydrate_many(rows)

    def calendar_entries(self, start_iso, end_iso, only_videos=False):
        """Tasks landing within [start_iso, end_iso], expanding recurring tasks
        into a virtual occurrence for every date the rule lands on in range —
        not just the single stored due_date, which only tracks the *next*
        occurrence. A recurring task whose stored due_date predates the range
        is still projected forward into it. Returns {iso_date: [task, ...]}.

        only_videos (month view "Only show videos"): main tasks of the Video type
        only -- including those that have subtasks (normally represented by their
        subtasks alone) -- and no subtask entries at all.
        """
        from .. import recurrence as rec
        start_d = date.fromisoformat(start_iso)
        end_d = date.fromisoformat(end_iso)
        # Candidates: anything due by the end of the range that either falls
        # inside it directly, or recurs (and so might project into it from an
        # earlier due_date).
        rows = self.conn.execute(
            "SELECT * FROM tasks WHERE due_date IS NOT NULL AND (due_date <= ? OR occ_base IS NOT NULL) "
            "AND (recurrence IS NOT NULL OR due_date >= ?)",
            (end_iso, start_iso)).fetchall()
        by_day: dict[str, list] = {}
        ctx = self._hydrate_context(rows) if rows else None
        for row in rows:
            task = self._hydrate(row, ctx)
            # A task with subtasks is represented on the calendar by its
            # subtasks (added below), not by itself -- showing both would be
            # redundant, and the subtasks carry the actual scheduled times.
            if only_videos:
                if not task["is_video"]:
                    continue
            elif task["subtasks"]:
                continue
            rule = task["recurrence"]
            due = date.fromisoformat(row["due_date"])
            if not rule:
                if start_d <= due <= end_d:
                    by_day.setdefault(due.isoformat(), []).append(task)
                continue
            # An occurrence dragged elsewhere is shown where it now sits; the
            # rest of the series keeps counting from where it originally was.
            base = None
            try:
                base = json.loads(row["occ_base"]) if row["occ_base"] else None
            except ValueError:
                base = None
            base_due = date.fromisoformat(base["due_date"]) if base and base.get("due_date") else due
            if base_due != due or (base and base.get("start_time") != row["start_time"]):
                if start_d <= due <= end_d:
                    entry = dict(task)
                    entry["is_projected"] = False
                    by_day.setdefault(due.isoformat(), []).append(entry)
            else:
                base = None
            moves = {m["orig_date"]: m for m in self.conn.execute(
                "SELECT * FROM occurrence_moves WHERE task_id=?", (row["id"],)).fetchall()}
            occ, occ_no, guard = base_due, row["occurrence_no"], 0
            # (a moved occurrence may sit up to a few weeks away from where the series has it)
            while occ <= end_d + timedelta(days=60 if moves else 0) and guard < 500:
                guard += 1
                if not (base is not None and occ == base_due):
                    entry = dict(task)
                    entry["due_date"] = occ.isoformat()
                    entry["is_projected"] = occ != base_due
                    entry["occurrence_date"] = occ.isoformat()
                    if base is not None:
                        entry["start_time"] = base.get("start_time")
                    mv = moves.get(occ.isoformat()) if occ != base_due else None
                    if mv:
                        entry["due_date"] = mv["new_date"]
                        entry["start_time"] = mv["new_time"]
                    shown = date.fromisoformat(entry["due_date"])
                    if start_d <= shown <= end_d:
                        by_day.setdefault(shown.isoformat(), []).append(entry)
                nxt = rec.next_occurrence(occ, rule, occ_no)
                if not nxt or nxt <= occ:
                    break
                occ_no += 1
                occ = nxt

        # Subtasks have their own due date/duration/urgency and no recurrence
        # of their own; they inherit the video flag from their parent task,
        # and show up in the calendar as their own entries.
        sub_rows = self.conn.execute("""
            SELECT s.*, t.is_video AS parent_is_video, t.title AS parent_title,
                   l.project_id AS project_id
            FROM subtasks s
            JOIN tasks t ON t.id = s.task_id
            JOIN todo_lists l ON l.id = t.todo_list_id
            WHERE s.due_date IS NOT NULL AND s.due_date >= ? AND s.due_date <= ?
        """, (start_iso, end_iso)).fetchall()
        proj_cache: dict = {}
        for row in sub_rows:
            pid = row["project_id"]
            if pid not in proj_cache:
                p = self.conn.execute("SELECT name, color FROM projects WHERE id=?", (pid,)).fetchone()
                proj_cache[pid] = (p["name"], p["color"]) if p else ("", "#3daee9")
            proj_name, proj_color = proj_cache[pid]
            entry = {
                "id": row["id"],
                "task_id": row["task_id"],
                "title": row["title"],
                "due_date": row["due_date"],
                "duration_minutes": row["duration_minutes"],
                "start_time": row["start_time"],
                "urgent": bool(row["urgent"]),
                "checked": bool(row["checked"]),
                "is_video": bool(row["parent_is_video"]),
                "is_subtask": True,
                "parent_task_id": row["task_id"],
                "parent_title": row["parent_title"],
                "project_id": pid,
                "project_name": proj_name,
                "project_color": proj_color,
                "timer_state": row["timer_state"],
                "time_spent_seconds": self._live_elapsed_seconds(row),
            }
            by_day.setdefault(row["due_date"], []).append(entry)

        # Finished occurrences of recurring tasks stay on the calendar, on
        # the day they were due, as done (read-only) entries -- the task row
        # itself has already rolled forward to its next occurrence.
        for c in self.conn.execute("""
            SELECT c.*, t.is_video, t.video_template, t.todo_list_id, t.duration_minutes AS series_duration,
                   t.start_time AS live_start_time, t.occ_base AS live_occ_base,
                   l.project_id, p.name AS project_name, p.color AS project_color, l.name AS todo_list_name
            FROM task_completions c
            JOIN tasks t ON t.id = c.task_id
            JOIN todo_lists l ON l.id = t.todo_list_id
            JOIN projects p ON p.id = l.project_id
            WHERE c.time_only = 0 AND c.occurrence_date IS NOT NULL AND c.occurrence_date >= ? AND c.occurrence_date <= ?
        """, (start_iso, end_iso)).fetchall():
            try:
                snap = json.loads(c["subtasks_json"] or "[]")
            except (ValueError, TypeError):
                snap = []
            occ_info = {
                "completion_id": c["id"], "occurrence_date": c["occurrence_date"],
                "occurrence_title": c["title"], "completed_at": c["completed_at"],
                "subtasks_snapshot": snap, "is_completed_occurrence": True,
                "is_video": bool(c["is_video"]), "video_template": c["video_template"],
                "project_id": c["project_id"], "project_name": c["project_name"],
                "project_color": c["project_color"], "todo_list_name": c["todo_list_name"],
                "task_id": c["task_id"], "time_spent_seconds": c["time_spent_seconds"] or 0,
                "occurrence_time_seconds": c["time_spent_seconds"] or 0,
            }
            # The subtasks the occurrence had when it finished stay on the
            # calendar too, on their own days (the live subtasks have since
            # moved on to the next occurrence).
            for x in snap:
                xd = x.get("due_date")
                if not xd or not (start_iso <= xd <= end_iso):
                    continue
                if any(e.get("id") == x.get("id") and e.get("is_subtask") for e in by_day.get(xd, [])):
                    continue
                by_day.setdefault(xd, []).append({
                    **occ_info,
                    "id": x.get("id"), "is_subtask": True, "parent_task_id": c["task_id"],
                    "parent_title": c["title"], "title": x.get("title") or "?", "due_date": xd,
                    "duration_minutes": x.get("duration_minutes"), "start_time": x.get("start_time"),
                    "urgent": bool(x.get("urgent")), "checked": bool(x.get("checked")),
                    "timer_state": "idle", "time_spent_seconds": x.get("time_spent_seconds") or 0,
                })
            # The time it ran at: stored when it finished; for older ones, the
            # series' own time (never a time the current occurrence was dragged to).
            slot_start = c["slot_start_time"]
            if slot_start is None:
                try:
                    ob = json.loads(c["live_occ_base"]) if c["live_occ_base"] else None
                except ValueError:
                    ob = None
                slot_start = ob["start_time"] if ob and "start_time" in ob else c["live_start_time"]
            by_day.setdefault(c["occurrence_date"], []).append({
                "id": c["task_id"], "task_id": c["task_id"], "completion_id": c["id"],
                "occurrence_date": c["occurrence_date"], "subtasks_snapshot": snap,
                "title": c["title"], "due_date": c["occurrence_date"],
                "duration_minutes": c["slot_duration"] if c["slot_duration"] is not None else c["series_duration"],
                "start_time": slot_start,
                "urgent": bool(c["urgent"]), "checked": True, "completed_at": c["completed_at"],
                "is_video": bool(c["is_video"]), "video_template": c["video_template"],
                "is_completed_occurrence": True, "recurrence": None, "subtasks": [], "tags": [],
                "project_id": c["project_id"], "project_name": c["project_name"],
                "project_color": c["project_color"], "todo_list_id": c["todo_list_id"],
                "todo_list_name": c["todo_list_name"],
                "timer_state": "idle", "time_spent_seconds": c["time_spent_seconds"] or 0,
            })

        if only_videos:
            by_day = {d: [e for e in es if e.get("is_video") and not e.get("is_subtask")] for d, es in by_day.items()}
            by_day = {d: es for d, es in by_day.items() if es}
        for day_entries in by_day.values():
            day_entries.sort(key=lambda t: (bool(t.get("checked")), not t.get("urgent"), t.get("is_subtask", False)))
        return by_day
