"""Backups: automatic snapshots, listing, diff and restore."""
from __future__ import annotations
from .core import _BACKUP_LABELS


class BackupsMixin:
    # -- backups ---------------------------------------------------------
    def _auto_backup(self, method, args, kwargs, result):
        try:
            self._backups.create(self.conn, self._backup_reason(method, args, kwargs, result))
        except Exception:  # noqa: BLE001 - a failed backup must never break the change itself
            import traceback
            traceback.print_exc()

    def _backup_reason(self, method, args, kwargs, result):
        if method in ("toggle_task", "toggle_subtask"):
            checked = args[1] if len(args) > 1 else kwargs.get("checked")
            what = "Task" if method == "toggle_task" else "Subtask"
            base = f"{what} {'completed' if checked else 'reopened'}"
            if method == "toggle_task" and result == "recurred":
                base = "Recurring task completed"
        else:
            base = _BACKUP_LABELS.get(method, method)
        ident = args[0] if args and isinstance(args[0], str) else (result if isinstance(result, str) else None)
        title = None
        if ident:
            for table, col in (("tasks", "title"), ("subtasks", "title"), ("projects", "name"), ("todo_lists", "name")):
                r = self.conn.execute(f"SELECT {col} FROM {table} WHERE id=?", (ident,)).fetchone()
                if r:
                    title = r[0]
                    break
        if title is None and method.startswith(("add_", "create_")) and args:
            title = next((a for a in args[1:] if isinstance(a, str)), None)
        reason = f"{base}: {title}" if title else base
        if method in ("update_task", "update_subtask") and kwargs:
            reason += f" ({', '.join(sorted(kwargs))})"
        return reason

    def create_backup(self, reason="Manual backup"):
        return self._backups.create(self.conn, reason, force=True)

    def list_backups(self):
        return [{k: v for k, v in m.items() if k != "fingerprint"} for m in self._backups.list()]

    def delete_old_backups(self, days):
        return self._backups.delete_older_than(int(days))

    def backup_diff(self, bid):
        from ..backups import diff_tables, dump_tables
        data = self._backups.load(bid)
        if not data:
            return None
        return {"backup": {k: v for k, v in data["meta"].items() if k != "fingerprint"},
                "diff": diff_tables(data["tables"], dump_tables(self.conn))}

    def restore_backup(self, bid):
        """Replace ALL data with the contents of backup `bid`. The current
        state is backed up first, so a restore can itself be undone."""
        from ..backups import dump_tables
        data = self._backups.load(bid)
        if not data:
            return None
        self._backups.create(self.conn, f"Before restoring backup of {data['meta']['created_at']}", force=True)
        current = dump_tables(self.conn)
        self.conn.real_commit()     # PRAGMA foreign_keys is ignored inside a transaction
        self.conn.execute("PRAGMA foreign_keys = OFF")
        try:
            self.conn.execute("BEGIN")
            for t in current:
                self.conn.execute(f'DELETE FROM "{t}"')
            for t, rows in data["tables"].items():
                if t not in current or not rows:
                    continue
                cols_now = [r["name"] for r in self.conn.execute(f'PRAGMA table_info("{t}")')]
                for row in rows:
                    cols = [c for c in cols_now if c in row]
                    self.conn.execute(
                        f'INSERT INTO "{t}" ({",".join(chr(34) + c + chr(34) for c in cols)}) '
                        f'VALUES ({",".join("?" * len(cols))})', [row[c] for c in cols])
            self.conn.real_commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            self.conn.execute("PRAGMA foreign_keys = ON")
        self._ensure_default_project()
        self._seed_templates()          # a backup from before templates were editable has none
        return data["meta"]
