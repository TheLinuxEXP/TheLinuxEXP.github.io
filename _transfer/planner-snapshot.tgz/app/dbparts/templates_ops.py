"""Video templates (the '+' button)."""
from __future__ import annotations
import re
import json
from datetime import date, timedelta
from .core import TEMPLATES, new_id


_EN_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September",
              "October", "November", "December"]


def expand_title(pattern, due):
    """Remplace {dd} {mm} {month} {yy} {yyyy} par la date d'échéance (« Weekly News Video {dd} {month} » ->
    « Weekly News Video 10 October »). Sans date, les marques sont retirées. Même vocabulaire que le nom de note."""
    if "{" not in (pattern or ""):
        return pattern
    if due is None:
        return re.sub(r"\s*\{(dd|mm|month|yy|yyyy)\}", "", pattern).strip()
    return (pattern.replace("{dd}", f"{due.day:02d}").replace("{mm}", f"{due.month:02d}")
            .replace("{month}", _EN_MONTHS[due.month - 1]).replace("{yyyy}", str(due.year))
            .replace("{yy}", f"{due.year % 100:02d}"))


def _norm(text):
    import unicodedata
    t = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "", t)


class TemplatesMixin:
    def _target_list_id(self, key):
        """The fixed list a template creates its task in (core.TEMPLATES[key]["target_list"] = (project, list)),
        or None when it has none / the project or list doesn't exist. The project name is matched loosely
        (accents, case, small typos)."""
        spec = (TEMPLATES.get(key) or {}).get("target_list")
        if not spec:
            return None
        import difflib
        want_p, want_l = _norm(spec[0]), _norm(spec[1])
        projects = self.conn.execute("SELECT id, name FROM projects").fetchall()
        exact = [p for p in projects if _norm(p["name"]) == want_p]
        if not exact:
            scored = sorted(((difflib.SequenceMatcher(None, _norm(p["name"]), want_p).ratio(), p) for p in projects),
                            key=lambda x: -x[0])
            exact = [p for r, p in scored if r >= 0.8] or [p for p in projects if "ctan" in _norm(p["name"])]
        for p in exact:
            for l in self.conn.execute("SELECT id, name FROM todo_lists WHERE project_id=? ORDER BY sort_order", (p["id"],)).fetchall():
                if _norm(l["name"]) in (want_l, want_l.rstrip("s")):
                    return l["id"]
        return None

    # -- video templates -------------------------------------------------
    @staticmethod
    def _next_weekday_strictly_after(after_date, weekday):
        """First date after `after_date` (never `after_date` itself) landing
        on the given weekday (Mon=0..Sun=6)."""
        days_ahead = (weekday - after_date.weekday()) % 7
        if days_ahead == 0:
            days_ahead = 7
        return after_date + timedelta(days=days_ahead)

    def _video_date_taken(self, due_date_iso):
        """A video task (finished or not) is already due that day."""
        return self.conn.execute(
            "SELECT 1 FROM tasks WHERE is_video = 1 AND substr(due_date, 1, 10) = ? LIMIT 1",
            (due_date_iso,)).fetchone() is not None

    def _title_date_taken(self, title, due_date_iso):
        row = self.conn.execute(
            "SELECT 1 FROM tasks WHERE title = ? COLLATE NOCASE AND due_date = ? LIMIT 1",
            (title, due_date_iso)).fetchone()
        return row is not None

    # The editable definition of every template lives in the video_templates /
    # video_template_subtasks tables; TEMPLATES (core.py) only provides the
    # built-in defaults used to seed them and for "Reset to default".
    def _insert_template(self, key, tpl, builtin, sort_order):
        self.conn.execute(
            "INSERT INTO video_templates (key, label, icon, menu_icon, task_title, main_weekday, is_video, "
            "note_title, builtin, sort_order) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (key, tpl["label"], tpl.get("icon"), tpl.get("menu_icon"), tpl["task_title"],
             tpl.get("main_weekday"), int(tpl.get("is_video", True)), tpl.get("note_title"),
             int(builtin), sort_order))
        self._set_template_subtasks(key, tpl.get("subtasks", []))

    def _set_template_subtasks(self, key, subtasks):
        self.conn.execute("DELETE FROM video_template_subtasks WHERE template_key=?", (key,))
        used = set()
        for i, s in enumerate(subtasks):
            # Keep the subtask's id across saves (so tasks created from it stay linked even if it is renamed);
            # a missing, repeated or foreign id (e.g. a duplicated template) gets a fresh one.
            sid = str(s.get("id") or "")
            if (not sid or sid in used
                    or self.conn.execute("SELECT 1 FROM video_template_subtasks WHERE id=?", (sid,)).fetchone()):
                sid = new_id()
            used.add(sid)
            self.conn.execute(
                "INSERT INTO video_template_subtasks (id, template_key, position, title, duration, offset_days, "
                "start_time, ai_buttons) VALUES (?,?,?,?,?,?,?,?)",
                (sid, key, i, s["title"], s.get("duration"), s.get("offset_days"), s.get("start_time"),
                 json.dumps(s.get("ai_buttons") or [], ensure_ascii=False)))

    def _seed_templates(self):
        """Fill the table with the built-in templates when it is empty (first
        run, or after restoring a backup that predates the feature)."""
        if self.conn.execute("SELECT 1 FROM video_templates LIMIT 1").fetchone():
            return
        for i, (key, tpl) in enumerate(TEMPLATES.items()):
            self._insert_template(key, tpl, True, i)
        self.conn.commit()

    def _template_row(self, r):
        subs = self.conn.execute(
            "SELECT id, title, duration, offset_days, start_time, ai_buttons FROM video_template_subtasks "
            "WHERE template_key=? ORDER BY position", (r["key"],)).fetchall()
        subtasks = []
        for x in subs:
            d = dict(x)
            try:
                d["ai_buttons"] = json.loads(d["ai_buttons"]) if d["ai_buttons"] else []
            except ValueError:
                d["ai_buttons"] = []
            subtasks.append(d)
        return {
            "key": r["key"], "label": r["label"], "icon": r["icon"] or "", "menu_icon": r["menu_icon"] or "",
            "task_title": r["task_title"], "main_weekday": r["main_weekday"], "is_video": bool(r["is_video"]),
            "note_title": r["note_title"] or "", "builtin": bool(r["builtin"]),
            "target_list_id": self._target_list_id(r["key"]),
            "subtasks": subtasks,
        }

    def list_templates(self):
        rows = self.conn.execute("SELECT * FROM video_templates ORDER BY sort_order, label").fetchall()
        return [self._template_row(r) for r in rows]

    def get_template(self, key):
        r = self.conn.execute("SELECT * FROM video_templates WHERE key=?", (key,)).fetchone()
        return self._template_row(r) if r else None

    def list_templates_keys(self):
        return {r["key"] for r in self.conn.execute("SELECT key FROM video_templates").fetchall()}

    def add_template(self, tpl):
        """Create a new (custom) template; returns its key."""
        import re as _re
        base = _re.sub(r"[^a-z0-9]+", "_", tpl["label"].lower()).strip("_")[:40] or "template"
        key, n = base, 2
        while self.conn.execute("SELECT 1 FROM video_templates WHERE key=?", (key,)).fetchone():
            key = f"{base}_{n}"
            n += 1
        order = self.conn.execute("SELECT COALESCE(MAX(sort_order), -1) + 1 FROM video_templates").fetchone()[0]
        self._insert_template(key, tpl, False, order)
        self.conn.commit()
        return key

    def save_template(self, key, tpl):
        """Replace a template's properties and its whole subtask list."""
        if not self.conn.execute("SELECT 1 FROM video_templates WHERE key=?", (key,)).fetchone():
            return None
        self.conn.execute(
            "UPDATE video_templates SET label=?, icon=?, menu_icon=?, task_title=?, main_weekday=?, is_video=?, "
            "note_title=? WHERE key=?",
            (tpl["label"], tpl.get("icon"), tpl.get("menu_icon"), tpl["task_title"], tpl.get("main_weekday"),
             int(tpl.get("is_video", True)), tpl.get("note_title"), key))
        self._set_template_subtasks(key, tpl.get("subtasks", []))
        self.conn.commit()
        return key

    def delete_template(self, key):
        """Custom templates only; tasks already created from it keep working."""
        r = self.conn.execute("SELECT builtin FROM video_templates WHERE key=?", (key,)).fetchone()
        if not r:
            return False
        if r["builtin"]:
            raise ValueError("The built-in templates can't be deleted (you can reset them to their defaults).")
        self.conn.execute("DELETE FROM video_template_subtasks WHERE template_key=?", (key,))
        self.conn.execute("DELETE FROM video_templates WHERE key=?", (key,))
        self.conn.commit()
        return True

    def reset_template(self, key):
        if key not in TEMPLATES:
            raise ValueError("Only the built-in templates have defaults to go back to.")
        tpl = TEMPLATES[key]
        if self.conn.execute("SELECT 1 FROM video_templates WHERE key=?", (key,)).fetchone():
            self.conn.execute(
                "UPDATE video_templates SET label=?, icon=?, menu_icon=?, task_title=?, main_weekday=?, is_video=1, "
                "note_title=? WHERE key=?",
                (tpl["label"], tpl.get("icon"), tpl.get("menu_icon"), tpl["task_title"], tpl.get("main_weekday"),
                 tpl.get("note_title"), key))
            self._set_template_subtasks(key, tpl["subtasks"])
        else:
            order = self.conn.execute("SELECT COALESCE(MAX(sort_order), -1) + 1 FROM video_templates").fetchone()[0]
            self._insert_template(key, tpl, True, order)
        self.conn.commit()
        return key

    def reorder_templates(self, keys):
        for i, k in enumerate(keys):
            self.conn.execute("UPDATE video_templates SET sort_order=? WHERE key=?", (i, k))
        self.conn.commit()

    def create_from_template(self, todo_list_id, key):
        tpl = self.get_template(key)
        if not tpl:
            raise KeyError(key)
        # A template with no main weekday is created with no due date at all,
        # and its subtasks aren't scheduled either -- there's no main date
        # left to offset them from.
        candidate = None
        due_date = None
        if tpl["main_weekday"] is not None:
            # nearest such weekday from today on (today included), skipping days that already
            # have a video task due; other (non-video) templates only avoid an identical title
            today = date.today()
            candidate = today + timedelta(days=(tpl["main_weekday"] - today.weekday()) % 7)
            taken = ((lambda c: self._video_date_taken(c.isoformat())) if tpl["is_video"] else
                     (lambda c: self._title_date_taken(expand_title(tpl["task_title"], c), c.isoformat())))
            while taken(candidate):
                candidate += timedelta(days=7)
            due_date = candidate.isoformat()
        todo_list_id = self._target_list_id(key) or todo_list_id
        tid = self.add_task(todo_list_id, expand_title(tpl["task_title"], candidate), due_date=due_date, is_video=tpl["is_video"],
                             video_template=key)
        for s in tpl["subtasks"]:
            sub_due = ((candidate + timedelta(days=s["offset_days"])).isoformat()
                       if candidate and s.get("offset_days") is not None else None)
            self.add_subtask(tid, s["title"], due_date=sub_due, duration_minutes=s["duration"],
                              start_time=s.get("start_time"), template_sub_id=s["id"])
        return tid
