"""Writing tasks: create, update, move/finish occurrences, toggle, attachments."""
from __future__ import annotations
import json
from datetime import date, datetime, timedelta
from .core import _stamp_anchor, new_id


class TaskWriteMixin:
    def search_tasks(self, term):
        like = f"%{term}%"
        rows = self.conn.execute(
            "SELECT * FROM tasks WHERE title LIKE ? OR notes LIKE ? ORDER BY checked, due_date",
            (like, like)).fetchall()
        return self._hydrate_many(rows)

    def add_task(self, todo_list_id, title, notes="", due_date=None, urgent=False,
                 duration_minutes=None, is_video=False, recurrence=None, tag_ids=None, start_time=None,
                 video_template=None):
        tid = new_id()
        order = self.conn.execute(
            "SELECT COALESCE(MAX(sort_order), 0) + 1 FROM tasks WHERE todo_list_id=?",
            (todo_list_id,)).fetchone()[0]
        self.conn.execute("""
            INSERT INTO tasks (id, todo_list_id, title, notes, due_date, urgent, duration_minutes,
                                is_video, recurrence, start_time, video_template, sort_order, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (tid, todo_list_id, title, notes, due_date, int(bool(urgent)), duration_minutes,
              int(bool(is_video)), json.dumps(_stamp_anchor(recurrence, due_date)) if recurrence else None, start_time, video_template,
              order, datetime.now().isoformat()))
        for gid in (tag_ids or []):
            self.conn.execute("INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?,?)", (tid, gid))
        self.conn.commit()
        return tid

    def _occ_base(self, row):
        try:
            return json.loads(row["occ_base"]) if row["occ_base"] else None
        except ValueError:
            return None

    def _base_due(self, row):
        """The date the series counts from: where this occurrence originally sat."""
        b = self._occ_base(row)
        return (b or {}).get("due_date") or row["due_date"]

    def move_occurrence(self, kind, eid, due_date=None, start_time=None, set_time=False):
        """Move ONE occurrence (a calendar drag): change this occurrence's date
        and/or time but leave the rest of a recurring series where it was. The
        original slot is remembered in occ_base and used when the occurrence is
        finished, so the next one is computed from it. Non-recurring items just
        move. `set_time` says start_time was given (None then means 'clear')."""
        table = "tasks" if kind == "task" else "subtasks"
        row = self.conn.execute(f"SELECT * FROM {table} WHERE id=?", (eid,)).fetchone()
        if not row:
            return
        task_row = row if kind == "task" else self.conn.execute(
            "SELECT * FROM tasks WHERE id=?", (row["task_id"],)).fetchone()
        fields = {}
        if due_date:
            fields["due_date"] = due_date
        if set_time:
            fields["start_time"] = start_time
        if not (task_row and task_row["recurrence"]):
            if kind == "task":
                self.update_task(eid, **fields)
            else:
                self.update_subtask(eid, **fields)
            return
        base = self._occ_base(row) or {"due_date": row["due_date"], "start_time": row["start_time"]}
        new_due = fields.get("due_date", row["due_date"])
        new_time = fields.get("start_time", row["start_time"])
        back_home = new_due == base["due_date"] and (new_time or None) == (base["start_time"] or None)
        fields["occ_base"] = None if back_home else json.dumps(base)
        self._update(table, eid, fields)

    def move_projected_occurrence(self, tid, orig_date, new_date=None, new_time=None, set_time=False):
        """Drag of a FUTURE occurrence of a recurring task: remember where it
        was moved; the series itself is untouched. Back on its own slot = no override."""
        row = self.conn.execute("SELECT recurrence, start_time FROM tasks WHERE id=?", (tid,)).fetchone()
        if not row or not row["recurrence"]:
            return
        cur = self.conn.execute("SELECT * FROM occurrence_moves WHERE task_id=? AND orig_date=?",
                                (tid, orig_date)).fetchone()
        date_ = new_date or (cur["new_date"] if cur else orig_date)
        time_ = new_time if set_time else (cur["new_time"] if cur else row["start_time"])
        if date_ == orig_date and (time_ or None) == (row["start_time"] or None):
            self.conn.execute("DELETE FROM occurrence_moves WHERE task_id=? AND orig_date=?", (tid, orig_date))
        else:
            self.conn.execute(
                "INSERT INTO occurrence_moves(task_id, orig_date, new_date, new_time) VALUES (?,?,?,?) "
                "ON CONFLICT(task_id, orig_date) DO UPDATE SET new_date=excluded.new_date, new_time=excluded.new_time",
                (tid, orig_date, date_, time_))
        self.conn.commit()

    def update_task(self, tid, **fields):
        if "recurrence" in fields or "due_date" in fields:
            # (re)stamp the day-of-month anchor when the user edits the rule or the date
            cur = self.conn.execute("SELECT recurrence, due_date FROM tasks WHERE id=?", (tid,)).fetchone()
            if cur:
                rule = fields["recurrence"] if "recurrence" in fields else (
                    json.loads(cur["recurrence"]) if cur["recurrence"] else None)
                if isinstance(rule, str):
                    try:
                        rule = json.loads(rule)
                    except ValueError:
                        rule = None
                due = fields["due_date"] if "due_date" in fields else cur["due_date"]
                if rule:
                    if isinstance(rule, dict):
                        rule.pop("anchor_day", None)
                    fields["recurrence"] = _stamp_anchor(rule, due)
        if "recurrence" in fields and fields["recurrence"] is not None and not isinstance(fields["recurrence"], str):
            fields["recurrence"] = json.dumps(fields["recurrence"]) if fields["recurrence"] else None
        if "urgent" in fields:
            fields["urgent"] = int(bool(fields["urgent"]))
        if "is_video" in fields:
            fields["is_video"] = int(bool(fields["is_video"]))
        if "mention_approved" in fields:
            fields["mention_approved"] = int(bool(fields["mention_approved"]))

        # If a video task's (or weekly-news video's) due date is moved, shift
        # every subtask's own due date by the same number of days, so each
        # keeps the same offset from the main task it had before -- the same
        # offset_days logic used to place subtask dates when the task was
        # first created from a template.
        shift_days = None
        if "due_date" in fields and fields["due_date"]:
            row = self.conn.execute("SELECT due_date, is_video FROM tasks WHERE id=?", (tid,)).fetchone()
            if row and row["is_video"] and row["due_date"]:
                try:
                    old = date.fromisoformat(row["due_date"])
                    new = date.fromisoformat(fields["due_date"])
                    if old != new:
                        shift_days = (new - old).days
                except ValueError:
                    shift_days = None

        self._update("tasks", tid, fields)

        if shift_days:
            subs = self.conn.execute(
                "SELECT id, due_date FROM subtasks WHERE task_id=? AND due_date IS NOT NULL", (tid,)).fetchall()
            for s in subs:
                try:
                    shifted = (date.fromisoformat(s["due_date"]) + timedelta(days=shift_days)).isoformat()
                except ValueError:
                    continue
                self.conn.execute("UPDATE subtasks SET due_date=? WHERE id=?", (shifted, s["id"]))
            if subs:
                self.conn.commit()

    def delete_task(self, tid):
        self._queue_task_files("id=?", (tid,))
        self.conn.execute("DELETE FROM time_log WHERE task_id=?", (tid,))
        self.conn.execute("DELETE FROM occurrence_moves WHERE task_id=?", (tid,))
        self.conn.execute("DELETE FROM tasks WHERE id=?", (tid,))
        self.conn.commit()

    def set_task_tags(self, tid, tag_ids):
        self.conn.execute("DELETE FROM task_tags WHERE task_id=?", (tid,))
        for gid in tag_ids:
            self.conn.execute("INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?,?)", (tid, gid))
        self.conn.commit()

    def _finish_occurrence(self, tid, row, nxt, occ_inc=1):
        """Record the current occurrence of a recurring task as finished
        (task time + a snapshot of its subtasks), then roll the task to `nxt`
        with fresh timers and unchecked subtasks."""
        # Record this occurrence as finished (with the time spent on
        # it, attributed to the day it was due), then roll the task
        # forward with a fresh timer for the next occurrence.
        self.stop_timer("tasks", tid)
        spent = self._timer_row("tasks", tid)["time_spent_seconds"] or 0
        # Snapshot the subtasks as they were when this occurrence
        # finished, so they can be shown under it afterwards.
        snap = [{"id": x["id"], "title": x["title"], "checked": bool(x["checked"]),
                 "due_date": x["due_date"], "duration_minutes": x["duration_minutes"],
                 "start_time": x["start_time"], "urgent": bool(x["urgent"]),
                 "time_spent_seconds": x["time_spent_seconds"]}
                for x in self.list_subtasks(tid)]
        self.conn.execute(
            "INSERT INTO task_completions (id, task_id, title, occurrence_date, completed_at, "
            "time_spent_seconds, urgent, subtasks_json, slot_start_time, slot_duration) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (new_id(), tid, row["title"], row["due_date"], datetime.now().isoformat(),
             spent, row["urgent"], json.dumps(snap), row["start_time"], row["duration_minutes"]))
        base = self._occ_base(row)
        self.conn.execute(
            "UPDATE tasks SET due_date=?, occurrence_no=occurrence_no+?, time_spent_seconds=0, "
            "timer_started_at=NULL, timer_state='idle', time_day=NULL, occ_base=NULL WHERE id=?",
            (nxt.isoformat(), occ_inc, tid))
        if base and "start_time" in base:           # the next occurrence is back on the series' own time
            self.conn.execute("UPDATE tasks SET start_time=? WHERE id=?", (base["start_time"], tid))
        mv = self.conn.execute("SELECT * FROM occurrence_moves WHERE task_id=? AND orig_date=?",
                               (tid, nxt.isoformat())).fetchone()
        if mv:      # this next occurrence had been dragged elsewhere: it becomes the current one, there
            series_time = self.conn.execute("SELECT start_time FROM tasks WHERE id=?", (tid,)).fetchone()["start_time"]
            self.conn.execute("UPDATE tasks SET due_date=?, start_time=?, occ_base=? WHERE id=?",
                              (mv["new_date"], mv["new_time"], json.dumps({"due_date": nxt.isoformat(), "start_time": series_time}), tid))
            self.conn.execute("DELETE FROM occurrence_moves WHERE task_id=? AND orig_date=?", (tid, nxt.isoformat()))
        # Each occurrence has its own subtasks: reset them (unchecked,
        # fresh timers) and move their due dates forward by the same
        # shift as the task, keeping their offsets.
        try:
            shift = (nxt - date.fromisoformat(self._base_due(row))).days
        except ValueError:
            shift = 0
        for x in self.conn.execute("SELECT id, due_date, due_rule, occ_base FROM subtasks WHERE task_id=?", (tid,)).fetchall():
            xb = self._occ_base(x)
            new_due = (xb or {}).get("due_date") or x["due_date"]      # an individually dragged subtask: back to its own slot
            ruled = self._due_from_rule(x["due_rule"], nxt)
            if ruled:
                new_due = ruled
            elif new_due and shift:
                try:
                    new_due = (date.fromisoformat(new_due) + timedelta(days=shift)).isoformat()
                except ValueError:
                    pass
            self.stop_timer("subtasks", x["id"])
            self.conn.execute(
                "UPDATE subtasks SET checked=0, completed_at=NULL, due_date=?, time_spent_seconds=0, "
                "timer_started_at=NULL, timer_state='idle', occ_base=NULL WHERE id=?", (new_due, x["id"]))
            if xb and "start_time" in xb:
                self.conn.execute("UPDATE subtasks SET start_time=? WHERE id=?", (xb["start_time"], x["id"]))
        self.conn.commit()

    def _archive_stale_time(self, tid, row, day):
        """Move time tracked on an earlier `day` off an occurrence that is
        still open: it is recorded as a closed-out entry dated that day (so
        reports and daily totals keep it), and the live timers reset."""
        self.stop_timer("tasks", tid)
        spent = self._timer_row("tasks", tid)["time_spent_seconds"] or 0
        snap = [{"id": x["id"], "title": x["title"], "checked": bool(x["checked"]),
                 "due_date": x["due_date"], "duration_minutes": x["duration_minutes"],
                 "start_time": x["start_time"], "urgent": bool(x["urgent"]),
                 "time_spent_seconds": x["time_spent_seconds"]}
                for x in self.list_subtasks(tid)]
        self.conn.execute(
            "INSERT INTO task_completions (id, task_id, title, occurrence_date, completed_at, "
            "time_spent_seconds, urgent, subtasks_json, time_only) VALUES (?,?,?,?,?,?,?,?,1)",
            (new_id(), tid, row["title"], day, f"{day}T23:59:59", spent, row["urgent"], json.dumps(snap)))
        self.conn.execute("UPDATE tasks SET time_spent_seconds=0, time_day=NULL WHERE id=?", (tid,))
        for x in snap:
            self.stop_timer("subtasks", x["id"])
            self.conn.execute("UPDATE subtasks SET time_spent_seconds=0 WHERE id=?", (x["id"],))
        self.conn.commit()

    def _roll_stale_occurrence(self, table, tid):
        """Called when a timer is started on a recurring task (or one of its
        subtasks). If the time already on it was tracked on an EARLIER day
        (the occurrence was never checked off), that occurrence is closed
        out with its time and the task moves to the occurrence for today, so
        every day's occurrence starts its time from zero."""
        from .. import recurrence as rec
        if table == "subtasks":
            r = self.conn.execute("SELECT task_id FROM subtasks WHERE id=?", (tid,)).fetchone()
            if not r:
                return
            tid = r["task_id"]
        row = self.conn.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
        if not row or not row["recurrence"] or not row["due_date"]:
            return
        today = date.today().isoformat()
        total = (row["time_spent_seconds"] or 0) + sum(
            x["time_spent_seconds"] or 0 for x in self.list_subtasks(tid))
        if total <= 0:
            return
        last_day = row["time_day"] or row["due_date"]
        if last_day >= today:
            return
        if row["due_date"] >= today:
            return      # still the current occurrence: time keeps adding up across days
        rule = json.loads(row["recurrence"])
        cur, no, inc = date.fromisoformat(self._base_due(row)), row["occurrence_no"], 0
        nxt = rec.next_occurrence(cur, rule, no)
        while nxt and nxt.isoformat() < today and inc < 500:
            cur, no, inc = nxt, no + 1, inc + 1
            nxt = rec.next_occurrence(cur, rule, no)
        if nxt:
            self._finish_occurrence(tid, row, nxt, occ_inc=inc + 1)

    def toggle_task(self, tid, checked: bool):
        """Returns 'done', 'recurred' or 'reopened'."""
        from .. import recurrence as rec
        row = self.conn.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
        if not row:
            return None
        if not checked:
            self.conn.execute("UPDATE tasks SET checked=0, completed_at=NULL WHERE id=?", (tid,))
            self.conn.commit()
            return "reopened"

        rule = json.loads(row["recurrence"]) if row["recurrence"] else None
        if rule and row["due_date"]:
            nxt = rec.next_occurrence(date.fromisoformat(self._base_due(row)), rule, row["occurrence_no"])
            if nxt:
                self._finish_occurrence(tid, row, nxt)
                return "recurred"
        self.conn.execute(
            "UPDATE tasks SET checked=1, completed_at=? WHERE id=?", (datetime.now().isoformat(), tid))
        self.conn.commit()
        self.stop_timer("tasks", tid)
        return "done"

    def set_attachment(self, tid, path, name):
        self.conn.execute("UPDATE tasks SET attachment_path=?, attachment_name=? WHERE id=?",
                           (path, name, tid))
        self.conn.commit()

    def clear_attachment(self, tid):
        self.conn.execute("UPDATE tasks SET attachment_path=NULL, attachment_name=NULL WHERE id=?", (tid,))
        self.conn.commit()
