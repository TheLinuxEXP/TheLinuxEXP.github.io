"""Subtasks."""
from __future__ import annotations
import json
import os
from datetime import datetime
from pathlib import Path
from .core import _chunks, data_dir, new_id


class SubtaskMixin:
    # -- subtasks ------------------------------------------------------
    def list_subtasks(self, task_id):
        return self.list_subtasks_many([task_id]).get(task_id, [])

    def list_subtasks_many(self, task_ids):
        """{task_id: [subtask, ...]} for several tasks in two queries (instead of two per task).
        Each subtask carries its live time, the time recorded on earlier occurrences of a recurring task (kept in the
        snapshots of its finished occurrences) and their sum."""
        task_ids = list(dict.fromkeys(task_ids))
        out: dict[str, list] = {tid: [] for tid in task_ids}
        for chunk in _chunks(task_ids):
            marks = ",".join("?" * len(chunk))
            rows = self.conn.execute(
                f"SELECT * FROM subtasks WHERE task_id IN ({marks}) "
                "ORDER BY checked, (due_date IS NULL), due_date, sort_order", chunk).fetchall()
            if not rows:
                continue
            earlier: dict[str, int] = {}
            with_rows = {r["task_id"] for r in rows}
            for c in self.conn.execute(
                    f"SELECT subtasks_json FROM task_completions WHERE task_id IN ({','.join('?' * len(with_rows))})",
                    list(with_rows)).fetchall():
                try:
                    for x in json.loads(c["subtasks_json"] or "[]"):
                        earlier[x.get("id")] = earlier.get(x.get("id"), 0) + int(x.get("time_spent_seconds") or 0)
                except (ValueError, TypeError, AttributeError):
                    continue
            for r in rows:
                d = dict(r)
                d["time_spent_seconds"] = self._live_elapsed_seconds(r)
                d["earlier_time_seconds"] = earlier.get(r["id"], 0)
                d["lifetime_seconds"] = d["time_spent_seconds"] + d["earlier_time_seconds"]
                out[r["task_id"]].append(d)
        return out

    def get_subtask(self, sid):
        row = self.conn.execute("SELECT * FROM subtasks WHERE id=?", (sid,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["time_spent_seconds"] = self._live_elapsed_seconds(row)
        return d

    def relink_notes_file(self, old_path, new_path):
        """A note was renamed/moved: tasks and subtasks linked to it follow it. Paths are compared normalised
        (symlinks resolved), so the stored spelling doesn't matter. Returns how many links were updated."""
        def norm(p):
            try:
                return os.path.normpath(str(Path(p).expanduser().resolve()))
            except OSError:
                return os.path.normpath(str(p))
        old_n, n = norm(old_path), 0
        for table, col in (("tasks", "notes_file"), ("tasks", "video_note_file"), ("subtasks", "notes_file")):
            for r in self.conn.execute(f"SELECT id, {col} FROM {table} WHERE {col} IS NOT NULL AND {col}<>''").fetchall():
                if norm(r[col]) == old_n:
                    self.conn.execute(f"UPDATE {table} SET {col}=? WHERE id=?", (str(new_path), r["id"]))
                    n += 1
        self.conn.commit()
        return n

    def add_subtask(self, task_id, title, due_date=None, duration_minutes=None, urgent=False, start_time=None,
                    template_sub_id=None):
        sid = new_id()
        order = self.conn.execute(
            "SELECT COALESCE(MAX(sort_order), 0) + 1 FROM subtasks WHERE task_id=?",
            (task_id,)).fetchone()[0]
        self.conn.execute("""
            INSERT INTO subtasks (id, task_id, title, due_date, duration_minutes, urgent, start_time, sort_order, created_at,
                                  template_sub_id)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (sid, task_id, title, due_date, duration_minutes, int(bool(urgent)), start_time, order,
              datetime.now().isoformat(), template_sub_id))
        self.conn.commit()
        return sid

    def update_subtask(self, sid, **fields):
        if "urgent" in fields:
            fields["urgent"] = int(bool(fields["urgent"]))
        self._update("subtasks", sid, fields)

    def delete_subtask(self, sid):
        self._queue_unlink(data_dir() / "generated" / sid)
        self.conn.execute("DELETE FROM time_log WHERE entity='subtask' AND entity_id=?", (sid,))
        self.conn.execute("DELETE FROM subtasks WHERE id=?", (sid,))
        self.conn.commit()

    def toggle_subtask(self, sid, checked: bool):
        if checked:
            self.conn.execute("UPDATE subtasks SET checked=1, completed_at=? WHERE id=?",
                               (datetime.now().isoformat(), sid))
            self.stop_timer("subtasks", sid)
        else:
            self.conn.execute("UPDATE subtasks SET checked=0, completed_at=NULL WHERE id=?", (sid,))
        self.conn.commit()
