"""Timers, the per-day time ledger, 'Other tasks' and time reports/insights."""
from __future__ import annotations
from datetime import date, datetime, timedelta


class TimeTrackingMixin:
    # -- time tracking -----------------------------------------------------
    # Each task/subtask row carries time_spent_seconds (the finalized total,
    # frozen while idle/paused), timer_started_at (set only while running --
    # the wall-clock moment the current running segment began) and
    # timer_state ('idle' | 'running' | 'paused'). "Live" elapsed time is
    # always computed on read as time_spent_seconds + (now - timer_started_at)
    # when running, rather than ticked up in the background, so it's exact
    # even across server restarts and needs no polling job.
    def _live_elapsed_seconds(self, row):
        spent = row["time_spent_seconds"] or 0
        if row["timer_state"] == "running" and row["timer_started_at"]:
            try:
                started = datetime.fromisoformat(row["timer_started_at"])
                spent += max(0, int((datetime.now() - started).total_seconds()))
            except ValueError:
                pass
        return spent

    def _timer_row(self, table, tid):
        return self.conn.execute(
            f"SELECT time_spent_seconds, timer_started_at, timer_state FROM {table} WHERE id=?", (tid,)
        ).fetchone()

    # -- per-day time ledger ---------------------------------------------
    @staticmethod
    def _split_by_day(start_dt, end_dt):
        """{iso_day: seconds} for the span start..end, cut at midnights."""
        out: dict[str, int] = {}
        cur = start_dt
        while cur < end_dt:
            midnight = datetime.combine(cur.date() + timedelta(days=1), datetime.min.time())
            seg_end = min(end_dt, midnight)
            out[cur.date().isoformat()] = out.get(cur.date().isoformat(), 0) + int(round((seg_end - cur).total_seconds()))
            cur = seg_end
        return out

    def _log_add(self, entity, entity_id, task_id, day, seconds):
        if not seconds:
            return
        self.conn.execute(
            "INSERT INTO time_log (id, entity, entity_id, task_id, day, seconds) VALUES (?,?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET seconds = seconds + excluded.seconds",
            (f"{entity}:{entity_id}:{day}", entity, entity_id, task_id, day, int(seconds)))

    def _log_reduce(self, entity, entity_id, amount):
        """Take `amount` seconds back out of the ledger, most recent days first."""
        for r in self.conn.execute(
                "SELECT id, seconds FROM time_log WHERE entity=? AND entity_id=? AND seconds>0 ORDER BY day DESC",
                (entity, entity_id)).fetchall():
            if amount <= 0:
                break
            take = min(amount, r["seconds"])
            self.conn.execute("UPDATE time_log SET seconds = seconds - ? WHERE id=?", (take, r["id"]))
            amount -= take

    def _log_time_change(self, table, tid, prior, new_spent, new_state):
        """Record, per day, the change in a task/subtask's time total."""
        entity = "task" if table == "tasks" else "subtask"
        if table == "tasks":
            task_id = tid
        else:
            r = self.conn.execute("SELECT task_id FROM subtasks WHERE id=?", (tid,)).fetchone()
            if not r:
                return
            task_id = r["task_id"]
        delta = int(new_spent) - int(prior["time_spent_seconds"] or 0)
        if delta > 0:
            days = None
            if prior["timer_state"] == "running" and prior["timer_started_at"] and new_state != "running":
                try:
                    days = self._split_by_day(datetime.fromisoformat(prior["timer_started_at"]), datetime.now())
                except ValueError:
                    days = None
            if days and sum(days.values()) > 0:
                total = sum(days.values())
                ordered = sorted(days.items())
                given = 0
                for i, (d, sec) in enumerate(ordered):
                    part = delta - given if i == len(ordered) - 1 else int(round(delta * sec / total))
                    part = max(0, min(part, delta - given))
                    given += part
                    self._log_add(entity, tid, task_id, d, part)
            else:
                self._log_add(entity, tid, task_id, date.today().isoformat(), delta)
        elif delta < 0:
            self._log_reduce(entity, tid, -delta)

    def _live_by_day(self, started_at):
        try:
            return self._split_by_day(datetime.fromisoformat(started_at), datetime.now())
        except (ValueError, TypeError):
            return {}

    def _timer_write(self, table, tid, spent_seconds, new_state):
        if table in ("tasks", "subtasks"):
            prior = self._timer_row(table, tid)
            if prior:
                self._log_time_change(table, tid, prior, spent_seconds, new_state)
        started_at = datetime.now().isoformat() if new_state == "running" else None
        self.conn.execute(
            f"UPDATE {table} SET time_spent_seconds=?, timer_started_at=?, timer_state=? WHERE id=?",
            (spent_seconds, started_at, new_state, tid))
        owner = tid if table == "tasks" else (self.conn.execute(
            "SELECT task_id FROM subtasks WHERE id=?", (tid,)).fetchone() or {"task_id": None})["task_id"]
        if owner:
            self.conn.execute("UPDATE tasks SET time_day=? WHERE id=?", (date.today().isoformat(), owner))
        self.conn.commit()

    def set_time_spent(self, table, tid, seconds):
        """Manually set the time recorded on a task/subtask (table is 'tasks'
        or 'subtasks'). If its timer is running it keeps running from now,
        counting on top of the new value."""
        row = self._timer_row(table, tid)
        if row is None:
            return
        seconds = max(0, int(seconds))
        state = row["timer_state"] or "idle"
        self._timer_write(table, tid, seconds, state)

    def start_timer(self, table, tid):
        """table is 'tasks' or 'subtasks'. Starting is a no-op if already
        running; starting a paused timer resumes it (same as resume_timer)
        rather than losing the accumulated time."""
        row = self._timer_row(table, tid)
        if not row or row["timer_state"] == "running":
            return
        if row["timer_state"] == "idle":
            self._roll_stale_occurrence(table, tid)
            row = self._timer_row(table, tid)
        self._timer_write(table, tid, row["time_spent_seconds"] or 0, "running")

    def resume_timer(self, table, tid):
        row = self._timer_row(table, tid)
        if not row or row["timer_state"] != "paused":
            return
        self._timer_write(table, tid, row["time_spent_seconds"] or 0, "running")

    def pause_timer(self, table, tid):
        row = self._timer_row(table, tid)
        if not row or row["timer_state"] != "running":
            return
        self._timer_write(table, tid, self._live_elapsed_seconds(row), "paused")

    def stop_timer(self, table, tid):
        row = self._timer_row(table, tid)
        if not row or row["timer_state"] == "idle":
            return
        self._timer_write(table, tid, self._live_elapsed_seconds(row), "idle")

    # -- "Other tasks" (standalone per-day time bucket) ------------------
    def other_timer(self, action, today_iso):
        """Apply a timer action to the "Other tasks" bucket. Acts on whichever
        day's bucket is currently running/paused (so a timer left running past
        midnight can still be stopped), else on `today_iso`."""
        row = self.conn.execute(
            "SELECT id FROM other_time WHERE timer_state != 'idle' ORDER BY id DESC LIMIT 1").fetchone()
        day = row["id"] if row else today_iso
        self.conn.execute("INSERT OR IGNORE INTO other_time (id) VALUES (?)", (day,))
        self.conn.commit()
        getattr(self, {"start": "start_timer", "stop": "stop_timer",
                       "pause": "pause_timer", "resume": "resume_timer"}[action])("other_time", day)
        return self.other_tasks_for(today_iso)

    def set_other_time(self, day_iso, seconds):
        """Manually set the time recorded in the "Other tasks" bucket of a day (a running timer keeps counting on top)."""
        self.conn.execute("INSERT OR IGNORE INTO other_time (id) VALUES (?)", (day_iso,))
        row = self.conn.execute("SELECT timer_state FROM other_time WHERE id=?", (day_iso,)).fetchone()
        self._timer_write("other_time", day_iso, max(0, int(seconds)), (row["timer_state"] if row else "idle") or "idle")

    def other_tasks_for(self, today_iso):
        """The widget/header view of "Other tasks": the active bucket if any,
        otherwise today's."""
        row = self.conn.execute(
            "SELECT * FROM other_time WHERE timer_state != 'idle' ORDER BY id DESC LIMIT 1").fetchone() \
            or self.conn.execute("SELECT * FROM other_time WHERE id=?", (today_iso,)).fetchone()
        if not row:
            return {"day": today_iso, "time_spent_seconds": 0, "timer_state": "idle"}
        return {"day": row["id"], "time_spent_seconds": self._live_elapsed_seconds(row),
                "timer_state": row["timer_state"]}

    def other_tasks_range(self, start_iso, end_iso):
        """{day: {time_spent_seconds, timer_state}} for days in range that have a bucket."""
        out = {}
        for row in self.conn.execute(
                "SELECT * FROM other_time WHERE id >= ? AND id <= ?", (start_iso, end_iso)).fetchall():
            out[row["id"]] = {"time_spent_seconds": self._live_elapsed_seconds(row),
                              "timer_state": row["timer_state"]}
        return out

    # -- "Other tasks" of each project (a permanent task per project, one time bucket per day) ----------
    def _project_other_row(self, project_id, today_iso):
        """The bucket shown for a project: the one whose timer is running/paused (so a timer left on past midnight can still
        be stopped), else today's, else None."""
        return self.conn.execute(
            "SELECT * FROM project_time WHERE project_id=? AND timer_state != 'idle' ORDER BY day DESC LIMIT 1",
            (project_id,)).fetchone() or self.conn.execute(
            "SELECT * FROM project_time WHERE id=?", (f"{project_id}:{today_iso}",)).fetchone()

    def _project_other_dict(self, project_id, today_iso, row=None, project=None):
        row = row if row is not None else self._project_other_row(project_id, today_iso)
        if project is None:
            project = self.conn.execute("SELECT name, color FROM projects WHERE id=?", (project_id,)).fetchone()
        base = {"project_id": project_id, "project_name": project["name"] if project else "",
                "color": project["color"] if project else "#7f8c8d"}
        if not row:
            return {**base, "day": today_iso, "time_spent_seconds": 0, "timer_state": "idle"}
        return {**base, "day": row["day"], "time_spent_seconds": self._live_elapsed_seconds(row),
                "timer_state": row["timer_state"]}

    def project_others(self, today_iso):
        """The "Other tasks" of every project, in the sidebar's project order (what the Today view and the widget list)."""
        rows = self.conn.execute(
            "SELECT * FROM project_time WHERE timer_state != 'idle' OR day = ? ORDER BY day", (today_iso,)).fetchall()
        chosen: dict[str, object] = {}
        for r in rows:                                   # a running/paused bucket wins over today's
            cur = chosen.get(r["project_id"])
            if cur is None or (r["timer_state"] != "idle" and (cur["timer_state"] == "idle" or r["day"] > cur["day"])):
                chosen[r["project_id"]] = r
        return [self._project_other_dict(p["id"], today_iso, chosen.get(p["id"]), p)
                for p in self.conn.execute("SELECT id, name, color FROM projects ORDER BY sort_order, name").fetchall()]

    def project_other_for(self, project_id, today_iso):
        return self._project_other_dict(project_id, today_iso)

    def project_other_timer(self, project_id, action, today_iso):
        """Timer action on a project's "Other tasks"; None if the project does not exist."""
        if not self.conn.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
            return None
        row = self.conn.execute(
            "SELECT day FROM project_time WHERE project_id=? AND timer_state != 'idle' ORDER BY day DESC LIMIT 1",
            (project_id,)).fetchone()
        day = row["day"] if row else today_iso
        tid = f"{project_id}:{day}"
        self.conn.execute("INSERT OR IGNORE INTO project_time (id, project_id, day) VALUES (?,?,?)", (tid, project_id, day))
        self.conn.commit()
        getattr(self, {"start": "start_timer", "stop": "stop_timer",
                       "pause": "pause_timer", "resume": "resume_timer"}[action])("project_time", tid)
        return self.project_other_for(project_id, today_iso)

    def set_project_other_time(self, project_id, day_iso, seconds):
        """Type the time of a project's "Other tasks" for one day (a running timer keeps counting on top). False if no such project."""
        if not self.conn.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
            return False
        tid = f"{project_id}:{day_iso}"
        self.conn.execute("INSERT OR IGNORE INTO project_time (id, project_id, day) VALUES (?,?,?)", (tid, project_id, day_iso))
        row = self.conn.execute("SELECT timer_state FROM project_time WHERE id=?", (tid,)).fetchone()
        self._timer_write("project_time", tid, max(0, int(seconds)), (row["timer_state"] if row else "idle") or "idle")
        return True

    def project_other_range(self, start_iso, end_iso):
        """{day: [{project_id, project_name, color, time_spent_seconds, timer_state}]} for the buckets that have time (or a timer) in range."""
        out: dict[str, list] = {}
        for r in self.conn.execute(
                "SELECT t.*, p.name AS pname, p.color AS pcolor FROM project_time t JOIN projects p ON p.id = t.project_id "
                "WHERE t.day >= ? AND t.day <= ? ORDER BY p.sort_order, p.name", (start_iso, end_iso)).fetchall():
            sec = self._live_elapsed_seconds(r)
            if sec > 0 or r["timer_state"] != "idle":
                out.setdefault(r["day"], []).append({
                    "project_id": r["project_id"], "project_name": r["pname"], "color": r["pcolor"],
                    "time_spent_seconds": sec, "timer_state": r["timer_state"]})
        return out

    def active_timers(self):
        """Every task/subtask whose timer is currently running or paused,
        for the header's active-timers indicator. Newest-started first."""
        out = []
        task_rows = self.conn.execute("""
            SELECT id, title, timer_state, timer_started_at, time_spent_seconds
            FROM tasks WHERE timer_state != 'idle'
        """).fetchall()
        for row in task_rows:
            out.append({
                "id": row["id"],
                "task_id": row["id"],
                "is_subtask": False,
                "title": row["title"],
                "parent_title": None,
                "timer_state": row["timer_state"],
                "timer_started_at": row["timer_started_at"],
                "time_spent_seconds": self._live_elapsed_seconds(row),
            })
        sub_rows = self.conn.execute("""
            SELECT s.id, s.title, s.timer_state, s.timer_started_at, s.time_spent_seconds,
                   s.task_id AS parent_task_id, t.title AS parent_title
            FROM subtasks s JOIN tasks t ON t.id = s.task_id
            WHERE s.timer_state != 'idle'
        """).fetchall()
        for row in sub_rows:
            out.append({
                "id": row["id"],
                "task_id": row["parent_task_id"],
                "is_subtask": True,
                "title": row["title"],
                "parent_title": row["parent_title"],
                "timer_state": row["timer_state"],
                "timer_started_at": row["timer_started_at"],
                "time_spent_seconds": self._live_elapsed_seconds(row),
            })
        for row in self.conn.execute("SELECT * FROM other_time WHERE timer_state != 'idle'").fetchall():
            out.append({
                "id": row["id"], "task_id": None, "is_subtask": False, "is_other": True,
                "title": "Other tasks", "parent_title": None,
                "timer_state": row["timer_state"], "timer_started_at": row["timer_started_at"],
                "time_spent_seconds": self._live_elapsed_seconds(row),
            })
        for row in self.conn.execute(
                "SELECT t.*, p.name AS pname FROM project_time t JOIN projects p ON p.id = t.project_id "
                "WHERE t.timer_state != 'idle'").fetchall():
            out.append({
                "id": row["id"], "task_id": None, "is_subtask": False, "is_other": True, "project_id": row["project_id"],
                "title": "Other tasks", "parent_title": None, "project_name": row["pname"],
                "timer_state": row["timer_state"], "timer_started_at": row["timer_started_at"],
                "time_spent_seconds": self._live_elapsed_seconds(row),
            })
        out.sort(key=lambda e: e["timer_started_at"] or "", reverse=True)
        return out

    def _ledger_rows(self, start_iso, end_iso):
        """(entity, entity_id, task_id, day, seconds) tracked within [start, end]:
        the saved ledger plus time still running on a live timer right now."""
        rows = [(r["entity"], r["entity_id"], r["task_id"], r["day"], r["seconds"]) for r in self.conn.execute(
            "SELECT entity, entity_id, task_id, day, seconds FROM time_log "
            "WHERE day >= ? AND day <= ? AND seconds > 0", (start_iso, end_iso)).fetchall()]
        for table, entity in (("tasks", "task"), ("subtasks", "subtask")):
            for r in self.conn.execute(
                    f"SELECT * FROM {table} WHERE timer_state='running' AND timer_started_at IS NOT NULL").fetchall():
                task_id = r["id"] if table == "tasks" else r["task_id"]
                for day, sec in self._live_by_day(r["timer_started_at"]).items():
                    if start_iso <= day <= end_iso and sec > 0:
                        rows.append((entity, r["id"], task_id, day, sec))
        return rows

    def time_by_day(self, start_iso, end_iso):
        """{iso_date: total_seconds} of time actually TRACKED on each day in
        [start, end] -- on any task or subtask, whatever its due date --
        including a timer still running right now, plus the "Other tasks"
        bucket -- but not the main task's own time when it has subtasks.
        Backs the week view's per-day hours total."""
        totals: dict[str, int] = {}
        # A main task that has subtasks is counted through its subtasks only:
        # time recorded on the main task itself is left out of the day's total.
        with_subtasks = {r[0] for r in self.conn.execute("SELECT DISTINCT task_id FROM subtasks").fetchall()}
        for entity, _id, task_id, day, sec in self._ledger_rows(start_iso, end_iso):
            if entity == "task" and task_id in with_subtasks:
                continue
            totals[day] = totals.get(day, 0) + sec
        for row in self.conn.execute(
                "SELECT * FROM other_time WHERE id >= ? AND id <= ?", (start_iso, end_iso)).fetchall():
            totals[row["id"]] = totals.get(row["id"], 0) + self._live_elapsed_seconds(row)
        for row in self.conn.execute(
                "SELECT * FROM project_time WHERE day >= ? AND day <= ?", (start_iso, end_iso)).fetchall():
            totals[row["day"]] = totals.get(row["day"], 0) + self._live_elapsed_seconds(row)    # the projects' "Other tasks"
        return totals

    def time_day_detail(self, day):
        """What the week view's total for `day` is made of: every subtask and
        every main task WITHOUT subtasks that time was tracked on that day
        (plus "Other tasks"), with the seconds -- same rules as time_by_day."""
        with_subtasks = {r[0] for r in self.conn.execute("SELECT DISTINCT task_id FROM subtasks").fetchall()}
        titles = {r["id"]: r["title"] for r in self.conn.execute("SELECT id, title FROM tasks").fetchall()}
        subs = {r["id"]: r["title"] for r in self.conn.execute("SELECT id, title FROM subtasks").fetchall()}
        agg: dict[tuple, int] = {}
        for entity, eid, task_id, d, sec in self._ledger_rows(day, day):
            if entity == "task" and task_id in with_subtasks:
                continue
            key = (entity, eid, task_id)
            agg[key] = agg.get(key, 0) + sec
        items = []
        for (entity, eid, task_id), sec in agg.items():
            if task_id not in titles or (entity == "subtask" and eid not in subs):
                continue
            items.append({"kind": entity, "task_id": task_id, "id": eid, "seconds": int(sec),
                          "title": subs[eid] if entity == "subtask" else titles[task_id],
                          "parent_title": titles[task_id] if entity == "subtask" else None})
        for r in self.conn.execute("SELECT * FROM other_time WHERE id=?", (day,)).fetchall():
            sec = self._live_elapsed_seconds(r)
            if sec > 0:
                items.append({"kind": "other", "task_id": None, "id": r["id"], "seconds": int(sec),
                              "title": "Other tasks", "parent_title": None})
        for r in self.conn.execute(
                "SELECT t.*, p.name AS pname FROM project_time t JOIN projects p ON p.id = t.project_id WHERE t.day=?", (day,)).fetchall():
            sec = self._live_elapsed_seconds(r)
            if sec > 0:
                items.append({"kind": "other", "task_id": None, "id": r["id"], "seconds": int(sec),
                              "title": "Other tasks", "parent_title": r["pname"]})
        items.sort(key=lambda i: -i["seconds"])
        return {"day": day, "total_seconds": sum(i["seconds"] for i in items), "items": items}

    def time_report(self, start_iso, end_iso):
        """Flat list of tracked-time entries within [start, end] for the time
        report: {date, activity, project, seconds}. `project` is the main
        task's title; `activity` is the subtask's title (or, for time on a
        main task itself, the task's title). Dated by the day the time was
        tracked; "Other tasks" use their own day."""
        titles = {r["id"]: r["title"] for r in self.conn.execute("SELECT id, title FROM tasks").fetchall()}
        subs = {r["id"]: r["title"] for r in self.conn.execute("SELECT id, title FROM subtasks").fetchall()}
        # "company" = the app project (sidebar) a task lives in; "Other tasks" has its own
        companies = {r["id"]: r["pname"] for r in self.conn.execute(
            "SELECT t.id, p.name AS pname FROM tasks t LEFT JOIN todo_lists l ON l.id=t.todo_list_id "
            "LEFT JOIN projects p ON p.id=l.project_id").fetchall()}
        out = []
        for entity, eid, task_id, day, sec in self._ledger_rows(start_iso, end_iso):
            project = titles.get(task_id)
            if project is None:
                continue
            activity = project if entity == "task" else subs.get(eid)
            if activity is None:
                continue
            out.append({"date": day, "activity": activity, "project": project, "seconds": int(sec),
                        "company": companies.get(task_id) or "No project"})
        for r in self.conn.execute("SELECT * FROM other_time WHERE id >= ? AND id <= ?", (start_iso, end_iso)).fetchall():
            sec = self._live_elapsed_seconds(r)
            if sec > 0:
                out.append({"date": r["id"], "activity": "Other tasks", "project": "Other tasks", "seconds": int(sec),
                            "company": "Other tasks"})
        # a project's "Other tasks" counts for that project ("By Company" = the app project)
        for r in self.conn.execute(
                "SELECT t.*, p.name AS pname FROM project_time t JOIN projects p ON p.id = t.project_id "
                "WHERE t.day >= ? AND t.day <= ?", (start_iso, end_iso)).fetchall():
            sec = self._live_elapsed_seconds(r)
            if sec > 0:
                out.append({"date": r["day"], "activity": "Other tasks", "project": "Other tasks", "seconds": int(sec),
                            "company": r["pname"]})
        return out

    def tag_time_seconds(self, start_iso, end_iso):
        """{tag_id: seconds} tracked within [start, end] on the tasks carrying
        each tag (a main task's own time + its subtasks'). A task with several
        tags splits its time evenly between them, so no hour is counted twice."""
        task_tags: dict[str, list[str]] = {}
        for r in self.conn.execute("SELECT task_id, tag_id FROM task_tags").fetchall():
            task_tags.setdefault(r["task_id"], []).append(r["tag_id"])
        out: dict[str, float] = {}
        for _entity, _eid, task_id, _day, sec in self._ledger_rows(start_iso, end_iso):
            tags = task_tags.get(task_id)
            if not tags:
                continue
            for tg in tags:
                out[tg] = out.get(tg, 0.0) + sec / len(tags)
        return {k: int(round(v)) for k, v in out.items()}

    def time_insight_entries(self, start_iso, end_iso):
        """Like time_report, plus what the AI insights need: whether the main
        task is a video, which app project/list it belongs to, and whether
        the time is on a subtask or on the task itself."""
        info = {r["id"]: r for r in self.conn.execute(
            "SELECT t.id, t.title, t.is_video, t.video_template, l.name AS list_name, p.name AS project_name "
            "FROM tasks t LEFT JOIN todo_lists l ON l.id=t.todo_list_id "
            "LEFT JOIN projects p ON p.id=l.project_id").fetchall()}
        subs = {r["id"]: r["title"] for r in self.conn.execute("SELECT id, title FROM subtasks").fetchall()}
        with_subtasks = {r[0] for r in self.conn.execute("SELECT DISTINCT task_id FROM subtasks").fetchall()}
        out = []
        for entity, eid, task_id, day, sec in self._ledger_rows(start_iso, end_iso):
            t = info.get(task_id)
            if t is None or (entity == "task" and task_id in with_subtasks):
                continue          # same rule as the calendar totals
            activity = t["title"] if entity == "task" else subs.get(eid)
            if activity is None:
                continue
            out.append({"date": day, "activity": activity, "task": t["title"], "is_video": bool(t["is_video"]),
                        "project": t["project_name"], "list": t["list_name"], "seconds": int(sec),
                        "other": False})
        for r in self.conn.execute("SELECT * FROM other_time WHERE id >= ? AND id <= ?", (start_iso, end_iso)).fetchall():
            sec = self._live_elapsed_seconds(r)
            if sec > 0:
                out.append({"date": r["id"], "activity": "Other tasks", "task": "Other tasks", "is_video": False,
                            "project": None, "list": None, "seconds": int(sec), "other": True})
        for r in self.conn.execute(
                "SELECT t.*, p.name AS pname FROM project_time t JOIN projects p ON p.id = t.project_id "
                "WHERE t.day >= ? AND t.day <= ?", (start_iso, end_iso)).fetchall():
            sec = self._live_elapsed_seconds(r)
            if sec > 0:
                out.append({"date": r["day"], "activity": "Other tasks", "task": "Other tasks", "is_video": False,
                            "project": r["pname"], "list": None, "seconds": int(sec), "other": True})
        return out

    def get_time_insight(self, kind, start_iso):
        r = self.conn.execute("SELECT text, generated_at FROM time_insights WHERE kind=? AND period_start=?",
                              (kind, start_iso)).fetchone()
        return {"text": r["text"], "generated_at": r["generated_at"]} if r else None

    def save_time_insight(self, kind, start_iso, text):
        self.conn.execute(
            "INSERT INTO time_insights(kind, period_start, text, generated_at) VALUES (?,?,?,?) "
            "ON CONFLICT(kind, period_start) DO UPDATE SET text=excluded.text, generated_at=excluded.generated_at",
            (kind, start_iso, text, datetime.now().isoformat(timespec="minutes")))
        self.conn.commit()

    def list_time_insights(self, kind, start_iso, end_iso):
        return {r["period_start"]: {"text": r["text"], "generated_at": r["generated_at"]} for r in self.conn.execute(
            "SELECT * FROM time_insights WHERE kind=? AND period_start >= ? AND period_start <= ?",
            (kind, start_iso, end_iso)).fetchall()}
