"""Sponsor billing: at the end of every month (and quarter) a task "Invoices <period>" is created in
"The Linux EXP / Tasks", with one "Invoice <sponsor> <amount>" subtask per sponsor to bill.

Per-sponsor settings live in tag_contracts (billing_period: monthly|quarterly, amount_type: per_video|fixed,
amount: free text). Per video = number of finished (checked) video tasks carrying the sponsor's tag and due in
the period, times the amount; fixed = the amount as is."""
from __future__ import annotations
import calendar
from decimal import Decimal, InvalidOperation
import re
from datetime import date, datetime, timedelta

BILLING_PROJECT, BILLING_LIST = "The Linux EXP", "Tasks"
_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September",
           "October", "November", "December"]


def _norm(text):
    import unicodedata
    t = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "", t)


def parse_amount(text):
    """(Decimal | None, currency symbol) from free text such as "500", "1 500,50 €", "$300"."""
    text = (text or "").strip()
    cur = next((c for c in "€$£" if c in text), "€")
    m = re.search(r"\d[\d\s  .,]*", text)
    if not m:
        return None, cur
    s = re.sub(r"[\s  ]", "", m.group(0)).rstrip(".,")
    if "," in s and "." in s:                               # the last separator is the decimal one
        dec = "," if s.rfind(",") > s.rfind(".") else "."
        s = s.replace("." if dec == "," else ",", "").replace(dec, ".")
    elif "," in s:
        head, _, tail = s.rpartition(",")
        s = (head.replace(",", "") + tail) if (len(tail) == 3 and head) else s.replace(",", ".")
    elif s.count(".") > 1 or (s.count(".") == 1 and len(s.rpartition(".")[2]) == 3 and s.rpartition(".")[0]):
        s = s.replace(".", "")
    try:
        return Decimal(s), cur
    except InvalidOperation:
        return None, cur


def format_amount(value, cur="€"):
    value = value.quantize(Decimal("0.01"))
    txt = str(int(value)) if value == value.to_integral_value() else f"{value:.2f}".replace(".", ",")
    return f"{txt} {cur}"


def month_end(year, month):
    return date(year, month, calendar.monthrange(year, month)[1])


def period_label(kind, start):
    return f"{_MONTHS[start.month - 1]} {start.year}" if kind == "monthly" else f"Q{(start.month - 1) // 3 + 1} {start.year}"


def periods_ending_between(first, last):
    """[(kind, start, end)] for every month / quarter whose last day is in [first, last], oldest first."""
    out = []
    y, m = first.year, first.month
    while date(y, m, 1) <= last:
        end = month_end(y, m)
        if first <= end <= last:
            out.append(("monthly", date(y, m, 1), end))
            if m % 3 == 0:
                out.append(("quarterly", date(y, m - 2, 1), end))
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


class BillingMixin:
    def billing_target_list_id(self):
        want_p, want_l = _norm(BILLING_PROJECT), _norm(BILLING_LIST)
        for p in self.conn.execute("SELECT id, name FROM projects").fetchall():
            if _norm(p["name"]) == want_p:
                for l in self.conn.execute("SELECT id, name FROM todo_lists WHERE project_id=? ORDER BY sort_order",
                                           (p["id"],)).fetchall():
                    if _norm(l["name"]) == want_l:
                        return l["id"]
        return None

    def _finished_videos(self, tag_id, start, end):
        return self.conn.execute(
            "SELECT COUNT(*) FROM tasks t JOIN task_tags tt ON tt.task_id = t.id "
            "WHERE tt.tag_id=? AND t.is_video=1 AND t.checked=1 AND substr(t.due_date,1,10) BETWEEN ? AND ?",
            (tag_id, start.isoformat(), end.isoformat())).fetchone()[0]

    def billing_invoices(self, kind, start, end):
        """[(sponsor name, subtask title)] for the period."""
        out = []
        rows = self.conn.execute(
            "SELECT g.id, g.name, c.amount_type, c.amount FROM tag_contracts c JOIN tags g ON g.id = c.tag_id "
            "WHERE c.billing_period=? ORDER BY g.name COLLATE NOCASE", (kind,)).fetchall()
        for r in rows:
            n = self._finished_videos(r["id"], start, end)
            fixed = r["amount_type"] == "fixed"
            if not fixed and n < 1:
                continue                                    # per video / no amount: only sponsors with a video
            value, cur = parse_amount(r["amount"])
            title = f"Invoice {r['name']}"
            if (r["amount"] or "").strip():
                if value is None:
                    if fixed:
                        title += f" {r['amount'].strip()}"  # not a number: keep the text as typed
                elif fixed:
                    title += " " + format_amount(value, cur)
                elif r["amount_type"] == "per_video":
                    title += " " + format_amount(value * n, cur)
            out.append((r["name"], title))
        return out

    def run_billing(self, today=None):
        """Creates the invoice tasks of every month / quarter that ended since billing was switched on and
        isn't done yet. Safe to call as often as you like. Returns the created task titles."""
        today = today or date.today()
        self.conn.execute("CREATE TABLE IF NOT EXISTS billing_runs (period_key TEXT PRIMARY KEY, task_id TEXT, created_at TEXT NOT NULL)")
        row = self.conn.execute("SELECT created_at FROM billing_runs WHERE period_key='__since__'").fetchone()
        if not row:      # first run: only periods ending from today on are billed (no backlog of past months)
            self.conn.execute("INSERT INTO billing_runs (period_key, task_id, created_at) VALUES ('__since__', NULL, ?)",
                              (today.isoformat(),))
            self.conn.commit()
            since = today
        else:
            since = date.fromisoformat(row["created_at"])
        first = max(since, today - timedelta(days=100))
        created = []
        lid = None
        for kind, start, end in periods_ending_between(first, today):
            key = f"{kind}:{start.isoformat()}"
            if self.conn.execute("SELECT 1 FROM billing_runs WHERE period_key=?", (key,)).fetchone():
                continue
            invoices = self.billing_invoices(kind, start, end)
            tid = None
            if invoices:
                lid = lid or self.billing_target_list_id()
                if not lid:
                    print(f"[billing] list “{BILLING_PROJECT} / {BILLING_LIST}” not found: {kind} invoices of {start} postponed", flush=True)
                    continue
                title = f"Invoices {period_label(kind, start)}"
                tid = self.add_task(lid, title, due_date=end.isoformat())
                for _name, sub in invoices:
                    self.add_subtask(tid, sub, due_date=end.isoformat())
                created.append(title)
            self.conn.execute("INSERT INTO billing_runs (period_key, task_id, created_at) VALUES (?,?,?)",
                              (key, tid, datetime.now().isoformat()))
            self.conn.commit()
        return created
