"""Projects, to-do lists, tags and sponsor contracts."""
from __future__ import annotations
from datetime import date, datetime
from .core import PROJECT_COLORS, _clean_color, data_dir, new_id


class CatalogMixin:
    # -- projects ------------------------------------------------------
    def list_projects(self):
        rows = self.conn.execute("""
            SELECT p.*,
                   (SELECT COUNT(*) FROM tasks t JOIN todo_lists l ON l.id = t.todo_list_id
                    WHERE l.project_id = p.id AND t.checked = 0) AS task_count
            FROM projects p ORDER BY p.sort_order, p.name
        """).fetchall()
        return [dict(r) for r in rows]

    def add_project(self, name, color=None):
        pid = new_id()
        order = self.conn.execute("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM projects").fetchone()[0]
        self.conn.execute(
            "INSERT INTO projects (id, name, color, sort_order, created_at) VALUES (?,?,?,?,?)",
            (pid, name, _clean_color(color, PROJECT_COLORS[0]), order, datetime.now().isoformat()))
        self.conn.commit()
        return pid

    def update_project(self, pid, **fields):
        self._update("projects", pid, fields)

    def delete_project(self, pid):
        self._queue_task_files(
            "todo_list_id IN (SELECT id FROM todo_lists WHERE project_id=?)", (pid,))
        self.conn.execute("DELETE FROM projects WHERE id=?", (pid,))
        self.conn.commit()

    # -- todo lists ------------------------------------------------------
    def list_todo_lists(self, project_id=None):
        if project_id:
            rows = self.conn.execute("""
                SELECT l.*, (SELECT COUNT(*) FROM tasks t WHERE t.todo_list_id = l.id AND t.checked = 0) AS task_count
                FROM todo_lists l WHERE l.project_id=? ORDER BY l.sort_order, l.name
            """, (project_id,)).fetchall()
        else:
            rows = self.conn.execute("""
                SELECT l.*, (SELECT COUNT(*) FROM tasks t WHERE t.todo_list_id = l.id AND t.checked = 0) AS task_count
                FROM todo_lists l ORDER BY l.sort_order, l.name
            """).fetchall()
        return [dict(r) for r in rows]

    def get_todo_list(self, lid):
        row = self.conn.execute("SELECT * FROM todo_lists WHERE id=?", (lid,)).fetchone()
        return dict(row) if row else None

    def add_todo_list(self, project_id, name):
        lid = new_id()
        order = self.conn.execute(
            "SELECT COALESCE(MAX(sort_order), 0) + 1 FROM todo_lists WHERE project_id=?",
            (project_id,)).fetchone()[0]
        self.conn.execute("INSERT INTO todo_lists (id, project_id, name, sort_order) VALUES (?,?,?,?)",
                           (lid, project_id, name, order))
        self.conn.commit()
        return lid

    def reorder_todo_lists(self, project_id, ids):
        """Gives the lists of a project the order of `ids` (unknown ids are ignored, lists not named keep their relative order
        after the others) and renumbers sort_order 1..n."""
        cur = [r[0] for r in self.conn.execute(
            "SELECT id FROM todo_lists WHERE project_id=? ORDER BY sort_order, name", (project_id,)).fetchall()]
        first = [i for i in dict.fromkeys(ids) if i in cur]
        for n, lid in enumerate(first + [i for i in cur if i not in first], 1):
            self.conn.execute("UPDATE todo_lists SET sort_order=? WHERE id=?", (n, lid))
        self.conn.commit()

    def update_todo_list(self, lid, **fields):
        self._update("todo_lists", lid, fields)

    def delete_todo_list(self, lid):
        self._queue_task_files("todo_list_id=?", (lid,))
        self.conn.execute("DELETE FROM todo_lists WHERE id=?", (lid,))
        self.conn.commit()

    # -- tags ------------------------------------------------------
    def list_tags(self):
        rows = self.conn.execute("""
            SELECT g.*, (SELECT COUNT(*) FROM task_tags tt JOIN tasks t ON t.id = tt.task_id
                         WHERE tt.tag_id = g.id AND t.checked = 0) AS task_count
            FROM tags g ORDER BY g.name
        """).fetchall()
        return [dict(r) for r in rows]

    def add_tag(self, name, color=None):
        tid = new_id()
        self.conn.execute("INSERT INTO tags (id, name, color) VALUES (?,?,?)",
                           (tid, name, _clean_color(color, PROJECT_COLORS[0])))
        self.conn.commit()
        return tid

    def update_tag(self, tid, **fields):
        self._update("tags", tid, fields)

    def delete_tag(self, tid):
        c = self.conn.execute("SELECT file_path FROM tag_contracts WHERE tag_id=?", (tid,)).fetchone()
        if c:
            self._queue_unlink(c["file_path"])
        self._queue_unlink(data_dir() / "contracts" / tid)
        self.conn.execute("DELETE FROM tags WHERE id=?", (tid,))
        self.conn.commit()

    # -- sponsor contracts (one per tag) ---------------------------------
    def list_tag_contracts(self):
        """Every tag with its contract (if any): the "Contracts and Billing" tab."""
        rows = self.conn.execute("""
            SELECT g.id, g.name, g.color, c.file_name, c.file_path, c.total_videos, c.end_date, c.uploaded_at,
                   c.billing_period, c.amount_type, c.amount
            FROM tags g LEFT JOIN tag_contracts c ON c.tag_id = g.id
            ORDER BY g.name COLLATE NOCASE
        """).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["has_contract"] = bool(d.pop("file_path"))
            out.append(d)
        return out

    def get_tag_contract(self, tid):
        row = self.conn.execute("SELECT * FROM tag_contracts WHERE tag_id=?", (tid,)).fetchone()
        return dict(row) if row else None

    def set_tag_contract(self, tid, path, name, total_videos=None, end_date=None,
                         billing_period=None, amount_type=None, amount=None):
        self.conn.execute(
            "INSERT INTO tag_contracts (tag_id, file_path, file_name, total_videos, end_date, uploaded_at, "
            "billing_period, amount_type, amount) VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(tag_id) DO UPDATE SET "
            "file_path=excluded.file_path, file_name=excluded.file_name, total_videos=excluded.total_videos, "
            "end_date=excluded.end_date, uploaded_at=excluded.uploaded_at, billing_period=excluded.billing_period, "
            "amount_type=excluded.amount_type, amount=excluded.amount",
            (tid, path, name, total_videos, end_date, datetime.now().isoformat(), billing_period, amount_type, amount))
        self.conn.commit()

    def tag_by_name(self, name):
        row = self.conn.execute("SELECT * FROM tags WHERE name=? COLLATE NOCASE", (name,)).fetchone()
        return dict(row) if row else None

    def tags_monthly_report(self, year, month):
        """For the "Sponsors" sidebar view: every tag, how many (main) tasks
        due that month carry it, and which tasks (with their due dates)."""
        start = f"{year:04d}-{month:02d}-01"
        if month == 12:
            end = f"{year + 1:04d}-01-01"
        else:
            end = f"{year:04d}-{month + 1:02d}-01"
        tags = self.conn.execute("SELECT * FROM tags ORDER BY name").fetchall()
        report = []
        for g in tags:
            rows = self.conn.execute("""
                SELECT t.id, t.title, t.due_date, t.checked, t.mention_approved FROM tasks t
                JOIN task_tags tt ON tt.task_id = t.id
                WHERE tt.tag_id = ? AND t.due_date >= ? AND t.due_date < ?
                ORDER BY t.due_date
            """, (g["id"], start, end)).fetchall()
            tasks = [dict(r) for r in rows]
            report.append({
                "id": g["id"], "name": g["name"], "color": g["color"],
                "count": len(tasks),
                "tasks": tasks,
            })
        # Earliest main-task due date first (a sponsor with several videos is
        # ranked by its earliest one); sponsors with none this month go last.
        report.sort(key=lambda r: (not r["tasks"], r["tasks"][0]["due_date"] if r["tasks"] else "", r["name"].lower()))
        return report

    def get_or_create_other_tasks_list(self):
        """The catch-all "Other tasks" todo list the Sponsors view files its
        "Create Task" button's tasks into -- found by name wherever it
        already lives, or created under the first project if it doesn't."""
        row = self.conn.execute(
            "SELECT id FROM todo_lists WHERE name = 'Other tasks' COLLATE NOCASE LIMIT 1").fetchone()
        if row:
            return row["id"]
        proj = self.conn.execute("SELECT id FROM projects ORDER BY sort_order, name LIMIT 1").fetchone()
        pid = proj["id"] if proj else self.add_project("My Project", PROJECT_COLORS[0])
        return self.add_todo_list(pid, "Other tasks")

    def create_sponsor_mention_task(self, sponsor_name):
        """The Sponsors view's "Create Task" button: a 30-minute task due
        today, in the "Other tasks" list, to go write the sponsor mention."""
        lid = self.get_or_create_other_tasks_list()
        title = f"Create sponsored mention for {sponsor_name}"
        tid = self.add_task(lid, title, due_date=date.today().isoformat(), duration_minutes=30)
        return self.get_task(tid)
