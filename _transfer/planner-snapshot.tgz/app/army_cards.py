"""Dessin des « cartes » (partie droite des slides de List to PPT) : fiche technique, règle de détachement, stratagèmes,
dispositions. Tout est dessiné avec Pillow, en français, dans une charte sombre assortie au template PowerPoint.

Les polices viennent du système (Inter / Raleway si présentes, sinon DejaVu / Liberation / Noto) ; variable
d'environnement TASKPLANNER_FONT_DIR pour en imposer un dossier. Sans aucune police trouvée, Pillow utilise la sienne.
"""
from __future__ import annotations
import glob
import os
import re
import shutil
import subprocess
from functools import lru_cache

from PIL import Image, ImageDraw, ImageFont

CARD_W, CARD_H = 1800, 1670          # même proportions que la zone de l'image sur la slide (≈ 6,3 × 5,8 M EMU)

C = {
    # charte « Décontracté du C'Tan » : fond clair, noir charbon, rouge du logo
    "bg": (249, 249, 247), "panel": (240, 240, 237), "panel2": (229, 229, 226), "line": (196, 196, 192),
    "text": (30, 30, 34), "muted": (104, 104, 110), "accent": (205, 28, 36), "accent_dk": (226, 150, 150),
    "accent_lt": (244, 84, 84), "head": (34, 34, 38), "on_head": (250, 250, 248), "tint": (252, 232, 232),
    "danger": (205, 28, 36), "ok": (60, 150, 100),
}

_REG = ["Inter", "Raleway", "DejaVu Sans", "Liberation Sans", "Noto Sans", "FreeSans", "Carlito"]
_BOLD_NAMES = {"Inter": ["Inter:bold", "Inter:black"], "Raleway": ["Raleway:black", "Raleway:bold"]}


def _fc(pattern: str) -> str | None:
    exe = shutil.which("fc-match")
    if not exe:
        return None
    try:
        out = subprocess.run([exe, "-f", "%{file}|%{family}", pattern], capture_output=True, text=True, timeout=5).stdout
    except Exception:
        return None
    path, _, fam = out.partition("|")
    return path if path and os.path.exists(path) else None


@lru_cache(maxsize=None)
def _font_paths() -> tuple[str | None, str | None]:
    d = os.environ.get("TASKPLANNER_FONT_DIR")
    if d:
        files = sorted(glob.glob(os.path.join(d, "*.ttf")) + glob.glob(os.path.join(d, "*.otf")))
        bold = next((f for f in files if "bold" in os.path.basename(f).lower()), None)
        reg = next((f for f in files if "bold" not in os.path.basename(f).lower() and "italic" not in os.path.basename(f).lower()), None)
        if reg:
            return reg, bold or reg
    for fam in _REG:
        reg, bold = _fc(f"{fam}:style=Regular"), _fc(f"{fam}:bold")
        if reg and fam.lower().split()[0] in os.path.basename(reg).lower().replace("-", "").replace("_", ""):
            return reg, bold or reg
    for pat in ("/usr/share/fonts/**/DejaVuSans.ttf", "/usr/share/fonts/**/LiberationSans-Regular.ttf", "/usr/share/fonts/**/NotoSans-Regular.ttf"):
        hit = glob.glob(pat, recursive=True)
        if hit:
            bold = glob.glob(os.path.join(os.path.dirname(hit[0]), "*Bold.ttf")) or [hit[0]]
            return hit[0], next((b for b in bold if os.path.basename(b).startswith(os.path.basename(hit[0])[:5])), bold[0])
    return None, None


@lru_cache(maxsize=512)
def font(size: int, bold: bool = False):
    reg, bld = _font_paths()
    path = bld if bold else reg
    size = max(8, int(size))
    try:
        if path:
            f = ImageFont.truetype(path, size)
            if bold and path == reg:                 # police variable : graisse demandée
                try:
                    f.set_variation_by_axes([700 if (a.get("name") or b"").lower() in (b"weight", "weight") else a.get("default", 0)
                                             for a in f.get_variation_axes()])
                except Exception:
                    pass
            return f
    except Exception:
        pass
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


# ------------------------------------------------------------------ texte
def _w(f, s: str) -> float:
    return f.getlength(s)


def wrap(text: str, f, width: int) -> list[str]:
    out = []
    for para in str(text or "").split("\n"):
        words, line = para.split(), ""
        for w in words:
            t = (line + " " + w).strip()
            if _w(f, t) <= width or not line:
                line = t
            else:
                out.append(line)
                line = w
        out.append(line)
    return out or [""]


class Pen:
    """Un crayon à échelle variable : en mode `dry`, il ne fait que mesurer la hauteur nécessaire."""

    def __init__(self, img: Image.Image | None, dry: bool, scale: float):
        self.img, self.dry, self.s = img, dry, scale
        self.d = ImageDraw.Draw(img) if img is not None else None

    def px(self, v: float) -> int:
        return max(1, int(round(v * self.s)))

    def text(self, x, y, s, size, color="text", bold=False, anchor="la"):
        if not self.dry:
            self.d.text((x, y), s, font=font(self.px(size), bold), fill=C[color] if isinstance(color, str) else color, anchor=anchor)

    def para(self, x, y, width, s, size, color="text", bold=False, gap=1.28, max_lines=None) -> int:
        f = font(self.px(size), bold)
        lines = wrap(s, f, width)
        if max_lines and len(lines) > max_lines:
            lines = lines[:max_lines]
            lines[-1] = lines[-1].rstrip(" ,;.") + "…"
        lh = int(self.px(size) * gap)
        for i, ln in enumerate(lines):
            self.text(x, y + i * lh, ln, size, color, bold)
        return len(lines) * lh

    def rect(self, box, fill=None, outline=None, r=14, width=2):
        """Rectangle presque carré (style « cadre tactique ») : le rayon demandé est ramené à 3 px."""
        if not self.dry:
            self.d.rounded_rectangle(box, radius=3, fill=C[fill] if isinstance(fill, str) else fill,
                                     outline=C[outline] if isinstance(outline, str) else outline, width=width)

    def chamfer(self, box, cut=None, fill=None, outline=None, width=2, corners="tr,bl"):
        """Rectangle à coins coupés en biais (comme les angles de l'écran d'attente)."""
        if self.dry:
            return
        x0, y0, x1, y1 = box
        c = cut if cut is not None else min(x1 - x0, y1 - y0) * 0.28
        c = min(c, (x1 - x0) / 2, (y1 - y0) / 2)
        cs = set(corners.split(","))
        pts = [(x0 + (c if "tl" in cs else 0), y0), (x1 - (c if "tr" in cs else 0), y0)]
        if "tr" in cs:
            pts.append((x1, y0 + c))
        pts += [(x1, y1 - (c if "br" in cs else 0))]
        if "br" in cs:
            pts.append((x1 - c, y1))
        pts += [(x0 + (c if "bl" in cs else 0), y1)]
        if "bl" in cs:
            pts.append((x0, y1 - c))
        pts += [(x0, y0 + (c if "tl" in cs else 0))]
        if "tl" in cs:
            pts.append((x0 + c, y0))
        self.d.polygon(pts, fill=C[fill] if isinstance(fill, str) else fill)
        if outline:
            self.d.line(pts + [pts[0]], fill=C[outline] if isinstance(outline, str) else outline, width=width, joint="curve")

    def line(self, p0, p1, color="line", width=2):
        if not self.dry:
            self.d.line([p0, p1], fill=C[color], width=width)


def _fit(draw_fn, w: int, h: int, scales=(3.0, 2.7, 2.4, 2.15, 2.0, 1.85, 1.7, 1.55, 1.4, 1.28, 1.16, 1.06, 1.0, 0.92, 0.85, 0.78, 0.72, 0.66, 0.6, 0.55, 0.5, 0.45, 0.4, 0.36)):
    """Le plus grand facteur d'échelle pour lequel le contenu tient dans la hauteur h."""
    for s in scales:
        if draw_fn(Pen(None, True, s), 0, 0, w, s) <= h:
            return s
    return scales[-1]


def _new_card(w=CARD_W, h=CARD_H) -> Image.Image:
    img = Image.new("RGB", (w, h), C["bg"])
    return img


M = 70   # marge intérieure des cartes : laisse la place aux traits d'angle


def _brackets(pen: Pen):
    """Les traits d'angle de l'écran d'attente : angles coupés en biais, trait noir, segment rouge suivi de trois points."""
    if pen.dry:
        return
    W, H = pen.img.size
    d, m, c = pen.d, 26, 58
    k = min(W, H) / 1670
    dark, red = C["head"], C["accent"]
    lw = max(3, int(5 * k))
    for fx in (1, -1):
        for fy in (1, -1):
            X = lambda v: v if fx == 1 else W - v
            Y = lambda v: v if fy == 1 else H - v
            d.line([(X(m), Y(m + c + 150 * k)), (X(m), Y(m + c)), (X(m + c), Y(m)), (X(m + c + 190 * k), Y(m))], fill=dark, width=lw, joint="curve")
            if fy == 1:                                            # haut : segment rouge + trois points
                d.line([(X(m + c + 235 * k), Y(m)), (X(m + c + 470 * k), Y(m))], fill=red, width=lw)
                for i in range(3):
                    cx = m + c + 505 * k + i * 26 * k
                    d.ellipse([X(cx) - 5 * k, Y(m) - 5 * k, X(cx) + 5 * k, Y(m) + 5 * k], fill=red)
            else:                                                  # bas : trait rouge vertical le long du bord
                d.line([(X(m + 14 * k), Y(m + c + 190 * k)), (X(m + 14 * k), Y(m + c + 330 * k))], fill=red, width=lw)
            if fy == 1:
                d.line([(X(m + 14 * k), Y(m + c + 190 * k)), (X(m + 14 * k), Y(m + c + 300 * k))], fill=red, width=lw)


_LOGO = {}


def _logo(pen: Pen, x, y, size):
    """Le logo (rond) posé dans le coin d'un bandeau ; ignoré si le fichier est absent."""
    if pen.dry:
        return
    try:
        key = int(size)
        if key not in _LOGO:
            here = os.path.dirname(os.path.abspath(__file__))
            im = Image.open(os.path.join(here, "assets", "logo.png")).convert("RGBA")
            _LOGO[key] = im.resize((key, key), Image.LANCZOS)
        pen.img.paste(_LOGO[key], (int(x), int(y)), _LOGO[key])
    except Exception:
        pass


def _render_block(draw) -> Image.Image:
    """draw(pen, x, y, w, scale) -> hauteur. Ajuste l'échelle, centre dans la marge, trace les traits d'angle."""
    img = _new_card()
    iw, ih = CARD_W - 2 * M, CARD_H - 2 * M
    s = _fit(lambda pen, x, y, w, s2: draw(Pen(None, True, s2), 0, 0, w, s2), iw, ih)
    pen = Pen(img, False, s)
    _brackets(pen)
    h = draw(Pen(None, True, s), 0, 0, iw, s)
    draw(pen, M, M + max(0, (ih - h) // 2), iw, s)
    return img


def _badge(pen: Pen, x, y, w, h, label, value, hot=False):
    pen.chamfer((x, y, x + w, y + h), cut=pen.px(20), fill="panel", outline="accent" if hot else "line", width=3 if hot else 2, corners="tr,bl")
    pen.text(x + w / 2, y + pen.px(14), label, 21, "accent" if hot else "muted", True, "ma")
    pen.text(x + w / 2, y + h * 0.60, str(value), 44, "text", True, "mm")


# ------------------------------------------------------------------ éléments communs
def _chips(pen: Pen, x, y, width, items, size=21, color="muted") -> int:
    """Des mots-clés en pastilles, passant à la ligne."""
    f = font(pen.px(size), True)
    cx, cy, lh = x, y, pen.px(size) + pen.px(20)
    for it in items:
        t = str(it).upper()
        tw = int(_w(f, t)) + pen.px(26)
        if cx + tw > x + width and cx > x:
            cx, cy = x, cy + lh + pen.px(8)
        pen.rect((cx, cy, cx + tw, cy + lh), fill="panel2", outline="line", width=2)
        pen.text(cx + tw / 2, cy + lh / 2, t, size, color, True, "mm")
        cx += tw + pen.px(10)
    return (cy + lh - y) if items else 0


def _as_bullets(v) -> list:
    """Une règle -> liste de puces : `bullets`/liste telle quelle, sinon texte découpé en phrases."""
    if isinstance(v, dict):
        v = v.get("bullets") or v.get("text") or v.get("effect")
    if isinstance(v, (list, tuple)):
        return [str(x).strip() for x in v if str(x).strip()]
    t = str(v or "").strip()
    if not t:
        return []
    out = []
    for blk in t.split("\n"):
        out += [p.strip() for p in re.split(r"(?<=[.;!?])\s+(?=[A-ZÉÈÀÂÊÎÔÛ\[])", blk.strip().lstrip("-•· ")) if p.strip()]
    return out


def _bullet_list(pen: Pen, x, y, w, items, size, color="text", gap=6, lh=1.22) -> int:
    """Puces compactes avec carré rouge ; renvoie la hauteur."""
    top = y
    ind = pen.px(size * 0.95)
    for it in items:
        sq = pen.px(size * 0.30)
        cy = y + int(pen.px(size) * 0.62)
        pen.rect((x + pen.px(4), cy - sq // 2, x + pen.px(4) + sq, cy + sq // 2), fill="accent", r=1, width=0)
        y += pen.para(x + ind, y, w - ind, it, size, color, False, lh) + pen.px(gap)
    return y - top


def _bl_h(pen: Pen, x, w, items, size, gap=6, lh=1.22) -> int:
    return _bullet_list(Pen(None, True, pen.s), 0, 0, w, items, size, gap=gap, lh=lh)


def _section_title(pen: Pen, x, y, width, label, size=24) -> int:
    pen.text(x, y, label.upper(), size, "accent", True)
    ly = y + pen.px(size) + pen.px(8)
    pen.line((x, ly), (x + width, ly), "line", 2)
    pen.line((x, ly), (x + pen.px(90), ly), "accent", 4)
    return pen.px(size) + pen.px(20)


# ------------------------------------------------------------------ fiche technique
HEADS_R = ["PORTÉE", "A", "CT", "F", "PA", "D"]
HEADS_M = ["PORTÉE", "A", "CC", "F", "PA", "D"]


def _weapon_table(pen: Pen, x, y, width, title, heads, rows, compact) -> int:
    start = y
    name_w = int(width * 0.46)
    col_w = (width - name_w) / len(heads)
    y += _section_title(pen, x, y, width, title, 23)
    for j, hd in enumerate(heads):
        pen.text(x + name_w + col_w * j + col_w / 2, y, hd, 19, "muted", True, "ma")
    y += pen.px(19) + pen.px(12)
    for k, wp in enumerate(rows):
        f_name = font(pen.px(24), True)
        nlines = wrap(wp.get("name", ""), f_name, name_w - pen.px(16))
        kw = ", ".join(wp.get("keywords") or [])
        klines = wrap(kw, font(pen.px(19)), name_w - pen.px(16)) if (kw and not compact) else []
        lh = int(pen.px(24) * 1.2)
        kh = int(pen.px(19) * 1.25)
        rh = len(nlines) * lh + len(klines) * kh + pen.px(18)
        pen.rect((x, y, x + width, y + rh), fill="panel" if k % 2 == 0 else "panel2", r=10, width=0)
        for i, ln in enumerate(nlines):
            pen.text(x + pen.px(10), y + pen.px(9) + i * lh, ln, 24, "text", True)
        for i, ln in enumerate(klines):
            pen.text(x + pen.px(10), y + pen.px(9) + len(nlines) * lh + i * kh, ln, 19, "accent")
        vals = [wp.get("range") or "Mêlée" if heads is HEADS_M else wp.get("range") or "—", wp.get("A", "—"), wp.get("skill", "—"),
                wp.get("S", "—"), wp.get("AP", "—"), wp.get("D", "—")]
        for j, v in enumerate(vals):
            pen.text(x + name_w + col_w * j + col_w / 2, y + rh / 2, str(v), 25, "text", False, "mm")
        y += rh + pen.px(6)
    return y - start


def draw_datasheet(pen: Pen, x: int, y: int, w: int, scale: float, d: dict, info: dict, compact=False, framed=True, cols=1) -> int:
    """Dessine une fiche technique dans la largeur w ; renvoie la hauteur utilisée. d = données Wahapedia (en français),
    info = ce qui vient de la liste (points, nombre d'exemplaires, option)."""
    pad = pen.px(34)
    ix, iw = x + pad, w - 2 * pad
    y0 = y
    y += pad // 2
    # bandeau : logo + nom + points
    head_h = pen.px(118)
    pen.chamfer((x + 4, y, x + w - 4, y + head_h), cut=pen.px(34), fill="head", corners="tr,bl")
    pen.line((x + 4 + pen.px(34), y + head_h - 3), (x + w - 4 - pen.px(8), y + head_h - 3), "accent", 4) if False else None
    lg = int(head_h * 0.72)
    _logo(pen, ix + pen.px(6), y + (head_h - lg) // 2, lg)
    tx = ix + pen.px(6) + lg + pen.px(22)
    name = (info.get("title") or d.get("name") or "").upper()
    nf = pen.px(50)
    while nf > 14 and _w(font(nf, True), name) > (x + w - tx) - pen.px(340):
        nf -= 2
    pen.text(tx, y + head_h * 0.38, name, nf / pen.s, "on_head", True, "lm")
    sub = " · ".join(x_ for x_ in [d.get("faction_line") or "", d.get("composition_short") or ""] if x_)
    if sub:
        pen.text(tx, y + head_h * 0.76, sub[:70], 21, "accent_dk", False, "lm")
    pts = info.get("points")
    if pts:
        label = f"{pts} PTS" + (f"  ×{info['count']}" if info.get("count", 1) > 1 else "")
        bw = int(_w(font(pen.px(36), True), label)) + pen.px(40)
        pen.chamfer((x + w - 4 - pad // 2 - bw, y + head_h * 0.2, x + w - 4 - pad // 2, y + head_h * 0.8), cut=pen.px(14), fill="accent", corners="tr,bl")
        pen.text(x + w - 4 - pad // 2 - bw / 2, y + head_h / 2, label, 36, "on_head", True, "mm")
    y += head_h + pen.px(22)

    # caractéristiques
    st = d.get("stats") or {}
    keys = [("M", "M"), ("T", "E"), ("Sv", "SV"), ("W", "PV"), ("Ld", "CD"), ("OC", "CO")]
    present = [(lab, st.get(k) or st.get(k.lower()) or "—") for k, lab in keys]
    gap = pen.px(12)
    bw = (iw - gap * (len(present) - 1)) // len(present)
    bh = pen.px(104)
    for i, (lab, val) in enumerate(present):
        _badge(pen, ix + i * (bw + gap), y, bw, bh, lab, val, hot=(lab == "SV"))
    y += bh + pen.px(10)
    inv = st.get("Inv") or st.get("inv")
    if inv and str(inv) not in ("-", "—", ""):
        pen.chamfer((ix, y, ix + iw, y + pen.px(48)), cut=pen.px(14), fill="tint", outline="accent", width=2, corners="tr,bl")
        pen.text(ix + pen.px(16), y + pen.px(24), f"Invulnérable {inv}", 24, "accent", True, "lm")
        if d.get("damaged"):
            pen.text(ix + iw - pen.px(16), y + pen.px(24), str(d["damaged"])[:60], 20, "muted", False, "rm")
        y += pen.px(60)
    else:
        y += pen.px(12)

    def weapons_block(x0, y1, w1):
        top = y1
        rng = [wp for wp in (d.get("weapons") or []) if (wp.get("type") or "").lower().startswith(("r", "d", "ranged", "dist"))]
        mel = [wp for wp in (d.get("weapons") or []) if wp not in rng]
        if rng:
            y1 += _weapon_table(pen, x0, y1, w1, "Armes à distance", HEADS_R, rng, compact) + pen.px(14)
        if mel:
            y1 += _weapon_table(pen, x0, y1, w1, "Armes de mêlée", HEADS_M, mel, compact) + pen.px(14)
        return y1 - top

    def text_block(x0, y1, w1):
        top = y1
        abil = d.get("abilities") or []
        if abil:
            y1 += _section_title(pen, x0, y1, w1, "Capacités", 23)
            for ab in abil:
                y1 += pen.para(x0, y1, w1, (ab.get("name") or "").upper(), 22, "accent", True)
                y1 += _bullet_list(pen, x0, y1, w1, _as_bullets(ab), 22, gap=3) + pen.px(8)
        core = d.get("core") or []
        if core:
            y1 += pen.para(x0, y1, w1, "Capacités de base : " + ", ".join(core), 21, "muted", False) + pen.px(8)
        fa = d.get("faction_abilities") or []
        if fa:
            y1 += pen.para(x0, y1, w1, "Capacités de faction : " + ", ".join(fa), 21, "muted", False) + pen.px(8)
        ld = d.get("leader")
        if ld and not compact:
            y1 += pen.para(x0, y1, w1, "Meneur : " + str(ld), 21, "muted", False) + pen.px(8)
        enh = info.get("enhancement") or d.get("enhancement")
        if enh and (enh.get("name") if isinstance(enh, dict) else enh):
            e = enh if isinstance(enh, dict) else {"name": enh}
            head = "OPTIMISATION : " + str(e.get("name", "")).upper() + (f"  (+{e['cost']} pts)" if e.get("cost") else "")
            bl = _as_bullets(e)
            bw_ = w1 - pen.px(32)
            hh = pen.px(26) + pen.px(34) + _bl_h(pen, 0, bw_, bl, 22, gap=3) + pen.px(8)
            pen.chamfer((x0, y1, x0 + w1, y1 + hh), cut=pen.px(26), fill="tint", outline="accent", width=3, corners="tr,bl")
            pen.text(x0 + pen.px(16), y1 + pen.px(12), head, 23, "accent", True)
            _bullet_list(pen, x0 + pen.px(16), y1 + pen.px(12) + pen.px(34), bw_, bl, 22, gap=3)
            y1 += hh + pen.px(12)
        kw = d.get("keywords") or []
        if kw and not compact:
            y1 += pen.px(6)
            y1 += _chips(pen, x0, y1, w1, kw[:12], 18) + pen.px(8)
        return y1 - top

    if cols == 2:
        gap2 = pen.px(30)
        lw = int((iw - gap2) * 0.54)
        rw = iw - gap2 - lw
        y += max(weapons_block(ix, y, lw), text_block(ix + lw + gap2, y, rw))
    else:
        y += weapons_block(ix, y, iw)
        y += text_block(ix, y, iw)
    y += pad // 2
    return y - y0


def render_datasheets(entries: list[dict]) -> Image.Image:
    """entries = [{"data": …, "info": …}] : une fiche, ou plusieurs empilées (personnages attachés)."""
    n = len(entries)
    if n == 1:
        e = entries[0]
        iw, ih = CARD_W - 2 * M, CARD_H - 2 * M
        best = None
        for cols, compact in ((1, False), (2, False), (2, True)):
            sc = _fit(lambda pen, x, y, w, s2: draw_datasheet(Pen(None, True, s2), 0, 0, w, s2, e["data"], e["info"], compact=compact, cols=cols, framed=False), iw, ih)
            if best is None or sc > best[0] * 1.15:
                best = (sc, cols, compact)
            if sc >= 0.8:
                break
        _, cols, compact = best
        return _render_block(lambda pen, x, y, w, s: draw_datasheet(pen, x, y, w, s, e["data"], e["info"], compact=compact, cols=cols, framed=False))
    img = _new_card()
    each = CARD_H // n
    for k, e in enumerate(entries):
        sub = Image.new("RGB", (CARD_W, each), C["bg"])
        mm = 60
        iw, ih = CARD_W - 2 * mm, each - 2 * mm
        s = _fit(lambda pen, x, y, w, s2: draw_datasheet(Pen(None, True, s2), 0, 0, w, s2, e["data"], e["info"], compact=True, framed=False), iw, ih)
        pen = Pen(sub, False, s)
        _brackets(pen)
        h = draw_datasheet(Pen(None, True, s), 0, 0, iw, s, e["data"], e["info"], compact=True, framed=False)
        draw_datasheet(pen, mm, mm + max(0, (ih - h) // 2), iw, s, e["data"], e["info"], compact=True, framed=False)
        img.paste(sub, (0, k * each))
    return img


# ------------------------------------------------------------------ règle de détachement, stratagèmes, dispositions
def _title_band(pen: Pen, x, y, w, kicker, title) -> int:
    bh = pen.px(150)
    pen.chamfer((x + 8, y, x + w - 8, y + bh), cut=pen.px(46), fill="head", corners="tr,bl")
    lg = int(bh * 0.66)
    _logo(pen, x + pen.px(36), y + (bh - lg) // 2, lg)
    tx = x + pen.px(36) + lg + pen.px(30)
    pen.text(tx, y + pen.px(40), kicker.upper(), 24, "accent_lt", True)
    nf = 54
    while nf > 12 and _w(font(pen.px(nf), True), title.upper()) > (x + w - tx) - pen.px(70):
        nf -= 2
    pen.text(tx, y + pen.px(100), title.upper(), nf, "on_head", True, "lm")
    return bh + pen.px(26)


def draw_rule(pen: Pen, x, y, w, s, data: dict, title: str) -> int:
    y0 = y + pen.px(26)
    y = y0
    pad = pen.px(46)
    ix, iw = x + pad, w - 2 * pad
    y += _title_band(pen, x + 14, y, w - 28, "Règle de détachement", title)
    rule = data.get("rule") or {}
    if rule.get("name"):
        y += pen.para(ix, y, iw, rule["name"].upper(), 34, "accent", True) + pen.px(12)
    y += _bullet_list(pen, ix, y, iw, _as_bullets(rule), 32, gap=14, lh=1.25)
    return y - y0 + pen.px(40)


def render_rule(data: dict, title: str) -> Image.Image:
    return _render_block(lambda pen, x, y, w, s: draw_rule(pen, x, y, w, s, data, title))



def draw_strat(pen: Pen, x, y, w, s, st: dict, compact=False) -> int:
    pad = pen.px(30)
    ix, iw = x + pad, w - 2 * pad
    f = font(pen.px(23))
    parts = []
    for lab, key in (("QUAND", "when"), ("CIBLE", "target"), ("EFFET", "effect"), ("RESTRICTIONS", "restrictions")):
        v = st.get(key)
        if v:
            parts.append((lab, _as_bullets(v) if key in ("effect", "restrictions") else str(v), key in ("effect", "restrictions")))
    lh = int(pen.px(23) * 1.26)
    hh = pen.px(20)
    cw = iw - pen.px(190)
    body_h = 0
    for lab, tx, isb in parts:
        body_h += (_bl_h(pen, 0, cw, tx, 23, gap=3) if isb else len(wrap(tx, f, cw)) * lh) + pen.px(8)
    total = pen.px(62) + pen.px(16) + body_h + hh
    pen.chamfer((x, y, x + w, y + total), cut=pen.px(30), fill="panel", outline="line", width=2, corners="tr,bl")
    pen.chamfer((x, y, x + w, y + pen.px(62)), cut=pen.px(30), fill="head", corners="tr")
    pen.rect((x, y + pen.px(62), x + pen.px(8), y + total - pen.px(30)), fill="accent", width=0)
    nm = (st.get("name") or "").upper()
    nf = 32
    while nf > 10 and _w(font(pen.px(nf), True), nm) > iw - pen.px(150):
        nf -= 2
    pen.text(ix, y + pen.px(31), nm, nf, "on_head", True, "lm")
    cp = st.get("cp")
    if cp not in (None, ""):
        bw = pen.px(110)
        pen.chamfer((x + w - pad - bw - pen.px(24), y + pen.px(9), x + w - pad - pen.px(24), y + pen.px(53)), cut=pen.px(12), fill="accent", corners="tr,bl")
        pen.text(x + w - pad - bw / 2 - pen.px(24), y + pen.px(31), f"{cp} PC", 26, "on_head", True, "mm")
    cy = y + pen.px(78)
    for lab, tx, isb in parts:
        pen.text(ix, cy + 2, lab, 18, "accent", True)
        if isb:
            cy += _bullet_list(pen, ix + pen.px(190), cy, cw, tx, 23, gap=3) + pen.px(8)
        else:
            cy += pen.para(ix + pen.px(190), cy, cw, tx, 23, "text", False, 1.26) + pen.px(8)
    return total


def draw_strats(pen: Pen, x, y, w, s, strats: list, title: str) -> int:
    y0 = y + pen.px(22)
    y = y0 + _title_band(pen, x + 14, y0, w - 28, "Stratagèmes", title)
    for st in strats:
        y += draw_strat(pen, x + pen.px(30), y, w - pen.px(60), s, st) + pen.px(18)
    return y - y0


def render_stratagems(strats: list, title: str) -> Image.Image:
    return _render_block(lambda pen, x, y, w, s: draw_strats(pen, x, y, w, s, strats, title))



def draw_dispositions(pen: Pen, x, y, w, s, ctx: dict) -> int:
    y0 = y + pen.px(26)
    y = y0
    pad = pen.px(46)
    ix, iw = x + pad, w - 2 * pad
    y += _title_band(pen, x + 14, y, w - 28, "Dispositions de forces", ctx.get("army") or "Dispositions")
    y += pen.px(14)
    for it in ctx.get("items") or []:
        pen.rect((ix, y, ix + pen.px(10), y + pen.px(40)), fill="accent", r=2, width=0)
        y += pen.para(ix + pen.px(28), y, iw - pen.px(28), (it.get("name") or "").upper(), 38, "accent", True) + pen.px(10)
        bl = [f"Contre {m['vs']} : {m['mission']}" if m.get("vs") else m["mission"] for m in it.get("missions") or []]
        if not bl and it.get("text"):
            bl = _as_bullets(it["text"])
        y += _bullet_list(pen, ix + pen.px(28), y, iw - pen.px(28), bl, 28, gap=8) + pen.px(22)
    if ctx.get("units_total"):
        y += pen.para(ix, y, iw, ctx["units_total"], 24, "muted", False) + pen.px(8)
    return y - y0 + pen.px(30)


def render_dispositions(ctx: dict) -> Image.Image:
    return _render_block(lambda pen, x, y, w, s: draw_dispositions(pen, x, y, w, s, ctx))
