"""Agent de capture : relit les captures d'articles faites par news_capture.py et corrige celles qui ne sont pas bonnes.

Répartition du travail :
  - le navigateur (Playwright) est piloté par `news_capture.py --agent-step` : il OBSERVE une page (plan numéroté de ses
    blocs, conteneurs possibles du corps, blocs cachés par le nettoyage) ou APPLIQUE une décision (masquer / rétablir des
    blocs, changer de conteneur) et refait la capture ;
  - l'IA (le modèle choisi dans « AI settings », avec les images si le modèle les lit) tourne ICI, dans le Planner :
    elle regarde le plan, le texte de la note du sujet et les mesures, puis répond par une décision en JSON.

Boucle par page : observer -> l'IA juge -> (« fix ») appliquer -> l'IA juge le résultat -> ... (2 corrections au plus).
Si les corrections n'améliorent rien, la capture d'origine est rétablie.

Mode : variable d'environnement PLANNER_CAPTURE_AGENT = off | auto (défaut : pages en échec ou douteuses) | all.
"""
from __future__ import annotations
import json
import os
import re
import shutil
from pathlib import Path

from . import ai
from .ai import AIError

MAX_FIXES = 2

SYSTEM = """You operate a screenshot tool that captures the BODY of a news article, to be shown full-screen in a video about
that article. You receive an outline of the page's blocks and measurements of the current capture, and you answer with ONE JSON
object. What a good capture is:
- Only the article's main body: its images and embeds (tweets, Mastodon / Bluesky / Reddit posts, videos, charts) STAY.
- NO site header or footer, menus, sidebars, advertising, cookie / newsletter / subscribe / share boxes, comment area, author
  box, "related / read next / more from / you may also like / popular" blocks, and nothing that interrupts the body's flow.
- The page's own title may be dropped when it is what makes the capture wide (big side margins). No big margins on the left /
  right: the capture must hug the text column.
- Dark mode is applied automatically; you do not handle it.
- The video's author wrote a short note about the article (given below, in his own words, with typos, so it is a loose summary):
  use it to understand which part of the article the video talks about. A page section that is clearly unrelated to the note
  (another story in a round-up, a long unrelated appendix, a live-blog's other entries) can be hidden; but never hide real article
  content just because the note is brief, and never hide most of the article.
Be conservative: if the capture is already good, accept it."""

BOILERPLATE = re.compile(
    r"^\W*(related( articles| posts| stories)?|read (next|more|also)|you (may|might) also like|more (from|on|stories)|recommended|"
    r"popular|trending|most read|comments?|leave a (comment|reply)|share( this)?( article| story)?|subscribe|newsletter|"
    r"sign up|advertisement|sponsored|about the author|follow us|cookie|accept all|log ?in|à lire aussi|lire aussi|publicité|"
    r"commentaires?|partager|articles? (en )?lien)\b", re.I)


def mode() -> str:
    m = (os.environ.get("PLANNER_CAPTURE_AGENT") or "auto").strip().lower()
    return m if m in ("off", "auto", "all") else "auto"


# -- the author's note, for one topic ------------------------------------------------------------------------
def note_text_for(note_text: str, urls: list[str]) -> str:
    """The author's own paragraphs about the topic whose links are `urls`: in the note's Content section, the paragraphs just
    before the URL block that contains one of these links."""
    m = re.search(r"^#{1,6}\s*\**\s*content\b.*$", note_text, re.I | re.M)
    body = note_text[m.end():] if m else note_text
    blocks = [b.strip() for b in re.split(r"\n\s*\n", body) if b.strip()]
    isurl = lambda b: all(re.match(r"^(https?|file)://\S+$", ln.strip()) for ln in b.splitlines() if ln.strip())
    wanted = {u.rstrip("/") for u in urls}
    for i, b in enumerate(blocks):
        if isurl(b) and any(ln.strip().rstrip("/") in wanted for ln in b.splitlines()):
            j = i
            while j > 0 and not isurl(blocks[j - 1]):
                j -= 1
            return "\n\n".join(blocks[j:i])[:2500]
    return ""


def keywords(text: str, limit: int = 600) -> list[str]:
    seen, out = set(), []
    for w in re.findall(r"[a-zà-ÿ0-9]{5,}", text.lower()):
        if w not in seen:
            seen.add(w)
            out.append(w)
    return out[:limit]


def coverage(note: str, body_text: str) -> float | None:
    """Share of the note's distinctive words that appear in the captured text (None when there is no note)."""
    kw = keywords(note)
    if len(kw) < 12:
        return None
    low = body_text.lower()
    return sum(1 for w in kw if w in low) / len(kw)


# -- is a capture suspicious? --------------------------------------------------------------------------------
def assess(c: dict, note: str) -> list[str]:
    """Reasons to look at a capture again (empty = looks fine). `c` is a capture_info entry or an agent observation."""
    flags = []
    if c.get("error"):
        flags.append("capture failed: " + str(c["error"])[:120])
        return flags
    info = c.get("info") or c
    text = info.get("body_text") or ""
    if info.get("text", len(text)) < 700:
        flags.append("very little text captured")
    cov = coverage(note, text) if note else None
    if cov is not None and cov < 0.3:
        flags.append(f"the captured text covers only {cov:.0%} of the note's words (wrong block?)")
    bp = [ln.strip()[:50] for ln in text.splitlines() if ln.strip() and len(ln.strip()) < 70 and BOILERPLATE.match(ln.strip())]
    if bp:
        flags.append("site furniture still in the capture: " + "; ".join(bp[:3]))
    if info.get("warns"):
        flags.append("; ".join(info["warns"])[:150])
    if (info.get("colW") or 0) > 1000:
        flags.append(f"wide capture ({info.get('colW')} px of page): big side margins?")
    if info.get("parts", 1) > 6:
        flags.append(f"{info.get('parts')} parts: the page is very long")
    emb = info.get("embeds") or {}
    if emb.get("page", 0) > emb.get("kept", 0):
        flags.append(f"{emb['page'] - emb['kept']} embed(s) of the page are not in the capture")
    if str(info.get("strategy", "")).startswith(("page", "balise main")):
        flags.append("the body was found by a fallback rule (" + str(info.get("strategy")) + ")")
    return flags


# -- the outline shown to the model ------------------------------------------------------------------------------
def _outline_text(o: dict) -> tuple[str, dict]:
    """Compact text of the outline + the id -> CSS path maps (u..., c..., h...)."""
    paths = {}
    lines = []
    units = o.get("units") or []
    i = 0
    while i < len(units):
        u = units[i]
        paths[f"u{u['i']}"] = u["path"]
        mt = f", note≈{int(u.get('match', 0) * 100)}%" if u.get("match") else ""
        def plain(x):
            return x["tag"] == "p" and x["kind"] == "block" and x["links"] < 0.3

        def parent(x):
            return x["path"].rsplit(" > ", 1)[0]

        if plain(u):                                  # runs of plain paragraphs of the same container and similar note match -> one line
            j = i
            while (j + 1 < len(units) and plain(units[j + 1]) and parent(units[j + 1]) == parent(u)
                   and abs(units[j + 1].get("match", 0) - units[j].get("match", 0)) <= 0.35):
                j += 1
                paths[f"u{units[j]['i']}"] = units[j]["path"]
            if j > i:
                run = units[i:j + 1]
                avg = sum(x.get("match", 0) for x in run) / len(run)
                lines.append(f"u{u['i']}-u{units[j]['i']}  p×{len(run)} ({sum(x['chars'] for x in run)} ch, note≈{int(avg * 100)}%)  \"{u['text'][:60]}…\" … \"{units[j]['text'][:40]}…\"")
                i = j + 1
                continue
        emb = " EMBED" if u.get("embed") else ""
        img = f" imgs={u['imgs']}" if u.get("imgs") else ""
        cls = f" .{u['cls']}" if u.get("cls") else ""
        lines.append(f"u{u['i']}  <{u['tag']}{cls}> {u['kind']}{emb}{img} ({u['chars']} ch, links {int(u['links'] * 100)}%{mt})  \"{u['text'][:100]}\"")
        i += 1
    cl = []
    for n, c in enumerate(o.get("cands") or []):
        paths[f"c{n}"] = c["path"]
        cl.append(f"c{n}  <{c['tag']}{' .' + c['cls'] if c['cls'] else ''}> {c['chars']} ch — {c['why']}")
    hl = []
    for n, h in enumerate(o.get("hidden") or []):
        paths[f"h{n}"] = h["path"]
        hl.append(f"h{n}  <{h['tag']}{' .' + h['cls'] if h['cls'] else ''}> ({h['chars']} ch)  \"{h['text'][:90]}\"")
    txt = ("BLOCKS OF THE CAPTURED BODY, in page order:\n" + "\n".join(lines or ["(none)"]) +
           "\n\nPOSSIBLE CONTAINERS FOR THE BODY (c...):\n" + "\n".join(cl or ["(none)"]) +
           "\n\nBLOCKS ALREADY HIDDEN by the automatic clean-up and that held text (h...):\n" + "\n".join(hl or ["(none)"]))
    return txt, paths


def _expand(ids, paths: dict, units: list) -> list[str]:
    """['u3', 'u7-u12', 'h0'] -> CSS paths (unknown ids are ignored)."""
    out = []
    for x in ids or []:
        x = str(x).strip()
        m = re.fullmatch(r"u(\d+)\s*-\s*u(\d+)", x)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            out += [paths[f"u{k}"] for k in range(min(a, b), max(a, b) + 1) if f"u{k}" in paths]
        elif x in paths:
            out.append(paths[x])
    return list(dict.fromkeys(out))


def _contact_sheet(files: list[str], dest: Path) -> str | None:
    """One small picture with all the parts side by side (for models that read images)."""
    try:
        from PIL import Image
        ims = [Image.open(f).convert("RGB") for f in files[:6]]
        if not ims:
            return None
        h = 1100
        ims = [im.resize((max(1, int(im.width * h / im.height)), h), Image.LANCZOS) if im.height > h else im for im in ims]
        W = sum(im.width for im in ims) + 12 * (len(ims) - 1)
        sheet = Image.new("RGB", (W, max(im.height for im in ims)), (128, 128, 128))
        x = 0
        for im in ims:
            sheet.paste(im, (x, 0))
            x += im.width + 12
        if sheet.width > 2400:
            sheet = sheet.resize((2400, int(sheet.height * 2400 / sheet.width)), Image.LANCZOS)
        dest.parent.mkdir(parents=True, exist_ok=True)
        sheet.save(dest)
        return str(dest)
    except Exception:  # noqa: BLE001 -- the picture is a bonus
        return None


def _facts(c: dict) -> str:
    info = c.get("info") or c
    emb = info.get("embeds") or {}
    return (f"strategy={info.get('strategy')}, body text={info.get('text')} ch, dark mode={info.get('dark')}, zoom x{info.get('scale')}, "
            f"capture width={info.get('colW')} css px, {info.get('parts')} part(s), page height={info.get('height')} css px, "
            f"embeds in capture={emb.get('kept')}/{emb.get('page')}")


def judge(page: dict, obs: dict, note: str, rnd: int, out_dir: Path) -> dict:
    """Ask the model for a decision about one page. Returns {verdict, body, hide, show, reason, ...}."""
    outline = obs.get("outline") or {}
    otxt, paths = _outline_text(outline)
    cur = page.get("current") or {}
    files = cur.get("files") or []
    sheet = _contact_sheet(files, out_dir / "_agent" / page["id"].replace(":", "_") / f"sheet{rnd}.png") if (files and ai.vision_available()) else None
    flags = assess(cur, note) if cur else []
    prompt = (
        f"Topic of the video: {page['title']}\nPage: {page['url']}\nPage title: {outline.get('title')!r}  first h1: {outline.get('h1')!r}\n"
        f"Round {rnd}: " + ("first look at the automatic capture." if rnd == 0 else f"result of your previous fix ({page.get('last_reason') or ''}).") + "\n\n"
        f"THE AUTHOR'S NOTE ABOUT THIS ARTICLE:\n{note or '(none found)'}\n\n"
        f"CURRENT CAPTURE: {_facts(cur) if cur else '(none: the capture failed)'}\n"
        f"Automatic checks: {'; '.join(flags) if flags else 'nothing suspicious'}\n"
        + (f"\nLook at this image (all parts of the capture side by side): {sheet}\n" if sheet else "")
        + "\n" + otxt +
        "\n\nAnswer with ONLY a JSON object:\n"
        '{"verdict": "accept" | "fix", "body": null | "c1", "hide": ["u12", "u20-u25"], "show": ["h0"], "reason": "short"}\n'
        "- accept: the capture is good as it is (hide/show/body ignored).\n"
        "- hide: block ids or ranges to remove (site furniture left, unrelated sections, anything cutting the body).\n"
        "- show: ids from the 'already hidden' list that are real article content and must come back.\n"
        "- body: use another container as the article body (only when the current one is wrong: it is applied ALONE, you will then see "
        "its outline and can hide blocks in the next round).\n"
        "Never hide embeds or images that belong to the article."
    )
    reply = ai.call_claude(prompt, system=SYSTEM, max_tokens=1200, read_dirs=[sheet and Path(sheet).parent] if sheet else None)
    d = ai.extract_json_object(reply)
    verdict = "fix" if str(d.get("verdict", "")).lower() == "fix" else "accept"
    dec = {"verdict": verdict, "reason": str(d.get("reason") or "")[:300], "hide": [], "show": [], "body": None}
    if verdict == "fix":
        if d.get("body") and str(d["body"]) in paths:
            dec["body"] = paths[str(d["body"])]
        else:
            dec["hide"] = _expand(d.get("hide"), paths, outline.get("units") or [])
            dec["show"] = _expand(d.get("show"), paths, outline.get("units") or [])
        if not (dec["body"] or dec["hide"] or dec["show"]):
            dec["verdict"] = "accept"
            dec["reason"] += " (no usable change proposed)"
    return dec


# -- orchestration -------------------------------------------------------------------------------------------
def _restore(files: list[str], backup: Path, base_glob: list[str]):
    for f in base_glob:
        try:
            Path(f).unlink()
        except OSError:
            pass
    for f in files:
        src = backup / Path(f).name
        if src.is_file():
            shutil.copy2(src, f)


def run(note_path: str, out_dir: Path, plan: dict, run_step) -> list[str]:
    """Review the captures of `plan` (the plan.json written by news_capture.py). `run_step(step_file)` runs
    `news_capture.py --agent-step` and returns when the .out.json is written. Returns report lines (Markdown)."""
    m = mode()
    if m == "off":
        return []
    from .notesfile import read_note_text
    try:
        note_all = read_note_text(Path(note_path))
    except OSError:
        note_all = ""
    pages = []
    for t in plan.get("topics", []):
        if re.match(r"\s*(intro|sponsor)", t.get("title") or "", re.I):
            continue
        urls = t.get("links") or []
        note = note_text_for(note_all, urls)
        for c in t.get("capture_info") or []:
            if c.get("error") and re.search(r"anti-robot|protégée|human", c["error"], re.I):
                continue                                      # a captcha: nothing an agent can do from here
            flags = assess(c, note)
            if m == "all" or flags:
                pages.append({"id": f"{t['index']}:{c['k']}", "topic": t["index"], "k": c["k"], "url": c["url"], "title": t["title"],
                              "note": note, "current": {**c, "info": c}, "orig_files": list(c.get("files") or []), "flags0": flags,
                              "fixes": 0, "done": False, "status": "", "reason": ""})
    if not pages:
        return ["**Capture agent:** every capture looks fine."]
    work = out_dir / "_agent"
    work.mkdir(parents=True, exist_ok=True)
    for p in pages:                                           # keep the original captures: they come back if the fixes do not help
        bk = work / p["id"].replace(":", "_") / "orig"
        bk.mkdir(parents=True, exist_ok=True)
        for f in p["orig_files"]:
            if Path(f).is_file():
                shutil.copy2(f, bk / Path(f).name)
        p["backup"] = bk
    errors = []
    for rnd in range(0, MAX_FIXES + 1):
        active = [p for p in pages if not p["done"]]
        if not active:
            break
        step = {"pages": []}
        for p in active:
            e = {"id": p["id"], "topic": p["topic"], "k": p["k"], "url": p["url"], "note_words": keywords(p["note"])}
            if rnd == 0 or p.get("pending") is None:
                e["observe"] = True
            else:
                e.update(hide=p["pending"]["hide"], show=p["pending"]["show"], body=p["pending"]["body"])
            step["pages"].append(e)
        sf = work / f"step{rnd}.json"
        sf.write_text(json.dumps(step, ensure_ascii=False), encoding="utf-8")
        outf = sf.with_suffix(".out.json")
        if outf.exists():
            outf.unlink()
        try:
            run_step(sf)
            results = {r["id"]: r for r in json.loads(outf.read_text(encoding="utf-8")).get("results", [])}
        except (AIError, OSError, ValueError) as ex:
            errors.append(f"round {rnd}: {ex}")
            break
        for p in active:
            r = results.get(p["id"]) or {"ok": False, "error": "no answer"}
            if not r.get("ok"):
                p["done"], p["status"] = True, f"kept the original ({r.get('error') or 'could not be re-opened'})"
                if p["fixes"]:
                    _restore(p["orig_files"], p["backup"], (p["current"].get("files") or []))
                    p["current"] = {**p["current"], "files": p["orig_files"]}
                continue
            if r.get("files"):                                 # a fix was applied: this is its result
                r["info"]["files"] = r["files"]
                p["current"] = {**r["info"], "info": r["info"]}
                p["current"]["error"] = None
            try:
                dec = judge(p, r, p["note"], rnd, out_dir)
            except AIError as ex:
                p["done"], p["status"] = True, f"not reviewed ({str(ex)[:120]})"
                errors.append(str(ex)[:200])
                if p["fixes"]:
                    pass                                       # keep the applied fix: it was made on a verified decision
                continue
            p["reason"] = dec["reason"]
            p["last_reason"] = dec["reason"]
            if dec["verdict"] == "accept":
                p["done"] = True
                p["status"] = "fixed" if p["fixes"] else "accepted as it was"
            elif p["fixes"] >= MAX_FIXES:
                # out of fixes: keep the result only if it has fewer problems than the original
                new_flags = assess(p["current"], p["note"])
                if len(new_flags) <= len(p["flags0"]):
                    p["status"] = "fixed (not fully verified)"
                else:
                    _restore(p["orig_files"], p["backup"], (p["current"].get("files") or []))
                    p["current"] = {**p["current"], "files": p["orig_files"]}
                    p["status"] = "kept the original (the fixes did not improve it)"
                p["done"] = True
            else:
                p["pending"] = dec
                p["fixes"] += 1
    # a page whose last fix was applied but never judged (round loop ended): keep it as is
    lines = ["**Capture agent:**"]
    for p in pages:
        if not p["done"]:
            p["status"] = p["status"] or "left as captured"
        extra = f" — {p['reason']}" if p["reason"] and p["status"].startswith(("fixed", "kept")) else ""
        why = f" (was flagged: {p['flags0'][0]})" if p["flags0"] else ""
        lines.append(f"- {p['title'][:60]} [{p['url'][:60]}]: {p['status']}{why}{extra}")
    for e in errors[:3]:
        lines.append(f"- ⚠️ {e}")
    return lines
