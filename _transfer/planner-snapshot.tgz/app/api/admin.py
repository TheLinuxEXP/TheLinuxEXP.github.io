"""Restart, backups, clean-up, notes/revenue registration and the sponsor filter."""
from __future__ import annotations
import os
from pathlib import Path
import sys
import threading
import time

from flask import abort, current_app, jsonify, request

from .common import _body, bp, db
from ..database import data_dir


# -- dev convenience: restart the whole process in place -------------------
@bp.post("/restart")
def restart_server():
    """Re-exec the running process with the same interpreter and argv, so a
    code change (backend or frontend) takes effect without the person having
    to Ctrl+C and rerun `python3 run.py` by hand. Runs on a short delay in a
    background thread so this request's own response has time to flush
    before the process image is replaced.

    Critically, this explicitly closes the dev server's own listening socket
    first: os.execv() normally lets the OS close inherited file descriptors
    on its own, but the new process can still race it and try to bind the
    port before the old socket is actually released, failing with "Address
    already in use". run.py stashes the live werkzeug server on
    app.config["_DEV_SERVER"] for exactly this."""
    srv = current_app.config.get("_DEV_SERVER")

    def do_restart():
        time.sleep(0.3)
        if srv is not None:
            try:
                srv.socket.close()
            except OSError:
                pass
        os.execv(sys.executable, [sys.executable] + sys.argv)
    threading.Thread(target=do_restart, daemon=True).start()
    return jsonify({"ok": True})


# -- Backups ----------------------------------------------------------------
@bp.get("/backups")
def list_backups():
    return jsonify(db().list_backups())


@bp.post("/backups")
def create_backup():
    meta = db().create_backup((request.get_json(silent=True) or {}).get("reason") or "Manual backup")
    return jsonify({k: v for k, v in meta.items() if k != "fingerprint"}), 201


@bp.post("/backups/prune")
def prune_backups():
    days = (request.get_json(silent=True) or {}).get("older_than_days")
    if days not in (7, 30, 90):
        abort(400)
    return jsonify({"removed": db().delete_old_backups(days)})


@bp.get("/backups/<bid>/diff")
def backup_diff(bid):
    result = db().backup_diff(bid)
    if result is None:
        abort(404)
    return jsonify(result)


@bp.post("/backups/<bid>/restore")
def restore_backup(bid):
    meta = db().restore_backup(bid)
    if meta is None:
        abort(404)
    return jsonify({"restored": meta})


# -- Clean up: remove generated files (decks + cropped PDF images) ----------
def _generated_root() -> Path:
    return data_dir() / "generated"


def _dir_stats(root: Path):
    files, size = 0, 0
    if root.is_dir():
        for p in root.rglob("*"):
            if p.is_file() and not p.is_symlink():
                files += 1
                size += p.stat().st_size
    return files, size


@bp.get("/cleanup")
def cleanup_info():
    files, size = _dir_stats(_generated_root())
    return jsonify({"files": files, "bytes": size})


@bp.post("/cleanup")
def cleanup_run():
    """Deletes everything under <data dir>/generated: the PowerPoint decks the
    "Generate" button made and the images it cropped out of PDFs. Tasks,
    attachments and backups are not touched."""
    import shutil
    root = _generated_root()
    files, size = _dir_stats(root)
    if root.is_dir():
        for child in root.iterdir():
            if child.is_symlink() or child.is_file():
                child.unlink()
            else:
                shutil.rmtree(child, ignore_errors=True)
    return jsonify({"files": files, "bytes": size})


# Notes & Scripts (Markdown notes folder) -- routes live in notes_api.py
from ..notes_api import register as _register_notes  # noqa: E402
_register_notes(bp)

# Finances > Revenue (per-client earnings, time and hourly rate) -- see revenue.py
from ..revenue import register as _register_revenue  # noqa: E402
_register_revenue(bp)


# Publication-calendar filter: sponsors (tag ids) hidden by the person. Kept on the
# server (data folder) so the choice follows them across browsers and devices.
def _sponsor_filter_file():
    return data_dir() / "sponsors_hidden.json"


@bp.get("/sponsors/hidden")
def sponsors_hidden_get():
    import json
    try:
        ids = json.loads(_sponsor_filter_file().read_text(encoding="utf-8"))
        ids = [i for i in ids if isinstance(i, str)] if isinstance(ids, list) else []
    except Exception:
        ids = []
    return jsonify({"hidden": ids})


@bp.put("/sponsors/hidden")
def sponsors_hidden_put():
    import json
    ids = _body().get("hidden", [])
    ids = sorted({i for i in ids if isinstance(i, str)})
    from ..fsutil import atomic_write_text
    atomic_write_text(_sponsor_filter_file(), json.dumps(ids))
    return jsonify({"hidden": ids})
