"""Task templates (the "+" menu): list, create-from-template, and the editor behind Utilities > Templates."""
from __future__ import annotations
import re

from flask import abort, jsonify

from .common import _TIME_RE, _body, _int_in, BadRequest, bp, db
from ..database import new_id


_BTN_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")


def _clean_ai_buttons(raw, i: int) -> list:
    """Validate the AI buttons of subtask number `i` (1-based, for messages)."""
    if raw in (None, ""):
        return []
    if not isinstance(raw, list) or len(raw) > 6:
        raise BadRequest(f"Subtask {i}: up to 6 AI buttons.")
    out, seen = [], set()
    for j, b in enumerate(raw, 1):
        if not isinstance(b, dict):
            raise BadRequest(f"Subtask {i}: invalid AI button.")
        where = f"Subtask {i}, AI button {j}"
        label = str(b.get("label") or "").strip()
        if not label:
            raise BadRequest(f"{where}: give the button a title.")
        if len(label) > 60:
            raise BadRequest(f"{where}: the title is too long (60 characters max).")
        kind = b.get("kind") or "prompt"
        if kind not in ("prompt", "powerpoint", "chapters", "capture", "montage", "timestamps", "text_timestamps", "thumbnails", "list_to_ppt", "setup_edit"):
            raise BadRequest(f"{where}: unknown type.")
        instructions = str(b.get("instructions") or "").strip()
        system = str(b.get("system") or "").strip()
        if kind == "prompt" and not instructions:
            raise BadRequest(f"{where}: the instructions for Claude are empty.")
        if len(instructions) > 20000:
            raise BadRequest(f"{where}: the instructions are too long (20000 characters max).")
        if len(system) > 2000:
            raise BadRequest(f"{where}: the system prompt is too long (2000 characters max).")
        src = b.get("sources") if isinstance(b.get("sources"), dict) else {}
        secs = src.get("note_sections") or []
        if secs != "all":
            if not isinstance(secs, list) or len(secs) > 12:
                raise BadRequest(f"{where}: invalid notes sections.")
            secs = [str(x).strip()[:80] for x in secs if str(x).strip()]
        post = b.get("post") or "none"
        if post not in ("none", "youtube_tags"):
            raise BadRequest(f"{where}: unknown post-processing.")
        bid = str(b.get("id") or "")
        if not _BTN_ID_RE.match(bid) or bid in seen:
            bid = new_id()
        seen.add(bid)
        out.append({
            "id": bid, "label": label, "kind": kind,
            "instructions": instructions if kind == "prompt" else "",
            "system": system if kind == "prompt" else "",
            "sources": {"note_sections": secs if kind == "prompt" else [],
                        "task_notes": bool(src.get("task_notes")) and kind == "prompt"},
            "apply_to_note": bool(b.get("apply_to_note")) and kind == "prompt",
            "post": post if kind == "prompt" else "none",
        })
    return out


def _clean_template(data: dict) -> dict:
    """Validate/normalise a template definition sent by the editor."""
    def text(key, label, required=False, limit=200):
        v = str(data.get(key) or "").strip()
        if required and not v:
            raise BadRequest(f"{label} can't be empty.")
        if len(v) > limit:
            raise BadRequest(f"{label} is too long.")
        return v

    wd = data.get("main_weekday")
    if wd in ("", None):
        wd = None
    else:
        wd = _int_in(wd, "Main day", 0, 6)
    raw = data.get("subtasks") or []
    if not isinstance(raw, list) or len(raw) > 60:
        raise BadRequest("A template can have up to 60 subtasks.")
    subs = []
    for i, s in enumerate(raw, 1):
        if not isinstance(s, dict):
            raise BadRequest("Invalid subtask.")
        title = str(s.get("title") or "").strip()
        if not title:
            raise BadRequest(f"Subtask {i} has no title.")
        if len(title) > 200:
            raise BadRequest(f"Subtask {i}: the title is too long.")
        start = s.get("start_time") or None
        if start and not _TIME_RE.match(str(start)):
            raise BadRequest(f"Subtask {i}: the start time must look like 14:30.")
        dur = s.get("duration")
        off = s.get("offset_days")
        subs.append({
            "id": str(s.get("id") or "")[:64],
            "title": title,
            "duration": _int_in(dur, f"Subtask {i} duration", 1, 60 * 24 * 14) if dur not in (None, "") else None,
            "offset_days": _int_in(off, f"Subtask {i} offset", -366, 366) if off not in (None, "") else None,
            "start_time": str(start) if start else None,
            "ai_buttons": _clean_ai_buttons(s.get("ai_buttons"), i),
        })
    return {
        "label": text("label", "The name", required=True, limit=80),
        "task_title": text("task_title", "The task title", required=True),
        "icon": text("icon", "The task icon", limit=8),
        "menu_icon": text("menu_icon", "The menu icon", limit=8),
        "note_title": text("note_title", "The note name pattern"),
        "main_weekday": wd,
        "is_video": bool(data.get("is_video", True)),
        "subtasks": subs,
    }


# -- list / create a task from a template -------------------------------------
@bp.get("/templates")
def list_templates():
    return jsonify(db().list_templates())


@bp.post("/templates/<key>")
def create_from_template(key):
    data = _body()
    if not data.get("todo_list_id"):
        return jsonify({"error": "todo_list_id required"}), 400
    if key not in db().list_templates_keys():
        abort(404)
    tid = db().create_from_template(data["todo_list_id"], key)
    return jsonify(db().get_task(tid)), 201


# -- editor -----------------------------------------------------------------------
@bp.post("/templates")
def add_template():
    key = db().add_template(_clean_template(_body()))
    return jsonify(db().get_template(key)), 201


@bp.put("/templates/<key>")
def save_template(key):
    if not db().save_template(key, _clean_template(_body())):
        abort(404)
    return jsonify(db().get_template(key))


@bp.delete("/templates/<key>")
def delete_template(key):
    try:
        if not db().delete_template(key):
            abort(404)
    except ValueError as e:
        raise BadRequest(str(e))
    return jsonify({"ok": True})


@bp.post("/templates/<key>/reset")
def reset_template(key):
    try:
        db().reset_template(key)
    except ValueError as e:
        raise BadRequest(str(e))
    return jsonify(db().get_template(key))


@bp.put("/template-order")
def reorder_templates():
    keys = _body().get("keys")
    if not isinstance(keys, list) or not all(isinstance(k, str) for k in keys):
        raise BadRequest("keys must be a list of template keys.")
    db().reorder_templates(keys)
    return jsonify(db().list_templates())
