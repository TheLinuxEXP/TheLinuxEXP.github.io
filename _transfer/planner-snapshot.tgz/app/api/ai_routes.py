"""AI-powered subtask actions (prompt buttons, chapters / timestamps, thumbnails). The PowerPoint buttons are in ppt_routes.py."""
from __future__ import annotations
import os
from pathlib import Path
import re

from flask import jsonify

from .. import ai, ai_config
from ..ai import AIError, call_claude
from .common import TAGS_MAX_CHARS, _body, _fit_tags, _load_notes_file_sections, _missing_section_message, _subtask_and_parent, _valid_notes_path, bp, db
from ..database import data_dir
from ..notesfile import find_section, read_note_text, replace_sections, save_note_text, trim_from_heading


# -- AI-powered subtask actions ---------------------------------------------
# Each reads either the parent task's linked notes file, or (for script
# planning) the parent task's own Notes field, and calls Claude to produce
# something the person copies into their own notes/YouTube fields. See
# app/ai.py for the Anthropic API key requirement.

CHANNEL_NAME = "The Linux Experiment"


# -- which AI the buttons use (the "AI settings" window) ----------------------
@bp.get("/ai/settings")
def ai_settings_get():
    return jsonify(ai_config.public_view())


@bp.put("/ai/settings")
def ai_settings_put():
    b = _body()
    try:
        ai_config.save({k: b[k] for k in ("active", "timeout", "profile") if k in b})
    except (ValueError, TypeError) as e:
        return jsonify({"error": str(e) or "Invalid settings."}), 400
    return jsonify(ai_config.public_view())


@bp.get("/ai/models")
def ai_models():
    from flask import request
    try:
        return jsonify({"models": ai.list_models(request.args.get("provider"))})
    except AIError as e:
        return jsonify({"models": [], "error": str(e)})


@bp.post("/ai/test")
def ai_test():
    try:
        return jsonify(ai.test_connection())
    except AIError as e:
        return jsonify({"ok": False, "error": str(e)})


@bp.post("/subtasks/<sid>/ai/order-topics")
def ai_order_topics(sid):
    _sub, task = _subtask_and_parent(sid)
    try:
        sections = _load_notes_file_sections(task)
        timestamps = find_section(sections, "Timestamps") or ""
        links = find_section(sections, "Links") or ""
        content = find_section(sections, "Content") or ""
        if not (timestamps.strip() or links.strip() or content.strip()):
            raise AIError('Couldn\'t find "Timestamps", "Links" or "Content" sections in the linked notes file.')
        prompt = f"""Below are three sections from a video-planning markdown note. Each one
lists the same set of topics, in the same order — one entry per topic — under
Timestamps, Links and Content respectively.

Reorder the topics consistently across all three sections, from the one most
likely to interest the audience of the YouTube channel "{CHANNEL_NAME}" to the
least likely. If two topics seem related to each other and are no more than 3
positions apart in your ranking, place the lower-ranked one immediately after
the higher-ranked one.

Keep each entry's own text/content as-is — only change the ORDER of entries,
identically across all three sections (so entry N under Timestamps still
corresponds to entry N under Links and under Content after reordering).

## Timestamps
{timestamps}

## Links
{links}

## Content
{content}

Reply with ONLY the three reordered sections, formatted exactly like this
(markdown, same three headings, nothing else before or after):
## Timestamps
...
## Links
...
## Content
...
"""
        result = call_claude(prompt, system=f"You help plan YouTube videos for the channel {CHANNEL_NAME}, a Linux/open-source tech channel.")
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"result": result})


@bp.post("/subtasks/<sid>/ai/apply-order-topics")
def ai_apply_order_topics(sid):
    """Writes the generated "Order topics" result into the task's linked note.
    mode "replace": the Timestamps / Links / Content sections of the note are
    swapped for the generated ones (everything else in the note is kept);
    mode "append": the generated block is added at the bottom of the note."""
    _sub, task = _subtask_and_parent(sid)
    data = _body()
    mode = data.get("mode")
    if mode not in ("replace", "append"):
        return jsonify({"error": "mode must be replace or append"}), 400
    generated = trim_from_heading(str(data.get("content") or ""), "Timestamps")
    if not generated.strip():
        return jsonify({"error": "Nothing to write."}), 400
    path = task.get("notes_file")
    if not path:
        return jsonify({"error": 'This task has no linked notes file yet — set one in the task panel ("Notes file") first.'}), 400
    if not _valid_notes_path(path):
        return jsonify({"error": "The linked notes file must be a Markdown or text file (.md, .markdown, .txt)."}), 400
    p = Path(path).expanduser()
    if not p.is_file():
        return jsonify({"error": f"Couldn't find the linked notes file on disk: {path}"}), 400
    original = read_note_text(p)
    summary = ""
    if mode == "append":
        new_text = original.rstrip() + "\n\n" + generated.strip() + "\n"
        summary = "Appended to the note"
    else:
        out = replace_sections(original, generated)
        if out is None:
            return jsonify({"error": "The generated text has no headings to replace with."}), 400
        new_text, replaced, appended = out
        summary = "Replaced " + ", ".join(replaced) if replaced else "Added sections"
        if appended:
            summary += ("; added " if replaced else ": ") + ", ".join(appended)
    # keep the previous version in the app's data folder, then write the note atomically
    save_note_text(p, original, new_text, data_dir() / "notes_backups" / "ai")
    return jsonify({"ok": True, "summary": summary, "path": str(p)})


@bp.post("/subtasks/<sid>/ai/generate-tags")
def ai_generate_tags(sid):
    _sub, task = _subtask_and_parent(sid)
    try:
        sections = _load_notes_file_sections(task)
        content = find_section(sections, "Content") or ""
        if not content.strip():
            raise AIError(_missing_section_message(sections, "Content"))
        prompt = f"""Below is the "Content" section from a video-planning note for a video on
the YouTube channel "{CHANNEL_NAME}" (a Linux/open-source tech channel):

{content}

Generate a comma-separated list of YouTube tags/keywords for this video: a
mix of broad (e.g. "linux", "open source") and specific terms (software names,
topics covered, common search phrasings). YouTube allows at most {TAGS_MAX_CHARS}
characters of tags in total (commas included), so use nearly all of it: the
whole list should come to between {TAGS_MAX_CHARS - 40} and {TAGS_MAX_CHARS}
characters. Put the most important tags first. Reply with ONLY the
comma-separated list, nothing else.
"""
        system = f"You write YouTube SEO tags for the channel {CHANNEL_NAME}, a Linux/open-source tech channel."
        result = _fit_tags(call_claude(prompt, system=system))
        if len(result) < TAGS_MAX_CHARS - 80:       # came back short: ask once for more
            more = call_claude(
                prompt + f"\nYour previous list was only {len(result)} characters:\n{result}\n"
                f"Write a longer one that uses the {TAGS_MAX_CHARS} characters, keeping the best tags.",
                system=system)
            longer = _fit_tags(more)
            if len(longer) > len(result):
                result = longer
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"result": result})


@bp.post("/subtasks/<sid>/ai/generate-thumbnails")
def ai_generate_thumbnails(sid):
    _sub, task = _subtask_and_parent(sid)
    try:
        sections = _load_notes_file_sections(task)
        content = find_section(sections, "Content") or ""
        if not content.strip():
            raise AIError(_missing_section_message(sections, "Content"))
        prompt = f"""Below is the "Content" section from a video-planning note for a video on
the YouTube channel "{CHANNEL_NAME}" (a Linux/open-source tech channel):

{content}

Generate:
- 3 candidate video titles (punchy and clickable, but accurate — suited to a
  Linux/tech YouTube audience)
- 3 thumbnail visual concepts (a sentence or two each: what's shown, any text
  overlay, the overall mood/style)

Reply in markdown with exactly two headed sections:
## Titles
1. ...
2. ...
3. ...
## Thumbnail ideas
1. ...
2. ...
3. ...
"""
        result = call_claude(prompt, system=f"You write video titles and thumbnail concepts for the channel {CHANNEL_NAME}, a Linux/open-source tech channel.")
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"result": result})


@bp.post("/subtasks/<sid>/ai/plan-script")
def ai_plan_script(sid):
    _sub, task = _subtask_and_parent(sid)
    try:
        notes = (task.get("notes") or "").strip()
        if not notes:
            raise AIError("This task's Notes field is empty — add some notes first.")
        prompt = f"""Below are my notes for a video I'm planning to script, for the YouTube
channel "{CHANNEL_NAME}" (a Linux/open-source tech channel):

{notes}

Based on these notes, draft a structure for the video's script: a sensible
ordered list of main points to cover. For each main point, include:
- a short description of what to say
- any relevant links related to that point (suggest real, well-known
  resources where you can; otherwise describe what kind of link to look for)
- an idea of what to show on screen to illustrate that point (e.g. a
  terminal demo, a diagram, a specific website, settings screen, etc.)

Reply in markdown, with one "##" heading per main point.
"""
        result = call_claude(prompt, system=f"You help script videos for the channel {CHANNEL_NAME}, a Linux/open-source tech channel.")
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"result": result})


# -- Configurable AI buttons (Utilities > Templates) ------------------------
# The buttons shown on a subtask come from the template the parent task was
# created from: title, instructions for Claude, which parts of the notes to
# send along, and what to do with the answer.
def _template_button(task, subtask, button_id):
    key = task.get("video_template")
    tpl = db().get_template(key) if key else None
    if not tpl:
        raise AIError("This task's template no longer exists.")
    want = (subtask.get("title") or "").strip().lower()
    link = subtask.get("template_sub_id")
    for s in tpl["subtasks"]:
        if (s["id"] == link) if link else (s["title"].strip().lower() == want):
            for b in s.get("ai_buttons") or []:
                if b["id"] == button_id:
                    return b
    raise AIError("This AI button isn't defined in the template any more.")


def _fill_placeholders(text, task, subtask):
    for k, v in (("{title}", task.get("title") or ""), ("{subtask}", subtask.get("title") or ""),
                 ("{due_date}", subtask.get("due_date") or task.get("due_date") or "")):
        text = text.replace(k, v)
    return text


def _button_context(button, task):
    src = button.get("sources") or {}
    wanted = src.get("note_sections") or []
    blocks = []
    if wanted:
        sections = _load_notes_file_sections(task)
        if wanted == "all":
            blocks += [f"## {k}\n{v}" for k, v in sections.items() if str(v).strip()]
        else:
            for name in wanted:
                body = find_section(sections, name) or ""
                if body.strip():
                    blocks.append(f"## {name}\n{body.strip()}")
            if not blocks:
                raise AIError(_missing_section_message(sections, wanted[0]))
    if src.get("task_notes"):
        notes = (task.get("notes") or "").strip()
        if notes:
            blocks.append(f"## Task notes\n{notes}")
        elif not blocks:
            raise AIError("This task's Notes field is empty — add some notes first.")
    return "\n\n".join(blocks)


def _generate_chapters(task):
    """Bouton « Generate Chapters » : horodatages des swoosh (A2 de Resolve) -> sections Timestamps et Links de la note liée."""
    from .. import chapters
    path = task.get("notes_file")
    if not path:
        raise AIError('This task has no linked notes file yet — set one in the task panel ("Notes file") first.')
    if not _valid_notes_path(path):
        raise AIError("The linked notes file must be a Markdown or text file (.md, .markdown, .txt).")
    p = Path(path).expanduser()
    if not p.is_file():
        raise AIError(f"Couldn't find the linked notes file on disk: {path}")
    original = read_note_text(p)
    stamps = chapters.run_swoosh_script()
    new_text, rep = chapters.apply_chapters(original, stamps)
    # previous version kept in the app's data folder, then the note is written atomically
    save_note_text(p, original, new_text, data_dir() / "notes_backups" / "chapters")
    try:
        cj = chapters.write_chapters_json(rep["timestamps"])
        cj_msg = f"chapters.json écrit : `{cj}`"
    except (AIError, OSError) as e:
        cj_msg = f"⚠️ chapters.json non écrit : {e}"
    result = (f"Note mise à jour : **{p.name}** ({len(rep['links'])} sujets, {len(stamps)} swoosh lus dans Resolve).\n\n"
              + cj_msg + "\n\n"
              "**Timestamps** (secondes)\n\n```\n" + "\n".join(rep["timestamps"]) + "\n```\n\n"
              "**Links** (MM:SS)\n\n```\n" + "\n".join(rep["links"]) + "\n```\n")
    return jsonify({"result": result, "apply_to_note": False})


def _generate_video_timestamps(task):
    """Bouton « Timestamps » : début de chaque swoosh de A2 (sauf celui de « Outro new ») -> MM:SS devant chaque sujet de la
    section Timestamps de la note « -VIDEO » de la tâche."""
    from .. import chapters
    path = task.get("video_note_file")
    if not path:
        raise AIError("Create the video note first (“Create Video Note” in the task's Content section).")
    if not _valid_notes_path(path):
        raise AIError("The video note must be a Markdown or text file (.md, .markdown, .txt).")
    p = Path(path).expanduser()
    if not p.is_file():
        raise AIError(f"Couldn't find the video note on disk: {path}")
    original = read_note_text(p)
    stamps = chapters.run_swoosh_script(skip_with="Outro new")
    new_text, region = chapters.apply_video_timestamps(original, stamps)
    # keep the previous version in the app's data folder, then write the note atomically
    save_note_text(p, original, new_text, data_dir() / "notes_backups" / "video-timestamps")
    result = (f"Timestamps added to **{p.name}** ({len(stamps)} swooshes read in Resolve).\n\n```\n" + "\n".join(region) + "\n```\n")
    return jsonify({"result": result, "apply_to_note": False})


def _ensure_video_note(task):
    """Step 1 of « Setup for editing »: the task's "-VIDEO" note, created from the linked note by the same code as « Create Video
    Note » (task panel). Already there (linked, or sitting next to the main note) -> reused, never overwritten.
    Returns (task with video_note_file set, message)."""
    from .. import video_note
    from ..notes_api import notes_root
    cur = task.get("video_note_file")
    if cur and Path(cur).expanduser().is_file():
        return task, f"Video note already there: **{Path(cur).name}**."
    path = task.get("notes_file")
    if not path:
        raise AIError('This task has no linked notes file yet — set one in the task panel ("Notes file") first.')
    if not _valid_notes_path(path):
        raise AIError("The linked notes file must be a Markdown or text file (.md, .markdown, .txt) inside the notes folder.")
    p = Path(path).expanduser()
    twin = p.with_name(f"{p.stem}-VIDEO{p.suffix}")
    if twin.is_file():
        dst, warnings = twin, []
    else:
        dst, warnings = video_note.create_video_note(path, [t["name"] for t in task.get("tags") or []], notes_root())
    db().update_task(task["id"], video_note_file=str(dst))
    msg = f"Video note {'linked' if twin.is_file() else 'created'}: **{dst.name}**."
    if warnings:
        msg += "\n" + "\n".join(f"- {w}" for w in warnings)
    return db().get_task(task["id"]), msg


def _setup_for_editing(task):
    """« Setup for editing » (Weekly News): create the video note -> take the captures -> base edit in Resolve. Each step is the
    existing workflow; the first failure stops the chain and says what was already done (a second click redoes the steps: the
    note is reused, the captures are simply retaken). The "Timestamps" button is a separate step of the template."""
    from .. import montage
    done, step = [], "Create the video note"
    try:
        task, msg = _ensure_video_note(task)
        done.append(msg)
        step = "Take captures"
        vn = task.get("video_note_file")
        if not _valid_notes_path(vn):
            raise AIError("The video note must be a Markdown or text file inside the notes folder.")
        done.append(montage.take_captures(vn))
        step = "Base edit"
        montage.base_edit(vn)
        done.append("**Base edit done** in DaVinci Resolve.")
    except AIError as e:
        steps = ("\n\n---\n\n".join(done) + "\n\n---\n\n") if done else ""
        raise AIError((f"Already done:\n\n{steps}" if done else "") + f"Stopped at “{step}”: {e}") from e
    return jsonify({"result": "\n\n---\n\n".join(done), "apply_to_note": False})


def _generate_text_timestamps(task):
    """Bouton « Generate Timestamps » (Normal Video) : swoosh de A2 + texte de la text box la plus proche (V1/V2/V3) ->
    section Timestamps de la note liée à la tâche principale."""
    from .. import chapters
    # a task that has a "-VIDEO" note (Weekly News) gets its timestamps there, not in the main note
    path = task.get("video_note_file") or task.get("notes_file")
    if not path:
        raise AIError('This task has no linked notes file yet — set one in the task panel ("Notes file") first.')
    if not _valid_notes_path(path):
        raise AIError("The notes file must be a Markdown or text file (.md, .markdown, .txt).")
    p = Path(path).expanduser()
    if not p.is_file():
        raise AIError(f"Couldn't find the notes file on disk: {path}")
    original = read_note_text(p)
    entries, warnings = chapters.run_text_timestamps()
    new_text, written, replaced, created = chapters.apply_text_timestamps(original, entries)
    # previous version kept in the app's data folder, then the note is written atomically
    save_note_text(p, original, new_text, data_dir() / "notes_backups" / "text-timestamps")
    result = (f"Note mise à jour : **{p.name}** ({len(written)} timestamps lus dans Resolve"
              + (", section « Timestamps » créée en fin de note" if created else "")
              + (f", {replaced} ancienne(s) ligne(s) remplacée(s)" if replaced else "") + ").\n\n"
              "```\n" + "\n".join(written) + "\n```\n")
    if warnings:
        result += "\n**À vérifier**\n\n" + "\n".join(f"- {w}" for w in warnings) + "\n"
    return jsonify({"result": result, "apply_to_note": False})


def _topic_titles(task):
    """Titres des sujets de la note de la tâche (section Timestamps), pour situer la vidéo."""
    import re as _re
    path = task.get("video_note_file") or task.get("notes_file")
    if path and not _valid_notes_path(path):
        return []
    try:
        text = read_note_text(path) if path else ""
    except OSError:
        return []
    out, inside = [], False
    for ln in text.splitlines():
        if _re.match(r"^\s*#{1,6}\s*timestamps?\b", ln, _re.I):
            inside = True
            continue
        if inside and (_re.match(r"^\s*#{1,6}\s", ln) or _re.match(r"^\s*links\s*:?\s*$", ln, _re.I)):
            break
        s = ln.strip()
        if inside and s and not _re.match(r"^timestamps?\s*:?$", s, _re.I) and not _re.match(r"^(https?://)", s):
            s = _re.sub(r"^\d+(?::\d{2}){0,2}\s+", "", s)
            if not _re.match(r"^(intro|sponsor)\b", s, _re.I):
                out.append(s)
    return out


def _make_thumbnails(task, sub):
    """Bouton « Create thumbnails » : idées (bouton « Generate ideas ») -> texte et logos -> 3 miniatures PNG."""
    from .. import thumbnails, montage
    from ..dbparts.core import _AI_THUMBS
    print("[thumbnails] début : idées", flush=True)
    ideas = _run_prompt_button(_AI_THUMBS, task, sub)
    print("[thumbnails] idées reçues, recherche des logos et du texte", flush=True)
    spec = thumbnails.build_specs(call_claude, CHANNEL_NAME, task.get("title") or "", _topic_titles(task), ideas)
    base = Path(os.environ.get("PLANNER_THUMBS_DIR") or (montage.scripts_dir() / "thumbnails")).expanduser()
    safe = re.sub(r"[^\w .-]+", "_", (task.get("title") or "video")).strip(" .") or "video"
    out_dir = base / safe
    print("[thumbnails] composition des images", flush=True)
    res = thumbnails.make_all_isolated(spec, out_dir, data_dir() / "thumb_cache")
    if not res["files"]:
        raise AIError("Aucune miniature n'a pu être créée (aucun logo téléchargeable). " + " ".join(res["warnings"][:3]))
    lines = [f"**{len(res['files'])} miniature(s)** créée(s) dans `{out_dir}` :", ""]
    lines += [f"- `{Path(f).name}`" for f in res["files"]]
    lines += ["", "**Texte et logos**", ""] + [f"- {n}" for n in res["notes"]]
    if res["warnings"]:
        lines += ["", "**À vérifier**", ""] + [f"- {w}" for w in res["warnings"]]
    lines += ["", "**Idées de départ**", "", ideas.strip()]
    return jsonify({"result": "\n".join(lines), "apply_to_note": False})


def _run_prompt_button(b, task, sub):
    """Exécute un bouton IA de type « prompt » (contexte de la note + instructions) et renvoie le texte."""
    context = _button_context(b, task)
    header = f"Task: {task.get('title') or ''}\nSubtask: {sub.get('title') or ''}"
    due = sub.get("due_date") or task.get("due_date")
    if due:
        header += f"\nDue date: {due}"
    prompt = _fill_placeholders(b["instructions"], task, sub) + "\n\n---\n" + header
    if context:
        prompt += "\n\n" + context
    system = _fill_placeholders(b.get("system") or "", task, sub) or \
        f"You help with tasks for the YouTube channel {CHANNEL_NAME}, a Linux/open-source tech channel."
    result = call_claude(prompt, system=system)
    if b.get("post") == "youtube_tags":
        result = _fit_tags(result)
        if len(result) < TAGS_MAX_CHARS - 80:       # came back short: ask once for more
            more = _fit_tags(call_claude(
                prompt + f"\n\nYour previous list was only {len(result)} characters:\n{result}\n"
                f"Write a longer one that uses the {TAGS_MAX_CHARS} characters, keeping the best tags.",
                system=system))
            if len(more) > len(result):
                result = more
    return result


@bp.post("/subtasks/<sid>/ai/run")
def ai_run_button(sid):
    sub, task = _subtask_and_parent(sid)
    data = _body()
    try:
        b = _template_button(task, sub, str(data.get("button_id") or ""))
        if b["kind"] == "chapters":
            return _generate_chapters(task)
        if b["kind"] == "timestamps":
            return _generate_video_timestamps(task)
        if b["kind"] == "text_timestamps":
            return _generate_text_timestamps(task)
        if b["kind"] == "thumbnails":
            return _make_thumbnails(task, sub)
        if b["kind"] == "setup_edit":
            return _setup_for_editing(task)
        if b["kind"] in ("capture", "montage"):
            from .. import montage
            vn = task.get("video_note_file")
            if not vn:
                raise AIError("Create the video note first (“Create Video Note” in the task's Content section).")
            if not _valid_notes_path(vn):
                raise AIError("The video note must be a Markdown or text file inside the notes folder.")
            if b["kind"] == "capture":
                return jsonify({"result": montage.take_captures(vn), "apply_to_note": False})
            montage.base_edit(vn)
            return jsonify({"result": "", "apply_to_note": False, "silent": True})
        if b["kind"] != "prompt":
            raise AIError("This button doesn't run a prompt.")
        result = _run_prompt_button(b, task, sub)
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:  # noqa: BLE001 -- jamais de page HTML 500 : le message réel s'affiche dans l'interface
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Erreur inattendue ({type(e).__name__}) : {e}"}), 500
    return jsonify({"result": result, "apply_to_note": bool(b.get("apply_to_note"))})
