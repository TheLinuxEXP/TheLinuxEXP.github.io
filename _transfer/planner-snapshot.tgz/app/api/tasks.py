"""Tasks, subtasks and attachments."""
from __future__ import annotations
from datetime import date
import os
from pathlib import Path

from flask import abort, jsonify, request, send_file
from werkzeug.utils import secure_filename

from ..ai import AIError
from .common import _TIMER_ACTIONS, _body, _check_fields, _check_id, _check_recurrence, _int_in, _valid_notes_path, attachments_dir, bp, db
from ..database import new_id
from .. import trash


# -- tasks ----------------------------------------------------------------
@bp.get("/tasks")
def list_tasks():
    todo_list_id = request.args.get("todo_list_id")
    project_id = request.args.get("project_id")
    search = request.args.get("search")
    if search:
        return jsonify(db().search_tasks(search))
    include_done = request.args.get("include_done", "1") != "0"
    due_date = request.args.get("due_date")
    no_due_date = request.args.get("no_due_date") == "1"
    urgent_only = request.args.get("urgent") == "1"
    return jsonify(db().list_tasks(todo_list_id, project_id, include_done,
                                    due_date, no_due_date, urgent_only))


@bp.get("/tasks/smart")
def smart_tasks():
    """Today/Tomorrow/Urgent sidebar views: matching main tasks plus any
    subtasks that match the same filter on their own (see smart_view_tasks)."""
    due_date = request.args.get("due_date")
    urgent_only = request.args.get("urgent") == "1"
    include_done = request.args.get("include_done", "1") != "0"
    include_overdue = request.args.get("include_overdue") == "1"
    return jsonify(db().smart_view_tasks(due_date=due_date, urgent_only=urgent_only,
                                          include_done=include_done, include_overdue=include_overdue))


@bp.get("/smartcounts")
def smart_counts():
    today = request.args.get("today")
    tomorrow = request.args.get("tomorrow")
    if not today or not tomorrow:
        abort(400)
    return jsonify(db().smart_counts(today, tomorrow))


@bp.get("/tasks/<tid>")
def get_task(tid):
    task = db().get_task(tid)
    if not task:
        abort(404)
    return jsonify(task)


@bp.post("/tasks")
def add_task():
    data = _body()
    if not data.get("todo_list_id"):
        return jsonify({"error": "todo_list_id required"}), 400
    _check_fields({k: data[k] for k in ("title", "due_date", "duration_minutes", "start_time", "notes") if k in data})
    data["recurrence"] = _check_recurrence(data.get("recurrence"))
    tid = db().add_task(
        todo_list_id=data["todo_list_id"],
        title=data.get("title", ""),
        notes=data.get("notes", ""),
        due_date=data.get("due_date") or None,
        urgent=bool(data.get("urgent", False)),
        duration_minutes=data.get("duration_minutes") or None,
        is_video=bool(data.get("is_video", False)),
        recurrence=data.get("recurrence") or None,
        tag_ids=data.get("tag_ids") or [],
        start_time=data.get("start_time") or None,
    )
    return jsonify(db().get_task(tid)), 201


@bp.patch("/tasks/<tid>")
def update_task(tid):
    fields = _body()
    allowed = {"title", "notes", "due_date", "urgent", "duration_minutes", "is_video",
               "recurrence", "todo_list_id", "sort_order", "start_time", "notes_file",
               "mention_approved", "video_template", "video_note_file"}
    spent = fields.get("time_spent_seconds")
    only_this = bool(fields.pop("occurrence_only", False))
    occ_date = fields.pop("occurrence_date", None)
    fields = _check_fields({k: v for k, v in fields.items() if k in allowed})
    if spent is not None:
        db().set_time_spent("tasks", tid, _int_in(spent, "Time spent", 0, 10**9))
    if only_this and set(fields) <= {"due_date", "start_time"}:
        # a calendar drag: move just this occurrence of a recurring task
        if occ_date:       # a future occurrence (shown, not yet current)
            db().move_projected_occurrence(tid, occ_date, fields.get("due_date"), fields.get("start_time"), "start_time" in fields)
        else:
            db().move_occurrence("task", tid, fields.get("due_date"), fields.get("start_time"), "start_time" in fields)
    else:
        db().update_task(tid, **fields)
    return jsonify(db().get_task(tid))


@bp.delete("/tasks/<tid>")
def delete_task(tid):
    db().delete_task(tid)
    return jsonify({"ok": True})


@bp.post("/tasks/<tid>/toggle")
def toggle_task(tid):
    checked = bool(_body().get("checked", True))
    result = db().toggle_task(tid, checked)
    return jsonify({"result": result, "task": db().get_task(tid)})


@bp.post("/tasks/<tid>/timer")
def task_timer(tid):
    action = _body().get("action")
    method = _TIMER_ACTIONS.get(action)
    if not method:
        return jsonify({"error": "action must be one of start/stop/pause/resume"}), 400
    getattr(db(), method)("tasks", tid)
    return jsonify(db().get_task(tid))


@bp.post("/tasks/<tid>/tags")
def set_task_tags(tid):
    tag_ids = _body().get("tag_ids", [])
    db().set_task_tags(tid, tag_ids)
    return jsonify(db().get_task(tid))


@bp.get("/video-project/current")
def current_video_project():
    """« Current Video project » : par défaut la tâche principale vidéo (non terminée, avec une échéance) dont l'échéance est
    la plus proche d'aujourd'hui (à égalité, la plus à venir). Avec ?id=… : cette tâche. `prev_id` / `next_id` : la vidéo
    précédente / suivante dans l'ordre des échéances (toutes les tâches vidéo datées, terminées ou non).
    `project` (nom) restreint tout cela aux vidéos de ce projet."""
    today = date.fromisoformat(request.args.get("today") or date.today().isoformat())
    # ?project=<nom> : seulement les vidéos des listes de ce projet (insensible à la casse), ex. « The Linux Exp »
    # (utilisé par l'onglet Timeline du widget Plasma).
    # Comparaison tolérante : sans casse, sans espaces ni ponctuation, sans « the » initial (« The Linux EXP » = « the-linux exp »).
    def _norm(name):
        n = "".join(ch for ch in (name or "").lower() if ch.isalnum() or ch.isspace()).split()
        return "".join(n[1:] if n[:1] == ["the"] else n)
    project = _norm(request.args.get("project"))
    project_id = (request.args.get("project_id") or "").strip()      # filtre exact par projet (sélecteur de la vue)
    rows = db().conn.execute(
        "SELECT t.id, t.due_date, t.checked, p.name AS pname, p.id AS pid FROM tasks t JOIN todo_lists l ON l.id=t.todo_list_id "
        "JOIN projects p ON p.id=l.project_id WHERE t.is_video=1 AND t.due_date IS NOT NULL AND t.due_date<>'' "
        "ORDER BY t.due_date, t.created_at, t.id").fetchall()
    if project:
        rows = [r for r in rows if _norm(r["pname"]) == project]
    if project_id:
        rows = [r for r in rows if r["pid"] == project_id]
    dated = []
    for r in rows:
        try:
            dated.append((date.fromisoformat(r["due_date"][:10]), r["id"], r["checked"]))
        except ValueError:
            continue
    want = request.args.get("id")
    cur = next((x for x in dated if x[1] == want), None) if want else None
    if cur is None:
        best = None
        for d, tid, checked in dated:
            if checked:
                continue
            key = (abs((d - today).days), 0 if d >= today else 1)
            if best is None or key < best[0]:
                best = (key, (d, tid, checked))
        cur = best[1] if best else None
    if cur is None:
        return jsonify({"task": None, "prev_id": None, "next_id": None})
    idx = dated.index(cur)
    return jsonify({"task": db().get_task(cur[1]),
                    "prev_id": dated[idx - 1][1] if idx > 0 else None,
                    "next_id": dated[idx + 1][1] if idx + 1 < len(dated) else None})


@bp.get("/video-tasks/upcoming")
def upcoming_video_tasks():
    """« Useful Resources » : les tâches principales vidéo non terminées dont l'échéance tombe dans les `days` prochains
    jours (14 par défaut, aujourd'hui compris), sans leurs sous-tâches, avec les notes liées."""
    from datetime import timedelta
    today = date.fromisoformat(request.args.get("today") or date.today().isoformat())
    try:
        days = max(1, min(120, int(request.args.get("days") or 14)))
    except ValueError:
        days = 14
    end = today + timedelta(days=days)
    rows = db().conn.execute(
        "SELECT id FROM tasks WHERE is_video=1 AND checked=0 AND due_date IS NOT NULL AND substr(due_date,1,10) BETWEEN ? AND ? "
        "ORDER BY due_date, created_at, id", (today.isoformat(), end.isoformat())).fetchall()
    out = []
    for r in rows:
        t = db().get_task(r["id"])
        out.append({k: t.get(k) for k in ("id", "title", "due_date", "notes_file", "video_note_file", "project_name", "project_color", "video_template")})
    return jsonify(out)


@bp.post("/tasks/<tid>/video-note")
def create_video_note_route(tid):
    """« Create Video Note » (panneau de la tâche, tâches Weekly News) : copie la note liée en « <nom>-VIDEO »."""
    from .. import video_note
    from ..notes_api import notes_root
    task = db().get_task(tid)
    if not task:
        abort(404)
    path = task.get("notes_file")
    try:
        if not path:
            raise AIError("Cette tâche n'a pas de note liée.")
        if not _valid_notes_path(path):
            raise AIError("La note liée doit être un fichier Markdown ou texte situé dans le dossier de notes.")
        dst, warnings = video_note.create_video_note(path, [t["name"] for t in task.get("tags") or []], notes_root())
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    db().update_task(tid, video_note_file=str(dst))
    root = notes_root().resolve()
    try:
        rel = dst.resolve().relative_to(root).as_posix()
    except ValueError:
        rel = None
    return jsonify({"path": str(dst), "rel": rel, "name": dst.stem, "warnings": warnings})


# -- subtasks ---------------------------------------------------------------
@bp.get("/tasks/<tid>/subtasks")
def list_subtasks(tid):
    return jsonify(db().list_subtasks(tid))


@bp.post("/tasks/<tid>/subtasks")
def add_subtask(tid):
    data = _body()
    _check_fields({k: data[k] for k in ("title", "due_date", "duration_minutes", "start_time") if k in data})
    sid = db().add_subtask(
        tid,
        data.get("title", "Subtask"),
        due_date=data.get("due_date") or None,
        duration_minutes=data.get("duration_minutes") or None,
        urgent=bool(data.get("urgent", False)),
        start_time=data.get("start_time") or None,
    )
    return jsonify(db().get_subtask(sid)), 201


@bp.patch("/subtasks/<sid>")
def update_subtask(sid):
    fields = _body()
    allowed = {"title", "due_date", "duration_minutes", "urgent", "sort_order", "start_time", "notes_file"}
    spent = fields.get("time_spent_seconds")
    only_this = bool(fields.pop("occurrence_only", False))
    fields = _check_fields({k: v for k, v in fields.items() if k in allowed})
    if spent is not None:
        db().set_time_spent("subtasks", sid, _int_in(spent, "Time spent", 0, 10**9))
    if only_this and set(fields) <= {"due_date", "start_time"}:
        db().move_occurrence("subtask", sid, fields.get("due_date"), fields.get("start_time"), "start_time" in fields)
    else:
        db().update_subtask(sid, **fields)
    return jsonify(db().get_subtask(sid))


@bp.delete("/subtasks/<sid>")
def delete_subtask(sid):
    db().delete_subtask(sid)
    return jsonify({"ok": True})


@bp.post("/subtasks/<sid>/toggle")
def toggle_subtask(sid):
    checked = bool(_body().get("checked", True))
    db().toggle_subtask(sid, checked)
    return jsonify(db().get_subtask(sid))


@bp.post("/subtasks/<sid>/timer")
def subtask_timer(sid):
    action = _body().get("action")
    method = _TIMER_ACTIONS.get(action)
    if not method:
        return jsonify({"error": "action must be one of start/stop/pause/resume"}), 400
    getattr(db(), method)("subtasks", sid)
    return jsonify(db().get_subtask(sid))


# -- attachments (one per task) --------------------------------------------
@bp.post("/tasks/<tid>/attachment")
def upload_attachment(tid):
    _check_id(tid)
    if not db().get_task(tid):
        abort(404)
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "no file"}), 400
    filename = secure_filename(f.filename) or new_id()
    dest_dir = attachments_dir(tid)
    # a task has at most one attachment. The new file is saved first (under a temporary name) and only then replaces the
    # old one, so a failed upload (disk full, connection cut) never leaves the task without its previous attachment.
    tmp = dest_dir / f".upload-{new_id()}"
    try:
        f.save(tmp)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    dest = dest_dir / filename
    for existing in dest_dir.glob("*"):
        if existing != tmp:
            trash.discard(existing)                   # the previous attachment is replaced, not destroyed
    os.replace(tmp, dest)
    db().set_attachment(tid, str(dest), dest.name)
    return jsonify(db().get_task(tid)), 201


@bp.get("/tasks/<tid>/attachment")
def download_attachment(tid):
    task = db().get_task(tid)
    if not task or not task.get("attachment_path"):
        abort(404)
    path = Path(task["attachment_path"])
    if not path.exists():
        abort(404)
    return send_file(path, as_attachment=True, download_name=task["attachment_name"])


@bp.delete("/tasks/<tid>/attachment")
def delete_attachment(tid):
    task = db().get_task(tid)
    if task and task.get("attachment_path"):
        trash.discard(task["attachment_path"])
    db().clear_attachment(tid)
    return jsonify(db().get_task(tid))
