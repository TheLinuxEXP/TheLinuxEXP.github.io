"""Shared pieces of the REST API: the blueprint, request helpers and validation.

The routes themselves live in the sibling modules (organize, tasks, schedule,
ai_routes, templates_routes, admin); they all register on the same ``bp`` blueprint and import what they need
from here explicitly."""
from __future__ import annotations
import re
from datetime import date
from pathlib import Path

from flask import Blueprint, abort, current_app, jsonify, request

from ..ai import AIError
from ..database import data_dir
from ..notesfile import read_markdown_sections

bp = Blueprint("api", __name__)


def db():
    return current_app.db


def _subtask_and_parent(sid):
    """A subtask plus its parent (main) task, or a 404 if either is gone."""
    sub = db().get_subtask(sid)
    if not sub:
        abort(404)
    task = db().get_task(sub["task_id"])
    if not task:
        abort(404)
    return sub, task


class BadRequest(Exception):
    pass


@bp.errorhandler(BadRequest)
def _bad_request(e):
    return jsonify({"error": str(e)}), 400


def _body() -> dict:
    """The JSON body, which must be an object (a list / string / number would
    crash handlers that call .get() on it)."""
    data = request.get_json(force=True, silent=True)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise BadRequest("The request body must be a JSON object.")
    return data


_TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
_NOTE_SUFFIXES = {".md", ".markdown", ".mdx", ".txt"}


def _inside_notes_folder(path: str) -> bool:
    """True if `path` (symlinks resolved) is inside the notes folder: a task's linked note must never point at
    some other file of the machine (the AI buttons read it and several of them write it back)."""
    from ..notes_api import notes_root
    try:
        p = Path(path).expanduser().resolve()
        root = notes_root().resolve()
    except (OSError, RuntimeError, ValueError):
        return False
    return p == root or root in p.parents


def _valid_notes_path(path) -> bool:
    return (isinstance(path, str) and 0 < len(path) <= 1024 and "\0" not in path
            and Path(path).suffix.lower() in _NOTE_SUFFIXES and _inside_notes_folder(path))


def _int_in(value, label, lo, hi):
    if isinstance(value, bool):
        raise BadRequest(f"{label} must be a whole number.")
    try:
        n = int(value)
    except (TypeError, ValueError):
        raise BadRequest(f"{label} must be a whole number.")
    if not lo <= n <= hi:
        raise BadRequest(f"{label} is out of range.")
    return n


def _check_recurrence(rule):
    if not rule:
        return None
    if not isinstance(rule, dict) or rule.get("unit") not in ("day", "week", "month", "year"):
        raise BadRequest("Invalid recurrence rule.")
    out = {"unit": rule["unit"], "interval": _int_in(rule.get("interval", 1), "Recurrence interval", 1, 1000)}
    if rule.get("weekdays"):
        if not isinstance(rule["weekdays"], list):
            raise BadRequest("Invalid recurrence weekdays.")
        out["weekdays"] = sorted({_int_in(w, "Weekday", 0, 6) for w in rule["weekdays"]})
    if rule.get("end_date"):
        try:
            date.fromisoformat(str(rule["end_date"]))
        except ValueError:
            raise BadRequest("Invalid recurrence end date.")
        out["end_date"] = str(rule["end_date"])
    if rule.get("count"):
        out["count"] = _int_in(rule["count"], "Recurrence count", 1, 100000)
    if rule.get("anchor_day"):
        out["anchor_day"] = _int_in(rule["anchor_day"], "Anchor day", 1, 31)
    return out


def _check_fields(fields: dict) -> dict:
    """Validate/normalise the task & subtask fields the UI may send."""
    f = dict(fields)
    if "title" in f:
        if not isinstance(f["title"], str) or not f["title"].strip():
            raise BadRequest("The title can't be empty.")
        f["title"] = f["title"].strip()[:500]
    if "notes" in f:
        f["notes"] = str(f["notes"] or "")[:200000]
    if "due_date" in f:
        if f["due_date"]:
            try:
                date.fromisoformat(str(f["due_date"]))
            except ValueError:
                raise BadRequest("The due date isn't a valid date.")
            f["due_date"] = str(f["due_date"])
        else:
            f["due_date"] = None
    if "start_time" in f:
        if f["start_time"] and not _TIME_RE.match(str(f["start_time"])):
            raise BadRequest("The start time must look like 14:30.")
        f["start_time"] = f["start_time"] or None
    if "duration_minutes" in f:
        f["duration_minutes"] = _int_in(f["duration_minutes"], "Duration", 0, 60 * 24 * 14) if f["duration_minutes"] else None
    if "sort_order" in f:
        f["sort_order"] = _int_in(f["sort_order"], "Sort order", -10**9, 10**9)
    if "time_spent_seconds" in f:
        f["time_spent_seconds"] = _int_in(f["time_spent_seconds"], "Time spent", 0, 10**9)
    for key in ("notes_file", "video_note_file"):
        if key in f:
            if f[key] in (None, ""):
                f[key] = None
            elif not _valid_notes_path(f[key]):
                raise BadRequest("The notes file must be a Markdown or text file (.md, .markdown, .txt) inside the notes folder.")
    if "recurrence" in f:
        f["recurrence"] = _check_recurrence(f["recurrence"])
    return f


def _load_notes_file_sections(task):
    path = task.get("notes_file")
    if not path:
        raise AIError('This task has no linked notes file yet — set one in the task panel ("Notes file") first.')
    if not _valid_notes_path(path):
        raise AIError("The linked notes file must be a Markdown or text file (.md, .markdown, .txt) inside the notes folder.")
    try:
        sections, _order = read_markdown_sections(path)
    except FileNotFoundError:
        raise AIError(f"Couldn't find the linked notes file on disk: {path}")
    return sections


TAGS_MAX_CHARS = 500     # YouTube's limit for the tags field


def _fit_tags(raw):
    """Clean a comma-separated tag list (no duplicates, no stray quotes or
    hashes) and keep as many whole tags as fit in TAGS_MAX_CHARS."""
    seen, out, total = set(), [], 0
    for tag in str(raw).replace("\n", ",").split(","):
        tag = tag.strip().strip("\"'").lstrip("#").strip()
        if not tag or tag.lower() in seen:
            continue
        add = len(tag) + (2 if out else 0)          # ", " between tags
        if total + add > TAGS_MAX_CHARS:
            continue                                  # a shorter later tag may still fit
        seen.add(tag.lower())
        out.append(tag)
        total += add
    return ", ".join(out)


def _missing_section_message(sections, name):
    """Tell "no such heading" apart from "heading found but nothing under it"."""
    if any(name.lower() in k.lower() for k in sections):
        return f'The "{name}" section in the linked notes file is empty — there is nothing under that heading.'
    found = ", ".join(f'"{k}"' for k in list(sections)[:8]) or "none"
    return f'Couldn\'t find a "{name}" section in the linked notes file. Headings found: {found}.'


_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def _check_id(value: str) -> str:
    """Ids are used to build folder names: only accept plain identifiers, so
    nothing like '..' can ever make a path leave the data directory."""
    if not isinstance(value, str) or not _ID_RE.match(value):
        abort(400)
    return value


def attachments_dir(task_id: str) -> Path:
    _check_id(task_id)
    d = data_dir() / "attachments" / task_id
    d.mkdir(parents=True, exist_ok=True)
    return d


# timer action name -> Database method (used by the task, subtask and 'other tasks' timers)
_TIMER_ACTIONS = {
    "start": "start_timer",
    "stop": "stop_timer",
    "pause": "pause_timer",
    "resume": "resume_timer",
}

