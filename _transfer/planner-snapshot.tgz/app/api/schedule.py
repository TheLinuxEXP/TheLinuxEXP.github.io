"""Calendar, time reports/insights, active timers and the desktop-widget tab coordination."""
from __future__ import annotations
import calendar as pycalendar
from datetime import date
import threading
import time

from flask import abort, jsonify, request

from ..ai import AIError, call_claude
from .common import _TIMER_ACTIONS, _body, _check_id, bp, db


# -- calendar --------------------------------------------------------------
@bp.get("/calendar")
def calendar_month():
    try:
        year = int(request.args.get("year"))
        month = int(request.args.get("month"))
    except (TypeError, ValueError):
        abort(400)
    first = f"{year:04d}-{month:02d}-01"
    last_day = pycalendar.monthrange(year, month)[1]
    last = f"{year:04d}-{month:02d}-{last_day:02d}"
    return jsonify(db().calendar_entries(first, last, only_videos=request.args.get("only_videos") == "1"))


@bp.get("/calendar/range")
def calendar_range():
    """Arbitrary [start, end] range (inclusive), used by the week view —
    unlike the month endpoint above, a week can straddle two months."""
    start = request.args.get("start")
    end = request.args.get("end")
    if not start or not end:
        abort(400)
    return jsonify(db().calendar_entries(start, end))


@bp.get("/other-tasks")
def other_tasks():
    """'Other tasks' bucket: ?start&end -> {day: {...}}; no params -> current/today's."""
    start, end = request.args.get("start"), request.args.get("end")
    if start and end:
        return jsonify(db().other_tasks_range(start, end))
    return jsonify(db().other_tasks_for(date.today().isoformat()))


@bp.patch("/other-tasks/<day>")
def other_tasks_set_time(day):
    """Type the time of a day's "Other tasks" bucket by hand: {"time_spent_seconds": n}."""
    try:
        date.fromisoformat(day)
        seconds = int(_body().get("time_spent_seconds"))
    except (ValueError, TypeError):
        return jsonify({"error": "A date (YYYY-MM-DD) and a number of seconds are required."}), 400
    if not 0 <= seconds <= 24 * 3600:
        return jsonify({"error": "Time must be between 0 and 24 hours."}), 400
    db().set_other_time(day, seconds)
    return jsonify(db().other_tasks_for(date.today().isoformat()))


@bp.post("/other-tasks/<day>/timer")
@bp.post("/other-tasks/timer")
def other_tasks_timer(day=None):
    action = _body().get("action")
    if action not in _TIMER_ACTIONS:
        return jsonify({"error": "action must be one of start/stop/pause/resume"}), 400
    return jsonify(db().other_timer(action, date.today().isoformat()))


@bp.get("/project-other-tasks")
def project_other_tasks():
    """The "Other tasks" of each project. No params -> [{project_id, project_name, color, day, time_spent_seconds, timer_state}]
    (the running bucket of each project, else today's); ?start&end -> {day: [...]} for the buckets that have time."""
    start, end = request.args.get("start"), request.args.get("end")
    if start and end:
        return jsonify(db().project_other_range(start, end))
    return jsonify(db().project_others(date.today().isoformat()))


@bp.patch("/project-other-tasks/<pid>/<day>")
def project_other_tasks_set_time(pid, day):
    """Type the time of a project's "Other tasks" for a day: {"time_spent_seconds": n}."""
    _check_id(pid)
    try:
        date.fromisoformat(day)
        seconds = int(_body().get("time_spent_seconds"))
    except (ValueError, TypeError):
        return jsonify({"error": "A date (YYYY-MM-DD) and a number of seconds are required."}), 400
    if not 0 <= seconds <= 24 * 3600:
        return jsonify({"error": "Time must be between 0 and 24 hours."}), 400
    if not db().set_project_other_time(pid, day, seconds):
        abort(404)
    return jsonify(db().project_other_for(pid, date.today().isoformat()))


@bp.post("/project-other-tasks/<pid>/<day>/timer")
@bp.post("/project-other-tasks/<pid>/timer")
def project_other_tasks_timer(pid, day=None):
    _check_id(pid)
    action = _body().get("action")
    if action not in _TIMER_ACTIONS:
        return jsonify({"error": "action must be one of start/stop/pause/resume"}), 400
    res = db().project_other_timer(pid, action, date.today().isoformat())
    if res is None:
        abort(404)
    return jsonify(res)


@bp.get("/calendar/time-by-day")
def calendar_time_by_day():
    """{iso_date: total_seconds} recorded on tasks/subtasks DUE within
    [start, end], whether or not they're done yet -- backs the week view's
    per-day hours total."""
    start = request.args.get("start")
    end = request.args.get("end")
    if not start or not end:
        abort(400)
    return jsonify(db().time_by_day(start, end))


@bp.get("/calendar/time-day")
def calendar_time_day():
    """Breakdown of one day's tracked-time total (the week view header)."""
    day = request.args.get("day")
    if not day:
        abort(400)
    return jsonify(db().time_day_detail(day))


@bp.get("/reports/time")
def time_report():
    """Tracked-time entries within [start, end] (see Database.time_report)."""
    start = request.args.get("start")
    end = request.args.get("end")
    if not start or not end:
        abort(400)
    return jsonify(db().time_report(start, end))


@bp.post("/reports/time/insights")
def time_insights():
    """Claude's written analysis of where the tracked time goes (see insights.py).
    With {kind: week|month, start: ISO date}: (re)generate and STORE the insights
    of that period; without: a one-off analysis of the recent past (not stored)."""
    from datetime import date as _date
    from .. import insights
    today = _date.today()
    body = request.get_json(silent=True) or {}
    kind, start = body.get("kind"), body.get("start")
    if kind in ("week", "month") and start:
        try:
            begin = _date.fromisoformat(start)
            begin = insights.week_start(begin) if kind == "week" else insights.month_start(begin)
            text = insights.generate_for_period(db(), kind, begin, call_claude, today)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        except AIError as e:
            return jsonify({"error": str(e)}), 400
        return jsonify({"result": text, "start": begin.isoformat(), **db().get_time_insight(kind, begin.isoformat())})
    entries = db().time_insight_entries(insights.window_start(today).isoformat(), today.isoformat())
    if not entries:
        return jsonify({"error": "No tracked time yet, so there is nothing to analyse."}), 400
    stats = insights.build_stats(entries, today)
    try:
        result = call_claude(insights.build_prompt(stats),
                             system="You are a calm, precise productivity analyst. Use only the numbers you are given.")
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"result": result, "generated_at": _date.today().isoformat()})


@bp.get("/reports/time/insights")
def stored_time_insights():
    """Stored per-period insights: ?kind=week|month&start&end -> {period_start: {text, generated_at}}."""
    kind = request.args.get("kind")
    start, end = request.args.get("start"), request.args.get("end")
    if kind not in ("week", "month") or not start or not end:
        abort(400)
    return jsonify(db().list_time_insights(kind, start, end))


@bp.get("/timers/active")
def active_timers():
    """Every task/subtask currently running or paused -- backs the header's
    active-timers indicator/popup."""
    return jsonify(db().active_timers())


# -- desktop widget: browser-tab coordination -------------------------------
# Lets the KDE Plasma "Today" widget reuse an already-open browser tab
# instead of always popping a new one: every open tab of this app pings
# /tab/heartbeat every few seconds while it's loaded, so /tab/open-request
# can tell whether a tab is likely alive right now. If so, it just leaves a
# "pending" task id for the page's own heartbeat (see static/js/system.js) to notice and
# jump to -- the tab brings *itself* to the front via window.focus(), which
# works reliably since it's the tab's own script doing it. If no tab seems to
# be open, the widget falls back to Qt.openUrlExternally() to launch one.
# This is all in-memory and intentionally not persisted -- it's a live signal
# about "is a tab open right now", which stops meaning anything the moment
# the process restarts anyway.
_tab_lock = threading.Lock()
_tab_state = {"last_heartbeat": 0.0, "pending_task_id": None}
_TAB_ALIVE_WINDOW = 12  # seconds; a few missed heartbeats (the page slows down to one every 5 s while in the background)


@bp.post("/tab/heartbeat")
def tab_heartbeat():
    """The page's one periodic call: says "a tab is open" AND hands back (consume-once, like /tab/pending) the task the widget
    asked to open, so the page needs a single request instead of a heartbeat plus a poll."""
    with _tab_lock:
        _tab_state["last_heartbeat"] = time.time()
        task_id = _tab_state["pending_task_id"]
        _tab_state["pending_task_id"] = None
    return jsonify({"ok": True, "task_id": task_id})


@bp.get("/tab/status")
def tab_status():
    with _tab_lock:
        alive = (time.time() - _tab_state["last_heartbeat"]) < _TAB_ALIVE_WINDOW
    return jsonify({"open": alive})


@bp.post("/tab/open-request")
def tab_open_request():
    data = _body()
    task_id = data.get("task_id")
    if not task_id:
        return jsonify({"error": "task_id required"}), 400
    with _tab_lock:
        had_open_tab = (time.time() - _tab_state["last_heartbeat"]) < _TAB_ALIVE_WINDOW
        _tab_state["pending_task_id"] = task_id
    return jsonify({"had_open_tab": had_open_tab})


@bp.get("/tab/pending")
def tab_pending():
    """Consume-once: the first tab to poll after an open-request claims it,
    so with several tabs open only one of them jumps to the task."""
    with _tab_lock:
        task_id = _tab_state["pending_task_id"]
        _tab_state["pending_task_id"] = None
    return jsonify({"task_id": task_id})
