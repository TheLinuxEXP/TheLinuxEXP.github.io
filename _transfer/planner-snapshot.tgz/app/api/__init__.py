"""REST API blueprint. Thin JSON wrapper around Database.

Split by topic; each module adds its routes to the shared blueprint."""
from .common import bp  # noqa: F401
from . import organize, tasks, templates_routes, schedule, ai_routes, ppt_routes, admin  # noqa: F401 -- importing registers the routes
