"""PowerPoint buttons of the Warhammer Video template: "Generate" (links / PDF -> slides) and "List to PPT" (army list ->
deck, or a zip of the card images). The text-only AI buttons are in ai_routes.py."""
from __future__ import annotations
from pathlib import Path

from flask import abort, jsonify, request, send_file

from .. import army_list, content_extract, pptx_gen
from ..ai import AIError, generate_slide_plan
from ..database import data_dir
from .common import _body, _check_id, _subtask_and_parent, bp


# -- "Generate" PowerPoint button (Warhammer Video's "Create powerpoint") --
# Unlike the text-only AI buttons above, this one takes multipart input
# (pasted links, an optional reference document, a free-text prompt),
# combines whatever was given into reference text, asks Claude to plan the
# slides, then stamps them out onto cloned copies of a real slide from the
# project's own "presentation.pptx" so the result matches its look. See
# app/pptx_gen.py and app/content_extract.py.
def _generated_pptx_path(sid: str) -> Path:
    _check_id(sid)
    return data_dir() / "generated" / sid / "presentation.pptx"


@bp.post("/subtasks/<sid>/ai/generate-pptx")
def ai_generate_pptx(sid):
    sub, task = _subtask_and_parent(sid)
    try:
        links = [u.strip() for u in (request.form.get("links") or "").splitlines() if u.strip()]
        prompt = (request.form.get("prompt") or "").strip()
        upload = request.files.get("file")

        doc_text, blocks, ocr_pages = "", [], 0
        if upload and upload.filename:
            doc_text, blocks, ocr_pages = content_extract.extract_document(
                upload, _generated_pptx_path(sid).parent / "blocks",
                force_ocr=request.form.get("force_ocr") == "1")

        if not links and not doc_text and not prompt:
            raise AIError("Add at least a prompt, a link, or a document to generate from.")

        link_text = "\n".join(content_extract.fetch_link_text(u) for u in links)
        out_path = _generated_pptx_path(sid)
        found = {}
        for b in blocks:
            found[b.kind] = found.get(b.kind, 0) + 1

        if blocks:
            # One slide per picture block cut out of the PDF: the image on the
            # right, a French recap in the person's tone on the left.
            from ..ai import select_blocks, write_block_slides
            labels = {"datasheet": "datasheet", "detachment_rule": "règle de détachement",
                      "enhancements": "améliorations", "stratagems": "stratagèmes"}
            outline = [f"{labels[b.kind]} — {b.title} (page {b.page})" for b in blocks]
            keep = select_blocks(outline, prompt)
            chosen = [(n, blocks[n]) for n in keep]
            texts = write_block_slides(
                [{"i": n, "kind": b.kind, "title": b.title, "detachment": b.detachment,
                  "page_top": b.page_top, "text": b.text, "image": str(b.path)} for n, b in chosen],
                pptx_gen.template_text_samples(), prompt, extra_context=link_text,
                read_dir=_generated_pptx_path(sid).parent / "blocks")
            slides = []
            for n, b in chosen:
                t = texts.get(n, {})
                slides.append({"title": t.get("title") or b.title, "lines": t.get("lines") or [], "image": b.path})
            slide_count = pptx_gen.build_picture_deck(slides, out_path)
        else:
            context_parts = []
            if doc_text:
                context_parts.append(f"## Reference document: {upload.filename}\n{doc_text}\n")
            if link_text:
                context_parts.append(link_text)
            plan = generate_slide_plan(chr(10).join(context_parts), prompt)
            slide_count = pptx_gen.build_presentation(plan, out_path, deck_title=task.get("title"))
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({
        "slide_count": slide_count,
        "ocr_pages": ocr_pages,
        "blocks_found": found,
        "download_url": f"/api/subtasks/{sid}/ai/generate-pptx/download",
    })


# -- "List to PPT" (Warhammer Video, "Create powerpoint"): an army list pasted from the Games Workshop app ->
# a deck in the person's own template. See app/army_list.py (parsing, slide plan), app/army_rules.py (rules read from
# Wahapedia through Claude, cached) and app/army_cards.py (the pictures on the right of each slide).
def _list_ppt_path(sid: str) -> Path:
    _check_id(sid)
    return data_dir() / "generated" / sid / "list-to-ppt.pptx"


def _list_zip_path(sid: str) -> Path:
    _check_id(sid)
    return data_dir() / "generated" / sid / "list-images.zip"


@bp.post("/subtasks/<sid>/ai/list-to-ppt")
def ai_list_to_ppt(sid):
    sub, task = _subtask_and_parent(sid)
    text = str(_body().get("text") or "")
    if not text.strip():
        return jsonify({"error": "Collez d'abord une liste d'armée."}), 400
    images_only = str(_body().get("mode") or "") == "images"
    out = _list_zip_path(sid) if images_only else _list_ppt_path(sid)
    try:
        res = army_list.generate_deck(text, out, out.parent, images_only=images_only)
    except AIError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:  # noqa: BLE001 -- the real message is shown in the dialog instead of an HTML 500 page
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Erreur inattendue ({type(e).__name__}) : {e}"}), 500
    res["download_url"] = f"/api/subtasks/{sid}/ai/list-to-ppt/download" + ("?kind=images" if images_only else "")
    res["images_only"] = images_only
    return jsonify(res)


@bp.get("/subtasks/<sid>/ai/list-to-ppt/download")
def download_list_ppt(sid):
    images = request.args.get("kind") == "images"
    path = _list_zip_path(sid) if images else _list_ppt_path(sid)
    if not path.exists():
        abort(404)
    sub, task = _subtask_and_parent(sid)
    if images:
        return send_file(path, as_attachment=True, download_name=f"{task.get('title') or 'liste'} - Images.zip")
    return send_file(path, as_attachment=True, download_name=f"{task.get('title') or 'liste'} - Liste.pptx")


@bp.post("/subtasks/<sid>/ai/list-to-ppt/open-folder")
def open_list_images_folder(sid):
    """Ouvre le dossier du zip dans le gestionnaire de fichiers par défaut (le Planner tourne sur la machine de l'utilisateur)."""
    import subprocess
    import sys
    if request.remote_addr not in ("127.0.0.1", "::1"):     # a file manager can only open on the machine running the server
        return jsonify({"error": "Ouverture du dossier possible uniquement depuis la machine qui fait tourner le Planner."}), 403
    path = _list_zip_path(sid)
    if not path.exists():
        return jsonify({"error": "Aucun zip généré pour cette tâche."}), 404
    opener = ["xdg-open", str(path.parent)] if sys.platform.startswith("linux") else \
             (["open", "-R", str(path)] if sys.platform == "darwin" else ["explorer", f"/select,{path}"])
    try:
        subprocess.Popen(opener, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError as e:
        return jsonify({"error": f"Impossible d'ouvrir le gestionnaire de fichiers ({e}).", "path": str(path)}), 500
    return jsonify({"ok": True, "path": str(path)})


@bp.get("/subtasks/<sid>/ai/generate-pptx/download")
def download_generated_pptx(sid):
    path = _generated_pptx_path(sid)
    if not path.exists():
        abort(404)
    sub, task = _subtask_and_parent(sid)
    name = f"{task.get('title') or 'presentation'} - Generated.pptx"
    return send_file(path, as_attachment=True, download_name=name)
