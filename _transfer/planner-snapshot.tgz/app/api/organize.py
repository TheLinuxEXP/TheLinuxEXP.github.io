"""Projects, to-do lists, tags and sponsor contracts."""
from __future__ import annotations
from datetime import date
import os
from pathlib import Path

from flask import abort, jsonify, request, send_file
from werkzeug.utils import secure_filename

from .common import _body, bp, db
from ..database import data_dir
from .. import trash


# -- projects -------------------------------------------------------------
@bp.get("/projects")
def list_projects():
    return jsonify(db().list_projects())


@bp.post("/projects")
def add_project():
    data = _body()
    pid = db().add_project(data.get("name", "New project"), data.get("color"))
    return jsonify({"id": pid}), 201


@bp.patch("/projects/<pid>")
def update_project(pid):
    fields = _body()
    fields = {k: v for k, v in fields.items() if k in {"name", "color", "sort_order"}}
    db().update_project(pid, **fields)
    return jsonify({"ok": True})


@bp.delete("/projects/<pid>")
def delete_project(pid):
    db().delete_project(pid)
    return jsonify({"ok": True})


# -- todo lists ---------------------------------------------------------------
@bp.get("/todolists")
def list_todo_lists():
    project_id = request.args.get("project_id")
    return jsonify(db().list_todo_lists(project_id))


@bp.post("/todolists")
def add_todo_list():
    data = _body()
    if not data.get("project_id"):
        return jsonify({"error": "project_id required"}), 400
    lid = db().add_todo_list(data["project_id"], data.get("name", "New list"))
    return jsonify({"id": lid}), 201


@bp.post("/todolists/reorder")
def reorder_todo_lists():
    data = _body()
    ids = data.get("ids")
    if not data.get("project_id") or not isinstance(ids, list):
        return jsonify({"error": "project_id and ids required"}), 400
    db().reorder_todo_lists(data["project_id"], [str(i) for i in ids])
    return jsonify({"ok": True})


@bp.patch("/todolists/<lid>")
def update_todo_list(lid):
    fields = _body()
    fields = {k: v for k, v in fields.items() if k in {"name", "sort_order"}}
    db().update_todo_list(lid, **fields)
    return jsonify({"ok": True})


@bp.delete("/todolists/<lid>")
def delete_todo_list(lid):
    db().delete_todo_list(lid)
    return jsonify({"ok": True})


# -- tags -------------------------------------------------------------
@bp.get("/tags")
def list_tags():
    return jsonify(db().list_tags())


@bp.post("/tags")
def add_tag():
    data = _body()
    tid = db().add_tag(data.get("name", "tag"), data.get("color"))
    return jsonify({"id": tid}), 201


@bp.patch("/tags/<tid>")
def update_tag(tid):
    fields = _body()
    fields = {k: v for k, v in fields.items() if k in {"name", "color"} and v}
    db().update_tag(tid, **fields)
    return jsonify({"ok": True})


@bp.delete("/tags/<tid>")
def delete_tag(tid):
    contract = db().get_tag_contract(tid)
    if contract and contract.get("file_path"):
        trash.discard(contract["file_path"])          # kept in the trash folder: a restored backup still finds the contract
    db().delete_tag(tid)
    return jsonify({"ok": True})


# -- sponsor contracts (one per tag) ----------------------------------------
@bp.get("/tags/contracts")
def list_tag_contracts():
    return jsonify(db().list_tag_contracts())


@bp.post("/tags/<tid>/contract")
def upload_tag_contract(tid):
    if not any(t["id"] == tid for t in db().list_tags()):
        abort(404)
    f = request.files.get("file")
    current = db().get_tag_contract(tid)
    raw_videos = (request.form.get("total_videos") or "").strip()
    try:
        total_videos = int(raw_videos) if raw_videos else None
        if total_videos is not None and total_videos < 0:
            raise ValueError
    except ValueError:
        return jsonify({"error": "The total number of videos must be a whole number."}), 400
    end_date = (request.form.get("end_date") or "").strip() or None
    if end_date:
        try:
            date.fromisoformat(end_date)
        except ValueError:
            return jsonify({"error": "The end date isn't a valid date."}), 400
    billing_period = (request.form.get("billing_period") or "").strip() or None
    amount_type = (request.form.get("amount_type") or "").strip() or None
    amount = (request.form.get("amount") or "").strip()[:40] or None
    if billing_period not in (None, "monthly", "quarterly"):
        return jsonify({"error": "Billing must be Monthly or Quarterly."}), 400
    if amount_type not in (None, "per_video", "fixed"):
        return jsonify({"error": "The amount type must be Per video or Fixed."}), 400
    extra = (billing_period, amount_type, amount)
    path, name = (current or {}).get("file_path"), (current or {}).get("file_name")
    if path and not Path(path).exists():
        path = name = None
    if not f or not f.filename:
        # no new file: the file (if any) stays, only the details change
        db().set_tag_contract(tid, path, name, total_videos, end_date, *extra)
        return jsonify(next(c for c in db().list_tag_contracts() if c["id"] == tid)), 201
    dest_dir = data_dir() / "contracts" / tid
    dest_dir.mkdir(parents=True, exist_ok=True)
    for existing in dest_dir.glob("*"):
        trash.discard(existing)                       # the previous contract file is replaced, not destroyed
    filename = secure_filename(f.filename) or "contract"
    dest = dest_dir / filename
    f.save(dest)
    db().set_tag_contract(tid, str(dest), filename, total_videos, end_date, *extra)
    return jsonify(next(c for c in db().list_tag_contracts() if c["id"] == tid)), 201


@bp.post("/billing/run")
def run_billing_now():
    """Creates any invoice task that is due (also done at start-up and every hour)."""
    return jsonify({"created": db().run_billing()})


@bp.get("/tags/<tid>/contract")
def download_tag_contract(tid):
    contract = db().get_tag_contract(tid)
    if not contract or not contract.get("file_path"):
        abort(404)
    path = Path(contract["file_path"])
    if not path.exists():
        abort(404)
    return send_file(path, as_attachment=True, download_name=contract["file_name"])


@bp.get("/tags/monthly-report")
def tags_monthly_report():
    try:
        year = int(request.args.get("year"))
        month = int(request.args.get("month"))
    except (TypeError, ValueError):
        abort(400)
    return jsonify(db().tags_monthly_report(year, month))


@bp.post("/sponsors/create-mention-task")
def create_sponsor_mention_task():
    data = _body()
    sponsor_name = (data.get("sponsor_name") or "").strip()
    if not sponsor_name:
        return jsonify({"error": "sponsor_name required"}), 400
    return jsonify(db().create_sponsor_mention_task(sponsor_name)), 201
