"""AI insights for the Time report.

All the arithmetic is done here, in Python (language models are unreliable at
sums and averages); Claude only gets the finished numbers and writes the
analysis and recommendations.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta

WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
RECENT_WEEKS = 10
LONG_WEEKS = 22          # about 5 months

# Which part of a video an activity belongs to (matched on the subtask title).
PHASES = [
    ("Scripts / research", ("script", "order topics", "research", "outline", "write", "topics", "notes", "powerpoint")),
    ("Recording", ("record", "voice", "filming", "film")),
    ("Editing", ("edit", "montage", "cut", "render")),
    ("Thumbnails & publishing", ("thumbnail", "publish", "upload", "title", "description", "schedule", "tags")),
]


# Standing rules about how this person works, given to the model in every prompt.
GUIDELINES = """Working constraints you must respect in the analysis and especially in the recommendations:
- Daily News show videos cannot be batched: they are recorded from information gathered the
  same day. Never suggest batching them, preparing them in advance, or moving their work to
  another day. (Other video types can be batched if the numbers support it.)
- Video production always follows the same order: write the script, record the A roll, edit
  the A roll, edit the full video, create the thumbnails, then publish. No step can start before
  the previous one is finished. Only suggest moving or grouping work in a way that keeps this
  order for each video, and do not suggest doing a later step ahead of an earlier one."""


def phase_of(activity: str) -> str:
    a = activity.lower()
    for name, words in PHASES:
        if any(w in a for w in words):
            return name
    return "Other video work"


def week_start(d: date) -> date:
    return d - timedelta(days=d.weekday())


def window_start(today: date) -> date:
    """First day the data must cover: LONG_WEEKS + the past week + this one."""
    return week_start(today) - timedelta(weeks=LONG_WEEKS + 1)


def _hours(sec) -> float:
    return round(sec / 3600, 2)


def _split(entries):
    """Totals per category for a list of entries."""
    cat, phase, proj, task = defaultdict(int), defaultdict(int), defaultdict(int), defaultdict(int)
    for e in entries:
        s = e["seconds"]
        if e["other"]:
            cat["Other tasks (not tied to a task)"] += s
        elif e["is_video"]:
            cat["Video projects"] += s
            phase[phase_of(e["activity"])] += s
            task[e["task"]] += s
        else:
            cat["Non-video tasks"] += s
            task[e["task"]] += s
        if not e["other"]:
            proj[e["project"] or "(no project)"] += s
    return cat, phase, proj, task


def _avg(d, weeks):
    return {k: _hours(v / weeks) for k, v in sorted(d.items(), key=lambda kv: -kv[1])}


def _top(d, n=8):
    return {k: _hours(v) for k, v in sorted(d.items(), key=lambda kv: -kv[1])[:n]}


def build_stats(entries, today: date, week: date | None = None) -> dict:
    """`week` (a Monday): analyse that week instead of the last complete one."""
    this_week = week_start(today)
    past = week or this_week - timedelta(weeks=1)         # default: last COMPLETE week (Mon-Sun)
    by_week = defaultdict(list)
    for e in entries:
        by_week[week_start(date.fromisoformat(e["date"]))].append(e)
    first = min(by_week) if by_week else None

    def window(n_weeks, ending_before):
        """Entries of the n weeks before `ending_before`, limited to weeks since the first tracked week."""
        weeks = [ending_before - timedelta(weeks=i) for i in range(1, n_weeks + 1)]
        weeks = [w for w in weeks if first is not None and w >= first]
        return weeks, [e for w in weeks for e in by_week.get(w, [])]

    past_entries = by_week.get(past, [])
    w10, e10 = window(RECENT_WEEKS, past)
    w22, e22 = window(LONG_WEEKS, past)

    def block(entries_, n):
        cat, phase, proj, task = _split(entries_)
        total = sum(cat.values())
        return {"weeks_covered": n, "total_hours": _hours(total) if n == 0 else _hours(total / max(n, 1)),
                "by_category_hours": _avg(cat, max(n, 1)), "video_phase_hours": _avg(phase, max(n, 1)),
                "by_project_hours": _avg(proj, max(n, 1)), "top_tasks_hours": dict(list(_avg(task, max(n, 1)).items())[:8])}

    cat, phase, proj, task = _split(past_entries)
    past_block = {"week": f"{past.isoformat()} to {(past + timedelta(days=6)).isoformat()}",
                  "total_hours": _hours(sum(cat.values())),
                  "by_category_hours": {k: _hours(v) for k, v in sorted(cat.items(), key=lambda kv: -kv[1])},
                  "video_phase_hours": {k: _hours(v) for k, v in sorted(phase.items(), key=lambda kv: -kv[1])},
                  "by_project_hours": {k: _hours(v) for k, v in sorted(proj.items(), key=lambda kv: -kv[1])},
                  "top_tasks_hours": _top(task)}

    # Weekday pattern over the long window (complete weeks only): average hours per weekday, zero days included.
    per_day = defaultdict(int)
    for e in e22:
        per_day[date.fromisoformat(e["date"])] += e["seconds"]
    wd_total = [0] * 7
    for d, sec in per_day.items():
        wd_total[d.weekday()] += sec
    n22 = max(len(w22), 1)
    wd_avg = {WEEKDAYS[i]: _hours(wd_total[i] / n22) for i in range(7)}
    wd_active = {WEEKDAYS[i]: round(sum(1 for d, s in per_day.items() if d.weekday() == i and s > 0) / n22, 2) for i in range(7)}
    # Same, over the recent window, and for the past week day by day.
    per_day10 = defaultdict(int)
    for e in e10:
        per_day10[date.fromisoformat(e["date"])] += e["seconds"]
    wd10 = [0] * 7
    for d, sec in per_day10.items():
        wd10[d.weekday()] += sec
    n10 = max(len(w10), 1)
    past_days = {WEEKDAYS[i]: _hours(sum(e["seconds"] for e in past_entries if date.fromisoformat(e["date"]).weekday() == i))
                 for i in range(7)}

    # What kind of work lands on which weekday (long window): hours per weekday per category.
    wd_cat = {WEEKDAYS[i]: defaultdict(int) for i in range(7)}
    for e in e22:
        name = "Other tasks" if e["other"] else (phase_of(e["activity"]) if e["is_video"] else "Non-video tasks")
        wd_cat[WEEKDAYS[date.fromisoformat(e["date"]).weekday()]][name] += e["seconds"]
    wd_mix = {d: {k: _hours(v / n22) for k, v in sorted(c.items(), key=lambda kv: -kv[1])} for d, c in wd_cat.items()}

    cat_t, phase_t, proj_t, task_t = _split(by_week.get(this_week, []))
    this_week_block = {"total_hours": _hours(sum(cat_t.values())), "days_elapsed_incl_today": today.weekday() + 1,
                       "by_category_hours": {k: _hours(v) for k, v in sorted(cat_t.items(), key=lambda kv: -kv[1])},
                       "video_phase_hours": {k: _hours(v) for k, v in sorted(phase_t.items(), key=lambda kv: -kv[1])},
                       "top_tasks_hours": _top(task_t)}
    weekly_totals = {w.isoformat(): _hours(sum(e["seconds"] for e in by_week.get(w, [])))
                     for w in sorted(set(w22) | set(w10) | {past})}
    return {
        "today": today.isoformat(),
        "first_tracked_week": first.isoformat() if first else None,
        "past_week": past_block,
        "past_week_by_weekday_hours": past_days,
        "average_week_previous_10_weeks": block(e10, len(w10)),
        "average_week_previous_5_months": block(e22, len(w22)),
        "weekday_average_hours_previous_5_months": wd_avg,
        "weekday_average_hours_previous_10_weeks": {WEEKDAYS[i]: _hours(wd10[i] / n10) for i in range(7)},
        "share_of_weeks_with_time_tracked_on_weekday_5_months": wd_active,
        "weekday_work_mix_hours_per_week_5_months": wd_mix,
        "weekly_total_hours": weekly_totals,
        **({"this_week_so_far": this_week_block} if week is None else {}),
        "weeks_of_history_before_past_week": len([w for w in by_week if w < past]),
    }


def build_prompt(stats: dict) -> str:
    import json
    return f"""Below are time-tracking statistics for the person who makes videos for a Linux
YouTube channel (the numbers were computed by the app and are exact; do not recompute
them, just interpret them). Hours are real tracked hours. "Average week" blocks are
hours per week averaged over the weeks covered. The "past week" is the week being analysed
(a Monday-Sunday week); "this_week_so_far" is the unfinished current week (use it as the main
evidence when the history before the past week is very short or empty, and say so plainly). Video
phases are guessed from subtask names. Time on a main task that has subtasks is counted
through its subtasks only. If a comparison period covers few weeks (weeks_covered), say
the baseline is thin instead of over-reading it.

{GUIDELINES}

{json.dumps(stats, indent=1, ensure_ascii=False)}

Write the analysis in English, in markdown, using exactly these four "## " sections and
nothing before or after them:

## Where your time goes
Overall split between video projects, other tasks and non-video tasks, which projects/tasks
dominate, and within videos how time divides between scripts, recording, editing, and
thumbnails/publishing (use the 5-month average as the "generally" picture).

## Past week vs. your usual
The past week in the same terms, compared with the previous-10-weeks average and the
previous-5-months average: what was higher, lower or unusual. Give concrete hours and
percentage differences.

## Your week rhythm
Which weekdays carry the most and the least time, how consistent that is (how often each
weekday has any time tracked), what kind of work lands on which day, and how the past week
looked by comparison.

## Recommendations
3 to 6 concrete, specific recommendations to balance work across the whole week (e.g. which
kind of task to move to which lighter weekday, what to batch, what to protect), each tied
to a number above. No generic advice.

Keep it tight: short paragraphs and bullet lists, bold for key figures, no tables, roughly 450 words total."""


# ---------------------------------------------------------------------------
# Stored per-period insights (weeks and months), generated automatically
# ---------------------------------------------------------------------------
def month_start(d: date) -> date:
    return d.replace(day=1)


def prev_month(d: date) -> date:
    return (d.replace(day=1) - timedelta(days=1)).replace(day=1)


def next_month(d: date) -> date:
    return (d.replace(day=28) + timedelta(days=4)).replace(day=1)


def period_end(kind: str, start: date) -> date:
    return start + timedelta(days=6) if kind == "week" else next_month(start) - timedelta(days=1)


def build_month_stats(entries, today: date, month: date) -> dict:
    end = period_end("month", month)
    mine = [e for e in entries if month <= date.fromisoformat(e["date"]) <= end]

    def month_block(m):
        e = [x for x in entries if m <= date.fromisoformat(x["date"]) <= period_end("month", m)]
        cat, phase, proj, task = _split(e)
        return cat, phase, proj, task, e

    cat, phase, proj, task, _ = month_block(month)
    per_day = defaultdict(int)
    for e in mine:
        per_day[date.fromisoformat(e["date"])] += e["seconds"]
    wd = [0] * 7
    wd_days = [0] * 7          # how many such weekdays fall in the month
    d = month
    while d <= end:
        wd_days[d.weekday()] += 1
        d += timedelta(days=1)
    for day, sec in per_day.items():
        wd[day.weekday()] += sec
    weekly = defaultdict(int)
    for day, sec in per_day.items():
        weekly[week_start(day)] += sec

    first = min((date.fromisoformat(e["date"]) for e in entries), default=None)
    prev = []
    m = prev_month(month)
    for _ in range(5):
        if first is not None and period_end("month", m) >= first:
            prev.append(m)
        m = prev_month(m)

    def avg_block(months):
        if not months:
            return {"months_covered": 0}
        c = defaultdict(int); ph = defaultdict(int); pr = defaultdict(int)
        for mm in months:
            a, b, cc, _t, _e = month_block(mm)
            for k, v in a.items(): c[k] += v
            for k, v in b.items(): ph[k] += v
            for k, v in cc.items(): pr[k] += v
        n = len(months)
        return {"months_covered": n, "total_hours": _hours(sum(c.values()) / n),
                "by_category_hours": _avg(c, n), "video_phase_hours": _avg(ph, n), "by_project_hours": _avg(pr, n)}

    return {
        "today": today.isoformat(),
        "month": month.isoformat()[:7],
        "total_hours": _hours(sum(cat.values())),
        "by_category_hours": {k: _hours(v) for k, v in sorted(cat.items(), key=lambda kv: -kv[1])},
        "video_phase_hours": {k: _hours(v) for k, v in sorted(phase.items(), key=lambda kv: -kv[1])},
        "by_project_hours": {k: _hours(v) for k, v in sorted(proj.items(), key=lambda kv: -kv[1])},
        "top_tasks_hours": _top(task, 10),
        "days_with_time_tracked": len(per_day),
        "weekday_hours_total_in_month": {WEEKDAYS[i]: _hours(wd[i]) for i in range(7)},
        "weekday_average_hours_per_such_day": {WEEKDAYS[i]: _hours(wd[i] / max(wd_days[i], 1)) for i in range(7)},
        "weekly_hours_within_month": {w.isoformat(): _hours(v) for w, v in sorted(weekly.items())},
        "average_month_over_previous_up_to_3_months": avg_block(prev[:3]),
        "average_month_over_previous_up_to_5_months": avg_block(prev[:5]),
    }


def build_period_prompt(kind: str, stats: dict) -> str:
    import json
    if kind == "week":
        return build_prompt(stats)
    return f"""Below are time-tracking statistics for one calendar month, for the person who makes
videos for a Linux YouTube channel. The numbers were computed by the app and are exact;
do not recompute them, just interpret them. Hours are real tracked hours. Video phases are
guessed from subtask names. Time on a main task that has subtasks is counted through its
subtasks only. The "average month" blocks are per-month averages over earlier months
(months_covered says how many exist; if it is 0 or 1, say the baseline is thin instead of
over-reading it).

{GUIDELINES}

{json.dumps(stats, indent=1, ensure_ascii=False)}

Write the review in English, in markdown, using exactly these four "## " sections and
nothing before or after them:

## Where the month went
Split between video projects, other tasks and non-video tasks; the projects/tasks that
dominated; within videos, the split between scripts, recording, editing and
thumbnails/publishing.

## Compared with earlier months
This month against the previous-3-month and previous-5-month averages: what rose, fell or
was unusual, with hours and percentages.

## Rhythm
Which weekdays carried the most and least time, how even the weeks were (use the weekly
hours), and how many days had any tracked time.

## For next month
2 to 5 concrete recommendations for a more balanced week, each tied to a number above.

Keep it tight: short paragraphs and bullet lists, bold for key figures, no tables, roughly
350 words total."""


def generate_for_period(db, kind: str, start: date, call_claude, today: date | None = None) -> str:
    """Compute the stats for one week or month, ask Claude, store and return the text."""
    today = today or date.today()
    end = period_end(kind, start)
    first = (start - timedelta(weeks=LONG_WEEKS + 1)) if kind == "week" else start.replace(year=start.year - 1)
    entries = db.time_insight_entries(first.isoformat(), end.isoformat())
    if not any(start <= date.fromisoformat(e["date"]) <= end for e in entries):
        raise ValueError("Nothing was tracked in this period, so there is nothing to analyse.")
    if kind == "week":
        stats = build_stats(entries, today, week=start)
    else:
        stats = build_month_stats(entries, today, start)
    text = call_claude(build_period_prompt(kind, stats),
                       system="You are a calm, precise productivity analyst. Use only the numbers you are given.")
    db.save_time_insight(kind, start.isoformat(), text)
    return text


def due_periods(today: date):
    """Periods whose insights should exist by `today`: the week ending on a
    Sunday (generated that same Sunday), the latest completed week (catch-up if
    the app wasn't running), and the previous month (from the 1st onwards)."""
    this_week = week_start(today)
    out = []
    if today.weekday() == 6:
        out.append(("week", this_week))
    out.append(("week", this_week - timedelta(weeks=1)))
    out.append(("month", prev_month(today)))
    return out


_last_attempt: dict = {}


def run_due(db, call_claude, today: date | None = None, retry_after_seconds: int = 6 * 3600):
    """Generate whatever is due and missing. Safe to call repeatedly."""
    import time
    today = today or date.today()
    for kind, start in due_periods(today):
        key = (kind, start)
        if db.get_time_insight(kind, start.isoformat()):
            continue
        if time.time() - _last_attempt.get(key, 0) < retry_after_seconds:
            continue
        _last_attempt[key] = time.time()
        try:
            generate_for_period(db, kind, start, call_claude, today)
        except Exception as e:   # noqa: BLE001 - background job: never crash the server
            print(f"[insights] could not generate {kind} {start}: {e}", flush=True)


def start_scheduler(db, call_claude, check_every_seconds: int = 3600, first_delay: int = 45):
    """Background thread: checks shortly after start-up, then every hour."""
    import threading, time

    def loop():
        time.sleep(first_delay)
        while True:
            try:
                run_due(db, call_claude)
            except Exception as e:   # noqa: BLE001
                print(f"[insights] scheduler error: {e}", flush=True)
            time.sleep(check_every_seconds)

    t = threading.Thread(target=loop, name="insights-scheduler", daemon=True)
    t.start()
    return t
