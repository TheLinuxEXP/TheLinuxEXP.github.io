"""Finances > Revenue: what each client paid, the time spent on its tasks
(through the Sponsor tags, matched to client names) and the hourly rate.

Clients come from the invoices of the finance module (``tiers`` of the issued
invoices). A tag is matched to a client automatically from its name; the
person can override any match (stored in ``revenue_matches.json`` in the
app's data folder, keyed by tag id)."""
from __future__ import annotations

import difflib
import json
import re
import unicodedata
from datetime import date

from flask import abort, current_app, jsonify, request

from .database import data_dir

# words that say nothing about WHO the client is
_NOISE = {"inc", "llc", "ltd", "gmbh", "ag", "sas", "sarl", "sa", "co", "corp", "corporation", "company",
          "technologies", "technology", "tech", "computers", "computer", "media", "group", "the", "limited",
          "irlande", "ireland"}
# invoices that are not (yet) real: empty status or the unsorted inbox
_SKIP_STATUS = {"", "boite de reception", "boite de réception"}


def _fold(t: str) -> str:
    t = unicodedata.normalize("NFKD", t or "")
    return "".join(c for c in t if not unicodedata.combining(c)).lower()


def _tokens(t: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", _fold(t)) if w not in _NOISE]


def _squash(t: str) -> str:
    return "".join(_tokens(t))


def auto_match(tag_name: str, clients: list[str]) -> str | None:
    """The client whose name best fits the tag's name, or None."""
    tn, tsq = _tokens(tag_name), _squash(tag_name)
    if not tsq:
        return None
    best, best_score = None, 0.0
    for c in clients:
        csq = _squash(c)
        if not csq:
            continue
        if _fold(c).strip() == _fold(tag_name).strip():
            score = 1.0                         # the very same name
        elif csq == tsq:
            score = 0.97
        elif min(len(csq), len(tsq)) >= 4 and (csq in tsq or tsq in csq):
            score = 0.92
        else:
            score = difflib.SequenceMatcher(None, tsq, csq).ratio()
            shared = set(tn) & set(_tokens(c))
            if shared and any(len(w) >= 4 for w in shared):
                score = max(score, 0.9)
        if score > best_score:
            best, best_score = c, score
    return best if best_score >= 0.8 else None


def _matches_file():
    return data_dir() / "revenue_matches.json"


def _load_matches() -> dict:
    try:
        d = json.loads(_matches_file().read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_matches(m: dict):
    from .fsutil import atomic_write_text
    atomic_write_text(_matches_file(), json.dumps(m, ensure_ascii=False, indent=1))


def _sales():
    """(core module, issued invoices) of the finance module, or (None, [])."""
    try:
        from gestion_ei_web import adapter as ad
        data = ad.load()
        return ad.core, [r for r in data.get("sales", []) if isinstance(r, dict)]
    except Exception:
        return None, []


def _month_bounds(month: str):
    y, m = (int(x) for x in month.split("-"))
    first = date(y, m, 1)
    nxt = date(y + (m == 12), m % 12 + 1, 1)
    return first, nxt


def build(db, month: str, basis: str) -> dict:
    core, sales = _sales()
    first, nxt = _month_bounds(month)
    totals: dict[str, dict] = {}      # client -> {total, month}
    for r in sales:
        if _fold(str(r.get("statut", ""))).strip() in _SKIP_STATUS:
            continue
        name = (r.get("tiers") or "").strip()
        if not name:
            continue
        try:
            if basis == "cashed":
                raw = r.get("date_encaissement")
                if not raw:
                    continue
                d = date.fromisoformat(str(raw)[:10])
            else:
                d = core.effective_date(r) if core else date.fromisoformat(str(r["date"])[:10])
        except (ValueError, KeyError, TypeError):
            continue
        ht = float(r.get("ht") or 0)
        c = totals.setdefault(name, {"total": 0.0, "month": 0.0})
        c["total"] += ht
        if first <= d < nxt:
            c["month"] += ht
    clients = sorted(totals)

    tags = db.list_tags()
    all_secs = db.tag_time_seconds("0000-01-01", "9999-12-31")
    mon_secs = db.tag_time_seconds(first.isoformat(), date.fromordinal(nxt.toordinal() - 1).isoformat())
    manual = _load_matches()

    rows = {c: {"client": c, "total": round(totals[c]["total"], 2), "month": round(totals[c]["month"], 2),
                "tags": [], "seconds_total": 0, "seconds_month": 0} for c in clients}
    tag_rows, unmatched = [], []
    for g in tags:
        tid = g["id"]
        if tid in manual:
            client, how = (manual[tid] or None), "manual"
        else:
            client, how = auto_match(g["name"], clients), "auto"
        if client is not None and client not in rows:
            client = None                       # the invoiced client vanished
        entry = {"id": tid, "name": g["name"], "color": g.get("color"), "client": client, "how": how if client or tid in manual else "none",
                 "seconds_total": all_secs.get(tid, 0), "seconds_month": mon_secs.get(tid, 0)}
        tag_rows.append(entry)
        if client is None:
            unmatched.append(entry)
        else:
            r = rows[client]
            r["tags"].append({"id": tid, "name": g["name"], "color": g.get("color"), "how": how})
            r["seconds_total"] += entry["seconds_total"]
            r["seconds_month"] += entry["seconds_month"]
    for r in rows.values():
        hrs = r["seconds_month"] / 3600
        r["rate_month"] = round(r["month"] / hrs, 2) if hrs > 0 and r["month"] > 0 else None
        hrs_t = r["seconds_total"] / 3600
        r["rate_total"] = round(r["total"] / hrs_t, 2) if hrs_t > 0 and r["total"] > 0 else None
    out = sorted(rows.values(), key=lambda r: (-r["month"], -r["total"], r["client"].lower()))
    return {"month": month, "basis": basis, "available": core is not None, "clients": out,
            "tags": tag_rows, "unmatched": unmatched, "client_names": clients}


def register(bp):
    @bp.get("/revenue")
    def revenue_get():
        month = request.args.get("month") or date.today().strftime("%Y-%m")
        if not re.fullmatch(r"\d{4}-\d{2}", month) or not 1 <= int(month[5:]) <= 12:
            abort(400, "Bad month")
        basis = "cashed" if request.args.get("basis") == "cashed" else "invoiced"
        return jsonify(build(current_app.db, month, basis))

    @bp.post("/revenue/match")
    def revenue_match():
        """{tag_id, client}: client = a name (manual match), "" (explicitly no
        client) or null (back to the automatic match)."""
        body = request.get_json(force=True) or {}
        tid = body.get("tag_id")
        if not any(t["id"] == tid for t in current_app.db.list_tags()):
            abort(404, "Unknown tag")
        m = _load_matches()
        if body.get("client") is None:
            m.pop(tid, None)
        else:
            m[tid] = str(body["client"])
        _save_matches(m)
        return jsonify({"ok": True})
