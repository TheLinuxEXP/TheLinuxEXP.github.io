"""« Generate Chapters » : lit les clips swoosh de la piste A2 de la timeline Resolve ouverte (script
swoosh_timestamps.py du dossier « Montage Resolve ») et écrit les horodatages dans la note d'une vidéo Weekly News :
  - section Timestamps : « <secondes> <titre> » (l'entrée Intro vaut toujours 0) ;
  - section Links      : « MM:SS <titre> » devant chaque sujet (les adresses en dessous ne bougent pas)."""
from __future__ import annotations
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .ai import AIError

_TS_HEAD = re.compile(r"^[\s\u200b\ufeff]*#{1,6}[\s\u200b\ufeff]*[\W_]*timestamps?\b.*$", re.I)
# "## Links", "Links:", "**Links**", "## 🔗 Links (sources)", with invisible characters the editor may have left in
_LINKS_HEAD = re.compile(r"^[\s\u200b\ufeff]*(?:#{1,6}[\s\u200b\ufeff]*[\W_]*links?\b.*|[\W_]*links?[\W_]*(?:\(.*\))?[\W_]*)$", re.I)
_ANY_HEAD = re.compile(r"^\s*#{1,6}\s")
_TS_ENTRY = re.compile(r"^\s*(\d+(?::\d{2}){0,2})\s+(\S.*?)\s*$")
_LEAD_TS = re.compile(r"^\s*\d{1,3}:\d{2}(?::\d{2})?\s+")
_TS_LABEL = re.compile(r"^\s*timestamps?\s*:?\s*$", re.I)
_URL = re.compile(r"^\s*(https?|file)://\S+\s*$", re.I)
_MMSS = re.compile(r"^\d+:\d{2}$")


def script_path() -> Path:
    env = os.environ.get("PLANNER_SWOOSH_SCRIPT")
    if env:
        return Path(env).expanduser()
    projects = Path(__file__).resolve().parents[3]          # .../Projects/Planner Unifié/webapp/app -> .../Projects
    return projects / "Montage Resolve" / "swoosh_timestamps.py"


def run_swoosh_script(timeout: int = 90, skip_with: str | None = None) -> list[str]:
    """Lance swoosh_timestamps.py et renvoie ses horodatages MM:SS (dans l'ordre). Rien n'est modifié dans Resolve."""
    sp = script_path()
    if not sp.is_file():
        raise AIError(f"Script introuvable : {sp}. (variable d'environnement PLANNER_SWOOSH_SCRIPT pour changer l'emplacement)")
    py = os.environ.get("PLANNER_SWOOSH_PYTHON") or shutil.which("python3") or sys.executable
    with tempfile.TemporaryDirectory() as tmp:
        try:
            cmd = [py, str(sp), "--out", os.devnull] + (["--skip-with", skip_with] if skip_with else [])
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=tmp)
        except subprocess.TimeoutExpired:
            raise AIError("Resolve n'a pas répondu à temps : vérifiez qu'il est ouvert avec la timeline à la page Edit.")
        except OSError as e:
            raise AIError(f"Impossible de lancer le script ({py}) : {e}")
    if p.returncode != 0:
        tail = (p.stderr.strip() or p.stdout.strip()).splitlines()
        raise AIError("Le script swoosh_timestamps a échoué : " + (tail[-1] if tail else f"code {p.returncode}"))
    stamps = [ln.strip() for ln in p.stdout.splitlines() if _MMSS.match(ln.strip())]
    if not stamps:
        raise AIError("Aucun clip « swoosh » trouvé sur la piste A2 de la timeline ouverte.")
    return stamps


def to_seconds(mmss: str) -> int:
    m, s = mmss.split(":")
    return int(m) * 60 + int(s)


def _region(lines, start_idx, stop):
    end = len(lines)
    for i in range(start_idx + 1, len(lines)):
        if stop(lines[i]):
            end = i
            break
    return start_idx + 1, end


def apply_chapters(text: str, stamps: list[str]):
    """Renvoie (nouveau texte, {"timestamps": [...lignes], "links": [...lignes]}). Lève AIError sans rien écrire si la note
    et les swoosh ne se correspondent pas (même nombre de sujets partout)."""
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = text.split("\n")
    lines = [ln[:-1] if ln.endswith("\r") else ln for ln in lines]

    ts_h = next((i for i, ln in enumerate(lines) if _TS_HEAD.match(ln)), None)
    if ts_h is None:
        raise AIError('La note n\'a pas de section « Timestamps ».')
    ts_a, ts_b = _region(lines, ts_h, lambda ln: bool(_ANY_HEAD.match(ln) or _LINKS_HEAD.match(ln)))
    ln_h = next((i for i, ln in enumerate(lines) if _LINKS_HEAD.match(ln)), None)
    if ln_h is None:
        raise AIError('La note n\'a pas de section « Links ».')
    ln_a, ln_b = _region(lines, ln_h, lambda ln: bool(_ANY_HEAD.match(ln)))

    # Entrées de Timestamps : « 111 Titre » (secondes devant le titre) ou, dans les notes plus récentes, le titre seul.
    # Un nombre en tête n'est un horodatage que si la plupart des entrées en ont un (sinon « 2026 fundraising... » serait coupé).
    ts_idx = [i for i in range(ts_a, ts_b) if lines[i].strip() and not _TS_LABEL.match(lines[i]) and not _URL.match(lines[i])]
    intro = [i for i in ts_idx if re.match(r"^\s*(\d+(:\d{2}){0,2}\s+)?intro\b", lines[i], re.I)]
    topics_ts = [i for i in ts_idx if i not in intro]
    numbered = sum(1 for i in topics_ts if _TS_ENTRY.match(lines[i]))
    with_numbers = bool(topics_ts) and numbered * 2 > len(topics_ts)

    def ts_title(i):
        m = _TS_ENTRY.match(lines[i])
        if i in intro:
            return re.sub(r"^\s*\d+(?::\d{2}){0,2}\s+", "", lines[i]).strip()
        return m.group(2) if (m and with_numbers) else lines[i].strip()
    links_idx = [i for i in range(ln_a, ln_b) if lines[i].strip() and not _URL.match(lines[i])]

    st = list(stamps)
    if len(st) == len(topics_ts) + 1 and to_seconds(st[0]) <= 5:      # un swoosh posé sur l'intro
        st = st[1:]
    if not (len(st) == len(topics_ts) == len(links_idx)):
        hint = ""
        if len(topics_ts) == len(links_idx):
            d = len(topics_ts) - len(st)
            hint = (f" Il manque {d} swoosh sur A2 (ou la note a {d} sujet(s) de trop)." if d > 0
                    else f" Il y a {-d} swoosh de trop sur A2 (ou il manque {-d} sujet(s) dans la note).")
        raise AIError(f"Les nombres ne correspondent pas : {len(st)} swoosh sur A2, {len(topics_ts)} sujet(s) dans Timestamps, "
                      f"{len(links_idx)} entrée(s) dans Links.{hint} Swoosh lus : {', '.join(stamps)}. La note n'a pas été modifiée.")

    out_ts, out_links = [], []
    for i in intro:
        lines[i] = f"0 {ts_title(i)}"
        out_ts.append(lines[i])
    for i, s in zip(topics_ts, st):
        lines[i] = f"{to_seconds(s)} {ts_title(i)}"
        out_ts.append(lines[i])
    for i, s in zip(links_idx, st):
        title = _LEAD_TS.sub("", lines[i]).strip()
        lines[i] = f"{s} {title}"
        out_links.append(lines[i])
    return nl.join(lines), {"timestamps": sorted(out_ts, key=lambda x: int(x.split()[0])), "links": out_links}


# -- « Generate Timestamps » (vidéo normale) : swoosh de A2 + text box de V1/V2/V3 -> section Timestamps de la note ----
_STAMP_LINE = re.compile(r"^(\d{1,3}:\d{2}(?::\d{2})?)(?:\s+(\S.*?))?\s*$")
_GENERATED = re.compile(r"^\s*\d{1,3}:\d{2}(?::\d{2})?(\s|$)")


def text_script_path() -> Path:
    env = os.environ.get("PLANNER_VIDEO_TIMESTAMPS_SCRIPT")
    return Path(env).expanduser() if env else script_path().with_name("video_timestamps.py")


def run_text_timestamps(timeout: int = 90):
    """Lance video_timestamps.py et renvoie ([(MM:SS, texte), ...], [avertissements]). Rien n'est modifié dans Resolve."""
    sp = text_script_path()
    if not sp.is_file():
        raise AIError(f"Script introuvable : {sp}. (variable d'environnement PLANNER_VIDEO_TIMESTAMPS_SCRIPT pour changer l'emplacement)")
    py = os.environ.get("PLANNER_SWOOSH_PYTHON") or shutil.which("python3") or sys.executable
    with tempfile.TemporaryDirectory() as tmp:
        try:
            p = subprocess.run([py, str(sp), "--out", os.devnull], capture_output=True, text=True, timeout=timeout, cwd=tmp)
        except subprocess.TimeoutExpired:
            raise AIError("Resolve n'a pas répondu à temps : vérifiez qu'il est ouvert avec la timeline à la page Edit.")
        except OSError as e:
            raise AIError(f"Impossible de lancer le script ({py}) : {e}")
    if p.returncode != 0:
        tail = (p.stderr.strip() or p.stdout.strip()).splitlines()
        raise AIError("Le script video_timestamps a échoué : " + (tail[-1] if tail else f"code {p.returncode}"))
    entries, warnings = [], []
    for ln in p.stdout.splitlines():
        m = _STAMP_LINE.match(ln.strip())
        if m:
            entries.append((m.group(1), m.group(2) or ""))
        elif ln.startswith("! "):
            warnings.append(ln[2:].strip())
    if not entries:
        raise AIError("Aucun clip « swoosh » trouvé sur la piste A2 de la timeline ouverte.")
    return entries, warnings


def apply_text_timestamps(text: str, entries):
    """Écrit « MM:SS texte » (un par swoosh) dans la section Timestamps de la note ; la section est créée en fin de note si
    elle n'existe pas. Les lignes « MM:SS … » d'un lancement précédent sont remplacées, tout autre contenu de la section est
    gardé. Renvoie (nouveau texte, lignes écrites, nombre d'anciennes lignes remplacées, section créée ?)."""
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = [ln[:-1] if ln.endswith("\r") else ln for ln in text.split("\n")]
    new = [f"{s} {t}".rstrip() for s, t in entries]
    ts_h = next((i for i, ln in enumerate(lines) if _TS_HEAD.match(ln)), None)
    if ts_h is None:
        while lines and not lines[-1].strip():
            lines.pop()
        lines += ([""] if lines else []) + ["## Timestamps", ""] + new
        return nl.join(lines) + nl, new, 0, True
    a, b = _region(lines, ts_h, lambda ln: bool(_ANY_HEAD.match(ln) or _LINKS_HEAD.match(ln)))
    region = lines[a:b]
    kept = [ln for ln in region if not _GENERATED.match(ln)]
    replaced = len(region) - len(kept)
    while kept and not kept[-1].strip():
        kept.pop()
    lead = [""] if (not kept and (not region or not region[0].strip())) else []
    block = lead + kept + new + ([""] if b < len(lines) else [])
    lines[a:b] = block
    return nl.join(lines), new, replaced, False


_SPONSOR = re.compile(r"^\s*(\d{1,3}:\d{2}(?::\d{2})?\s+)?sponsor\b", re.I)
_INTRO = re.compile(r"^\s*(\d{1,3}:\d{2}(?::\d{2})?\s+|\d+\s+)?intro\b", re.I)


def apply_video_timestamps(text: str, stamps: list[str]):
    """Note « -VIDEO » : met « MM:SS » devant chaque sujet de la section Timestamps (Intro = 00:00). Ici les lignes « Sponsor… »
    sont des sujets comme les autres (elles ont un swoosh). Renvoie (nouveau texte, lignes de Timestamps).
    Lève AIError, sans rien modifier, si le nombre de swoosh ne correspond pas au nombre de sujets."""
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = [ln[:-1] if ln.endswith("\r") else ln for ln in text.split("\n")]
    ts_h = next((i for i, ln in enumerate(lines) if _TS_HEAD.match(ln)), None)
    if ts_h is None:
        raise AIError('La note n\'a pas de section « Timestamps ».')
    ts_a, ts_b = _region(lines, ts_h, lambda ln: bool(_ANY_HEAD.match(ln) or _LINKS_HEAD.match(ln)))
    idx = [i for i in range(ts_a, ts_b) if lines[i].strip() and not _TS_LABEL.match(lines[i]) and not _URL.match(lines[i])]
    intro = [i for i in idx if _INTRO.match(lines[i])][:1]
    topics = [i for i in idx if i not in intro]                 # sponsors inclus
    st = list(stamps)
    if len(st) == len(topics) + 1 and st and to_seconds(st[0]) <= 5:          # un swoosh posé sur l'intro
        st = st[1:]
    if len(st) != len(topics):
        d = len(topics) - len(st)
        hint = (f" Il manque {d} swoosh sur A2 (ou la note a {d} sujet(s) de trop)." if d > 0
                else f" Il y a {-d} swoosh de trop sur A2 (ou il manque {-d} sujet(s) dans la note).")
        raise AIError(f"Les nombres ne correspondent pas : {len(st)} swoosh sur A2 (le dernier, sur « Outro new », est ignoré), "
                      f"{len(topics)} sujet(s) dans Timestamps (Intro exclue, sponsors inclus).{hint} "
                      f"Swoosh lus : {', '.join(stamps)}. La note n'a pas été modifiée.")
    for i in intro:
        m = re.match(r"^\s*(?:\d{1,3}:\d{2}(?::\d{2})?\s+|\d+\s+)?(intro\b.*)$", lines[i], re.I)
        lines[i] = "00:00 " + (m.group(1).strip() if m else "Intro")
    for i, s in zip(topics, st):
        lines[i] = f"{s} {_LEAD_TS.sub('', lines[i]).strip()}"
    region = [lines[i] for i in idx]
    return nl.join(lines), region


# -- chapters.json (format de PODCAST/E38/chapters.json) ---------------------
DEFAULT_PODCAST_DIR = "/run/media/nick/Video Stuff/Videos/Common/PODCAST"
CHAPTERS_VERSION = "1.2.0"


def podcast_dir() -> Path:
    return Path(os.environ.get("PLANNER_PODCAST_DIR") or DEFAULT_PODCAST_DIR).expanduser()


def latest_episode_dir(base=None) -> Path:
    """Dossier EXX au numéro le plus haut (comparaison numérique : E10 > E9)."""
    base = Path(base) if base else podcast_dir()
    if not base.is_dir():
        raise AIError(f"Dossier des podcasts introuvable (disque non monté ?) : {base}")
    best, best_n = None, -1
    for d in base.iterdir():
        m = re.fullmatch(r"[Ee](\d+)", d.name)
        if m and d.is_dir() and int(m.group(1)) > best_n:
            best, best_n = d, int(m.group(1))
    if best is None:
        raise AIError(f"Aucun dossier EXX dans {base}")
    return best


def build_chapters_json(timestamps: list[str]) -> str:
    """timestamps : lignes « secondes Titre » (Intro = 0 en premier)."""
    import json
    items = []
    for line in timestamps:
        m = re.match(r"\s*(\d+)\s+(.*\S)\s*$", line)
        if not m:
            raise AIError(f"Ligne de timestamp illisible pour chapters.json : {line!r}")
        items.append((int(m.group(1)), m.group(2)))
    out = ['{', f'  "version": {json.dumps(CHAPTERS_VERSION)},', '  "chapters": [']
    for i, (s, t) in enumerate(items):
        out.append('    { "startTime": %d, "title": %s }%s' % (s, json.dumps(t, ensure_ascii=False),
                                                              "," if i < len(items) - 1 else ""))
    out += ['  ]', '}']
    return "\n".join(out) + "\n"


def write_chapters_json(timestamps: list[str], base=None) -> Path:
    folder = latest_episode_dir(base)
    target = folder / "chapters.json"
    content = build_chapters_json(timestamps)
    if target.exists():                      # l'ancienne version est conservée
        shutil.copy2(target, folder / "chapters.json.bak")
    tmp = folder / f".chapters.json.tmp-{os.getpid()}"
    tmp.write_text(content, encoding="utf-8", newline="")
    os.replace(tmp, target)
    return target
