"""« Create Video Note » : copie la note de la tâche en « <nom>-VIDEO.md » (même dossier) et l'adapte à la vidéo."""
from __future__ import annotations
import os
import re
from pathlib import Path

from .ai import AIError
from .chapters import _TS_HEAD, _LINKS_HEAD, _ANY_HEAD, _TS_ENTRY, _TS_LABEL, _URL, _LEAD_TS, _region
from .notesfile import read_markdown_sections, read_note_text

_CONTENT_HEAD = re.compile(r"^\s*#{1,6}\s*content\s*$", re.I)
SNIPPETS_NAME = "sponsor snippets.md"
FIXED_SPONSOR = "Tuxedo"               # section des Snippets / sponsor ajouté à la fin de chaque vidéo
FIXED_SPONSOR_LINE = "Sponsor: Tuxedo Computers"


def find_snippets(root: Path) -> Path:
    """La note « Sponsor Snippets » du dossier des notes (la plus récemment modifiée s'il y en a plusieurs)."""
    found = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if not d.startswith(".") and d not in ("trash", "node_modules")]
        for fn in fns:
            if fn.lower() == SNIPPETS_NAME:
                found.append(Path(dp) / fn)
    if not found:
        raise AIError('Note « Sponsor Snippets » introuvable dans le dossier des notes.')
    return max(found, key=lambda p: p.stat().st_mtime)


def snippet_for(sections: dict, name: str):
    """Texte de la section dont le titre correspond à `name` (insensible à la casse, puis préfixe)."""
    n = name.strip().lower()
    cand = {k: v for k, v in sections.items() if k.strip().lower() != "sponsor snippets" and v.strip()}
    for k, v in cand.items():
        if k.strip().lower() == n:
            return k, v.strip()
    for k, v in cand.items():
        kl = k.strip().lower()
        if kl.startswith(n) or n.startswith(kl):
            return k, v.strip()
    return None


def build_video_note(text: str, tag_names: list[str], snippets_text_sections: dict):
    """Renvoie (nouveau texte, avertissements)."""
    warnings = []
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = [ln[:-1] if ln.endswith("\r") else ln for ln in text.split("\n")]

    ts_h = next((i for i, ln in enumerate(lines) if _TS_HEAD.match(ln)), None)
    if ts_h is None:
        raise AIError('La note n\'a pas de section « Timestamps ».')
    ts_a, ts_b = _region(lines, ts_h, lambda ln: bool(_ANY_HEAD.match(ln) or _LINKS_HEAD.match(ln)))
    ts_idx = [i for i in range(ts_a, ts_b) if lines[i].strip() and not _TS_LABEL.match(lines[i]) and not _URL.match(lines[i])]
    intro = next((i for i in ts_idx if re.match(r"^\s*(\d+(:\d{2}){0,2}\s+)?intro\b", lines[i], re.I)), None)
    if intro is None:
        raise AIError('Pas d\'entrée « Intro » dans la section Timestamps.')
    topics = [i for i in ts_idx if i != intro]
    numbered = sum(1 for i in topics if _TS_ENTRY.match(lines[i]))
    with_numbers = bool(topics) and numbered * 2 > len(topics)     # sinon « 2026 fundraising… » serait coupé

    # Links : repérés avant de toucher aux lignes
    ln_h = next((i for i, ln in enumerate(lines) if _LINKS_HEAD.match(ln)), None)
    link_idx = []
    if ln_h is not None:
        a, b = _region(lines, ln_h, lambda ln: bool(_ANY_HEAD.match(ln)))
        link_idx = [i for i in range(a, b) if lines[i].strip() and not _URL.match(lines[i])]

    # Content : mention du sponsor de la vidéo puis, juste après, celle de Tuxedo (au début de Content)
    main, main_tag = None, None
    for t in tag_names:
        if t.strip().lower().startswith(FIXED_SPONSOR.lower()):
            continue
        main = snippet_for(snippets_text_sections, t)
        if main:
            main_tag = t.strip()
            break
    tux = snippet_for(snippets_text_sections, FIXED_SPONSOR)
    if not main:
        warnings.append("Aucun tag de la tâche ne correspond à une section de « Sponsor Snippets » : mention du sponsor non ajoutée "
                        f"(tags : {', '.join(tag_names) or 'aucun'}).")
    if not tux:
        warnings.append("Section « Tuxedo » introuvable dans « Sponsor Snippets » : texte Tuxedo non ajouté.")

    sponsor_name = main_tag or next((t.strip() for t in tag_names if t.strip() and not t.strip().lower().startswith(FIXED_SPONSOR.lower())), "")
    last_ts = max(topics) if topics else intro
    new_intro = re.sub(r"^\s*\d+(?::\d{2}){0,2}\s+", "", lines[intro]).strip()
    edits = {intro: ["00:00 " + new_intro, ("Sponsor: " + sponsor_name) if sponsor_name else "Sponsor:"]}
    for i in topics:
        m = _TS_ENTRY.match(lines[i])
        edits[i] = [m.group(2) if (m and with_numbers) else lines[i].strip()]
    edits[last_ts] = edits[last_ts] + [FIXED_SPONSOR_LINE]
    for i in link_idx:
        edits[i] = [_LEAD_TS.sub("", lines[i]).strip()]

    out = []
    for i, ln in enumerate(lines):
        out.extend(edits.get(i, [ln]))
    lines = out

    head_txt = []
    for part in (main, tux):                  # sponsor de la vidéo, puis Tuxedo juste après
        if part:
            head_txt += [part[1], ""]
    ch = next((i for i, ln in enumerate(lines) if _CONTENT_HEAD.match(ln)), None)
    if ch is None:
        while lines and not lines[-1].strip():
            lines.pop()
        lines += ["", "## Content", ""] + head_txt
        while lines and not lines[-1].strip():
            lines.pop()
    elif head_txt:
        lines[ch + 1:ch + 1] = [""] + head_txt
    return nl.join(lines).rstrip("\r\n") + nl, warnings


def create_video_note(note_path: str, tag_names: list[str], notes_root: Path):
    p = Path(note_path).expanduser()
    if not p.is_file():
        raise AIError(f"Note liée introuvable sur le disque : {note_path}")
    dst = p.with_name(f"{p.stem}-VIDEO{p.suffix}")
    if dst.exists():
        raise AIError(f"La note « {dst.name} » existe déjà : elle n'a pas été écrasée.")
    sn = find_snippets(notes_root)
    sections, _ = read_markdown_sections(str(sn))
    new_text, warnings = build_video_note(read_note_text(p), tag_names, sections)
    tmp = dst.with_name(f".{dst.name}.tmp-{os.getpid()}")
    tmp.write_text(new_text, encoding="utf-8", newline="")
    os.replace(tmp, dst)
    return dst, warnings
