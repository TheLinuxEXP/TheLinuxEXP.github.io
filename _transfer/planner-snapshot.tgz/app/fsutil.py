"""Small file helpers shared by the modules that keep their own JSON state files."""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path


def atomic_write_text(path, text: str, mode: int | None = None) -> None:
    """Writes `text` so that `path` is always either the old file or the new one in full - never a half-written file
    (power cut, crash, two requests at once): a uniquely named temporary file next to it, flushed to disk, then renamed."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp-{os.getpid()}-{threading.get_ident()}-{time.monotonic_ns()}")
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o666 if mode is None else mode)
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
