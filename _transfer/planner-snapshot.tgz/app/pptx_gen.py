"""Generates a PowerPoint deck that visually matches an existing template
deck, for the "Create powerpoint" subtask's "Generate" AI button (currently
only on the Warhammer Video template).

Rather than building generic placeholder slides (which would look nothing
like a real, designed deck), this clones the actual XML of a representative
slide from the template -- keeping its exact fonts, colors, positioning and
any decorative picture -- once per generated slide, and only swaps in the
new title/bullet text. The template's own original slides are then dropped
from the saved output, leaving just the newly generated ones.

Requires the `python-pptx` package (pip install python-pptx), which is not
a hard dependency of the rest of the app -- see requirements.txt.
"""
from __future__ import annotations
import copy
from collections import Counter
from pathlib import Path

from .ai import AIError

# One level above the webapp/ directory this file lives under (app/ ->
# webapp/ -> the Video Planner project root), where the style-reference
# deck is expected to live.
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

MAX_SLIDES = 200


def _pptx_module():
    try:
        import pptx  # noqa: F401
    except ImportError:
        raise AIError(
            "The 'python-pptx' package isn't installed. Run: pip install python-pptx"
        )
    return pptx


def find_template_path() -> Path:
    """The existing deck named "presentation" (any case, .pptx preferred) that new decks should visually match: the file
    given by TASKPLANNER_PPTX_TEMPLATE, else one at the project root, else one in the old "OLD-Video Planner" folder
    next to it (or in webapp/)."""
    import os
    env = os.environ.get("TASKPLANNER_PPTX_TEMPLATE")
    if env and Path(env).expanduser().is_file():
        return Path(env).expanduser()
    folders = [PROJECT_ROOT, PROJECT_ROOT / "webapp", PROJECT_ROOT.parent / "OLD-Video Planner"]
    for folder in folders:
        candidates = sorted(folder.glob("[Pp]resentation.*"))
        pptx_candidates = [c for c in candidates if c.suffix.lower() == ".pptx"]
        if pptx_candidates:
            return pptx_candidates[0]
    for folder in folders:
        candidates = sorted(folder.glob("[Pp]resentation.*"))
        if candidates:
            return candidates[0]
    raise AIError(
        f'No "presentation.pptx" file found at the Video Planner project root '
        f"({PROJECT_ROOT}). Add one there (or set TASKPLANNER_PPTX_TEMPLATE) to use as the style basis for generated slides."
    )


def _slide_signatures(prs):
    """{shape-type signature: [slide indices]}, plus a Counter of how often
    each signature occurs -- used to find the deck's "normal content slide"
    layout (the most common one) versus its one-off cover slide."""
    sigs, counter = {}, Counter()
    for i, slide in enumerate(prs.slides):
        kinds = tuple(str(s.shape_type) for s in slide.shapes)
        counter[kinds] += 1
        sigs.setdefault(kinds, []).append(i)
    return sigs, counter


def _pick_slide_indices(prs):
    """(cover_index_or_None, content_index) -- the content index is the most
    common slide "shape signature" in the deck (excluding index 0, which is
    usually a distinct cover slide); the cover index is 0 if it has its own,
    different signature from the content slides, else None."""
    sigs, counter = _slide_signatures(prs)
    if not counter:
        raise AIError("The template presentation has no slides to copy the style from.")
    non_cover = {k: v for k, v in sigs.items() if v != [0]}
    best_sig = max(non_cover or sigs, key=lambda k: len(non_cover.get(k, sigs[k])))
    content_candidates = [i for i in sigs[best_sig] if i != 0] or sigs[best_sig]
    content_idx = content_candidates[0]
    cover_idx = 0 if 0 not in sigs[best_sig] else None
    return cover_idx, content_idx


def _clone_slide(prs, idx):
    from pptx.oxml.ns import qn
    from pptx.opc.constants import RELATIONSHIP_TYPE as RT

    source = prs.slides[idx]
    dest = prs.slides.add_slide(source.slide_layout)
    # The template's slides hide the master's decorative shapes
    # (showMasterSp="0") so the plain dark background shows; keep that, or the
    # master's big light-grey shapes appear behind everything.
    for attr in ("showMasterSp", "showMasterPhAnim"):
        if source._element.get(attr) is not None:
            dest._element.set(attr, source._element.get(attr))
    for shp in list(dest.shapes):
        shp._element.getparent().remove(shp._element)
    for shp in source.shapes:
        new_el = copy.deepcopy(shp._element)
        dest.shapes._spTree.append(new_el)
        # Pictures reference their image via a relationship id scoped to the
        # source slide part -- re-point each copied blip at a new
        # relationship on the destination slide part (same underlying image).
        for blip in new_el.findall(".//" + qn("a:blip")):
            old_rid = blip.get(qn("r:embed"))
            if not old_rid:
                continue
            image_part = source.part.related_part(old_rid)
            new_rid = dest.part.relate_to(image_part, RT.IMAGE)
            blip.set(qn("r:embed"), new_rid)
    return dest


def _text_boxes(slide):
    return [s for s in slide.shapes if s.has_text_frame and s.shape_type is not None
            and s.shape_type.name == "TEXT_BOX"]


def _set_lines_matching_style(text_frame, lines):
    """Replace a text frame's content with `lines` (one per paragraph),
    reusing the formatting (font, size, bold, color) of its first existing
    run for every line, so generated text keeps the template's exact look
    instead of falling back to generic default formatting."""
    from pptx.oxml.ns import qn
    from pptx.oxml.xmlchemy import OxmlElement

    if not lines:
        lines = [""]
    paragraphs = list(text_frame.paragraphs)
    base_p = paragraphs[0]
    if not base_p.runs:
        base_p.text = ""
    template_run_el = copy.deepcopy(base_p.runs[0]._r)
    base_el = base_p._p

    empty_shell = copy.deepcopy(base_el)
    for r_el in empty_shell.findall(qn("a:r")):
        empty_shell.remove(r_el)

    for p in paragraphs[1:]:
        p._p.getparent().remove(p._p)
    for r_el in base_el.findall(qn("a:r")):
        base_el.remove(r_el)

    prev_el = base_el
    for i, line in enumerate(lines):
        p_el = base_el if i == 0 else copy.deepcopy(empty_shell)
        if i > 0:
            prev_el.addnext(p_el)
            prev_el = p_el
        run_el = copy.deepcopy(template_run_el)
        t_el = run_el.find(qn("a:t"))
        if t_el is None:
            t_el = OxmlElement("a:t")
            run_el.append(t_el)
        t_el.text = line
        p_el.append(run_el)


def _delete_slide(prs, slide):
    from pptx.oxml.ns import qn
    xml_slides = prs.slides._sldIdLst
    for sldId in list(xml_slides):
        rid = sldId.get(qn("r:id"))
        if prs.part.related_part(rid) is slide.part:
            prs.part.drop_rel(rid)
            xml_slides.remove(sldId)
            return


def _place_datasheets(prs, slide, boxes, item, paths):
    """Swap the template's decorative picture for cropped datasheet images,
    fitted (aspect ratio kept) into the free area: right of the bullets, or
    the whole slide body when the slide has no bullets."""
    from PIL import Image

    for shp in list(slide.shapes):
        if shp.shape_type is not None and shp.shape_type.name == "PICTURE":
            shp._element.getparent().remove(shp._element)
    top, bottom, margin = 868680, prs.slide_height - 150000, 250000
    if item.get("bullets"):
        left = 6300000
        if len(boxes) >= 2:   # keep bullets clear of the pictures
            boxes[1].width = min(boxes[1].width, left - boxes[1].left - 100000)
    else:
        left = margin
        if len(boxes) >= 2:
            boxes[1]._element.getparent().remove(boxes[1]._element)
    right = prs.slide_width - margin
    gap = 150000
    n = len(paths)
    cell_w = (right - left - gap * (n - 1)) // n
    cell_h = bottom - top
    for i, path in enumerate(paths):
        with Image.open(path) as im:
            iw, ih = im.size
        scale = min(cell_w / iw, cell_h / ih)
        w, h = int(iw * scale), int(ih * scale)
        x = left + i * (cell_w + gap) + (cell_w - w) // 2
        y = top + (cell_h - h) // 2
        slide.shapes.add_picture(str(path), x, y, w, h)


def build_presentation(plan: list[dict], output_path: Path, deck_title: str | None = None) -> int:
    """plan: [{"title": str, "bullets": [str, ...], "datasheet_paths": [Path, ...]?}, ...]. Builds a new deck
    at output_path, styled after find_template_path(), containing one cover
    slide (if the template has a distinct one, titled `deck_title`) plus one
    cloned content slide per plan entry. Returns the number of slides
    written. Raises AIError on any problem."""
    _pptx_module()
    from pptx import Presentation

    if not plan:
        raise AIError("Nothing to put in the presentation -- the generated slide plan was empty.")
    plan = plan[:MAX_SLIDES]

    prs = Presentation(str(find_template_path()))
    cover_idx, content_idx = _pick_slide_indices(prs)
    original_slides = list(prs.slides)

    new_slides = []   # no cover slide: every slide is a content slide on the dark background

    for item in plan:
        dest = _clone_slide(prs, content_idx)
        boxes = _text_boxes(dest)
        if len(boxes) >= 2:
            _set_lines_matching_style(boxes[0].text_frame, [item.get("title") or ""])
            _set_lines_matching_style(boxes[1].text_frame, item.get("bullets") or [])
        elif boxes:
            _set_lines_matching_style(boxes[0].text_frame, [item.get("title") or ""])
        if item.get("datasheet_paths"):
            _place_datasheets(prs, dest, boxes, item, item["datasheet_paths"][:2])
        new_slides.append(dest)

    for s in original_slides:
        _delete_slide(prs, s)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(output_path))
    return len(new_slides)


# ---------------------------------------------------------------------------
# Picture-per-slide decks (Warhammer PDF blocks): title, French recap on the
# left in the deck's own text styles, one picture on the right.
# ---------------------------------------------------------------------------
def template_text_samples(max_chars: int = 3500, max_slides: int = 7) -> str:
    """A few existing slides' text from the template deck, so the AI can copy
    the person's tone."""
    _pptx_module()
    from pptx import Presentation
    try:
        prs = Presentation(str(find_template_path()))
    except AIError:
        return "(aucun exemple disponible)"
    chunks = []
    for slide in prs.slides:
        boxes = _text_boxes(slide)
        if len(boxes) < 2:
            continue
        title = boxes[0].text_frame.text.strip()
        body = "\n".join(p.text.strip() for p in boxes[1].text_frame.paragraphs if p.text.strip())
        if len(body) < 60:
            continue
        chunks.append(f"[{title}]\n{body}")
        if len(chunks) >= max_slides:
            break
    return "\n\n".join(chunks)[:max_chars] or "(aucun exemple disponible)"


def _para_kind(p):
    from pptx.oxml.ns import qn
    pPr = p._p.find(qn("a:pPr"))
    lvl = int(pPr.get("lvl", "0")) if pPr is not None else 0
    has_bullet = pPr is not None and pPr.find(qn("a:buChar")) is not None
    return lvl, has_bullet


def _collect_protos(prs):
    """Heading / bullet / sub-bullet paragraph prototypes taken from the
    template deck's own text boxes (any slide that has them)."""
    from pptx.oxml.ns import qn
    found = {}
    for slide in prs.slides:
        for box in _text_boxes(slide):
            for p in box.text_frame.paragraphs:
                if not p.runs or not p.text.strip():
                    continue
                lvl, has_bullet = _para_kind(p)
                key = ("--" if lvl >= 3 else "-") if has_bullet else "#"
                found.setdefault(key, p._p)
    anyp = next(iter(found.values()), None)
    if anyp is None:
        raise AIError("The template presentation has no text to copy the style from.")
    protos = {k: copy.deepcopy(found.get(k, found.get("-", found.get("#", anyp)))) for k in ("#", "-", "--")}
    if "--" not in found and "-" in found:
        pPr = protos["--"].find(qn("a:pPr"))
        if pPr is not None and pPr.get("marL"):
            pPr.set("marL", str(int(pPr.get("marL")) + 400000))
    run_protos = {}
    for k, p_el in protos.items():
        r = p_el.find(qn("a:r"))
        run_protos[k] = copy.deepcopy(r if r is not None else next(iter(protos.values())).find(qn("a:r")))
    return protos, run_protos


def _fill_rich_text(text_frame, lines, protos_pair, max_size_pt=16):
    """lines use '# ' (bold heading), '- ' (bullet), '-- ' (sub-bullet), ''
    (blank). Each paragraph is cloned from the matching paragraph of the
    template's own text so bullets, indents, fonts and spacing are identical."""
    import math
    from pptx.oxml.ns import qn

    paras = list(text_frame.paragraphs)
    protos, run_protos = protos_pair

    parsed = []
    for raw in lines:
        raw = str(raw).rstrip()
        if raw.startswith("--"):
            parsed.append(("--", raw[2:].strip()))
        elif raw.startswith("-"):
            parsed.append(("-", raw[1:].strip()))
        elif raw.startswith("#"):
            parsed.append(("#", raw[1:].strip()))
        elif raw.strip():
            parsed.append(("-", raw.strip()))
        else:
            parsed.append(("", ""))
    while parsed and not parsed[-1][1]:
        parsed.pop()

    # shrink the font as the text gets longer, so it stays inside the slide
    size = max_size_pt
    for size in (max_size_pt, 14, 13, 12, 11, 10):
        chars = max(14, int(356 / (0.55 * size)))
        total = sum(1 if not t else math.ceil((len(t) + 2) / (chars - (4 if k == "--" else 0))) for k, t in parsed)
        if total * size * 1.5 <= 440:
            break

    body = text_frame._txBody
    for p in paras:
        body.remove(p._p)
    for kind, text in parsed:
        base = protos["#" if kind == "" else kind]
        p_el = copy.deepcopy(base)
        for child in list(p_el):
            if child.tag in (qn("a:r"), qn("a:br"), qn("a:fld")):
                p_el.remove(child)
        if kind:
            r_el = copy.deepcopy(run_protos[kind])
            r_el.find(qn("a:t")).text = text
            end = p_el.find(qn("a:endParaRPr"))
            if end is not None:
                end.addprevious(r_el)
            else:
                p_el.append(r_el)
        for rpr in list(p_el.iter(qn("a:rPr"))) + list(p_el.iter(qn("a:endParaRPr"))):
            rpr.set("sz", str(int(size * 100)))
        body.append(p_el)


def _place_picture(prs, slide, boxes, image_path):
    from PIL import Image
    for shp in list(slide.shapes):
        if shp.shape_type is not None and shp.shape_type.name == "PICTURE":
            shp._element.getparent().remove(shp._element)
    top, bottom, right = 868680, prs.slide_height - 150000, prs.slide_width - 250000
    left = 5650000
    if len(boxes) >= 2:
        boxes[1].width = min(boxes[1].width, left - boxes[1].left - 100000)
    with Image.open(image_path) as im:
        iw, ih = im.size
    scale = min((right - left) / iw, (bottom - top) / ih)
    w, h = int(iw * scale), int(ih * scale)
    x = left + (right - left - w) // 2
    y = top + (bottom - top - h) // 2
    slide.shapes.add_picture(str(image_path), x, y, w, h)


def build_picture_deck(slides: list[dict], output_path: Path) -> int:
    """slides: [{"title": str, "lines": [str, ...], "image": Path}, ...] ->
    one slide each, cloned from the template's regular content slide (dark
    background, same fonts/positions). No cover slide."""
    _pptx_module()
    from pptx import Presentation

    if not slides:
        raise AIError("Nothing to put in the presentation.")
    prs = Presentation(str(find_template_path()))
    _, content_idx = _pick_slide_indices(prs)
    original = list(prs.slides)
    protos_pair = _collect_protos(prs)
    count = 0
    for item in slides[:MAX_SLIDES]:
        dest = _clone_slide(prs, content_idx)
        boxes = _text_boxes(dest)
        if boxes:
            title = (item.get("title") or "").upper()
            _set_lines_matching_style(boxes[0].text_frame, [title])
            if len(title) > 26:     # long names must stay on one line, whatever the font actually used
                from pptx.oxml.ns import qn as _qn
                size = max(2000, int(3600 * 26 / len(title)))
                for rpr in boxes[0].text_frame._txBody.iter(_qn("a:rPr")):
                    rpr.set("sz", str(size))
        if len(boxes) >= 2:
            _fill_rich_text(boxes[1].text_frame, item.get("lines") or [], protos_pair)
        _place_picture(prs, dest, boxes, item["image"])
        count += 1
    for s in original:
        _delete_slide(prs, s)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(output_path))
    return count
