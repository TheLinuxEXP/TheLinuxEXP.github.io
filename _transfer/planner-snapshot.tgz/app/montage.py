"""Boutons « Take Captures » et « Base edit » : lancent news_capture.py / resolve_build_news.py (dossier « Montage Resolve »)."""
from __future__ import annotations
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .ai import AIError
from .chapters import script_path


def scripts_dir() -> Path:
    return script_path().parent


def captures_dir(note: Path) -> Path:
    """Dossier des captures d'une note « -VIDEO » (plan.json + PNG)."""
    base = Path(os.environ.get("PLANNER_CAPTURES_DIR") or (scripts_dir() / "captures")).expanduser()
    return base / note.stem


def _candidates():
    seen, out = set(), []
    for c in (os.environ.get("PLANNER_CAPTURE_PYTHON"), os.environ.get("PLANNER_SWOOSH_PYTHON"), "/usr/bin/python3",
              "/usr/local/bin/python3", shutil.which("python3"), sys.executable):
        if c and c not in seen and Path(c).exists():
            seen.add(c)
            out.append(c)
    return out


def _python(module=None):
    """Interpréteur à utiliser. Avec `module`, le premier qui sait l'importer (le Planner tourne souvent dans un
    environnement virtuel qui n'a pas Playwright, alors que le python3 du système l'a)."""
    cands = _candidates()
    if not module:
        return cands[0] if cands else sys.executable
    for c in cands:
        try:
            if subprocess.run([c, "-c", f"import {module}"], capture_output=True, timeout=30).returncode == 0:
                return c
        except (OSError, subprocess.TimeoutExpired):
            continue
    py = cands[0] if cands else "python3"
    raise AIError(f"The Python module “{module}” is not installed for any of these interpreters: {', '.join(cands) or 'none found'}.\n"
                  f"Install it with:  {py} -m pip install playwright && {py} -m playwright install chromium\n"
                  "(add --break-system-packages to pip if it refuses), or point PLANNER_CAPTURE_PYTHON to a Python that has it.")


def _kill_group(proc):
    """Arrête le script et tout ce qu'il a lancé (Chrome compris)."""
    if os.name != "posix":
        try:
            proc.kill()
        except OSError:
            pass
        return
    try:
        import signal
        os.killpg(proc.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError, OSError):
        pass


def _run(script: str, args: list[str], timeout: int, module=None):
    sp = scripts_dir() / script
    if not sp.is_file():
        raise AIError(f"Script not found: {sp}")
    with tempfile.TemporaryDirectory() as tmp:
        # Le script tourne dans son propre groupe de processus : à la fin (ou au délai dépassé) tout le groupe est arrêté,
        # ce qui ferme aussi les Chrome lancés par Playwright s'il en reste.
        kw = {"start_new_session": True} if os.name == "posix" else {}
        fo, fe = Path(tmp) / "out.txt", Path(tmp) / "err.txt"          # fichiers (pas de tubes) : un Chrome resté ouvert ne bloque pas la lecture
        with open(fo, "w", encoding="utf-8") as so, open(fe, "w", encoding="utf-8") as se:
            try:
                proc = subprocess.Popen([_python(module), str(sp), *args], stdout=so, stderr=se, text=True, cwd=tmp, **kw)
            except OSError as e:
                raise AIError(f"Could not start {script}: {e}")
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                _kill_group(proc)
                proc.wait()
                raise AIError(f"{script} took too long and was stopped.")
            finally:
                _kill_group(proc)
        p = subprocess.CompletedProcess(proc.args, proc.returncode, fo.read_text(encoding="utf-8", errors="replace"),
                                        fe.read_text(encoding="utf-8", errors="replace"))
    return p


def _tail(p):
    lines = (p.stderr.strip() or p.stdout.strip()).splitlines()
    return lines[-1] if lines else f"exit code {p.returncode}"


def clear_captures(out: Path) -> int:
    """Efface les captures précédentes de cette vidéo (PNG, plan.json, journal, copies d'import) dans son dossier."""
    if not out.is_dir():
        return 0
    n = 0
    for f in list(out.glob("*.png")) + [out / "plan.json", out / "build_report.txt"]:
        try:
            if f.is_file():
                f.unlink()
                n += 1
        except OSError:
            pass
    imp = out / "_resolve_import"
    if imp.is_dir():
        n += sum(1 for _ in imp.glob("*"))
        shutil.rmtree(imp, ignore_errors=True)
    return n


def take_captures(note_path: str, timeout: int = 3600):
    note = Path(note_path).expanduser()
    if not note.is_file():
        raise AIError(f"The video note was not found on disk: {note}")
    out = captures_dir(note)
    cleared = clear_captures(out)
    shutil.rmtree(out / "_agent", ignore_errors=True)
    p = _run("news_capture.py", [str(note), str(out)], timeout, module="playwright")
    if p.returncode != 0:
        raise AIError("The capture script failed: " + _tail(p))
    agent_lines = _review_with_agent(note, out, timeout)
    fails = re.findall(r"^FAIL\s+(.*)$", p.stdout, re.M)
    ok = len(re.findall(r"^OK\s", p.stdout, re.M))
    msg = f"**Captures finished.**\n\n{ok} page(s) captured" + (f", {len(fails)} failed" if fails else "") + f".\n\nFolder: `{out}`" + (f" ({cleared} previous file(s) removed)" if cleared else "")
    if fails:
        msg += "\n\nFailed:\n" + "\n".join(f"- {f}" for f in fails)
    if agent_lines:
        msg += "\n\n" + "\n".join(agent_lines)
    # Nothing captured and nothing failed = the script found no link to open: say which topics have none and why
    try:
        topics = json.loads((out / "plan.json").read_text(encoding="utf-8")).get("topics", [])
    except (OSError, ValueError):
        topics = []
    # intro and sponsors have nothing to capture: only the other topics without a link are worth reporting
    nolink = [t for t in topics if not t.get("links") and not re.match(r"\s*(intro|sponsor)", t.get("title") or "", re.I)]
    if nolink or (topics and ok == 0):
        msg += (f"\n\n**{len(nolink)} topic(s) without any link (nothing captured for them):**" if nolink
                else f"\n\n**{len(topics)} topic(s) found, but none has a link.**")
        msg += "\n" + "\n".join(f"- {t.get('title')}" for t in nolink[:30])
        msg += ("\n\nLinks are read under the “Links” heading: a title line followed by its `https://…` URL(s). "
                "A group is matched to a topic by time, by identical title, or by order.")
    return msg


def _review_with_agent(note: Path, out: Path, timeout: int) -> list[str]:
    """The capture agent (capture_agent.py) re-reads the flagged captures and fixes them. Never fatal: whatever goes wrong,
    the captures the script made stay, and the report says so."""
    from . import capture_agent
    if capture_agent.mode() == "off":
        return []
    try:
        plan = json.loads((out / "plan.json").read_text(encoding="utf-8"))

        def run_step(sf):
            r = _run("news_capture.py", [str(note), str(out), "--agent-step", str(sf)], max(600, timeout // 2), module="playwright")
            if r.returncode != 0:
                raise AIError("agent step failed: " + _tail(r))

        lines = capture_agent.run(str(note), out, plan, run_step)
        if lines and any("fixed" in ln for ln in lines):         # files changed: rebuild plan.json from the PNGs on disk
            _run("news_capture.py", [str(note), str(out), "--rescan"], 300)
        return lines
    except (AIError, OSError, ValueError) as e:
        return [f"**Capture agent:** not run ({str(e)[:200]}). The captures above are the script's own."]


def base_edit(note_path: str, timeout: int = 1800):
    note = Path(note_path).expanduser()
    plan = captures_dir(note) / "plan.json"
    if not plan.is_file():
        raise AIError("No captures found for this video note — run “Take Captures” first.")
    # Captures taken before the note had its times (Generate Chapters / Timestamps): re-read the note's times and keep the
    # captures already on disk (--rescan), instead of making the person redo every capture
    try:
        untimed = any(t.get("untimed") for t in json.loads(plan.read_text(encoding="utf-8")).get("topics", []))
    except (OSError, ValueError):
        untimed = False
    if untimed:
        r = _run("news_capture.py", [str(note), str(plan.parent), "--rescan"], 300)
        if r.returncode != 0:
            raise AIError("Could not refresh the plan from the note: " + _tail(r))
    p = _run("resolve_build_news.py", ["--plan", str(plan)], timeout)
    if p.returncode != 0:
        raise AIError("The editing script failed: " + _tail(p))
