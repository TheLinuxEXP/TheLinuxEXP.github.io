"use strict";

// Dev restart and desktop-widget coordination.

/* ---------------------------------------------------------------------- *
 * Dev convenience: restart the Python process in place, then reload once
 * it's back up, so a code push doesn't require Ctrl+C / rerun by hand.
 * ---------------------------------------------------------------------- */
function formatBytes(n) {
  if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + " MB";
  if (n >= 1024) return Math.round(n / 1024) + " KB";
  return n + " B";
}

// "Clean up": deletes the generated files (PowerPoint decks made by the
// Generate button + the images cropped from PDFs) to free disk space.
function wireCleanup() {
  document.getElementById("cleanupBtn").addEventListener("click", async () => {
    const info = await api.get("/api/cleanup");
    if (!info.files) { showToast("Nothing to clean up"); return; }
    if (!(await confirmModal({
      title: "Clean up generated files?",
      message: `${info.files} files, ${formatBytes(info.bytes)} will be deleted: the PowerPoint decks made by the Generate button and the images cropped from PDFs. `
        + "Your tasks, attachments and backups are not touched, and a deck can be generated again later.",
      confirmLabel: "Delete files", danger: true,
    }))) return;
    const done = await api.post("/api/cleanup", {});
    showToast(`Freed ${formatBytes(done.bytes)} (${done.files} files)`);
  });
}

function wireUtilities() {
  const toggle = document.getElementById("utilitiesToggle");
  const menu = document.getElementById("utilitiesList");
  // monochrome icons for the static Utilities entries
  document.querySelectorAll("[data-sym]").forEach((n) => { if (!n.querySelector("svg")) n.replaceWith(symbolicIcon(n.dataset.sym)); });
  // The gear in the header opens the menu (always closed when the page loads). It animates in and out through the
  // `.open` class; a click anywhere else, Escape, or a choice in the menu closes it.
  const setOpen = (open) => {
    menu.classList.toggle("open", open);
    toggle.classList.toggle("active", open);
    toggle.setAttribute("aria-expanded", String(open));
    menu.setAttribute("aria-hidden", String(!open));
  };
  closeUtilitiesMenu = () => setOpen(false);
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
    const willOpen = !menu.classList.contains("open");
    closeDropdowns();
    setOpen(willOpen);
  });
  menu.addEventListener("click", (e) => { e.stopPropagation(); if (e.target.closest(".row-item")) setOpen(false); });
  document.addEventListener("click", () => setOpen(false));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && menu.classList.contains("open")) { setOpen(false); toggle.focus(); } });
}
let closeUtilitiesMenu = () => {};

function wireBackups() {
  document.getElementById("backupsBtn").addEventListener("click", openBackupsView);
}

function wireReloadServer() {
  document.getElementById("reloadServerBtn").addEventListener("click", async () => {
    showToast("Restarting server…");
    try {
      await api.post("/api/restart", {});
    } catch (e) {
      // the restart itself may tear the connection down before the response
      // finishes — that's expected, not a failure.
    }
    let attempts = 0;
    const poll = setInterval(async () => {
      attempts += 1;
      try {
        const r = await fetch("/", { cache: "no-store" });
        if (r.ok) { clearInterval(poll); window.location.reload(); }
      } catch (e) {
        // still restarting
      }
      if (attempts > 40) clearInterval(poll); // ~20s: give up quietly
    }, 500);
  });
}

/* ---------------------------------------------------------------------- *
 * Desktop-widget coordination: lets the KDE Plasma "Today" widget reuse this
 * tab instead of always opening a new one. While this tab is loaded, it
 * pings the server every few seconds so the widget can tell a tab is alive;
 * it also polls for a "pending" task id the widget may have left (clicked
 * from the widget while this tab was already open) and jumps to it, pulling
 * itself to the front. A #task=<id> in the URL on load is the fallback path
 * for when the widget had to open a brand-new tab.
 * ---------------------------------------------------------------------- */
function wireDesktopWidgetBridge() {
  // One periodic call: the heartbeat ("a tab is open", used by the widget to decide whether to reuse this tab) also returns
  // the task the widget asked to open, if any. Every 2 s while the page is in front, every 5 s in the background.
  // no-store: it must always hit the server, never a cached response, or the widget's "is a tab open?" check goes stale.
  const beat = async () => {
    try {
      const r = await fetch("/api/tab/heartbeat", { method: "POST", cache: "no-store" });
      if (r.ok) {
        const data = await r.json();
        if (data && data.task_id) {
          window.focus();
          console.info("planner-app:raise");   // the KDE window (kde-app/) listens for this to come to the front
          openTaskDetail(data.task_id);
        }
      }
    } catch (e) {
      // server hiccup -- try again on the next tick
    }
    setTimeout(beat, document.hidden ? 5000 : 2000);
  };
  beat();

  const m = /#task=([\w-]+)/.exec(window.location.hash);
  if (m) {
    history.replaceState(null, "", window.location.pathname + window.location.search);
    openTaskDetail(m[1]);
  }
}
