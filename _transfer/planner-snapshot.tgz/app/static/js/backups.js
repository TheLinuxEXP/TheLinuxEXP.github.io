"use strict";

// Backups view.

/* ---------------------------------------------------------------------- *
 * Backups — a backup of the whole database is written automatically after
 * every task/subtask change, creation, completion or deletion. Pick one to
 * see how it differs from the current data, and restore it if wanted.
 * ---------------------------------------------------------------------- */
async function openBackupsView() {
  state.view = { type: "backups", title: "Backups" };
  state.backups.selected = null;
  state.backups.diff = null;
  state.backups.list = await api.get("/api/backups");
  renderMain();
  renderSidebar();
}

async function selectBackup(id) {
  state.backups.selected = id;
  state.backups.diff = null;
  state.backups.loading = true;
  renderMain();
  try {
    state.backups.diff = await api.get(`/api/backups/${id}/diff`);
  } finally {
    state.backups.loading = false;
  }
  renderMain();
}

function formatBackupTime(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { day: "2-digit", month: "short" }) + " "
    + d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

const BACKUP_TABLE_TITLES = {
  projects: "Projects", todo_lists: "Todo lists", tasks: "Tasks", subtasks: "Subtasks",
  tags: "Tags", task_tags: "Tags on tasks", task_completions: "Finished occurrences of recurring tasks",
  other_time: "Other tasks time",
  project_time: "Projects’ Other tasks time",
};

function formatBackupValue(prop, v) {
  if (v === null || v === undefined || v === "") return "(empty)";
  if (prop === "time_spent_seconds") return formatElapsed(v);
  if (prop === "checked" || prop === "urgent" || prop === "is_video") return v ? "yes" : "no";
  return String(v);   // full value, never truncated
}

function backupPropsDetails(props) {
  // every property that has a value (empty ones and the internal id are noise), always visible
  const shown = (props || []).filter((p) => p.prop !== "id" && p.value !== null && p.value !== undefined && p.value !== "");
  return el("table", { class: "backup-props" }, shown.map((p) => el("tr", {}, [
    el("td", { class: "backup-prop" }, p.prop),
    el("td", {}, formatBackupValue(p.prop, p.value)),
  ])));
}

function backupSummary(diff) {
  const parts = [];
  const names = { projects: "project", todo_lists: "list", tasks: "task", subtasks: "subtask", tags: "tag",
    task_tags: "tag assignment", task_completions: "finished occurrence", other_time: "“Other tasks” time entry", project_time: "project “Other tasks” time entry" };
  for (const [table, d] of Object.entries(diff)) {
    const n = names[table] || table;
    if (d.created_since.length) parts.push(`${d.created_since.length} ${n}(s) created since`);
    if (d.deleted_since.length) parts.push(`${d.deleted_since.length} ${n}(s) deleted since`);
    if (d.changed.length) parts.push(`${d.changed.length} ${n}(s) changed`);
  }
  return parts.join(" · ");
}

function renderBackupDiff(result) {
  const box = el("div", { class: "backup-diff" });
  const tables = Object.keys(result.diff);
  if (!tables.length) {
    box.appendChild(el("div", { class: "muted", style: "padding:14px 0" }, "No differences: the current data is identical to this backup."));
    return box;
  }
  for (const table of tables) {
    const d = result.diff[table];
    const section = el("div", { class: "backup-section" }, [
      el("h3", {}, BACKUP_TABLE_TITLES[table] || table),
    ]);
    for (const item of d.deleted_since) {
      section.appendChild(el("div", { class: "backup-item removed" }, [
        el("span", { class: "backup-badge" }, "Deleted since"),
        el("strong", {}, " " + item.label), el("span", { class: "muted" }, " " + (item.context || "")),
        el("div", { class: "muted small" }, "Restoring brings it back."),
        backupPropsDetails(item.props),
      ]));
    }
    for (const item of d.created_since) {
      section.appendChild(el("div", { class: "backup-item added" }, [
        el("span", { class: "backup-badge" }, "Created since"),
        el("strong", {}, " " + item.label), el("span", { class: "muted" }, " " + (item.context || "")),
        el("div", { class: "muted small" }, "Restoring removes it."),
        backupPropsDetails(item.props),
      ]));
    }
    for (const item of d.changed) {
      section.appendChild(el("div", { class: "backup-item changed" }, [
        el("span", { class: "backup-badge" }, "Changed"),
        el("strong", {}, " " + item.label), el("span", { class: "muted" }, " " + (item.context || "")),
        el("table", { class: "backup-props" }, item.props.map((p) => el("tr", {}, [
          el("td", { class: "backup-prop" }, p.prop),
          el("td", {}, formatBackupValue(p.prop, p.backup)),
          el("td", { class: "muted" }, "→"),
          el("td", {}, formatBackupValue(p.prop, p.current)),
        ]))),
      ]));
    }
    box.appendChild(section);
  }
  box.insertBefore(el("div", { style: "margin-bottom:10px" }, [
    el("div", { style: "font-weight:600" }, "Compared with the current data: " + backupSummary(result.diff)),
    el("div", { class: "muted small" }, "Each changed property reads: value in the backup → value now."),
  ]), box.firstChild);
  return box;
}

function renderBackupsView() {
  const wrap = el("div", { class: "backups-wrap" });
  const { list, selected, diff, loading } = state.backups;

  const left = el("div", { class: "backups-list" }, [
    el("button", {
      class: "btn", style: "margin-bottom:8px;width:100%",
      onclick: async () => {
        await api.post("/api/backups", {});
        state.backups.list = await api.get("/api/backups");
        showToast("Backup created");
        renderMain();
      },
    }, "Back up now"),
    el("button", {
      class: "btn", style: "margin-bottom:8px;width:100%",
      onclick: async () => {
        const days = await confirmModal({
          title: "Remove old backups", message: "Backups older than the chosen period are permanently deleted.",
          confirmLabel: "Remove", danger: true,
          choices: [
            { value: 7, label: "Older than a week" },
            { value: 30, label: "Older than a month" },
            { value: 90, label: "Older than 3 months" },
          ],
        });
        if (!days) return;
        const res = await api.post("/api/backups/prune", { older_than_days: days });
        state.backups.list = await api.get("/api/backups");
        if (state.backups.selected && !state.backups.list.some((b) => b.id === state.backups.selected)) {
          state.backups.selected = null; state.backups.diff = null;
        }
        showToast(res.removed ? `Removed ${res.removed} backup${res.removed > 1 ? "s" : ""}` : "No backups that old");
        renderMain();
      },
    }, "Remove old backups"),
  ]);
  if (!list.length) left.appendChild(el("div", { class: "muted" }, "No backups yet — one is created after your next change."));
  for (const b of list) {
    left.appendChild(el("div", {
      class: "backup-row" + (b.id === selected ? " active" : ""),
      onclick: () => selectBackup(b.id),
    }, [
      el("div", { class: "backup-reason" }, b.reason),
      el("div", { class: "muted small" }, `${formatBackupTime(b.created_at)} · ${b.counts.tasks} tasks, ${b.counts.subtasks} subtasks`),
    ]));
  }

  const right = el("div", { class: "backups-detail" });
  if (!selected) {
    right.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("database"),
      el("div", {}, "Pick a backup to see how it differs from your current data"),
    ]));
  } else if (loading || !diff) {
    right.appendChild(el("div", { class: "muted" }, "Comparing…"));
  } else {
    const meta = diff.backup;
    right.appendChild(el("div", { class: "backup-detail-head" }, [
      el("div", {}, [
        el("h2", { style: "margin:0" }, formatBackupTime(meta.created_at)),
        el("div", { class: "muted" }, meta.reason),
      ]),
      el("button", {
        class: "btn danger",
        onclick: async () => {
          if (!(await confirmModal({ title: "Restore this backup?", message: `All data goes back to the state of ${formatBackupTime(meta.created_at)}. The current data is backed up first, so you can undo this from the list.`, confirmLabel: "Restore", danger: true }))) return;
          await api.post(`/api/backups/${meta.id}/restore`, {});
          showToast("Backup restored");
          setTimeout(() => location.reload(), 600);
        },
      }, "Restore this backup"),
    ]));
    right.appendChild(renderBackupDiff(diff));
  }

  wrap.appendChild(left);
  wrap.appendChild(right);
  return wrap;
}

// Month view filter "Only show videos": main tasks of Video type only (no subtasks).
// Remembered across reloads (a per-browser convenience, so just localStorage).
const ONLY_VIDEOS_KEY = "taskplanner.calendar.onlyVideos";
function onlyVideosToggle() {
  const on = state.calendar.onlyVideos;
  return el("label", { class: "toggle-inline completed-toggle" + (on ? " on" : ""), title: "Month view: only main tasks of the Video type (no subtasks)" }, [
    el("input", {
      type: "checkbox",
      checked: on ? "checked" : null,
      onchange: async (e) => {
        state.calendar.onlyVideos = e.target.checked;
        e.target.closest("label").classList.toggle("on", e.target.checked);
        try { localStorage.setItem(ONLY_VIDEOS_KEY, e.target.checked ? "1" : "0"); } catch { /* not remembered */ }
        await switchSettled();
        loadCalendar();   // the server returns the main video tasks (even those with subtasks)
      },
    }),
    el("span", {}, "Only show videos"),
  ]);
}

function renderHeaderActions() {
  const box = document.getElementById("headerActions");
  box.innerHTML = "";
  if (state.view.type === "calendar") {
    if (state.calendar.mode !== "week") box.appendChild(onlyVideosToggle());
    box.appendChild(el("button", {
      class: "btn",
      onclick: () => {
        if (state.calendar.mode === "week") { state.calendar.weekStart = startOfWeekIso(todayIso()); loadCalendar(); }
        else openCalendar(new Date().getFullYear(), new Date().getMonth() + 1);
      },
    }, "Today"));
    if (state.calendar.mode === "week") {
      box.appendChild(el("button", {
        class: "btn", title: "Place today's untimed tasks and subtasks in the free slots of today's calendar",
        onclick: autoOrderToday,
      }, "Auto order"));
      if (loadAutoOrdered().length) {
        box.appendChild(el("button", {
          class: "btn", title: "Remove the start times given by the last Auto order",
          onclick: revertAutoOrder,
        }, "Revert"));
      }
    }
    return;
  }
  if (state.view.type === "smart") {
    // Inbox/Today/Tomorrow/Urgent: data is always fetched complete (done
    // items included), and this toggle just decides whether renderSmartView
    // filters them back out -- no refetch needed, so this just re-renders.
    box.appendChild(showCompletedToggle(() => renderMain()));
    return;
  }
  if (state.view.type === "list" && state.view.todoListId) {
    const list = state.todoLists.find((l) => l.id === state.view.todoListId);
    if (!list) return;
    box.appendChild(showCompletedToggle(refreshCurrentView));
    box.appendChild(el("button", {
      class: "btn",
      onclick: async () => {
        const name = await promptModal({ title: "Rename list", value: list.name });
        if (name && name.trim()) api.patch(`/api/todolists/${list.id}`, { name: name.trim() }).then(refreshAfterStructureChange);
      },
    }, "Rename list"));
    box.appendChild(el("button", {
      class: "btn danger",
      onclick: async () => {
        if (!(await confirmModal({ title: "Delete list?", message: `“${list.name}” and all its tasks will be deleted.`, confirmLabel: "Delete", danger: true }))) return;
        await api.del(`/api/todolists/${list.id}`);
        await refreshSidebarData();
        openFirstAvailable();
      },
    }, "Delete list"));
  }
}
