"use strict";

// Account page (Utilities > Account): who is signed in, change identifier / password, sign out.

async function openAccountView() {
  state.view = { type: "account", title: "Account" };
  state.account = await api.get("/api/auth/me");
  renderMain();
  renderSidebar();
}

function renderAccountView() {
  const me = state.account || {};
  const field = (label, input) => el("div", { class: "field" }, [el("label", {}, label), input]);
  const ident = el("input", { type: "text", value: me.identifier || "", autocomplete: "username", placeholder: "Email or identifier" });
  const cur = el("input", { type: "password", autocomplete: "current-password" });
  const pw1 = el("input", { type: "password", autocomplete: "new-password", placeholder: `At least ${me.min_password_length || 8} characters` });
  const pw2 = el("input", { type: "password", autocomplete: "new-password" });
  const msg = el("div", { style: "font-size:13px;min-height:18px;margin-top:10px" });
  const say = (t, bad) => { msg.textContent = t; msg.style.color = bad ? "var(--danger, #c0392b)" : "var(--muted)"; };

  async function save() {
    if (pw1.value !== pw2.value) { say("The two new passwords differ.", true); return; }
    if (!cur.value) { say("Enter your current password.", true); return; }
    try {
      const r = await api.send("POST", "/api/auth/change", {
        current_password: cur.value, identifier: ident.value.trim(), new_password: pw1.value || null,
      });
      state.account = { ...me, identifier: r.identifier, must_change: r.must_change };
      showToast("Account updated");
      renderMain();
    } catch (e) {
      let t = e.message;
      try { t = JSON.parse(t).error || t; } catch (_) { /* plain text */ }
      say(t, true);
    }
  }

  const children = [];
  if (me.must_change) {
    children.push(el("div", { class: "account-warn" },
      "You are still using the default password. Choose a new one below."));
  }
  children.push(
    el("div", { class: "muted", style: "margin-bottom:16px" }, ["Signed in as ", el("b", {}, me.identifier || "")]),
    field("Identifier (email or name)", ident),
    field("Current password", cur),
    field("New password (leave empty to keep the current one)", pw1),
    field("Repeat the new password", pw2),
    el("div", { class: "btn-row spread" }, [
      el("button", { class: "btn", onclick: async () => { await fetch("/logout", { method: "POST" }); location.href = "/login"; } }, "Sign out"),
      el("button", { class: "btn primary", onclick: save }, "Save"),
    ]),
    msg,
  );
  return el("div", { class: "account-wrap" }, children);
}

function wireAccount() {
  const b = document.getElementById("accountBtn");
  if (b) b.addEventListener("click", openAccountView);
}
