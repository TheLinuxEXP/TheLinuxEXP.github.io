"use strict";

// Current Video project view.

/* ---------------------------------------------------------------------- *
 * Current Video project — the video (main) task whose due date is closest to
 * today, its subtasks laid out as the steps of a timeline.
 * ---------------------------------------------------------------------- */
state.videoProject = { task: null, rootPath: "" };
// Project filter of the view ("" = All projects), remembered between sessions.
try { state.videoProject.projectId = localStorage.getItem("taskplanner-vp-project") || ""; } catch { state.videoProject.projectId = ""; }

async function openVideoProject() {
  state.videoProject.taskId = null;                  // the tile always starts on the video closest to today
  state.view = { type: "videoproject", title: "Current Video project" };
  await loadVideoProject();
  renderSidebar();
}

async function loadVideoProject() {
  try {
    const id = state.videoProject.taskId;
    let pid = state.videoProject.projectId || "";
    if (pid && !(state.projects || []).some((p) => p.id === pid)) { pid = state.videoProject.projectId = ""; }   // project deleted since
    const res = await api.get(`/api/video-project/current?today=${todayIso()}` + (id ? `&id=${encodeURIComponent(id)}` : "") + (pid ? `&project_id=${encodeURIComponent(pid)}` : ""));
    state.videoProject.task = res.task;
    state.videoProject.prevId = res.prev_id;
    state.videoProject.nextId = res.next_id;
    if (!id && !pid) state.currentVideo = res.task;
  } catch (e) { state.videoProject.task = null; }
  try { state.videoProject.rootPath = (await NotesApp.root()) || ""; } catch (e) { state.videoProject.rootPath = ""; }
  if (state.view.type === "videoproject") renderMain();
}

function renderVideoProject() {
  const wrap = el("div", { class: "vp" });
  const task = state.videoProject.task;
  const projectSelect = el("select", { class: "vp-project-filter", title: "Filter by project", style: "width:auto;min-width:170px;margin-left:auto" }, [
    el("option", { value: "" }, "All projects"),
    ...(state.projects || []).map((p) => el("option", { value: p.id, selected: p.id === state.videoProject.projectId || undefined }, p.name)),
  ]);
  projectSelect.value = state.videoProject.projectId || "";
  projectSelect.addEventListener("change", () => {
    state.videoProject.projectId = projectSelect.value;
    state.videoProject.taskId = null;                 // back to the video closest to today within this project
    try { localStorage.setItem("taskplanner-vp-project", projectSelect.value); } catch { /* ignore */ }
    loadVideoProject();
  });
  if (!task) {
    wrap.appendChild(el("div", { class: "vp-head" }, [el("span", { class: "muted" }, "Project"), projectSelect]));
    wrap.appendChild(el("div", { class: "empty-state" }, [el("div", {}, state.videoProject.projectId ? "No open video task with a due date in this project." : "No open video task with a due date.")]));
    return wrap;
  }
  const refresh = () => loadVideoProject();
  const root = (state.videoProject.rootPath || "").replace(/\/$/, "");
  const relOf = (p) => (root && p && p.startsWith(root + "/")) ? p.slice(root.length + 1) : null;
  const noteChip = (icon, label, path) => {
    const rel = relOf(path);
    const name = path.split("/").pop().replace(/\.md$/i, "");
    return rel
      ? el("button", { class: "note-link-chip clickable", type: "button", title: `Open ${path}`, onclick: () => NotesApp.openNote(rel) }, [el("span", {}, `${icon} ${name}`)])
      : el("span", { class: "note-link-chip", title: path }, [el("span", {}, `${icon} ${name}`)]);
  };

  // header
  const due = formatDue(task.due_date);
  const go = (id) => { state.videoProject.taskId = id; loadVideoProject(); };
  wrap.appendChild(el("div", { class: "vp-head" }, [
    el("button", { class: "icon-btn vp-arrow", type: "button", title: "Previous video", disabled: !state.videoProject.prevId || undefined,
      onclick: () => go(state.videoProject.prevId) }, "‹"),
    el("button", { class: "icon-btn vp-arrow", type: "button", title: "Next video", disabled: !state.videoProject.nextId || undefined,
      onclick: () => go(state.videoProject.nextId) }, "›"),
    el("h2", { class: "vp-title", onclick: () => openTaskDetail(task.id), title: "Open the task" }, task.title),
    el("span", { class: "muted" }, `Due ${due.text || task.due_date}`),
    projectSelect,
  ]));

  // main info
  const info = el("div", { class: "vp-info" });
  info.appendChild(el("div", { class: "vp-info-row" }, [
    el("span", { class: "vp-info-label" }, "Note"),
    task.notes_file ? noteChip("📄", "Note", task.notes_file) : el("span", { class: "muted small" }, "none linked"),
  ]));
  if (task.video_note_file) {
    info.appendChild(el("div", { class: "vp-info-row" }, [
      el("span", { class: "vp-info-label" }, "Video note"),
      noteChip("🎬", "Video note", task.video_note_file),
    ]));
  }
  const tags = task.tags || [];
  const mention = el("button", {
    type: "button", class: "vp-mention " + (task.mention_approved ? "done" : "todo"),
    title: "Sponsor mention for this month — click to change (same as “Done” in the Sponsors tab)",
    onclick: async () => { await api.patch(`/api/tasks/${task.id}`, { mention_approved: !task.mention_approved }); refresh(); },
  }, task.mention_approved ? "✓ Mention done" : "Mention not done");
  info.appendChild(el("div", { class: "vp-info-row" }, [
    el("span", { class: "vp-info-label" }, "Sponsor"),
    tags.length
      ? el("span", { class: "chip-row" }, tags.map((g) => el("span", { class: "chip selected" }, [el("span", { class: "swatch", style: `background:${g.color};width:9px;height:9px` }), g.name])))
      : el("span", { class: "muted small vp-no-sponsor" }, "No sponsor"),
    tags.length ? mention : null,           // a mention only makes sense when there is a sponsor
  ]));
  wrap.appendChild(info);

  // timeline
  // in the order of the template the video was made from (subtasks are created in that order), not by date
  const subs = [...(task.subtasks || [])].sort((a, b) =>
    (a.sort_order || 0) - (b.sort_order || 0) || (a.due_date || "9999").localeCompare(b.due_date || "9999") || (a.start_time || "99:99").localeCompare(b.start_time || "99:99"));
  const line = el("div", { class: "vp-timeline" });
  for (const s of subs) {
    const done = !!s.checked;
    const d = s.due_date ? formatDue(s.due_date).text : "";
    const head = el("div", { class: "vp-step-head" }, [
      el("div", {
        class: "checkbox small" + (done ? " checked" : ""),
        onclick: async () => { await api.post(`/api/subtasks/${s.id}/toggle`, { checked: !done }); refresh(); },
      }, done ? "✓" : ""),
      el("span", { class: "vp-step-title" + (done ? " done" : "") }, s.title),
      el("span", { class: "muted small" }, [d, s.start_time || ""].filter(Boolean).join(" · ")),
      el("span", { class: "vp-step-status " + (done ? "done" : "todo") }, done ? "Completed" : "To do"),
    ]);
    const body = el("div", { class: "vp-step-body" });
    if (done) {
      body.appendChild(el("span", { class: "muted small" }, `Time spent: ${formatElapsed(s.time_spent_seconds || 0)}`));
    } else {
      body.appendChild(timerControls(s, "subtasks", refresh));
      for (const b of subtaskAIButtons(s.title, task, s.template_sub_id)) {
        body.appendChild(el("button", {
          type: "button", class: "btn ai-btn",
          onclick: (e) => (b.kind === "list_to_ppt" ? openListToPptModal(s.id, b.label)
            : b.kind === "powerpoint" || b.endpoint === "generate-pptx"
            ? openGeneratePptxModal(s.id, b.label)
            : runSubtaskAI(e.currentTarget, s.id, b.endpoint, b.label, b.buttonId)),
        }, `✨ ${b.label}`));
      }
    }
    line.appendChild(el("div", { class: "vp-step" + (done ? " done" : "") }, [el("span", { class: "vp-dot" }), head, body]));
  }
  if (!subs.length) line.appendChild(el("div", { class: "muted" }, "This task has no subtasks."));
  wrap.appendChild(line);
  return wrap;
}

async function openSponsorsView(year, month) {
  const now = new Date();
  state.sponsors.year = year || state.sponsors.year || now.getFullYear();
  state.sponsors.month = month || state.sponsors.month || (now.getMonth() + 1);
  state.view = { type: "sponsors", title: "Sponsors" };
  if (state.sponsors.tab === "contracts") await loadSponsorContracts();
  else await loadSponsorsReport();
  renderSidebar();
}

async function loadSponsorContracts() {
  state.sponsors.contracts = await api.get("/api/tags/contracts");
  renderMain();
}

function setSponsorsTab(tab) {
  state.sponsors.tab = tab;
  if (tab === "contracts") loadSponsorContracts();
  else loadSponsorsReport();
}

function sponsorsTabs() {
  const tab = state.sponsors.tab || "calendar";
  return el("div", { class: "sponsors-tabs" }, [
    el("div", { class: "seg" }, [
      ["calendar", "Publication Calendar"],
      ["contracts", "Contracts and Billing"],
    ].map(([key, label]) => el("button", {
      type: "button",
      class: "seg-btn" + (tab === key ? " active" : ""),
      onclick: () => { if (tab !== key) setSponsorsTab(key); },
    }, label))),
  ]);
}

function renderSponsorContracts() {
  const wrap = el("div", {});
  const tags = state.sponsors.contracts || [];
  if (!tags.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("megaphone"),
      el("div", {}, "No tags yet — add some from a task's tag picker"),
    ]));
    return wrap;
  }
  const list = el("div", { class: "contract-list" });
  for (const tag of tags) {
    const has = !!tag.has_contract;
    const info = [];
    if (has) {
      info.push(tag.total_videos != null ? `${tag.total_videos} video${tag.total_videos === 1 ? "" : "s"}` : "No video total");
      info.push(tag.end_date ? `Ends ${formatDateDisplay(tag.end_date)}` : "No end date");
    }
    if (tag.billing_period) {
      const kind = tag.amount_type === "per_video" ? " per video" : tag.amount_type === "fixed" ? " fixed" : "";
      info.push(`${tag.billing_period === "quarterly" ? "Quarterly" : "Monthly"}${tag.amount ? ` · ${tag.amount}${kind}` : ""}`);
    }
    const download = has
      ? el("a", {
          class: "icon-btn contract-btn",
          href: `/api/tags/${tag.id}/contract`,
          download: tag.file_name || "contract",
          title: `Download the contract (${tag.file_name})`,
        }, [symbolicIcon("download")])
      : null;
    const gear = el("button", {
      type: "button",
      class: "icon-btn contract-btn" + (has ? "" : " none"),
      title: has ? "Contract settings" : "No contract yet — add one",
      "aria-label": "Contract settings",
      onclick: () => openContractSheet(tag),
    }, [symbolicIcon("gear")]);
    const action = el("span", { class: "contract-actions" }, [download, gear]);
    list.appendChild(el("div", { class: "sponsor-tag-card contract-row" }, [
      el("span", { class: "dot", style: `background:${tag.color}` }),
      el("span", { class: "sponsor-tag-name" }, tag.name),
      el("span", { class: "contract-info muted small" }, info.join(" · ")),
      action,
    ]));
  }
  wrap.appendChild(list);
  return wrap;
}

// The contract sheet (gear button): file, video total and end date.
function openContractSheet(tag) {
  const has = !!tag.has_contract;
  const file = el("input", { type: "file", class: has ? "hidden" : "" });
  const videos = el("input", { type: "number", min: "0", step: "1", placeholder: "Leave empty if unknown" });
  const endDate = el("input", { type: "date" });
  if (has) { videos.value = tag.total_videos != null ? tag.total_videos : ""; endDate.value = tag.end_date || ""; }
  // billing: Monthly / Quarterly invoices, Per video / Fixed amount (see "Invoices" tasks created at month / quarter end)
  const period = el("select", {}, [el("option", { value: "" }, "— No automatic invoice —"), el("option", { value: "monthly" }, "Monthly"), el("option", { value: "quarterly" }, "Quarterly")]);
  const amountType = el("select", {}, [el("option", { value: "per_video" }, "Per video"), el("option", { value: "fixed" }, "Fixed")]);
  const amount = el("input", { type: "text", placeholder: "e.g. 500 (empty = invoice without amount)", maxlength: "40", autocomplete: "off" });
  period.value = tag.billing_period || "";
  amountType.value = tag.amount_type || "per_video";
  amount.value = tag.amount || "";
  const paintBilling = () => { amountType.disabled = amount.disabled = !period.value; };
  period.addEventListener("change", paintBilling);
  paintBilling();
  const save = el("button", {
    class: "btn primary",
    onclick: async () => {
      const fd = new FormData();
      if (file.files[0]) fd.append("file", file.files[0]);
      fd.append("total_videos", videos.value);
      fd.append("end_date", endDate.value);
      fd.append("billing_period", period.value);
      fd.append("amount_type", period.value ? amountType.value : "");
      fd.append("amount", period.value ? amount.value : "");
      save.disabled = true;
      try {
        await api.postForm(`/api/tags/${tag.id}/contract`, fd);
        closeModal();
        showToast(has ? `Contract updated for ${tag.name}` : `Contract added for ${tag.name}`);
        await loadSponsorContracts();
      } catch (e) {
        let msg = "Couldn't save the contract.";
        try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
        showToast(msg);
      } finally { save.disabled = false; }
    },
  }, "Save");
  // when a file is already stored: its name, plus icon-only download / replace buttons
  const fileName = el("span", { class: "contract-file-name" }, tag.file_name || "");
  file.addEventListener("change", () => {
    if (has) fileName.textContent = file.files[0] ? `${file.files[0].name} (will replace ${tag.file_name})` : tag.file_name;
  });
  const fileField = has
    ? el("div", { class: "contract-file-row" }, [
        symbolicIcon("notes"), fileName,
        el("a", { class: "icon-btn contract-btn", href: `/api/tags/${tag.id}/contract`, download: tag.file_name || "contract",
          title: "Download the contract", "aria-label": "Download the contract" }, [symbolicIcon("download")]),
        el("button", { type: "button", class: "icon-btn contract-btn", title: "Replace the file", "aria-label": "Replace the file",
          onclick: () => file.click() }, [symbolicIcon("upload")]),
        file,
      ])
    : file;
  openModal(`Contract — ${tag.name}`, [
    el("div", { class: "field" }, [el("label", {}, "Contract file (optional)"), fileField]),
    el("div", { class: "field" }, [el("label", {}, "Total number of videos (optional)"), videos]),
    el("div", { class: "field" }, [el("label", {}, "End date (optional)"), endDate]),
    el("div", { class: "field" }, [el("label", {}, "Billing"), period]),
    el("div", { class: "field" }, [el("label", {}, "Amount type"), amountType]),
    el("div", { class: "field" }, [el("label", {}, "Amount"), amount]),
    el("div", { class: "muted small" }, "At the end of each month (or quarter) an “Invoices …” task is created in The Linux EXP / Tasks with one “Invoice <sponsor> <amount>” subtask. Per video: finished videos tagged with this sponsor and due in the period × the amount. Fixed: the amount as is."),
  ], [el("button", { class: "btn", onclick: closeModal }, "Cancel"), save]);
}

async function loadSponsorsReport() {
  const { year, month } = state.sponsors;
  state.sponsors.data = await api.get(`/api/tags/monthly-report?year=${year}&month=${month}`);
  try { state.sponsors.hidden = (await api.get("/api/sponsors/hidden")).hidden || []; } catch (_) { /* keep what we had */ }
  renderMain();
}

function navSponsorsMonth(delta) {
  let { year, month } = state.sponsors;
  month += delta;
  if (month < 1) { month = 12; year -= 1; }
  else if (month > 12) { month = 1; year += 1; }
  state.sponsors.year = year;
  state.sponsors.month = month;
  loadSponsorsReport();
}

function renderSponsorsView() {
  if (state.sponsors.tab === "contracts") {
    const box = el("div", {}, [sponsorsTabs(), renderSponsorContracts()]);
    return box;
  }
  const { year, month, data } = state.sponsors;
  const wrap = el("div", {});
  wrap.appendChild(sponsorsTabs());

  const hiddenSet = new Set(state.sponsors.hidden || []);
  const hiddenCount = data.filter((t) => hiddenSet.has(t.id)).length;
  wrap.appendChild(el("div", { class: "calendar-header" }, [
    el("button", { class: "icon-btn", onclick: () => navSponsorsMonth(-1) }, "‹"),
    el("h2", {}, `${MONTH_NAMES[month - 1]} ${year}`),
    el("button", { class: "icon-btn", onclick: () => navSponsorsMonth(1) }, "›"),
    el("button", { class: "btn small", style: "margin-left:auto", title: "Choose which sponsors are shown",
      onclick: openSponsorFilter }, hiddenCount ? `Filter (${hiddenCount} hidden)` : "Filter"),
  ]));

  if (!data.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("megaphone"),
      el("div", {}, "No tags yet — add some from a task's tag picker"),
    ]));
    return wrap;
  }
  const visible = data.filter((t) => !hiddenSet.has(t.id));
  if (!visible.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("megaphone"),
      el("div", {}, "All sponsors are hidden"),
      el("button", { class: "btn small", onclick: openSponsorFilter }, "Change the filter"),
    ]));
    return wrap;
  }

  const list = el("div", { class: "sponsor-tag-list" });
  for (const tag of visible) {
    const card = el("div", { class: "sponsor-tag-card" }, [
      el("div", { class: "sponsor-tag-head" }, [
        el("span", { class: "dot", style: `background:${tag.color}` }),
        el("span", { class: "sponsor-tag-name" }, tag.name),
        el("span", { class: "sponsor-tag-count" }, `${tag.count} this month`),
      ]),
    ]);
    if (tag.tasks.length) {
      const dueList = el("div", { class: "sponsor-tag-dues" });
      for (const t of tag.tasks) {
        const row = el("div", { class: "sponsor-tag-due-item" });
        row.appendChild(el("div", {
          class: "sponsor-tag-due-row",
          onclick: () => openTaskDetail(t.id),
        }, [
          el("span", { class: "sponsor-due-date" }, formatDue(t.due_date).text || t.due_date),
          el("span", { class: "sponsor-due-title" + (t.checked ? " done" : "") }, t.title),
          t.checked ? el("span", { class: "sponsor-due-check", title: "Done" }, "✓") : null,
        ]));

        const daysUntil = Math.round((parseIso(t.due_date) - parseIso(todayIso())) / 86400000);
        if (!t.checked && !t.mention_approved && daysUntil <= 14) {
          const alert = el("div", { class: "sponsor-mention-alert" }, [
            el("span", {}, "Do you have the mention done and approved?"),
            el("span", { class: "sponsor-mention-days" + (daysUntil <= 3 ? " soon" : "") + (daysUntil < 0 ? " late" : ""), title: "Time left before the video task's due date" },
              daysUntil < 0 ? `Due ${-daysUntil} day${daysUntil === -1 ? "" : "s"} ago`
                : daysUntil === 0 ? "Due today"
                : daysUntil === 1 ? "Due tomorrow"
                : `${daysUntil} days left`),
            el("button", {
              class: "btn small",
              title: 'Creates a task in "Other tasks", due today, 0.5h estimated',
              onclick: async (e) => {
                e.stopPropagation();
                await api.post("/api/sponsors/create-mention-task", { sponsor_name: tag.name });
                showToast(`Task created: "Create sponsored mention for ${tag.name}"`);
              },
            }, "Create Task"),
            el("button", {
              class: "btn primary small",
              onclick: async (e) => {
                e.stopPropagation();
                await api.patch(`/api/tasks/${t.id}`, { mention_approved: true });
                alert.remove();
              },
            }, "Done"),
          ]);
          row.appendChild(alert);
        }
        dueList.appendChild(row);
      }
      card.appendChild(dueList);
    }
    list.appendChild(card);
  }
  wrap.appendChild(list);
  return wrap;
}

// Modal: tick the sponsors to show. Saved on the server as soon as it changes.
function openSponsorFilter() {
  const data = state.sponsors.data || [];
  const hidden = new Set(state.sponsors.hidden || []);
  const save = async () => {
    state.sponsors.hidden = [...hidden];
    try { await api.send("PUT", "/api/sponsors/hidden", { hidden: [...hidden] }); }
    catch (_) { showToast("Could not save the filter"); }
    renderMain();
  };
  const boxes = [];
  const list = el("div", { class: "sponsor-filter-list" });
  for (const t of [...data].sort((a, b) => a.name.localeCompare(b.name))) {
    const cb = el("input", { type: "checkbox" });
    cb.checked = !hidden.has(t.id);
    cb.addEventListener("change", () => { if (cb.checked) hidden.delete(t.id); else hidden.add(t.id); save(); });
    boxes.push([t, cb]);
    list.appendChild(el("label", { class: "sponsor-filter-row" }, [
      cb, el("span", { class: "dot", style: `background:${t.color}` }), el("span", {}, t.name),
    ]));
  }
  const setAll = (show) => { for (const [t, cb] of boxes) { cb.checked = show; if (show) hidden.delete(t.id); else hidden.add(t.id); } save(); };
  openModal("Sponsors shown", [
    el("div", { class: "row", style: "display:flex;gap:8px;margin-bottom:10px" }, [
      el("button", { class: "btn small", onclick: () => setAll(true) }, "Show all"),
      el("button", { class: "btn small", onclick: () => setAll(false) }, "Hide all"),
    ]),
    data.length ? list : el("div", { class: "muted" }, "No sponsors yet."),
  ], [el("button", { class: "btn primary", onclick: closeModal }, "Done")]);
}

async function refreshCurrentView() {
  await refreshSidebarData();
  if (state.view.type === "list" && state.view.todoListId) {
    state.tasks = await api.get(`/api/tasks?todo_list_id=${state.view.todoListId}&include_done=${state.showCompleted ? 1 : 0}`);
    await loadProjectOther();
    renderMain();
  } else if (state.view.type === "project" && state.view.projectId) {
    state.tasks = await api.get(`/api/tasks?project_id=${state.view.projectId}&include_done=${state.showCompleted ? 1 : 0}`);
    await loadProjectOther();
    renderMain();
  } else if (state.view.type === "calendar") {
    await loadCalendar();
  } else if (state.view.type === "smart") {
    await loadSmartTasks(state.view.smartType);
    renderMain();
  } else if (state.view.type === "videoproject") {
    await loadVideoProject();
  }
}
