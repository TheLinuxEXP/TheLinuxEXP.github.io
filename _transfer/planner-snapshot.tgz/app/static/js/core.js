"use strict";

// Core: API helpers, global state, small utilities, per-task/subtask timer control.

/* ---------------------------------------------------------------------- *
 * API helpers
 * ---------------------------------------------------------------------- */
// An expired / cut-off session answers 401 on the API. The page is NOT thrown away (what is being typed in a note or a task
// would be lost): a banner offers to sign in again in a new tab - the session cookie is shared, so saving works again.
(function () {
  const realFetch = window.fetch.bind(window);
  let banner = null;
  function showBanner(text, href) {
    if (banner) return;
    banner = document.createElement("div");
    banner.setAttribute("role", "alert");
    banner.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:99999;padding:10px 16px;background:#c0392b;color:#fff;font:14px/1.4 system-ui,sans-serif;text-align:center";
    banner.append(text + " ");
    const a = document.createElement("a");
    a.href = href; a.target = "_blank"; a.rel = "noopener"; a.textContent = "Sign in again";
    a.style.cssText = "color:#fff;font-weight:700;text-decoration:underline";
    banner.append(a, " (opens in a new tab; what you typed here is kept and will be saved afterwards).");
    document.body.appendChild(banner);
  }
  window.fetch = async (...args) => {
    const r = await realFetch(...args);
    if (location.pathname.startsWith("/login") || location.pathname.startsWith("/change-password")) return r;
    if (r.status === 401) showBanner("Your session has ended.", "/login");
    else if (r.status === 403 && r.headers.get("X-Must-Change")) showBanner("You must choose a new password.", "/change-password");
    else if (banner && r.ok) { banner.remove(); banner = null; }
    return r;
  };
})();

const api = {
  async get(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
  async send(method, url, body) {
    const r = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
  post(url, body) { return this.send("POST", url, body); },
  patch(url, body) { return this.send("PATCH", url, body); },
  del(url) { return this.send("DELETE", url); },
  async upload(url, file) {
    const fd = new FormData();
    fd.append("file", file);
    const r = await fetch(url, { method: "POST", body: fd });
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
  // POST a pre-built FormData (text fields plus an optional file) --
  // used by the "Generate" PowerPoint button, which takes links/prompt
  // text alongside an optional reference document in one multipart request.
  async postForm(url, formData) {
    const r = await fetch(url, { method: "POST", body: formData });
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
};

function loadOnlyVideos() {
  try { return localStorage.getItem("taskplanner.calendar.onlyVideos") === "1"; } catch { return false; }  // literal: called while `state` is built, before the const below exists
}

/* ---------------------------------------------------------------------- *
 * Global state
 * ---------------------------------------------------------------------- */
const state = {
  projects: [],
  todoLists: [],   // flat, all lists across all projects
  tags: [],
  expanded: new Set(),  // expanded project ids in the sidebar tree
  knownProjectIds: new Set(),  // projects already seen once, so they default open exactly once
  collapsedGroups: new Set(),  // collapsed project-group ids within a smart view
  expandedSubtasks: new Set(), // task ids whose subtask list is expanded (folded by default)
  showCompleted: false,
  smartCounts: { inbox: 0, today: 0, tomorrow: 0, urgent: 0 },
  view: { type: "list", todoListId: null, title: "Tasks" },
  tasks: [],
  projectOther: [],  // the "Other tasks" of each project (permanent task per project: today's time bucket / running timer)
  completedOccurrences: [],  // finished occurrences of recurring tasks (smart views' Show completed)
  orphanParents: [],   // main tasks of those subtasks, listed (collapsible) with the matching subtasks under them
  orphanSubtasks: [],  // subtasks matching the current smart-view filter whose parent task doesn't
  calendar: { year: 0, month: 0, mode: "week", weekStart: null, data: {}, onlyVideos: loadOnlyVideos() },
  sponsors: { year: 0, month: 0, data: [], hidden: [] },
  timeReport: { tab: "activity", gran: "week", anchor: null, selected: null, periods: [], entries: [] },
  backups: { list: [], selected: null, diff: null, loading: false },
  templates: [],   // task templates (Utilities > Templates), loaded from /api/templates
  tplEditor: { key: null, draft: null, dirty: false, isNew: false },
};

const PROJECT_COLORS = ["#3daee9", "#e01b24", "#ff9800", "#2ecc71", "#9b59b6",
  "#f39c12", "#1abc9c", "#e91e63", "#607d8b", "#795548"];
// A task's video_template is stamped on at creation (and survives a rename)
// but can also be set or changed by hand from the task detail panel's
// "Video type" picker. The templates themselves (label, icons, main day,
// subtasks...) are editable in Utilities > Templates and live in state.templates.
const FALLBACK_TEMPLATE_ICONS = { weekly_news: "📅", warhammer_video: "🎲" };
function templateByKey(key) { return state.templates.find((t) => t.key === key) || null; }
function templateLabel(key) { const t = templateByKey(key); return t ? t.label : (key || "Video"); }
// Templates with a main day get their dates scheduled automatically; the others
// are created with no due date.
function templateIsUnscheduled(key) { const t = templateByKey(key); return !!t && t.main_weekday === null; }
async function refreshTemplates() {
  try { state.templates = await api.get("/api/templates"); } catch (e) { console.error(e); }
}

// The icon shown next to a video task's title (set per template; plain camera by default).
function videoTitleIcon(videoTemplate) {
  const t = templateByKey(videoTemplate);
  return (t && t.icon) || FALLBACK_TEMPLATE_ICONS[videoTemplate] || "🎥";
}
const WEEKDAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"];
const HOUR_HEIGHT = 64; // px per hour in the week view
const HOUR_START = 8;   // first hour row shown in the week view (8am)
const HOUR_END = 19;    // last hour row shown ends here (7pm) -- working hours only

/* ---------------------------------------------------------------------- *
 * Small utilities
 * ---------------------------------------------------------------------- */
function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else if (v !== false && v !== null && v !== undefined) node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

// Makes a <textarea> grow to fit its content as you type, instead of
// scrolling internally -- used for the notes field so everything typed
// stays visible at once.
function autoGrowTextarea(ta) {
  const grow = () => { ta.style.height = "auto"; ta.style.height = ta.scrollHeight + "px"; };
  ta.addEventListener("input", grow);
  setTimeout(grow, 0);
  return ta;
}

function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function parseIso(dateStr) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function toIso(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function tomorrowIso() {
  const d = parseIso(todayIso());
  d.setDate(d.getDate() + 1);
  return toIso(d);
}

function addDaysIso(iso, days) {
  const d = parseIso(iso);
  d.setDate(d.getDate() + days);
  return toIso(d);
}

function startOfWeekIso(iso) {
  const d = parseIso(iso);
  const dow = (d.getDay() + 6) % 7; // Monday=0 .. Sunday=6
  d.setDate(d.getDate() - dow);
  return toIso(d);
}

function timeToMinutes(hhmm) {
  if (!hhmm) return null;
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

function minutesToTime(mins) {
  mins = Math.max(0, Math.min(23 * 60 + 59, Math.round(mins)));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

function formatDue(dateStr) {
  if (!dateStr) return { text: "", overdue: false };
  const today = parseIso(todayIso());
  const due = parseIso(dateStr);
  const diffDays = Math.round((due - today) / 86400000);
  const overdue = diffDays < 0;
  let text;
  if (diffDays === 0) text = "Today";
  else if (diffDays === 1) text = "Tomorrow";
  else if (diffDays === -1) text = "Yesterday";
  else if (diffDays > 1 && diffDays < 7) text = due.toLocaleDateString(undefined, { weekday: "long" });
  else text = due.toLocaleDateString(undefined, { day: "numeric", month: "short", year: diffDays < -300 || diffDays > 300 ? "numeric" : undefined });
  return { text, overdue };
}

function formatDuration(minutes) {
  if (!minutes && minutes !== 0) return "";
  minutes = parseInt(minutes, 10);
  if (!minutes) return "";
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h && m) return `${h}h ${m}m`;
  if (h) return `${h}h`;
  return `${m}m`;
}

function formatElapsed(totalSeconds) {
  const s = Math.max(0, Math.round(totalSeconds || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h) return `${h}h ${m}m`;
  return `${m}m`;
}

/* ---------------------------------------------------------------------- *
 * Time tracking: a Start/Stop/Pause/Resume control + elapsed-time label,
 * shared by task and subtask rows in every list view (project, todo list,
 * inbox/today/tomorrow/urgent -- not the calendar, which has its own
 * per-day hours total instead). The elapsed label ticks live client-side
 * while running (see wireTimerTicker), computed from the seconds the
 * server reported plus time elapsed since that read, so it stays accurate
 * without polling the server every second.
 * ---------------------------------------------------------------------- */
// What the last click on a timer button was, so the rebuilt controls (the views re-render after every change) can play
// the matching animation: "start" -> the timer starts running, "stop" -> it ends. Only honoured for a moment.
const timerFx = {};
function takeTimerFx(kind, id, timerState) {
  const fx = timerFx[`${kind}:${id}`];
  if (!fx || Date.now() - fx.t > 1500) return "";
  if (fx.action === "start" && timerState === "running") return "fx-start";
  if (fx.action === "stop" && timerState === "idle") return "fx-stop";
  if (fx.action === "pause" && timerState === "paused") return "fx-pause";
  if (fx.action === "resume" && timerState === "running") return "fx-resume";
  return "";
}

function timerControls(entity, kind, onDone) {
  const timerState = entity.timer_state || "idle";
  const wrap = el("div", { class: "timer-controls" });
  const fx = takeTimerFx(kind, entity.id, timerState);
  if (fx) wrap.classList.add(fx);

  const act = async (action, e) => {
    e.stopPropagation();
    e.currentTarget.classList.add("pressed");      // instant feedback while the server answers
    timerFx[`${kind}:${entity.id}`] = { action, t: Date.now() };
    await api.post(`/api/${kind}/${entity.id}/timer`, { action });
    timerFx[`${kind}:${entity.id}`].t = Date.now();
    refreshActiveTimers();
    if (onDone) onDone(); else refreshCurrentView();
  };

  // A main task with subtasks reports its own time PLUS every subtask's.
  const hasTotal = kind === "tasks" && entity.subtasks && entity.subtasks.length && entity.total_time_seconds != null;
  const shownSeconds = hasTotal ? entity.total_time_seconds : (entity.time_spent_seconds || 0);
  const rate = hasTotal ? (entity.running_timers || 0) : (timerState === "running" ? 1 : 0);
  const labelAttrs = { class: "timer-elapsed" };
  if (rate > 0) {
    labelAttrs["data-running"] = "1";
    labelAttrs["data-base-seconds"] = String(shownSeconds);
    labelAttrs["data-rate"] = String(rate);
    labelAttrs["data-since-ms"] = String(Date.now());
  }
  if (hasTotal) labelAttrs.title = `Total: this task ${formatElapsed(entity.own_time_seconds)} + subtasks ${formatElapsed(entity.total_time_seconds - entity.own_time_seconds)}`;
  wrap.appendChild(el("span", labelAttrs, formatElapsed(shownSeconds)));

  const ICONS = {
    start: '<path d="M8 5v14l11-7z"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
    resume: '<path d="M8 5v14l11-7z"/>',
  };
  const TITLES = { start: "Start timer", stop: "Stop timer", pause: "Pause timer", resume: "Resume timer" };
  const iconBtn = (action, ghost) => {
    const b = el("button", { class: "btn small timer-btn icon-only" + (ghost ? " ghost" : "") + ` t-${action}`, title: TITLES[action], "aria-label": TITLES[action], onclick: (e) => act(action, e) });
    b.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true">${ICONS[action]}</svg>`;
    return b;
  };
  if (timerState === "idle") {
    wrap.appendChild(iconBtn("start"));
  } else {
    wrap.appendChild(iconBtn("stop"));
    if (timerState === "running") wrap.appendChild(iconBtn("pause", true));
    else if (timerState === "paused") wrap.appendChild(iconBtn("resume", true));
  }
  return wrap;
}

// One editable field, in minutes, for the actual measured time on a task /
// subtask (not the estimated duration). Saving sets the value directly (a
// running timer keeps counting on top of it).
function timeEditor(entity, kind, onDone) {
  const input = el("input", {
    type: "number", min: "0", step: "1", class: "time-edit-input",
    value: String(Math.round((entity.time_spent_seconds || 0) / 60)),
    title: "Time actually spent, in minutes",
  });
  input.addEventListener("change", async () => {
    const minutes = Math.max(0, parseFloat(input.value) || 0);
    await api.patch(`/api/${kind}/${entity.id}`, { time_spent_seconds: Math.round(minutes * 60) });
    refreshActiveTimers();
    if (onDone) onDone(); else refreshCurrentView();
  });
  return el("span", { class: "time-editor", title: "Time actually spent, in minutes", onclick: (e) => e.stopPropagation() },
    [input, " min spent"]);
}

// Ticks every running timer-elapsed label once a second, purely client-side
// (base seconds + time since that value was read), so running timers feel
// live without re-fetching from the server on an interval.
function wireTimerTicker() {
  setInterval(() => {
    for (const label of document.querySelectorAll('.timer-elapsed[data-running="1"]')) {
      const base = parseInt(label.dataset.baseSeconds, 10) || 0;
      const since = parseInt(label.dataset.sinceMs, 10) || Date.now();
      const rate = parseInt(label.dataset.rate, 10) || 1;
      label.textContent = formatElapsed(base + rate * (Date.now() - since) / 1000);
    }
  }, 1000);
}
