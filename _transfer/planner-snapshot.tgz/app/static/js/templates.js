"use strict";

// Templates editor (Utilities > Templates).

/* ---------------------------------------------------------------------- *
 * Templates (Utilities > Templates) -- edit the task templates behind the "+"
 * menu (main task title, icons, main day, subtasks with duration / day offset /
 * start time, linked-note name) and create new ones. A change only affects
 * tasks created from the template afterwards.
 * ---------------------------------------------------------------------- */
const WEEKDAY_LONG = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

function wireTemplates() {
  document.getElementById("templatesBtn").addEventListener("click", openTemplatesView);
}

function tplEmptyDraft() {
  return { key: null, label: "", icon: "🎥", menu_icon: "🎥", task_title: "", main_weekday: 2, is_video: true,
           note_title: "", builtin: false, subtasks: [{ title: "", duration: 30, offset_days: 0, start_time: null }] };
}
function tplSelect(key) {
  const t = templateByKey(key);
  state.tplEditor = { key: t ? t.key : null, draft: t ? JSON.parse(JSON.stringify(t)) : null, dirty: false, isNew: false };
}
async function openTemplatesView() {
  state.view = { type: "templates", title: "Templates" };
  await refreshTemplates();
  const cur = state.tplEditor;
  if (!(cur.isNew || (cur.key && templateByKey(cur.key)))) tplSelect(state.templates[0] ? state.templates[0].key : null);
  renderMain();
  renderSidebar();
}
function tplErrorMessage(e) {
  let m = (e && e.message) || "Something went wrong";
  try { m = JSON.parse(m).error || m; } catch { /* not JSON */ }
  return m;
}
async function tplConfirmDiscard() {
  if (!state.tplEditor.dirty) return true;
  return confirmModal({ title: "Discard changes?", message: "This template has unsaved changes.", confirmLabel: "Discard", danger: true });
}

// Dates a template would produce if used right now (same rule as the server).
function tplPreview(draft) {
  if (draft.main_weekday === null || draft.main_weekday === undefined) return null;
  const now = new Date(); now.setHours(0, 0, 0, 0);
  const ahead = ((draft.main_weekday + 1) - ((now.getDay() + 6) % 7 + 1) + 7) % 7 || 7;   // Mon=0..Sun=6
  const base = new Date(now); base.setDate(base.getDate() + ahead);
  const fmt = (d) => d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
  const month = base.toLocaleString("en-GB", { month: "long" }), pad = (n) => String(n).padStart(2, "0");
  const title = (draft.task_title || "")
    .replaceAll("{dd}", pad(base.getDate())).replaceAll("{mm}", pad(base.getMonth() + 1)).replaceAll("{month}", month)
    .replaceAll("{yyyy}", String(base.getFullYear())).replaceAll("{yy}", pad(base.getFullYear() % 100));
  return {
    main: fmt(base), title,
    subs: draft.subtasks.map((s) => {
      if (s.offset_days === null || s.offset_days === undefined || s.offset_days === "") return "no date";
      const d = new Date(base); d.setDate(d.getDate() + Number(s.offset_days));
      return fmt(d);
    }),
  };
}

// Editor for the AI buttons of one template subtask (shown under its row).
function tplAiPanel(s, touch, repaint) {
  s.ai_buttons = s.ai_buttons || [];
  const box = el("div", { class: "tpl-ai" });
  box.appendChild(el("div", { class: "muted small" },
    "Buttons shown on this subtask in tasks created from the template. Placeholders usable in the instructions: {title} (task), {subtask}, {due_date}."));
  s.ai_buttons.forEach((b, k) => {
    b.sources = b.sources || { note_sections: [], task_notes: false };
    const card = el("div", { class: "tpl-ai-card" });
    const set = (fn) => { fn(); touch(); };
    const label = el("input", { type: "text", value: b.label || "", placeholder: "Button title", maxlength: "60" });
    label.addEventListener("input", () => set(() => { b.label = label.value; }));
    const kind = el("select", {}, [el("option", { value: "prompt" }, "Ask the AI (instructions)"), el("option", { value: "powerpoint" }, "PowerPoint generator"), el("option", { value: "list_to_ppt" }, "Army list to PowerPoint (Warhammer)"), el("option", { value: "chapters" }, "Chapters from Resolve swooshes"), el("option", { value: "capture" }, "Take captures (VIDEO note)"), el("option", { value: "montage" }, "Base edit in Resolve"), el("option", { value: "timestamps" }, "Timestamps from Resolve (VIDEO note)"), el("option", { value: "text_timestamps" }, "Timestamps + text boxes from Resolve (task note)"), el("option", { value: "thumbnails" }, "Create 3 thumbnails"), el("option", { value: "setup_edit" }, "Setup for editing (note + captures + base edit)")]);
    kind.value = b.kind || "prompt";
    kind.addEventListener("change", () => { b.kind = kind.value; touch(); repaint(); });
    card.appendChild(el("div", { class: "tpl-ai-head" }, [
      label, kind,
      el("button", { class: "icon-btn small", title: "Remove this button", onclick: () => { s.ai_buttons.splice(k, 1); touch(); repaint(); } }, "✕"),
    ]));
    if (b.kind === "chapters") {
      card.appendChild(el("div", { class: "muted small" }, "Reads the “swoosh” clips on track A2 of the timeline open in DaVinci Resolve, then rewrites the linked note: seconds before each topic in Timestamps (Intro = 0) and MM:SS before each topic in Links. Only the title is configurable."));
    } else if (b.kind === "thumbnails") {
      card.appendChild(el("div", { class: "muted small" }, "Runs “Generate ideas”, then builds 3 thumbnails (1920×1080 PNG) in your usual style: one “Linux & Open Source News”, two with a headline from the ideas and the “Linux Weekly News” label. Logos are downloaded from the web (never AI-generated). Only the title is configurable."));
    } else if (b.kind === "timestamps") {
      card.appendChild(el("div", { class: "muted small" }, "Reads the “swoosh” clips on track A2 of the timeline open in DaVinci Resolve (the one starting with the “Outro new” clip is ignored) and writes MM:SS before each topic in the Timestamps section of the task's “-VIDEO” note (Intro = 00:00; “Sponsor…” lines count as topics and get their own timestamp). Only the title is configurable."));
    } else if (b.kind === "text_timestamps") {
      card.appendChild(el("div", { class: "muted small" }, "Reads the “swoosh” clips on track A2 of the timeline open in DaVinci Resolve and, for each one, the text of the nearest text box on V1, V2 or V3, then writes “MM:SS text” lines in the Timestamps section of the task's linked note (previous lines of this kind are replaced). Only the title is configurable."));
    } else if (b.kind === "capture") {
      card.appendChild(el("div", { class: "muted small" }, "Runs the screenshot script (news_capture.py) on the task's “-VIDEO” note, then shows “Captures finished”. Only the title is configurable."));
    } else if (b.kind === "montage") {
      card.appendChild(el("div", { class: "muted small" }, "Runs the editing script (resolve_build_news.py) on the timeline open in DaVinci Resolve, using the captures of the task's “-VIDEO” note. No message when done. Only the title is configurable."));
    } else if (b.kind === "setup_edit") {
      card.appendChild(el("div", { class: "muted small" }, "Runs, in order: Create Video Note (an existing “-VIDEO” note is kept) → Take captures → Base edit (timeline open in DaVinci Resolve). Stops at the first step that fails and says what was already done. Only the title is configurable."));
    } else if (b.kind === "list_to_ppt") {
      card.appendChild(el("div", { class: "muted small" }, "Opens a dialog to paste a Warhammer 40,000 army list (Games Workshop app format), then builds a PowerPoint in your template: detachment rule, stratagems (3 per slide), force dispositions, one slide per unit, characters attached to their unit. Rules come from Wahapedia, in French. Only the title is configurable."));
    } else if ((b.kind || "prompt") === "powerpoint") {
      card.appendChild(el("div", { class: "muted small" }, "Opens the PowerPoint generator (links, document, prompt). Only the title is configurable."));
    } else {
      const ins = el("textarea", { rows: "8", placeholder: "What should the AI do? e.g. “Write 3 title ideas from the notes below…”", maxlength: "20000" });
      ins.value = b.instructions || "";
      ins.addEventListener("input", () => set(() => { b.instructions = ins.value; }));
      const sys = el("textarea", { rows: "2", placeholder: "Optional system prompt (the AI's role). Empty = YouTube channel assistant.", maxlength: "2000" });
      sys.value = b.system || "";
      sys.addEventListener("input", () => set(() => { b.system = sys.value; }));
      const mode = el("select", {}, [
        el("option", { value: "none" }, "No note content"),
        el("option", { value: "all" }, "Whole linked note"),
        el("option", { value: "sections" }, "Only these note sections"),
      ]);
      const secs = b.sources.note_sections;
      mode.value = secs === "all" ? "all" : (secs && secs.length ? "sections" : "none");
      const secInput = el("input", { type: "text", placeholder: "Timestamps, Links, Content", value: Array.isArray(secs) ? secs.join(", ") : "" });
      secInput.style.display = mode.value === "sections" ? "" : "none";
      mode.addEventListener("change", () => {
        b.sources.note_sections = mode.value === "all" ? "all" : (mode.value === "none" ? [] : secInput.value.split(",").map((x) => x.trim()).filter(Boolean));
        secInput.style.display = mode.value === "sections" ? "" : "none";
        touch();
      });
      secInput.addEventListener("input", () => set(() => { b.sources.note_sections = secInput.value.split(",").map((x) => x.trim()).filter(Boolean); }));
      const notes = el("input", { type: "checkbox", checked: b.sources.task_notes || undefined });
      notes.addEventListener("change", () => set(() => { b.sources.task_notes = notes.checked; }));
      const apply = el("input", { type: "checkbox", checked: b.apply_to_note || undefined });
      apply.addEventListener("change", () => set(() => { b.apply_to_note = apply.checked; }));
      const post = el("select", {}, [el("option", { value: "none" }, "Show the answer as is"), el("option", { value: "youtube_tags" }, "YouTube tags (clean up, max 500 characters)")]);
      post.value = b.post || "none";
      post.addEventListener("change", () => set(() => { b.post = post.value; }));
      card.appendChild(el("div", { class: "field" }, [el("label", {}, "Instructions for the AI"), ins]));
      card.appendChild(el("div", { class: "field" }, [el("label", {}, "System prompt (optional)"), sys]));
      card.appendChild(el("div", { class: "tpl-ai-opts" }, [
        el("div", { class: "field" }, [el("label", {}, "Send the linked note"), mode, secInput]),
        el("div", { class: "field" }, [el("label", {}, "After the answer"), post]),
      ]));
      card.appendChild(el("label", { class: "tpl-check" }, [notes, el("span", {}, "Also send the task's Notes field")]));
      card.appendChild(el("label", { class: "tpl-check" }, [apply, el("span", {}, "Offer “Replace / Append to note” (the answer must keep the same ## headings)")]));
    }
    box.appendChild(card);
  });
  if (s.ai_buttons.length < 6) box.appendChild(el("button", {
    class: "btn small",
    onclick: () => {
      s.ai_buttons.push({ id: "", label: "", kind: "prompt", instructions: "", system: "", sources: { note_sections: [], task_notes: false }, apply_to_note: false, post: "none" });
      touch(); repaint();
    },
  }, "＋ Add an AI button"));
  return box;
}

function renderTemplatesView() {
  const ed = state.tplEditor;
  const wrap = el("div", { class: "tpl-wrap" });

  /* -- left: list -- */
  const list = el("div", { class: "tpl-list" });
  list.appendChild(el("button", {
    class: "btn primary", style: "width:100%;margin-bottom:10px",
    onclick: async () => {
      if (!(await tplConfirmDiscard())) return;
      state.tplEditor = { key: null, draft: tplEmptyDraft(), dirty: true, isNew: true };
      renderMain();
    },
  }, "＋ New template"));
  state.templates.forEach((t, i) => {
    const move = async (dir) => {
      const keys = state.templates.map((x) => x.key);
      const j = i + dir;
      if (j < 0 || j >= keys.length) return;
      [keys[i], keys[j]] = [keys[j], keys[i]];
      state.templates = await api.send("PUT", "/api/template-order", { keys });
      renderMain();
    };
    list.appendChild(el("div", {
      class: "tpl-row" + (!ed.isNew && ed.key === t.key ? " active" : ""),
      onclick: async () => {
        if (!ed.isNew && ed.key === t.key) return;
        if (!(await tplConfirmDiscard())) return;
        tplSelect(t.key);
        renderMain();
      },
    }, [
      el("span", { class: "tpl-row-icon" }, t.menu_icon || t.icon || "🎥"),
      el("span", { class: "tpl-row-label" }, [t.label, t.builtin ? el("span", { class: "tpl-tag" }, "built-in") : null]),
      el("span", { class: "tpl-row-move" }, [
        el("button", { class: "icon-btn small", title: "Move up", disabled: i === 0 || undefined, onclick: (e) => { e.stopPropagation(); move(-1); } }, "↑"),
        el("button", { class: "icon-btn small", title: "Move down", disabled: i === state.templates.length - 1 || undefined, onclick: (e) => { e.stopPropagation(); move(1); } }, "↓"),
      ]),
    ]));
  });
  if (ed.isNew) list.appendChild(el("div", { class: "tpl-row active" }, [
    el("span", { class: "tpl-row-icon" }, ed.draft.menu_icon || "🎥"),
    el("span", { class: "tpl-row-label" }, [ed.draft.label || "New template", el("span", { class: "tpl-tag" }, "unsaved")]),
  ]));
  wrap.appendChild(list);

  /* -- right: editor -- */
  const d = ed.draft;
  const editor = el("div", { class: "tpl-editor" });
  if (!d) {
    editor.appendChild(el("div", { class: "empty-state" }, [el("div", {}, "No template yet — create one with “New template”.")]));
    wrap.appendChild(editor);
    return wrap;
  }

  const saveBtn = el("button", { class: "btn primary" }, "Save");
  const dirtyNote = el("span", { class: "muted small tpl-dirty" }, "");
  const preview = el("div", { class: "tpl-preview muted small" });
  const paintMeta = () => {
    saveBtn.disabled = !ed.dirty;
    dirtyNote.textContent = ed.dirty ? "Unsaved changes" : "";
    const pv = tplPreview(d);
    preview.innerHTML = "";
    if (!pv) { preview.textContent = "No main day: the task and its subtasks are created with no due date; you schedule them yourself."; return; }
    preview.appendChild(el("div", {}, `If created now: “${pv.title || "…"}” on ${pv.main}`));
    d.subtasks.forEach((s, i) => preview.appendChild(el("div", { style: "padding-left:12px" },
      `• ${s.title || "…"} — ${pv.subs[i]}${s.start_time ? " at " + s.start_time : ""}${s.duration ? " (" + formatDuration(s.duration) + ")" : ""}`)));
  };
  const touch = () => { ed.dirty = true; paintMeta(); };
  const bind = (input, key, conv) => { input.addEventListener("input", () => { d[key] = conv ? conv(input.value) : input.value; touch(); }); return input; };
  const field = (label, input, hint) => el("div", { class: "field" }, [el("label", {}, label), input, hint ? el("div", { class: "muted small", style: "margin-top:3px" }, hint) : null]);

  const weekdaySelect = el("select", {}, [
    el("option", { value: "" }, "None — no automatic due date"),
    ...WEEKDAY_LONG.map((n, i) => el("option", { value: String(i) }, n)),
  ]);
  weekdaySelect.value = d.main_weekday === null || d.main_weekday === undefined ? "" : String(d.main_weekday);
  weekdaySelect.addEventListener("change", () => { d.main_weekday = weekdaySelect.value === "" ? null : Number(weekdaySelect.value); touch(); });
  const isVideo = el("input", { type: "checkbox", checked: d.is_video || undefined });
  isVideo.addEventListener("change", () => { d.is_video = isVideo.checked; touch(); });

  editor.appendChild(el("div", { class: "tpl-grid" }, [
    field("Template name", bind(el("input", { type: "text", value: d.label, placeholder: "e.g. Short video", maxlength: "80" }), "label"), "Shown in the “+” menu and in the task's Video type."),
    field("Main task title", bind(el("input", { type: "text", value: d.task_title, placeholder: "e.g. New short", maxlength: "200" }), "task_title"), "Title given to the task when it is created. Placeholders: {dd} {mm} {month} {yy} {yyyy} (date = due date), e.g. “Weekly News Video {dd} {month}”."),
    field("Icon on tasks", bind(el("input", { type: "text", value: d.icon, maxlength: "8", style: "width:90px" }), "icon"), "Next to the task title in lists and the calendar."),
    field("Icon in “+” menu", bind(el("input", { type: "text", value: d.menu_icon, maxlength: "8", style: "width:90px" }), "menu_icon")),
    field("Main task day", weekdaySelect, "The task is due on the next such day; subtask dates are offset from it."),
    field("Linked-note name", bind(el("input", { type: "text", value: d.note_title, placeholder: "Linux News Podcast {dd} {month} {yy}" }), "note_title"),
      "Used by “Create note” on tasks of this type. Placeholders: {dd} {mm} {month} {yy} {yyyy} {title} (date = task due date). Empty = task title."),
  ]));
  editor.appendChild(el("label", { class: "tpl-check" }, [isVideo, el("span", {}, "Created as a video (shows in the “only videos” calendar filter)")]));

  /* subtasks */
  editor.appendChild(el("h3", { class: "tpl-h" }, "Subtasks"));
  const subsBox = el("div", { class: "tpl-subs" });
  const numConv = (v) => (v === "" ? null : Number(v));
  const openAi = new Set();
  function paintSubs() {
    subsBox.innerHTML = "";
    subsBox.appendChild(el("div", { class: "tpl-sub tpl-sub-head muted small" }, [
      el("span", {}, "Title"), el("span", {}, "Duration (min)"), el("span", {}, "Day offset"), el("span", {}, "Start time"), el("span", {}),
    ]));
    d.subtasks.forEach((s, i) => {
      const move = (dir) => { const j = i + dir; if (j < 0 || j >= d.subtasks.length) return; [d.subtasks[i], d.subtasks[j]] = [d.subtasks[j], d.subtasks[i]]; touch(); paintSubs(); };
      const t = el("input", { type: "text", value: s.title, placeholder: "Subtask title", maxlength: "200" });
      const du = el("input", { type: "number", min: "1", value: s.duration ?? "", placeholder: "—" });
      const of = el("input", { type: "number", value: s.offset_days ?? "", placeholder: "none", title: "Days from the main task's date: -1 = the day before, 0 = same day, empty = no date" });
      const st = el("input", { type: "time", value: s.start_time || "" });
      t.addEventListener("input", () => { s.title = t.value; touch(); });
      du.addEventListener("input", () => { s.duration = numConv(du.value); touch(); });
      of.addEventListener("input", () => { s.offset_days = numConv(of.value); touch(); });
      st.addEventListener("input", () => { s.start_time = st.value || null; touch(); });
      const nAi = (s.ai_buttons || []).length;
      const aiToggle = el("button", {
        class: "icon-btn small tpl-ai-toggle" + (nAi ? " has" : ""), title: "AI buttons shown on this subtask",
        onclick: () => { openAi.has(s) ? openAi.delete(s) : openAi.add(s); paintSubs(); },
      }, `✨${nAi || ""}`);
      const row = el("div", { class: "tpl-sub" }, [
        t, du, of, st,
        el("span", { class: "tpl-sub-actions" }, [
          aiToggle,
          el("button", { class: "icon-btn small", title: "Move up", disabled: i === 0 || undefined, onclick: () => move(-1) }, "↑"),
          el("button", { class: "icon-btn small", title: "Move down", disabled: i === d.subtasks.length - 1 || undefined, onclick: () => move(1) }, "↓"),
          el("button", { class: "icon-btn small", title: "Remove", onclick: () => { openAi.delete(s); d.subtasks.splice(i, 1); touch(); paintSubs(); } }, "✕"),
        ]),
      ]);
      subsBox.appendChild(el("div", { class: "tpl-sub-block" }, [row, openAi.has(s) ? tplAiPanel(s, touch, paintSubs) : null]));
    });
    subsBox.appendChild(el("button", {
      class: "btn", style: "margin-top:8px",
      onclick: () => { d.subtasks.push({ title: "", duration: 30, offset_days: d.main_weekday === null ? null : 0, start_time: null }); touch(); paintSubs(); },
    }, "＋ Add subtask"));
    paintMeta();
  }
  weekdaySelect.addEventListener("change", paintMeta);
  editor.appendChild(subsBox);
  paintSubs();
  editor.appendChild(el("div", { class: "tpl-preview-box" }, [el("div", { class: "tpl-h2" }, "Preview"), preview]));

  /* actions */
  saveBtn.addEventListener("click", async () => {
    if (!d.label.trim()) { showToast("Give the template a name"); return; }
    if (!d.task_title.trim()) { showToast("Give the main task a title"); return; }
    if (d.subtasks.some((s) => !s.title.trim())) { showToast("Every subtask needs a title (or remove the empty one)"); return; }
    try {
      const payload = { ...d, subtasks: d.subtasks.map((s) => ({ id: s.id || "", title: s.title, duration: s.duration, offset_days: s.offset_days, start_time: s.start_time, ai_buttons: s.ai_buttons || [] })) };
      const saved = ed.isNew ? await api.post("/api/templates", payload) : await api.send("PUT", `/api/templates/${ed.key}`, payload);
      await refreshTemplates();
      tplSelect(saved.key);
      showToast("Template saved");
      renderMain();
    } catch (e) { showToast(tplErrorMessage(e)); }
  });
  const actions = el("div", { class: "btn-row spread tpl-actions" });
  const left = el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" });
  const right = el("div", { style: "display:flex;gap:8px;align-items:center" }, [dirtyNote, saveBtn]);
  if (!ed.isNew) {
    left.appendChild(el("button", {
      class: "btn", title: "Create a copy of this template to edit",
      onclick: async () => {
        if (!(await tplConfirmDiscard())) return;
        const copy = JSON.parse(JSON.stringify(d));
        copy.key = null; copy.builtin = false; copy.label = `${d.label} (copy)`;
        state.tplEditor = { key: null, draft: copy, dirty: true, isNew: true };
        renderMain();
      },
    }, "Duplicate"));
    if (d.builtin) {
      left.appendChild(el("button", {
        class: "btn", title: "Restore this built-in template's original settings",
        onclick: async () => {
          if (!(await confirmModal({ title: "Reset to default?", message: `“${d.label}” goes back to its original settings. Tasks already created are not changed.`, confirmLabel: "Reset", danger: true }))) return;
          try { await api.post(`/api/templates/${ed.key}/reset`, {}); await refreshTemplates(); tplSelect(ed.key); showToast("Template reset"); renderMain(); }
          catch (e) { showToast(tplErrorMessage(e)); }
        },
      }, "Reset to default"));
    } else {
      left.appendChild(el("button", {
        class: "btn danger",
        onclick: async () => {
          if (!(await confirmModal({ title: "Delete template?", message: `“${d.label}” will be removed from the “+” menu. Tasks already created from it are not changed.`, confirmLabel: "Delete", danger: true }))) return;
          try { await api.del(`/api/templates/${ed.key}`); await refreshTemplates(); tplSelect(state.templates[0] ? state.templates[0].key : null); showToast("Template deleted"); renderMain(); }
          catch (e) { showToast(tplErrorMessage(e)); }
        },
      }, "Delete"));
    }
  } else {
    left.appendChild(el("button", {
      class: "btn",
      onclick: () => { tplSelect(state.templates[0] ? state.templates[0].key : null); renderMain(); },
    }, "Cancel"));
  }
  actions.appendChild(left);
  actions.appendChild(right);
  editor.appendChild(actions);
  editor.appendChild(el("div", { class: "muted small", style: "margin-top:10px" },
    "Dates, durations and subtasks apply to tasks created from now on; existing tasks are left as they are. AI buttons (title and instructions) apply right away, including to existing tasks made from this template."));
  wrap.appendChild(editor);
  return wrap;
}
