"use strict";

// Time report.

/* ---------------------------------------------------------------------- *
 * Time report — stacked bar chart of tracked time, per week or per month,
 * grouped by Activity (same subtask name; a main task's own time counts
 * under the task's name) or by Project (same main task name).
 * ---------------------------------------------------------------------- */
const REPORT_COLORS = ["#3daee9", "#f39c12", "#2ecc71", "#9b59b6", "#e91e63", "#1abc9c", "#e67e22", "#5c6bc0"];
const REPORT_OTHER_COLOR = "#9aa0a6";
// bars shown: 5 weeks / 12 months / the 7 days of one week ("thisweek")
const reportPeriodCount = (gran) => (gran === "week" ? 5 : gran === "thisweek" ? 7 : 12);
// how many periods the ‹ › buttons move: a whole window, or one week for "thisweek"
const reportStepCount = (gran) => (gran === "thisweek" ? 1 : reportPeriodCount(gran));
// Colors come from the API and are interpolated into SVG/HTML strings: only plain hex is accepted.
function safeColor(c, fallback = "#7f8c8d") {
  return typeof c === "string" && /^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(c) ? c : fallback;
}
const escHtml = (t) => String(t).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// "thisweek": the anchor is the Monday of the shown week, each bar is one day
function reportPeriodStart(iso, gran) {
  if (gran === "thisweek") return iso;
  return gran === "month" ? iso.slice(0, 8) + "01" : startOfWeekIso(iso);
}
function reportNextPeriod(start, gran) {
  if (gran === "week" || gran === "thisweek") return addDaysIso(start, 7);
  const d = parseIso(start);
  return toIso(new Date(d.getFullYear(), d.getMonth() + 1, 1));
}
function reportPrevPeriod(start, gran) {
  if (gran === "week" || gran === "thisweek") return addDaysIso(start, -7);
  const d = parseIso(start);
  return toIso(new Date(d.getFullYear(), d.getMonth() - 1, 1));
}
function isoWeekNumber(iso) {
  const d = parseIso(iso);
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  t.setUTCDate(t.getUTCDate() + 4 - (t.getUTCDay() || 7));
  return Math.ceil(((t - Date.UTC(t.getUTCFullYear(), 0, 1)) / 86400000 + 1) / 7);
}
function reportWeekRange(start) {
  const a = parseIso(start), b = parseIso(addDaysIso(start, 6));
  const m = (d) => MONTH_NAMES[d.getMonth()].slice(0, 3);
  return a.getMonth() === b.getMonth() ? `${a.getDate()}–${b.getDate()} ${m(b)}` : `${a.getDate()} ${m(a)}–${b.getDate()} ${m(b)}`;
}
function reportPeriodLabel(start, gran, long) {
  const d = parseIso(start);
  if (gran === "thisweek") {
    const wd = WEEKDAY_NAMES[(d.getDay() + 6) % 7];
    return long ? `${wd} ${d.getDate()} ${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}` : wd;
  }
  if (gran === "month") return long ? `${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}` : `${MONTH_NAMES[d.getMonth()].slice(0, 3)} ${String(d.getFullYear()).slice(2)}`;
  const mon = `${d.getDate()} ${MONTH_NAMES[d.getMonth()].slice(0, 3)}`;
  if (!long) return `W${isoWeekNumber(start)}`;
  return `Week ${isoWeekNumber(start)} · ${reportWeekRange(start)} ${parseIso(addDaysIso(start, 6)).getFullYear()}`;
}

async function openTimeReport() {
  const tr = state.timeReport;
  state.view = { type: "timereport", title: "Time report" };
  if (tr.insights) tr.insights.collapsed = true;    // coming back to the page: insights start collapsed
  if (!tr.anchor) tr.anchor = reportAnchorNow(tr.gran);
  renderSidebar();
  await loadTimeReport();
}

// The anchor to show "now": the last period (week / month) or the current week's Monday.
function reportAnchorNow(gran) {
  return gran === "thisweek" ? startOfWeekIso(todayIso()) : reportPeriodStart(todayIso(), gran);
}

async function loadTimeReport() {
  const tr = state.timeReport;
  const periods = [];
  if (tr.gran === "thisweek") {
    for (let i = 0; i < 7; i++) periods.push(addDaysIso(tr.anchor, i));
  } else {
    let p = tr.anchor;
    for (let i = 0; i < reportPeriodCount(tr.gran); i++) { periods.unshift(p); p = reportPrevPeriod(p, tr.gran); }
  }
  tr.periods = periods;
  const end = tr.gran === "thisweek" ? periods[6] : addDaysIso(reportNextPeriod(tr.anchor, tr.gran), -1);
  tr.entries = await api.get(`/api/reports/time?start=${periods[0]}&end=${end}`);
  if (tr.gran === "thisweek") tr.stored = {};       // insights are stored per week / month, not per day
  else {
    try { tr.stored = await api.get(`/api/reports/time/insights?kind=${tr.gran}&start=${periods[0]}&end=${periods[periods.length - 1]}`); }
    catch (_) { tr.stored = {}; }
  }
  if (!tr.selected || !periods.includes(tr.selected)) {
    tr.selected = (tr.gran === "thisweek" && periods.includes(todayIso())) ? todayIso() : periods[periods.length - 1];
  }
  renderMain();
}

// Minimal markdown (## headings, - bullets, **bold**, paragraphs) for the insights text.
function insightsMarkdown(md) {
  const inline = (t) => escHtml(t).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>");
  let html = "", list = null;
  const close = () => { if (list) { html += `</${list}>`; list = null; } };
  for (const raw of String(md).split("\n")) {
    const line = raw.trim();
    let m;
    if (!line) { close(); continue; }
    if ((m = line.match(/^#{1,4}\s+(.*)/))) { close(); html += `<h3>${inline(m[1])}</h3>`; }
    else if ((m = line.match(/^[-*•]\s+(.*)/))) { if (list !== "ul") { close(); html += "<ul>"; list = "ul"; } html += `<li>${inline(m[1])}</li>`; }
    else if ((m = line.match(/^\d+[.)]\s+(.*)/))) { if (list !== "ol") { close(); html += "<ol>"; list = "ol"; } html += `<li>${inline(m[1])}</li>`; }
    else { close(); html += `<p>${inline(line)}</p>`; }
  }
  close();
  return html;
}

// Stored (auto-generated) insights of the selected week / month.
function renderPeriodInsights(tr, period, hasTime) {
  const stored = (tr.stored || {})[period];
  const loadingKey = `${tr.gran}:${period}`;
  const label = tr.gran === "week" ? "week" : "month";
  const box = el("div", { class: "insights-box period-insights" + (tr.periodCollapsed ? " collapsed" : "") });
  const generate = async () => {
    tr.periodLoading = loadingKey; tr.periodError = ""; renderMain();
    try {
      const r = await api.post("/api/reports/time/insights", { kind: tr.gran, start: period });
      (tr.stored || (tr.stored = {}))[period] = { text: r.result, generated_at: r.generated_at };
    } catch (err) { tr.periodError = (err && err.message) || String(err); }
    tr.periodLoading = null; renderMain();
  };
  if (tr.periodLoading === loadingKey) {
    box.appendChild(el("div", { class: "muted" }, `The AI is analysing this ${label}… this can take up to a minute.`));
    return box;
  }
  if (!stored) {
    if (!hasTime) return el("span");
    const when = tr.gran === "week" ? "on Sunday" : "on the 1st of the next month";
    box.appendChild(el("div", { class: "insights-none" }, [
      el("span", { class: "muted" }, `No insights stored for this ${label} yet — they're generated automatically ${when}.`),
      el("button", { class: "btn small", onclick: generate }, "✨ Generate now"),
    ]));
    if (tr.periodError) box.appendChild(el("div", { class: "insights-error" }, tr.periodError));
    return box;
  }
  const head = el("button", { type: "button", class: "insights-head", onclick: () => {
    tr.periodCollapsed = !tr.periodCollapsed;
    box.classList.toggle("collapsed", tr.periodCollapsed);
  } }, [el("span", { class: "insights-chevron" }, "▾"), el("strong", {}, `✨ Insights for this ${label}`),
        el("span", { class: "muted small" }, `generated ${String(stored.generated_at).replace("T", " ")}`)]);
  const body = el("div", { class: "insights-body" });
  body.innerHTML = insightsMarkdown(stored.text);
  const regen = el("button", { class: "btn small", style: "margin-top:8px", onclick: generate }, "Regenerate");
  box.appendChild(head);
  box.appendChild(el("div", { class: "insights-collapse" }, [el("div", { class: "insights-inner" }, [body, regen])]));
  if (tr.periodError) box.appendChild(el("div", { class: "insights-error" }, tr.periodError));
  return box;
}

function renderTimeReport() {
  const tr = state.timeReport;
  const wrap = el("div", { class: "report-wrap" });
  const setTab = (tab) => { tr.tab = tab; renderMain(); };
  const setGran = (gran) => {
    if (tr.gran === gran) return;
    tr.gran = gran; tr.anchor = reportAnchorNow(gran); tr.selected = null; loadTimeReport();
  };
  const seg = (items, current, onPick) => el("div", { class: "seg" }, items.map(([key, label]) =>
    el("button", { type: "button", class: "seg-btn" + (current === key ? " active" : ""), onclick: () => onPick(key) }, label)));

  const thisPeriod = reportAnchorNow(tr.gran);
  wrap.appendChild(el("div", { class: "report-controls" }, [
    seg([["activity", "By Activity"], ["project", "By Project"], ["company", "By Company"]], tr.tab, setTab),
    seg([["thisweek", "This week"], ["week", "Week by week"], ["month", "Month by month"]], tr.gran, setGran),
    el("div", { class: "report-nav" }, [
      el("button", { class: "icon-btn", title: "Earlier", onclick: () => { for (let i = 0; i < reportStepCount(tr.gran); i++) tr.anchor = reportPrevPeriod(tr.anchor, tr.gran); tr.selected = null; loadTimeReport(); } }, "‹"),
      el("button", { class: "btn small", onclick: () => { tr.anchor = thisPeriod; tr.selected = null; loadTimeReport(); } }, "Today"),
      el("button", { class: "icon-btn", title: "Later", onclick: () => { for (let i = 0; i < reportStepCount(tr.gran); i++) tr.anchor = reportNextPeriod(tr.anchor, tr.gran); tr.selected = null; loadTimeReport(); } }, "›"),
    ]),
  ]));

  // Group entries: period start -> group name -> seconds (names merged case-insensitively).
  const byPeriod = new Map(tr.periods.map((p) => [p, new Map()]));
  const display = new Map();      // lower-cased name -> first-seen display name
  const totals = new Map();       // lower-cased name -> total over the window
  for (const e of tr.entries) {
    const per = reportPeriodStart(e.date, tr.gran);   // for "thisweek" this is the day itself
    const bucket = byPeriod.get(per);
    if (!bucket) continue;
    const name = ((tr.tab === "activity" ? e.activity : tr.tab === "company" ? e.company : e.project) || "(untitled)").trim();
    const key = name.toLowerCase();
    if (!display.has(key)) display.set(key, name);
    bucket.set(key, (bucket.get(key) || 0) + e.seconds);
    totals.set(key, (totals.get(key) || 0) + e.seconds);
  }
  const ranked = [...totals.entries()].sort((a, b) => b[1] - a[1]).map(([k]) => k);
  const colorOf = new Map(ranked.slice(0, REPORT_COLORS.length).map((k, i) => [k, REPORT_COLORS[i]]));
  // By Company: each bar uses its app project's own colour ("Other tasks": neutral grey)
  if (tr.tab === "company") {
    for (const k of ranked) {
      const proj = state.projects.find((p) => (p.name || "").trim().toLowerCase() === k);
      colorOf.set(k, proj ? proj.color : (k === "other tasks" ? "#7f8c8d" : REPORT_OTHER_COLOR));
    }
  }
  const colorFor = (k) => safeColor(colorOf.get(k) || REPORT_OTHER_COLOR);
  const periodTotal = (p) => [...byPeriod.get(p).values()].reduce((a, b) => a + b, 0);

  if (!ranked.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("clock"),
      el("div", {}, tr.gran === "thisweek" ? "No tracked time this week" : "No tracked time in this period"),
    ]));
    return wrap;
  }

  if (tr.gran === "thisweek") {
    const weekTotal = tr.periods.reduce((a, p) => a + periodTotal(p), 0);
    wrap.appendChild(el("div", { class: "report-detail-head", style: "margin:4px 0 6px" }, [
      el("h3", { style: "margin:0" }, reportPeriodLabel(tr.periods[0], "week", true)),
      el("span", { class: "muted" }, `Week total ${formatElapsed(weekTotal)}`),
    ]));
  }

  // ---- stacked bar chart (SVG) ----
  const W = 760, H = 292, L = 44, R = 8, T = 12, B = 42;
  const maxSec = Math.max(...tr.periods.map(periodTotal), 1);
  const stepH = [0.25, 0.5, 1, 2, 4, 5, 10, 20, 40, 50, 100].find((s) => maxSec / 3600 / s <= 5) || 100;
  const topH = Math.ceil(maxSec / 3600 / stepH) * stepH;
  const plotH = H - T - B, slot = (W - L - R) / tr.periods.length, barW = Math.min(44, slot * 0.64);
  const yOf = (sec) => T + plotH - (sec / 3600 / topH) * plotH;
  let svg = `<svg viewBox="0 0 ${W} ${H}" class="report-chart" role="img" aria-label="Tracked time per ${tr.gran}">`;
  for (let h = 0; h <= topH + 1e-9; h += stepH) {
    const y = yOf(h * 3600);
    svg += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" class="rc-grid"/><text x="${L - 6}" y="${y + 4}" text-anchor="end" class="rc-axis">${+h.toFixed(2)}h</text>`;
  }
  tr.periods.forEach((p, i) => {
    const x = L + slot * i + (slot - barW) / 2;
    const sel = p === tr.selected;
    svg += `<g class="rc-bar${sel ? " sel" : ""}" data-period="${p}">`;
    svg += `<rect x="${L + slot * i}" y="${T}" width="${slot}" height="${plotH}" class="rc-hit"/>`;
    let acc = 0;
    const segs = [...byPeriod.get(p).entries()].sort((a, b) => (ranked.indexOf(a[0]) - ranked.indexOf(b[0])));
    for (const [k, sec] of segs) {
      const y1 = yOf(acc + sec), y0 = yOf(acc);
      svg += `<rect x="${x}" y="${y1}" width="${barW}" height="${Math.max(0.5, y0 - y1)}" fill="${colorFor(k)}" class="rc-seg"><title>${escHtml(display.get(k))} — ${formatElapsed(sec)}</title></rect>`;
      acc += sec;
    }
    const tot = periodTotal(p);
    if (tot > 0) svg += `<text x="${x + barW / 2}" y="${yOf(tot) - 4}" text-anchor="middle" class="rc-total">${formatElapsed(tot)}</text>`;
    svg += `<text x="${x + barW / 2}" y="${H - 24}" text-anchor="middle" class="rc-axis${sel ? " rc-axis-sel" : ""}">${escHtml(reportPeriodLabel(p, tr.gran, false))}</text>`;
    if (tr.gran === "week") svg += `<text x="${x + barW / 2}" y="${H - 10}" text-anchor="middle" class="rc-axis rc-range">${escHtml(reportWeekRange(p))}</text>`;
    if (tr.gran === "thisweek") { const d = parseIso(p); svg += `<text x="${x + barW / 2}" y="${H - 10}" text-anchor="middle" class="rc-axis rc-range">${d.getDate()} ${MONTH_NAMES[d.getMonth()].slice(0, 3)}</text>`; }
    svg += "</g>";
  });
  svg += "</svg>";
  const chart = el("div", { class: "report-chart-box" });
  chart.innerHTML = svg;
  chart.querySelectorAll(".rc-bar").forEach((g) => g.addEventListener("click", () => { tr.selected = g.dataset.period; renderMain(); }));
  wrap.appendChild(chart);

  // ---- legend ----
  const legend = el("div", { class: "report-legend" });
  for (const k of (tr.tab === "company" ? ranked : ranked.slice(0, REPORT_COLORS.length))) {
    legend.appendChild(el("span", { class: "legend-item" }, [el("span", { class: "dot", style: `background:${colorFor(k)}` }), display.get(k)]));
  }
  if (tr.tab !== "company" && ranked.length > REPORT_COLORS.length) legend.appendChild(el("span", { class: "legend-item" }, [el("span", { class: "dot", style: `background:${REPORT_OTHER_COLOR}` }), "Other"]));
  wrap.appendChild(legend);

  // ---- breakdown of the selected period ----
  const sel = tr.selected;
  const rows = [...byPeriod.get(sel).entries()].sort((a, b) => b[1] - a[1]);
  const tot = periodTotal(sel);
  const detail = el("div", { class: "report-detail" }, [
    el("div", { class: "report-detail-head" }, [
      el("h3", { style: "margin:0" }, reportPeriodLabel(sel, tr.gran, true)),
      el("span", { class: "muted" }, `Total ${formatElapsed(tot)}`),
    ]),
  ]);
  if (tr.gran !== "thisweek") detail.appendChild(renderPeriodInsights(tr, sel, rows.length > 0));
  if (!rows.length) detail.appendChild(el("div", { class: "muted" }, "Nothing tracked in this period."));
  for (const [k, sec] of rows) {
    const pct = tot ? (sec / tot) * 100 : 0;
    detail.appendChild(el("div", { class: "report-row" }, [
      el("span", { class: "dot", style: `background:${colorFor(k)}` }),
      el("span", { class: "report-row-name" }, display.get(k)),
      el("span", { class: "report-row-bar" }, [el("span", { style: `width:${pct}%;background:${colorFor(k)}` })]),
      el("span", { class: "report-row-time" }, formatElapsed(sec)),
      el("span", { class: "muted report-row-pct" }, `${Math.round(pct)}%`),
    ]));
  }
  detail.appendChild(el("div", { class: "muted small", style: "margin-top:10px" },
    "Time is counted on the day it was tracked. Time recorded before per-day tracking existed is placed on the best-known day (when it was last tracked or finished)."));
  wrap.appendChild(detail);
  return wrap;
}
