"use strict";

// Task list and rows.

/* ---------------------------------------------------------------------- *
 * Task list & rows
 * ---------------------------------------------------------------------- */
function renderTaskList(tasks, opts = {}) {
  const wrap = el("div", {});
  if (!tasks.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon(opts.emptyIcon || "checkCircle"),
      el("div", {}, opts.emptyText || "Nothing here"),
    ]));
    return wrap;
  }
  for (const t of tasks) wrap.appendChild(taskRow(t, opts));
  return wrap;
}

function taskRow(task, opts = {}) {
  const due = formatDue(task.due_date);
  const checked = !!task.checked;
  const finishedOcc = !!task.is_completed_occurrence;
  const projected = !!task.is_projected || finishedOcc;

  const checkbox = el("div", {
    class: "checkbox" + (checked ? " checked" : "") + (projected ? " disabled" : ""),
    title: finishedOcc ? "This occurrence is finished" : (projected ? "This is an upcoming occurrence — open the task to manage it" : ""),
    onclick: async (e) => {
      e.stopPropagation();
      if (projected) {
        showToast(finishedOcc ? "This occurrence is already finished" : "This is a future occurrence — open the task to see its current status");
        return;
      }
      const res = await api.post(`/api/tasks/${task.id}/toggle`, { checked: !checked });
      if (res.result === "recurred") showToast("Task rescheduled to next occurrence");
      refreshCurrentView();
    },
  }, checked ? "✓" : "");

  const metaBits = [];
  if (due.text) metaBits.push(el("span", { class: due.overdue ? "overdue" : "" }, due.text));
  if (task.recurrence) metaBits.push(el("span", {}, "🔁 " + describeRecurrence(task.recurrence)));
  if (task.is_projected) metaBits.push(el("span", { class: "muted" }, "upcoming occurrence"));
  if (task.duration_minutes) metaBits.push(el("span", { class: "duration-chip" }, "⏱ " + formatDuration(task.duration_minutes)));
  // Today / Tomorrow: only the subtasks that are due in that view
  const shownSubs = (opts.smartType === "today" || opts.smartType === "tomorrow")
    ? (task.subtasks || []).filter((s) => s.matches_filter !== false)
    : (task.subtasks || []);
  const hasSubtasks = !opts.suppressSubtasks && shownSubs.length;
  const expanded = state.expandedSubtasks.has(task.id);
  if (shownSubs.length) {
    const done = shownSubs.filter((s) => s.checked).length;
    metaBits.push(el("span", { class: "muted" }, `☑ ${done}/${shownSubs.length}`));
  }
  if (task.attachment_name) metaBits.push(el("span", {}, "📎 " + task.attachment_name));
  for (const g of task.tags || []) {
    metaBits.push(el("span", { class: "task-label-chip", style: `color:${g.color}` }, g.name));
  }
  if (opts.showListHint && task.todo_list_name) {
    metaBits.push(el("span", { style: "margin-left:auto" }, `${task.project_name} / ${task.todo_list_name}`));
  }

  const titleBits = [
    (!checked && due.overdue) ? el("span", { class: "overdue-clock", title: "Overdue" }, "⏰ ") : null,
    task.urgent ? el("span", { class: "urgent-flag", title: "Urgent" }, "🚩 ") : null,
    task.is_video ? el("span", { class: "video-badge", title: templateLabel(task.video_template) },
      videoTitleIcon(task.video_template) + " ") : null,
    task.title,
  ];

  const list = hasSubtasks ? el("div", { class: "subtask-list" + (expanded ? " expanded" : "") }) : null;
  if (hasSubtasks) for (const s of shownSubs) list.appendChild(subtaskRow(s, task, { plain: !!opts.smartType }));

  const foldToggle = hasSubtasks ? el("button", {
    class: "fold-toggle" + (expanded ? " expanded" : ""),
    title: expanded ? "Hide subtasks" : "Show subtasks",
    onclick: (e) => {
      e.stopPropagation();
      const nowExpanded = !state.expandedSubtasks.has(task.id);
      if (nowExpanded) state.expandedSubtasks.add(task.id); else state.expandedSubtasks.delete(task.id);
      foldToggle.classList.toggle("expanded", nowExpanded);
      foldToggle.title = nowExpanded ? "Hide subtasks" : "Show subtasks";
      list.classList.toggle("expanded", nowExpanded);
    },
  }, "▸") : el("span", { class: "fold-toggle placeholder" });

  const row = el("div", { class: "task-row", onclick: () => openTaskDetail(task.id) }, [
    foldToggle,
    checkbox,
    el("div", { class: "task-main" }, [
      el("div", { class: "task-content" + (checked ? " done" : "") }, titleBits),
      metaBits.length ? el("div", { class: "task-meta" }, metaBits) : null,
    ]),
    timerControls(task, "tasks"),
    el("div", { class: "task-actions row-tail" }, [
      el("button", {
        class: "icon-btn small",
        title: "Delete",
        onclick: async (e) => {
          e.stopPropagation();
          if (await confirmDeleteTask(task)) { await api.del(`/api/tasks/${task.id}`); refreshCurrentView(); }
        },
      }, "🗑"),
    ]),
  ]);

  if (!hasSubtasks) return row;
  return el("div", { class: "task-with-subtasks" }, [row, list]);
}

function subtaskRow(sub, parentTask, opts = {}) {
  const checked = !!sub.checked;
  const due = formatDue(sub.due_date);

  const checkbox = el("div", {
    class: "checkbox small" + (checked ? " checked" : ""),
    onclick: async (e) => {
      e.stopPropagation();
      await api.post(`/api/subtasks/${sub.id}/toggle`, { checked: !checked });
      refreshCurrentView();
    },
  }, checked ? "✓" : "");

  const metaBits = [];
  if (due.text) metaBits.push(el("span", { class: due.overdue ? "overdue" : "" }, due.text));
  if (sub.duration_minutes) metaBits.push(el("span", { class: "duration-chip" }, "⏱ " + formatDuration(sub.duration_minutes)));

  return el("div", { class: "subtask-row" + (sub.matches_filter === false && parentTask.context_only ? " out-of-view" : ""), onclick: () => openTaskDetail(parentTask.id) }, [
    checkbox,
    el("div", { class: "task-main" }, [
      el("div", { class: "task-content" + (checked ? " done" : "") }, [
        (!checked && due.overdue) ? el("span", { class: "overdue-clock", title: "Overdue" }, "⏰ ") : null,
        sub.title,
      ]),
      metaBits.length ? el("div", { class: "task-meta" }, metaBits) : null,
    ]),
    timerControls(sub, "subtasks"),
    el("div", { class: "row-tail" }, opts.plain ? [] : [
      el("span", {
        class: "urgent-flag" + (sub.urgent ? "" : " off"),
        title: "Toggle urgent",
        onclick: async (e) => {
          e.stopPropagation();
          await api.patch(`/api/subtasks/${sub.id}`, { urgent: !sub.urgent });
          refreshCurrentView();
        },
      }, "🚩"),
      parentTask.is_video ? el("span", { class: "video-badge", title: "Inherits video flag" },
        videoTitleIcon(parentTask.video_template)) : null,
    ]),
  ]);
}
