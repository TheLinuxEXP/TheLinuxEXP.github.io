"use strict";

// Boot: wires everything up and opens the first view. Must be loaded last.

/* ---------------------------------------------------------------------- *
 * Boot
 * ---------------------------------------------------------------------- */
// The current view is remembered per browser tab (sessionStorage): a page
// reload keeps it, while a brand-new tab / fresh launch starts on Today.
const VIEW_KEY = "taskplanner.view";
function saveCurrentView() {
  const v = state.view || {};
  const d = { type: v.type, smartType: v.smartType, todoListId: v.todoListId, projectId: v.projectId, fiscalSection: v.fiscalSection };
  try { sessionStorage.setItem(VIEW_KEY, JSON.stringify(d)); } catch { /* storage unavailable: just not remembered */ }
}
function loadSavedView() {
  try { return JSON.parse(sessionStorage.getItem(VIEW_KEY) || "null"); } catch { return null; }
}

async function openSavedOrToday(saved) {
  const v = saved || {};
  if (v.type === "smart" && v.smartType) return openSmartView(v.smartType);
  if (v.type === "list" && v.todoListId) {
    const l = state.todoLists.find((x) => x.id === v.todoListId);
    if (l) return openTodoList(l);
  }
  if (v.type === "project" && v.projectId) {
    const p = state.projects.find((x) => x.id === v.projectId);
    if (p) return openProjectView(p);
  }
  if (v.type === "calendar") return openCalendar();
  if (v.type === "fiscal" && document.body.dataset.fiscal === "1") return openFiscalView(v.fiscalSection);
  if (v.type === "sponsors") return openSponsorsView();
  if (v.type === "videoproject") return openVideoProject();
  if (v.type === "timereport") return openTimeReport();
  if (v.type === "revenue" && document.body.dataset.fiscal === "1") return openRevenue();
  if (v.type === "backups") return openBackupsView();
  if (v.type === "templates") return openTemplatesView();
  if (v.type === "account") return openAccountView();
  return openSmartView("today");     // first load
}

// The task detail panel starts under the page header, whatever height the header has (it wraps on narrow windows).
function trackHeaderHeight() {
  const header = document.querySelector(".app-header");
  if (!header) return;
  const sync = () => document.documentElement.style.setProperty("--app-header-h", header.offsetHeight + "px");
  sync();
  if (window.ResizeObserver) new ResizeObserver(sync).observe(header); else window.addEventListener("resize", sync);
}

async function boot() {
  trackHeaderHeight();
  const saved = loadSavedView();   // read before anything renders and overwrites it
  state.bootPending = true;
  initTheme();
  document.getElementById("resourcesBtn").addEventListener("click", (e) => { e.stopPropagation(); openResourcesMenu(e.currentTarget); });
  wireQuickAdd();
  wireReloadServer();
  wireUtilities();
  wireBackups();
  wireTemplates();
  wireCleanup();
  wireAiSettings();
  wireAccount();
  wireDesktopWidgetBridge();
  wireTimerTicker();
  wireStatusIndicators();
  await Promise.all([refreshSidebarData(), refreshTemplates()]);
  if (state.todoLists.length) state.expanded.add(state.todoLists[0].project_id);
  try { await openSavedOrToday(saved); } finally { state.bootPending = false; }
  saveCurrentView();
}

boot().catch((err) => { console.error(err); showToast("Failed to load: " + err.message); });
