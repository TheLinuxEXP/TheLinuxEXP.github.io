"use strict";

// Finances > Revenue.

/* ---------------------------------------------------------------------- *
 * Finances > Revenue — per client: what was earned, the time worked on its
 * tasks (via the Sponsor tags matched to the client's name) and the hourly
 * rate of the chosen month.
 * ---------------------------------------------------------------------- */
const eur = (n) => (n == null ? "—" : new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", maximumFractionDigits: n % 1 ? 2 : 0 }).format(n));
const hoursText = (sec) => {
  if (!sec) return "—";
  const m = Math.round(sec / 60);
  return `${Math.floor(m / 60)}h${String(m % 60).padStart(2, "0")}`;
};

async function openRevenue() {
  const rv = state.revenue || (state.revenue = { month: todayIso().slice(0, 7), basis: "invoiced", data: null, error: "" });
  state.view = { type: "revenue", title: "Revenu" };
  renderSidebar();
  await loadRevenue();
}

async function loadRevenue() {
  const rv = state.revenue;
  try {
    rv.data = await api.get(`/api/revenue?month=${rv.month}&basis=${rv.basis}`);
    rv.error = "";
  } catch (err) { rv.error = (err && err.message) || String(err); }
  if (state.view.type === "revenue") renderMain();
}

function revenueShiftMonth(rv, delta) {
  const [y, m] = rv.month.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  rv.month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  loadRevenue();
}

function openRevenueMatching() {
  const rv = state.revenue, data = rv.data;
  if (!data) return;
  const body = [el("div", { class: "muted small", style: "margin-bottom:10px" },
    "Each Sponsor tag is matched to a client by name. Fix the ones that are wrong or missing — your choice is remembered.")];
  const list = el("div", { class: "rv-match-list" });
  const rows = [...data.tags].sort((a, b) => (a.client ? 1 : 0) - (b.client ? 1 : 0) || a.name.localeCompare(b.name));
  for (const t of rows) {
    const sel = el("select", {}, [
      el("option", { value: "__auto" }, "Automatic"),
      el("option", { value: "__none" }, "— no client —"),
      ...data.client_names.map((c) => el("option", { value: c }, c)),
    ]);
    const manual = t.how === "manual";
    sel.value = !manual ? "__auto" : (t.client == null ? "__none" : t.client);
    const hint = el("span", { class: "muted small rv-hint" }, "");
    const paintHint = () => {
      hint.textContent = sel.value === "__auto" ? (t.how === "auto" && t.client ? `→ ${t.client}` : "no match found") : "";
    };
    paintHint();
    sel.addEventListener("change", async () => {
      const v = sel.value;
      try {
        await api.post("/api/revenue/match", { tag_id: t.id, client: v === "__auto" ? null : v === "__none" ? "" : v });
        showToast("Match saved");
        rv.dirty = true;
      } catch (err) { showToast("Could not save the match"); }
      paintHint();
    });
    list.appendChild(el("div", { class: "rv-match-row" + (t.client ? "" : " unmatched") }, [
      el("span", { class: "dot", style: `background:${t.color || "#999"}` }),
      el("span", { class: "rv-match-tag" }, t.name),
      sel, hint,
    ]));
  }
  if (!rows.length) list.appendChild(el("div", { class: "muted" }, "No tags yet."));
  body.push(list);
  openModal("Match tags to clients", body, [el("button", { class: "btn primary", onclick: () => { closeModal(); if (rv.dirty) { rv.dirty = false; loadRevenue(); } } }, "Done")]);
  document.getElementById("modalBody").classList.add("modal-wide");
}

function renderRevenue() {
  const rv = state.revenue;
  const wrap = el("div", { class: "report-wrap revenue-wrap" });
  const d = rv.data;
  const [y, m] = rv.month.split("-").map(Number);
  const isNow = rv.month === todayIso().slice(0, 7);
  const monthLabel = `${MONTH_NAMES[m - 1]} ${y}`;
  const seg = (items, current, onPick) => el("div", { class: "seg" }, items.map(([key, label]) =>
    el("button", { type: "button", class: "seg-btn" + (current === key ? " active" : ""), onclick: () => onPick(key) }, label)));

  const unmatchedCount = d ? d.unmatched.length : 0;
  // three fixed zones: month (left) · Invoiced/Cashed (centre) · tag matching (right).
  // Nothing moves when the choices change: "Today" keeps its place (hidden, not removed)
  // and the matching button keeps one width.
  wrap.appendChild(el("div", { class: "rv-bar" }, [
    el("div", { class: "rv-bar-left report-nav" }, [
      el("button", { class: "icon-btn", title: "Previous month", onclick: () => revenueShiftMonth(rv, -1) }, "‹"),
      el("strong", { class: "rv-month" }, monthLabel),
      el("button", { class: "icon-btn", title: "Next month", onclick: () => revenueShiftMonth(rv, 1) }, "›"),
      el("button", { class: "btn small", style: isNow ? "visibility:hidden" : "", tabindex: isNow ? "-1" : "0",
        onclick: () => { rv.month = todayIso().slice(0, 7); loadRevenue(); } }, "Today"),
    ]),
    el("div", { class: "rv-bar-mid" }, [seg([["invoiced", "Invoiced"], ["cashed", "Cashed"]], rv.basis, (b) => { rv.basis = b; loadRevenue(); })]),
    el("div", { class: "rv-bar-right" }, [
      el("button", { class: "btn small", title: "Match Sponsor tags to client names", disabled: d ? null : "disabled",
        onclick: openRevenueMatching }, unmatchedCount ? `🔗 Match tags (${unmatchedCount})` : "🔗 Match tags"),
    ]),
  ]));

  if (rv.error) { wrap.appendChild(el("div", { class: "insights-error" }, rv.error)); return wrap; }
  if (!d) { wrap.appendChild(el("div", { class: "muted" }, "Loading…")); return wrap; }
  if (!d.available || !d.clients.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [emptyStateIcon("coins"), el("div", {}, "No invoices found")]));
    return wrap;
  }

  const monthTotal = d.clients.reduce((a, c) => a + c.month, 0);
  const monthSec = d.clients.reduce((a, c) => a + c.seconds_month, 0);
  const paidClients = d.clients.filter((c) => c.seconds_month > 0 && c.month > 0);
  const paidSum = paidClients.reduce((a, c) => a + c.month, 0), paidSec = paidClients.reduce((a, c) => a + c.seconds_month, 0);
  const stat = (label, value, sub) => el("div", { class: "rv-stat" }, [
    el("div", { class: "muted small" }, label), el("div", { class: "rv-stat-val" }, value), sub ? el("div", { class: "muted small" }, sub) : null]);
  wrap.appendChild(el("div", { class: "rv-stats" }, [
    stat(`Earned in ${MONTH_NAMES[m - 1]}`, eur(monthTotal), rv.basis === "cashed" ? "cashed (HT)" : "invoiced (HT)"),
    stat("Time on clients' tasks", hoursText(monthSec), "this month"),
    stat("Average hourly rate", paidSec ? eur(Math.round((paidSum / (paidSec / 3600)) * 100) / 100) + "/h" : "—", "clients with both income and time"),
  ]));

  const head = ["Client", "Earned " + MONTH_NAMES[m - 1].slice(0, 3), "Earned total", "Time " + MONTH_NAMES[m - 1].slice(0, 3), "Time total", "Hourly rate"];
  const table = el("div", { class: "rv-table" });
  table.appendChild(el("div", { class: "rv-row rv-head" }, head.map((t, i) => el("span", { class: i ? "num" : "" }, t))));
  for (const c of d.clients) {
    table.appendChild(el("div", { class: "rv-row" }, [
      el("span", { class: "rv-client" }, [
        el("span", { class: "rv-client-name" }, c.client),
        c.tags.length ? el("span", { class: "rv-tags" }, c.tags.map((t) => el("span", {
          class: "task-label-chip", style: `color:${t.color || "inherit"}`,
          title: t.how === "manual" ? "Matched manually" : "Matched automatically" }, t.name + (t.how === "manual" ? " ✎" : "")))) : null,
      ]),
      el("span", { class: "num" }, eur(c.month || null)),
      el("span", { class: "num muted" }, eur(c.total || null)),
      el("span", { class: "num" }, hoursText(c.seconds_month)),
      el("span", { class: "num muted" }, hoursText(c.seconds_total)),
      el("span", { class: "num rv-rate", title: c.rate_total ? `All-time average: ${eur(c.rate_total)}/h` : "" }, c.rate_month == null ? "—" : eur(c.rate_month) + "/h"),
    ]));
  }
  wrap.appendChild(table);

  if (d.unmatched.length) {
    wrap.appendChild(el("div", { class: "muted small", style: "margin-top:12px" },
      `Tags without a client: ${d.unmatched.map((t) => t.name + (t.seconds_total ? ` (${hoursText(t.seconds_total)})` : "")).join(", ")}. Use “Match tags” to assign them.`));
  }
  wrap.appendChild(el("div", { class: "muted small", style: "margin-top:10px" },
    "Amounts are excl. VAT. Time comes from the Sponsor tags of tasks (a task with several tags shares its time between them). The hourly rate is the month's earnings divided by the month's hours, shown when both exist."));
  return wrap;
}
