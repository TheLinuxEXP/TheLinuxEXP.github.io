"use strict";

// Header status indicators, theme, sidebar.

/* ---------------------------------------------------------------------- *
 * Header status indicators: active timers + in-flight AI generations.
 * Both render into #statusIndicators, top-right of the main header --
 * unlike #headerActions (view-specific, rebuilt by renderHeaderActions),
 * this is independent of the current view and keeps its own refresh loop.
 * ---------------------------------------------------------------------- */
state.activeTimers = [];
state.aiTasks = []; // client-side only: { id, label } -- one per in-flight AI call this tab

function startAiTask(label) {
  const id = (startAiTask._next = (startAiTask._next || 1) + 1);
  state.aiTasks.push({ id, label });
  renderStatusIndicators();
  return id;
}
function finishAiTask(id) {
  state.aiTasks = state.aiTasks.filter((t) => t.id !== id);
  renderStatusIndicators();
}

async function refreshActiveTimers() {
  if (document.hidden) return;            // nobody is looking: refreshed as soon as the tab is shown again (see wireStatusIndicators)
  try {
    state.activeTimers = await api.get("/api/timers/active");
  } catch (e) {
    // transient failure -- keep showing the last known snapshot
  }
  renderStatusIndicators();
}

function wireStatusIndicators() {
  refreshActiveTimers();
  setInterval(refreshActiveTimers, 5000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) refreshActiveTimers(); });
}

function indicatorRow({ title, sub, status, statusClass, meta, onClick }) {
  return el("div", { class: "indicator-row" + (onClick ? " clickable" : ""), onclick: onClick || undefined }, [
    el("div", { class: "indicator-row-main" }, [
      el("div", { class: "indicator-row-title" }, title),
      sub ? el("div", { class: "indicator-row-sub" }, sub) : null,
    ]),
    el("div", { class: "indicator-row-end" }, [
      el("span", { class: "indicator-status " + statusClass }, status),
      meta ? el("span", { class: "indicator-meta" }, meta) : null,
    ]),
  ]);
}

function indicatorPanel(rows) {
  return el("div", { class: "indicator-panel" },
    rows.length ? rows : [el("div", { class: "indicator-row-empty" }, "Nothing here")]);
}

function renderStatusIndicators() {
  const box = document.getElementById("statusIndicators");
  if (!box) return;
  // The box is rebuilt on every refresh, so remember what was showing: an indicator that was already there is drawn
  // as is, one that just appeared pops in, and a count that changed gives its badge a little bump.
  const before = renderStatusIndicators._shown || {};
  const shown = {};
  box.innerHTML = "";

  if (state.activeTimers.length) {
    box.appendChild(el("button", {
      type: "button",
      class: "indicator-btn",
      title: "Active timers",
      onclick: (e) => {
        e.stopPropagation();
        openDropdown(e.currentTarget, [indicatorPanel(state.activeTimers.map((entry) => indicatorRow({
          title: entry.title,
          sub: entry.is_subtask ? `↳ ${entry.parent_title || ""}` : (entry.project_name ? `↳ ${entry.project_name}` : null),
          status: entry.timer_state === "paused" ? "Paused" : "Running",
          statusClass: entry.timer_state === "paused" ? "paused" : "running",
          meta: formatElapsed(entry.time_spent_seconds),
          onClick: entry.is_other ? undefined : () => { closeDropdowns(); openTaskDetail(entry.task_id); },
        })))]);
      },
    }, [
      el("span", { class: "indicator-icon" }, "⏱"),
      el("span", { class: "indicator-count" }, String(state.activeTimers.length)),
    ]));
    shown.timers = state.activeTimers.length;
    animateIndicator(box.lastChild, before.timers, shown.timers);
  }

  if (state.aiTasks.length) {
    box.appendChild(el("button", {
      type: "button",
      class: "indicator-btn",
      title: "AI generation in progress",
      onclick: (e) => {
        e.stopPropagation();
        openDropdown(e.currentTarget, [indicatorPanel(state.aiTasks.map((t) => indicatorRow({
          title: t.label,
          status: "Working…",
          statusClass: "working",
        })))]);
      },
    }, [
      el("span", { class: "indicator-icon" }, "✨"),
      el("span", { class: "indicator-count" }, String(state.aiTasks.length)),
    ]));
    shown.ai = state.aiTasks.length;
    box.lastChild.classList.add("working");
    animateIndicator(box.lastChild, before.ai, shown.ai);
  }
  renderStatusIndicators._shown = shown;
}

function animateIndicator(btn, prevCount, count) {
  if (prevCount === undefined) btn.classList.add("pop-in");
  else if (prevCount !== count) btn.querySelector(".indicator-count").classList.add("bump");
}

function formatHoursTotal(totalMinutes) {
  if (!totalMinutes) return "";
  const hrs = totalMinutes / 60;
  const rounded = Math.round(hrs * 10) / 10;
  return `${Number.isInteger(rounded) ? rounded : rounded.toFixed(1)}h`;
}

function describeRecurrence(rule) {
  if (!rule) return "";
  const unit = rule.unit || "day";
  const interval = parseInt(rule.interval || 1, 10);
  const plural = { day: "days", week: "weeks", month: "months", year: "years" }[unit];
  const singular = { day: "day", week: "week", month: "month", year: "year" }[unit];
  let base = interval === 1 ? `Every ${singular}` : `Every ${interval} ${plural}`;
  if (unit === "week" && rule.weekdays && rule.weekdays.length) {
    const names = [...new Set(rule.weekdays)].sort().map((i) => WEEKDAY_NAMES[i]).join(", ");
    base += ` on ${names}`;
  }
  return base;
}

// opts.sticky: stays until the person closes it with the × at its top right (used for AI-button errors).
function showToast(msg, opts = {}) {
  const t = document.getElementById("toast");
  clearTimeout(showToast._t);
  t.classList.toggle("sticky", !!opts.sticky);
  t.textContent = "";
  t.appendChild(el("span", { class: "toast-msg" }, msg));
  if (opts.sticky) {
    t.appendChild(el("button", { type: "button", class: "toast-close", title: "Close", "aria-label": "Close",
      onclick: (e) => { e.stopPropagation(); t.classList.add("hidden"); t.classList.remove("sticky"); } }, "×"));
  } else {
    showToast._t = setTimeout(() => t.classList.add("hidden"), 2200);
  }
  t.classList.remove("hidden");
}

// Menus fade/scale out before they leave the DOM (`immediate` skips that, e.g. when another menu replaces this one).
const REDUCED_MOTION = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
function closeDropdowns(immediate) {
  document.querySelectorAll(".dropdown:not(.closing)").forEach((d) => {
    if (immediate || REDUCED_MOTION.matches) { d.remove(); return; }
    d.classList.add("closing");
    setTimeout(() => d.remove(), 140);
  });
  if (immediate) document.querySelectorAll(".dropdown.closing").forEach((d) => d.remove());
  closeUtilitiesMenu();
}
document.addEventListener("click", closeDropdowns);

// Dropdown menus are appended to <body> and positioned with `fixed`
// coordinates computed from the anchor button's own bounding rect, rather
// than relying on a `position: relative` ancestor + `position: absolute`.
// Several sidebar rows (e.g. a todo-list row) have `overflow: hidden` for
// text-ellipsis purposes, which would silently clip an absolutely-positioned
// dropdown nested inside them to zero visible size.
function openDropdown(anchorBtn, buttons) {
  closeDropdowns(true);
  const rect = anchorBtn.getBoundingClientRect();
  const dd = el("div", { class: "dropdown" }, buttons);
  dd.style.position = "fixed";
  dd.style.top = `${rect.bottom + 4}px`;
  dd.style.right = `${Math.max(4, window.innerWidth - rect.right)}px`;
  document.body.appendChild(dd);
  return dd;
}

/* ---------------------------------------------------------------------- *
 * "Useful Resources" (top right of every page): the video tasks due in the next 2 weeks with links to their notes,
 * and the 5 most recent notes.
 * ---------------------------------------------------------------------- */
async function openResourcesMenu(btn) {
  if (document.querySelector(".dropdown.res-menu:not(.closing)")) { closeDropdowns(); return; }
  const dd = openDropdown(btn, [el("div", { class: "res-empty" }, "Loading…")]);
  dd.classList.add("res-menu");
  let videos = [], recent = [], root = "";
  try {
    const [v, st, r] = await Promise.all([
      api.get(`/api/video-tasks/upcoming?today=${todayIso()}&days=14`),
      api.get("/api/notes/state").catch(() => ({ recent: [] })),
      NotesApp.root().catch(() => ""),
    ]);
    videos = v; recent = (st.recent || []).slice(0, 5); root = (r || "").replace(/\/$/, "");
  } catch (e) {
    dd.innerHTML = "";
    dd.appendChild(el("div", { class: "res-empty" }, "Could not load the resources."));
    return;
  }
  const relOf = (p) => (root && p && p.startsWith(root + "/")) ? p.slice(root.length + 1) : null;
  const openNote = (rel) => { closeDropdowns(); NotesApp.openNote(rel); };
  const noteName = (p) => (p || "").split("/").pop().replace(/\.md$/i, "");
  const noteChip = (icon, path, label) => {
    const rel = relOf(path);
    return rel
      ? el("button", { class: "res-note", type: "button", title: `${icon === "🎬" ? "Video note" : "Note"}: ${noteName(path)}`, onclick: () => openNote(rel) }, `${icon} ${label || noteName(path)}`)
      : el("span", { class: "res-note muted", title: path }, `${icon} ${label || noteName(path)}`);
  };

  dd.innerHTML = "";
  dd.appendChild(el("div", { class: "res-label" }, "Videos in the next 2 weeks"));
  if (!videos.length) dd.appendChild(el("div", { class: "res-empty" }, "No upcoming video."));
  for (const t of videos) {
    const due = formatDue(t.due_date);
    const notes = [];
    if (t.notes_file) notes.push(noteChip("📄", t.notes_file));
    if (t.video_note_file) notes.push(noteChip("🎬", t.video_note_file));
    dd.appendChild(el("div", { class: "res-video" }, [
      el("button", { type: "button", class: "res-title", onclick: () => { closeDropdowns(); openTaskDetail(t.id); } }, [
        el("span", { title: templateLabel(t.video_template) }, `${videoTitleIcon(t.video_template)} ${t.title}`),
        el("span", { class: "res-date" }, due.text || t.due_date),
      ]),
      notes.length ? el("div", { class: "res-notes" }, notes) : el("div", { class: "res-empty", style: "padding-top:0" }, "no linked note"),
    ]));
  }
  dd.appendChild(el("div", { class: "res-label", style: "margin-top:6px" }, "Recent notes"));
  if (!recent.length) dd.appendChild(el("div", { class: "res-empty" }, "No recent note."));
  for (const rel of recent) {
    const parts = rel.split("/");
    dd.appendChild(el("button", { type: "button", class: "res-note-row", onclick: () => openNote(rel) },
      [el("span", {}, noteName(rel)), parts.length > 1 ? el("small", {}, parts.slice(0, -1).join(" / ")) : null]));
  }
}

/* ---------------------------------------------------------------------- *
 * Theme
 * ---------------------------------------------------------------------- */
function initTheme() {
  const saved = localStorage.getItem("taskplanner-theme");
  if (saved) document.documentElement.setAttribute("data-theme", saved);
  document.getElementById("themeToggle").addEventListener("click", () => {
    const cur = document.documentElement.getAttribute("data-theme")
      || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    const next = cur === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("taskplanner-theme", next);
  });
}

/* ---------------------------------------------------------------------- *
 * Sidebar
 * ---------------------------------------------------------------------- */
async function refreshSidebarData() {
  const [projects, todoLists, tags, counts, current] = await Promise.all([
    api.get("/api/projects"),
    api.get("/api/todolists"),
    api.get("/api/tags"),
    api.get(`/api/smartcounts?today=${todayIso()}&tomorrow=${tomorrowIso()}`),
    api.get(`/api/video-project/current?today=${todayIso()}`).catch(() => ({ task: null })),
  ]);
  state.currentVideo = current.task || null;
  state.projects = projects;
  state.todoLists = todoLists;
  state.tags = tags;
  state.smartCounts = counts;
  // Projects are unfolded by default. A project collapsed by the user stays
  // collapsed across refreshes (it's removed from `expanded`, not re-added),
  // but a project seen for the first time this session starts open.
  for (const p of projects) {
    if (!state.knownProjectIds.has(p.id)) {
      state.knownProjectIds.add(p.id);
      state.expanded.add(p.id);
    }
  }
  renderSidebar();
}

// Monochrome (currentColor) line icons for the sidebar entries.
const SYMBOLIC_ICONS = {
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  megaphone: '<path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  notes: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4M10 9H8M16 13H8M16 17H8"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5M3 12a9 3 0 0 0 18 0"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  cpu: '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  sparkles: '<path d="M9.94 14.06 12 21l2.06-6.94L21 12l-6.94-2.06L12 3 9.94 9.94 3 12z"/>',
  layout: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
};
// Big monochrome icon for the "Nothing here" style empty states.
function emptyStateIcon(name) {
  const box = el("div", { class: "empty-ico" });
  box.innerHTML = `<svg viewBox="0 0 24 24" width="44" height="44" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SYMBOLIC_ICONS[name] || ""}</svg>`;
  return box;
}
function symbolicIcon(name) {
  const span = el("span", { class: "ri-icon sym" });
  span.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SYMBOLIC_ICONS[name] || ""}</svg>`;
  return span;
}

function renderSidebar() {
  if (state.view && state.view.type && !state.bootPending) saveCurrentView();
  const bb = document.getElementById("backupsBtn");
  if (bb) bb.classList.toggle("active", state.view.type === "backups");
  const ab = document.getElementById("accountBtn");
  if (ab) ab.classList.toggle("active", state.view.type === "account");
  const tb = document.getElementById("templatesBtn");
  if (tb) tb.classList.toggle("active", state.view.type === "templates");
  renderTopNav();
  renderFinanceNav();
  renderProjectsTree();
}
