"use strict";

// Task detail panel and subtasks editor.

/* ---------------------------------------------------------------------- *
 * Task detail panel
 * ---------------------------------------------------------------------- */
// Task panel: the note (a Markdown file of "Notes & Scripts") this task is linked
// to. Stored as the file's full path in task.notes_file, which is what the AI
// buttons read. When nothing is linked, notes whose title shares keywords with
// the task's title are suggested.
function renderNoteLinkField(task, patch) {
  const field = el("div", { class: "field note-link-field" }, [el("label", {}, "Note / script")]);
  const body = el("div", {});
  field.appendChild(body);
  let current = task.notes_file || "";
  let root = "";
  let suggestions = [];
  const base = () => root.replace(/\/$/, "");
  const relOf = (p) => (root && p && p.startsWith(base() + "/")) ? p.slice(base().length + 1) : null;

  async function link(rel) {
    const value = rel ? `${base()}/${rel}` : null;
    await patch({ notes_file: value });
    current = value || ""; task.notes_file = value;
    paint();
  }
  async function choose() {
    const rel = await NotesApp.pickNote({ title: "Link a note", query: task.title, current: relOf(current) });
    if (rel === null) return;
    await link(rel);
  }

  // the template's note name pattern ("Linux News Podcast 14 October 26" for weekly news), else the task title
  function newNoteName() {
    const tpl = templateByKey(task.video_template);
    if (tpl && tpl.note_title && task.due_date) {
      const [y, m, d] = task.due_date.slice(0, 10).split("-").map(Number);
      const month = new Date(y, m - 1, d).toLocaleString("en-GB", { month: "long" });
      const pad = (n) => String(n).padStart(2, "0");
      return tpl.note_title
        .replaceAll("{dd}", pad(d)).replaceAll("{mm}", pad(m)).replaceAll("{month}", month)
        .replaceAll("{yyyy}", String(y)).replaceAll("{yy}", pad(y % 100)).replaceAll("{title}", task.title);
    }
    return task.title;
  }
  async function createNote() {
    try {
      const path = await NotesApp.create(newNoteName());
      await link(path);
      showToast("Note created");
      closeTaskDetail(); NotesApp.openNote(path);
    } catch (e) { showToast("Could not create the note"); }
  }

  async function createVideoNote() {
    try {
      const res = await api.post(`/api/tasks/${task.id}/video-note`, {});
      task.video_note_file = res.path; paint(); paintVideoNote();
      showToast(res.warnings && res.warnings.length ? `“${res.name}” created — ${res.warnings.join(" ")}` : `“${res.name}” created`);
      if (res.rel) { closeTaskDetail(); NotesApp.openNote(res.rel); }
    } catch (e) {
      let msg = "Could not create the video note";
      try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
      showToast(msg);
    }
  }

  // second link, below the main note: the "-VIDEO" note made by "Create Video Note"
  const vbody = el("div", {});
  field.appendChild(vbody);
  function paintVideoNote() {
    vbody.innerHTML = "";
    const vp = task.video_note_file;
    if (!vp) return;
    const rel = relOf(vp);
    const name = vp.split("/").pop().replace(/\.md$/i, "");
    vbody.appendChild(el("div", { class: "note-link-row", style: "margin-top:6px" }, [
      el("span", { class: "muted small" }, "Video note"),
      el(rel ? "button" : "span", rel
        ? { class: "note-link-chip clickable", type: "button", title: `Open ${vp}`, onclick: () => { closeTaskDetail(); NotesApp.openNote(rel); } }
        : { class: "note-link-chip", title: vp }, [el("span", {}, "🎬 " + name)]),
      el("button", { class: "icon-btn small", type: "button", title: "Unlink the video note (the button comes back)", onclick: async () => {
        await patch({ video_note_file: null }); task.video_note_file = null; paint(); paintVideoNote();
      } }, "✕"),
    ]));
  }

  function paint() {
    body.innerHTML = "";
    paintVideoNote();
    if (current) {
      const rel = relOf(current);
      const shown = rel ? rel.replace(/\.md$/i, "") : current.split("/").pop().replace(/\.md$/i, "");
      const name = shown.split("/").pop();
      const folder = rel ? shown.split("/").slice(0, -1).join("/") : "outside the notes folder";
      body.appendChild(el("div", { class: "note-link-row" }, [
        el(rel ? "button" : "span", rel
          ? { class: "note-link-chip clickable", type: "button", title: `Open ${current}`, onclick: () => { closeTaskDetail(); NotesApp.openNote(rel); } }
          : { class: "note-link-chip", title: current }, [
          el("span", {}, "📄 " + name),
          folder ? el("span", { class: "nl-folder" }, folder) : null,
        ]),
        el("button", { class: "btn small", type: "button", onclick: choose }, "Change"),
        task.video_template === "weekly_news" && !task.video_note_file ? el("button", {
          class: "btn small", type: "button", title: "Copy this note as “… -VIDEO” (same folder) and prepare it for the video",
          onclick: createVideoNote,
        }, "Create Video Note") : null,
        el("button", { class: "icon-btn small", type: "button", title: "Unlink", onclick: () => link(null) }, "✕"),
      ]));
      return;
    }
    body.appendChild(el("div", { class: "note-link-row" }, [
      el("button", { class: "btn small", type: "button", onclick: choose }, "🔎 Find a note…"),
      el("button", { class: "btn small", type: "button", onclick: createNote }, "＋ Create Note"),
    ]));
    if (suggestions.length) {
      body.appendChild(el("div", { class: "note-suggest" }, [
        el("span", {}, "Suggested:"),
        ...suggestions.map((n) => el("button", { type: "button", title: `${n.path} — click to link`, onclick: () => link(n.path) }, n.name)),
      ]));
    }
  }

  paint();
  (async () => {
    try {
      root = await NotesApp.root();
      if (!current) suggestions = await NotesApp.suggest(task.title, 3);
      paint();
    } catch (e) { /* notes folder unavailable: the field still works for unlinking */ }
  })();
  return field;
}

async function openTaskDetail(id) {
  const task = await api.get(`/api/tasks/${id}`);
  renderTaskPanel(task);
  document.getElementById("taskDetailOverlay").classList.remove("hidden");
}

// Clicking a calendar entry: a finished occurrence of a recurring task opens
// ITS OWN details, everything else opens the (current) task.
function openEntryDetail(t) {
  if (t.is_completed_occurrence) return openOccurrenceDetail(t);
  return openTaskDetail(t.is_subtask ? t.parent_task_id : t.id);
}

// Read-only details of one finished occurrence (what was recorded when it
// was finished), as opposed to the task's current, rolled-forward state.
function openOccurrenceDetail(c) {
  const panelEl = document.getElementById("taskPanel");
  panelEl.innerHTML = "";
  const panel = { appendChild: (n) => { if (n) panelEl.appendChild(n); } };
  const subs = c.subtasks_snapshot || c.subtasks || [];
  const day = c.occurrence_date || c.due_date;
  const ownSeconds = c.occurrence_time_seconds ?? ownSeconds ?? 0;
  const subTotal = subs.reduce((n, x) => n + (x.time_spent_seconds || 0), 0);
  const row = (label, value) => value ? el("div", { class: "field" }, [el("label", {}, label), el("div", {}, value)]) : null;
  const when = c.completed_at ? new Date(c.completed_at) : null;
  panel.appendChild(el("div", { class: "panel-head" }, [
    el("div", { style: "font-size:16px;font-weight:600;flex:1 1 220px" }, [c.is_video ? videoTitleIcon(c.video_template) + " " : "", c.occurrence_title || c.title]),
    el("button", { class: "icon-btn panel-head-close", onclick: closeTaskDetail }, "✕"),
  ]));
  panel.appendChild(el("div", { class: "muted", style: "margin-bottom:12px" }, "🔁 Finished occurrence of a recurring task — read only"));
  panel.appendChild(row("Occurrence date", day ? formatDue(day).text : null));
  panel.appendChild(row("Finished", when && !isNaN(when) ? when.toLocaleString([], { dateStyle: "medium", timeStyle: "short" }) : null));
  panel.appendChild(row("Project", [c.project_name, c.todo_list_name].filter(Boolean).join(" › ") || null));
  panel.appendChild(row("Time spent", (ownSeconds || subTotal)
    ? `${formatElapsed((ownSeconds || 0) + subTotal)}` + (subs.length && ownSeconds ? ` (task itself ${formatElapsed(ownSeconds)})` : "") : null));
  if (subs.length) {
    const list = el("div", { class: "subtask-list expanded" });
    for (const s of subs) {
      list.appendChild(el("div", { class: "subtask-row", style: "cursor:default" }, [
        el("div", { class: "checkbox small disabled" + (s.checked ? " checked" : "") }, s.checked ? "✓" : ""),
        el("div", { class: "task-main" }, [
          el("div", { class: "task-content" + (s.checked ? " done" : "") }, s.title),
          el("div", { class: "task-meta" }, [
            s.due_date ? el("span", {}, formatDue(s.due_date).text) : null,
            s.time_spent_seconds ? el("span", { class: "duration-chip" }, "⏱ " + formatElapsed(s.time_spent_seconds)) : null,
          ]),
        ]),
      ]));
    }
    panel.appendChild(el("div", { class: "field" }, [el("label", {}, `Subtasks (${subs.filter((x) => x.checked).length}/${subs.length} done)`), list]));
  }
  panel.appendChild(el("div", { class: "btn-row", style: "margin-top:20px" }, [
    el("button", { class: "btn", onclick: () => openTaskDetail(c.task_id) }, "Open current task"),
  ]));
  document.getElementById("taskDetailOverlay").classList.remove("hidden");
}

function closeTaskDetail() {
  document.getElementById("taskDetailOverlay").classList.add("hidden");
}
document.getElementById("taskDetailOverlay").addEventListener("click", (e) => {
  if (e.target.id === "taskDetailOverlay") closeTaskDetail();
});

// Collapsible sections in the task panel. The panel is rebuilt on every
// refresh, so the collapsed state lives here rather than in the DOM.
const collapsedPanelSections = new Set();
function panelSection(key, title, nodes) {
  const section = el("div", { class: "panel-section" + (collapsedPanelSections.has(key) ? " collapsed" : "") });
  const header = el("button", { type: "button", class: "panel-section-header", "aria-expanded": String(!collapsedPanelSections.has(key)) }, [
    el("span", { class: "ps-caret" }, "▶"), el("span", {}, title),
  ]);
  const inner = el("div", { class: "panel-section-inner" }, nodes.filter(Boolean));
  const body = el("div", { class: "panel-section-body" }, [inner]);
  header.addEventListener("click", () => {
    const collapsed = !section.classList.contains("collapsed");
    section.classList.toggle("collapsed", collapsed);
    section.classList.add("animating");
    clearTimeout(section._t);
    section._t = setTimeout(() => section.classList.remove("animating"), 260);
    header.setAttribute("aria-expanded", String(!collapsed));
    if (collapsed) collapsedPanelSections.add(key); else collapsedPanelSections.delete(key);
  });
  section.append(header, body);
  return section;
}

// Text fields of the task panel are saved while you type (quietly: no re-render, so the caret stays where it is) and when
// the page is hidden or closed. A plain "change" listener only fires when the field loses focus, so text typed just before
// closing the tab, reloading or restarting the app used to be lost.
const _pendingFieldSaves = new Set();
function flushPendingFieldSaves() { for (const f of [..._pendingFieldSaves]) f(); }
window.addEventListener("pagehide", flushPendingFieldSaves);
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") flushPendingFieldSaves(); });
function autosaveField(input, url, field, { onCommit, allowEmpty = true } = {}) {
  let saved = input.value, timer = null;
  const dirty = () => input.value !== saved && (allowEmpty || input.value.trim() !== "");
  const send = (keepalive) => {
    clearTimeout(timer);
    if (!dirty()) return null;
    const value = input.value;
    saved = value;
    return fetch(url, { method: "PATCH", keepalive, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ [field]: value }) })
      .then((r) => { if (!r.ok) saved = null; return r; })               // not saved: try again at the next change
      .catch(() => { saved = null; });
  };
  const flush = () => { if (!input.isConnected) { _pendingFieldSaves.delete(flush); return; } send(true); };
  _pendingFieldSaves.add(flush);
  input.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => send(false), 1000); });
  input.addEventListener("change", async () => { await send(false); if (onCommit) onCommit(); });
}

function renderTaskPanel(task) {
  const panel = document.getElementById("taskPanel");
  panel.innerHTML = "";

  const patch = async (fields) => { await api.patch(`/api/tasks/${task.id}`, fields); refreshCurrentView(); };

  const titleInput = el("input", { type: "text", value: task.title, style: "font-size:16px;font-weight:600;border:none;background:transparent;width:100%;color:var(--fg)" });
  autosaveField(titleInput, `/api/tasks/${task.id}`, "title", { onCommit: refreshCurrentView, allowEmpty: false });

  // Urgent / Video toggles, as pill buttons
  const flagChip = (icon, label, field, on, kind) => {
    const input = el("input", { type: "checkbox", checked: on || undefined });
    const chip = el("label", { class: `flag-chip ${kind}` + (on ? " on" : "") }, [
      input, el("span", { class: "flag-chip-icon" }, icon), el("span", {}, label),
    ]);
    input.addEventListener("change", (e) => {
      chip.classList.toggle("on", e.target.checked);
      patch({ [field]: e.target.checked });
    });
    return chip;
  };
  panel.appendChild(el("div", { class: "panel-head" }, [
    titleInput,
    el("div", { class: "field flag-chips panel-head-chips" }, [
      flagChip("🚩", "Urgent", "urgent", task.urgent, "urgent"),
      flagChip("🎥", "Video", "is_video", task.is_video, "video"),
    ]),
    el("button", { class: "icon-btn panel-head-close", onclick: closeTaskDetail }, "✕"),
  ]));

  const organize = [], content = [], timing = [];
  const orgRow = [], timeRow = [];
  const refreshDetail = () => { openTaskDetail(task.id); refreshCurrentView(); };
  const hasSubs = task.subtasks && task.subtasks.length;
  timeRow.push(el("div", { class: "field grow" }, [
    el("label", {}, hasSubs ? "Time spent (this task)" : "Time spent"),
    el("div", { class: "time-spent-line", style: "display:flex;gap:10px;align-items:center" }, [
      timeEditor({ ...task, time_spent_seconds: task.own_time_seconds ?? task.time_spent_seconds }, "tasks", refreshDetail),
      timerControls({ ...task, subtasks: [] }, "tasks", refreshDetail),
    ]),
  ]));
  const totalNote = hasSubs ? el("div", { class: "muted small", style: "margin:4px 0 12px" },
    `Total with subtasks: ${formatElapsed(task.total_time_seconds)}`) : null;

  // Video type -- only meaningful once the task is flagged as a video.
  // Setting this by hand (rather than only at creation from a template)
  // also decides which icon shows next to the title in list views, and
  // whether retitling the task will treat it as a Weekly News Video for
  // things like the "Edit A Roll" subtask backfill.
  if (task.is_video) {
    const known = state.templates.map((t) => el("option", { value: t.key }, t.label));
    if (task.video_template && !templateByKey(task.video_template)) {      // template since deleted: keep the value selectable
      known.push(el("option", { value: task.video_template }, `${task.video_template} (deleted template)`));
    }
    const templateSelect = el("select", { id: "videoTypeSelect" }, [
      el("option", { value: "" }, "— Not set —"),
      ...known,
    ]);
    templateSelect.value = task.video_template || "";
    templateSelect.addEventListener("change", () => patch({ video_template: templateSelect.value || null }));
    orgRow.push(el("div", { class: "field" }, [el("label", {}, "Video type"), templateSelect]));
  }

  const descInput = autoGrowTextarea(el("textarea", { placeholder: "Notes" }, task.notes || ""));
  descInput.value = task.notes || "";
  autosaveField(descInput, `/api/tasks/${task.id}`, "notes", { onCommit: refreshCurrentView });
  const notesField = el("div", { class: "field" }, [el("label", {}, "Notes"), descInput]);

  // Due date — a popup mini-calendar rather than a native <input type=date>,
  // whose picker-indicator icon is often invisible in dark mode.
  const dueField = el("div", { class: "field" }, [
    el("label", {}, "Due date"),
    dateField(task.due_date, (iso) => patch({ due_date: iso })),
  ]);

  // Start time — used to place the task in the calendar's week view.
  const startTimeInput = el("input", { type: "time", value: task.start_time || "" });
  startTimeInput.addEventListener("change", () => patch({ start_time: startTimeInput.value || null }));
  timeRow.push(el("div", { class: "field" }, [el("label", {}, "Start time"), startTimeInput]));

  // Estimated duration, entered in hours (e.g. 1.5 for an hour and a half)
  // but stored as minutes so existing display/sum logic doesn't need two units.
  const initialHours = task.duration_minutes ? Math.round((task.duration_minutes / 60) * 100) / 100 : "";
  const durationInput = el("input", { type: "number", min: "0", step: "0.25", value: initialHours, placeholder: "hours" });
  const durationPreview = el("span", { class: "muted small", style: "margin-left:8px" }, formatDuration(task.duration_minutes));
  durationInput.addEventListener("change", () => {
    const hours = durationInput.value ? parseFloat(durationInput.value) : null;
    const minutes = hours ? Math.round(hours * 60) : null;
    durationPreview.textContent = formatDuration(minutes);
    patch({ duration_minutes: minutes });
  });
  timeRow.push(el("div", { class: "field" }, [
    el("label", {}, "Estimated duration (hours)"),
    el("div", { class: "duration-line", style: "display:flex;align-items:center" }, [durationInput, durationPreview]),
  ]));

  // Linked notes file — a markdown file on this computer. The AI buttons on
  // this task's video-related subtasks (order topics, tags, thumbnails) read
  // this file's "Timestamps"/"Links"/"Content" sections.
  content.push(renderNoteLinkField(task, patch));

  // Recurrence
  const rec = renderRecurrenceField(task, patch);
  timing.push(el("div", { class: "field-row due-row" }, [dueField, rec.chipField]), rec.body);

  // Move to list
  const projSelect = el("select", {}, state.projects.map((p) => el("option", { value: p.id, selected: p.id === task.project_id || undefined }, p.name)));
  const listSelect = el("select", {}, []);
  function paintListOptions(projectId, currentListId) {
    listSelect.innerHTML = "";
    for (const l of state.todoLists.filter((x) => x.project_id === projectId)) {
      listSelect.appendChild(el("option", { value: l.id, selected: l.id === currentListId || undefined }, l.name));
    }
  }
  paintListOptions(task.project_id, task.todo_list_id);
  projSelect.addEventListener("change", () => {
    // Changing the project moves the task to that project's first list
    // (the List selector below can then pick another one).
    const lists = state.todoLists.filter((x) => x.project_id === projSelect.value);
    if (!lists.length) {
      projSelect.value = task.project_id;
      showToast("That project has no list yet — create one first");
      return;
    }
    paintListOptions(projSelect.value, lists[0].id);
    patch({ todo_list_id: lists[0].id });
  });
  listSelect.addEventListener("change", () => patch({ todo_list_id: listSelect.value }));
  orgRow.push(el("div", { class: "field" }, [el("label", {}, "Project"), projSelect]));
  orgRow.push(el("div", { class: "field" }, [el("label", {}, "List"), listSelect]));

  // Tags
  const chipRow = el("div", { class: "chip-row" });
  function paintChips() {
    chipRow.innerHTML = "";
    const selectedIds = new Set((task.tags || []).map((g) => g.id));
    for (const g of state.tags) {
      chipRow.appendChild(el("div", {
        class: "chip" + (selectedIds.has(g.id) ? " selected" : ""),
        onclick: async () => {
          const ids = new Set(selectedIds);
          if (ids.has(g.id)) ids.delete(g.id); else ids.add(g.id);
          const updated = await api.post(`/api/tasks/${task.id}/tags`, { tag_ids: [...ids] });
          task.tags = updated.tags;
          paintChips();
          refreshCurrentView();
        },
      }, [el("span", { class: "swatch", style: `background:${g.color};width:9px;height:9px` }), g.name]));
    }
    const newInput = el("input", { type: "text", placeholder: "New tag", style: "width:100px;padding:3px 8px;border-radius:12px;border:1px solid var(--border);background:var(--bg);color:var(--fg);font-size:12px" });
    newInput.addEventListener("keydown", async (e) => {
      if (e.key === "Enter" && newInput.value.trim()) {
        const res = await api.post("/api/tags", { name: newInput.value.trim(), color: PROJECT_COLORS[state.tags.length % PROJECT_COLORS.length] });
        state.tags = await api.get("/api/tags");
        const updated = await api.post(`/api/tasks/${task.id}/tags`, { tag_ids: [...selectedIds, res.id] });
        task.tags = updated.tags;
        paintChips();
        refreshCurrentView();
      }
    });
    chipRow.appendChild(newInput);
  }
  paintChips();
  organize.push(el("div", { class: "field" }, [el("label", {}, "Tags"), chipRow]));

  // Attachment
  content.push(el("div", { class: "field" }, [
    el("label", {}, "Attached file"),
    task.attachment_name
      ? el("div", { class: "attachment-row" }, [
          el("a", { href: `/api/tasks/${task.id}/attachment`, target: "_blank" }, "📎 " + task.attachment_name),
          el("button", { class: "icon-btn small", onclick: async () => { await api.del(`/api/tasks/${task.id}/attachment`); openTaskDetail(task.id); refreshCurrentView(); } }, "🗑"),
        ])
      : (() => {
          const input = el("input", { type: "file" });
          input.addEventListener("change", async () => {
            if (input.files[0]) { await api.upload(`/api/tasks/${task.id}/attachment`, input.files[0]); openTaskDetail(task.id); refreshCurrentView(); }
          });
          return input;
        })(),
  ]));

  content.push(notesField);   // free-text Notes: last field of the Content section
  organize.unshift(el("div", { class: "field-row" }, orgRow));
  timing.splice(2, 0, el("div", { class: "field-row time-row" }, timeRow), totalNote);
  panel.appendChild(panelSection("organize", "Organize", organize));
  panel.appendChild(panelSection("content", "Content", content));
  panel.appendChild(panelSection("timing", "Timing", timing));
  panel.appendChild(panelSection("subtasks", "Subtasks", [renderSubtasksField(task)]));

  // Danger zone
  panel.appendChild(el("div", { class: "btn-row spread", style: "margin-top: 24px" }, [
    el("button", {
      class: "btn",
      onclick: async () => { await api.post(`/api/tasks/${task.id}/toggle`, { checked: !task.checked }); openTaskDetail(task.id); refreshCurrentView(); },
    }, task.checked ? "Mark not done" : "Mark done"),
    el("button", {
      class: "btn danger",
      onclick: async () => { if (await confirmDeleteTask(task)) { await api.del(`/api/tasks/${task.id}`); closeTaskDetail(); refreshCurrentView(); } },
    }, "Delete task"),
  ]));
}

/* ---------------------------------------------------------------------- *
 * Subtasks editor (inside the task panel). Each subtask has its own due
 * date, estimated duration (hours) and urgency flag; the video flag is
 * inherited from the parent task, not editable per subtask.
 * ---------------------------------------------------------------------- */
function renderSubtasksField(task) {
  const wrap = el("div", { class: "field" });
  const list = el("div", { class: "subtask-editor-list" });
  if ((task.subtasks || []).length) {
    list.appendChild(el("div", { class: "subtask-editor-head" },
      ["", "Subtask", "Due", "Start", "Est. (h)", "Spent", "Timer"].map((t) => el("span", {}, t))));
  }
  for (const s of task.subtasks || []) list.appendChild(subtaskEditorRow(s, task));
  wrap.appendChild(list);

  const newInput = el("input", { type: "text", placeholder: "Add a subtask" });
  newInput.addEventListener("keydown", async (e) => {
    if (e.key === "Enter" && newInput.value.trim()) {
      await api.post(`/api/tasks/${task.id}/subtasks`, { title: newInput.value.trim() });
      openTaskDetail(task.id);
      refreshCurrentView();
    }
  });
  wrap.appendChild(el("div", { class: "inline-add-row" }, [newInput]));
  return wrap;
}

function subtaskEditorRow(s, task) {
  const checked = !!s.checked;

  const checkbox = el("div", {
    class: "checkbox small" + (checked ? " checked" : ""),
    onclick: async () => {
      await api.post(`/api/subtasks/${s.id}/toggle`, { checked: !checked });
      openTaskDetail(task.id);
      refreshCurrentView();
    },
  }, checked ? "✓" : "");

  const titleInput = el("input", { type: "text", value: s.title, class: "subtask-editor-title" });
  titleInput.addEventListener("change", async () => {
    await api.patch(`/api/subtasks/${s.id}`, { title: titleInput.value });
    refreshCurrentView();
  });

  const dateBtn = dateField(s.due_date, async (iso) => {
    await api.patch(`/api/subtasks/${s.id}`, { due_date: iso });
    refreshCurrentView();
  });
  dateBtn.classList.add("small");

  const timeInput = el("input", { type: "time", value: s.start_time || "", title: "Start time" });
  timeInput.addEventListener("change", async () => {
    await api.patch(`/api/subtasks/${s.id}`, { start_time: timeInput.value || null });
    refreshCurrentView();
  });

  const hours = s.duration_minutes ? Math.round((s.duration_minutes / 60) * 100) / 100 : "";
  const durInput = el("input", { type: "number", min: "0", step: "0.25", value: hours, placeholder: "h", title: "Estimated duration (hours)" });
  durInput.addEventListener("change", async () => {
    const h = durInput.value ? parseFloat(durInput.value) : null;
    await api.patch(`/api/subtasks/${s.id}`, { duration_minutes: h ? Math.round(h * 60) : null });
    refreshCurrentView();
  });

  const subRefresh = () => { openTaskDetail(task.id); refreshCurrentView(); };
  // display:contents (see app.css): "min spent" and the timer are two separate grid cells
  const subTimerControls = el("span", { class: "sub-time-wrap" }, [
    timeEditor(s, "subtasks", subRefresh),
    timerControls(s, "subtasks", subRefresh),
  ]);

  const mainRow = el("div", { class: "subtask-editor-row" + (checked ? " done" : "") }, [
    checkbox,
    titleInput,
    dateBtn,
    timeInput,
    durInput,
    subTimerControls,
  ]);

  const aiButtons = subtaskAIButtons(s.title, task, s.template_sub_id);
  if (!aiButtons.length) return mainRow;

  const aiRow = el("div", { class: "subtask-ai-row" }, aiButtons.map((b) => el("button", {
    type: "button",
    class: "btn ai-btn",
    onclick: (e) => (b.kind === "list_to_ppt" ? openListToPptModal(s.id, b.label)
      : b.kind === "powerpoint" || b.endpoint === "generate-pptx"
      ? openGeneratePptxModal(s.id, b.label)
      : runSubtaskAI(e.currentTarget, s.id, b.endpoint, b.label, b.buttonId)),
  }, `✨ ${b.label}`)));

  return el("div", {}, [mainRow, aiRow]);
}
