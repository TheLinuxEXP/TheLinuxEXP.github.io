"use strict";

// Finances (Gestion fiscale EI) embedded module.

/* ---------------------------------------------------------------------- *
 * Finances (Gestion fiscale EI) -- a self-contained module served by its own
 * Flask blueprint under /fiscal (see gestion_ei_web/). Its assets are loaded
 * on first use; each section is mounted once and kept (so a half-filled
 * dialog, the selected tab or the chart's hidden series survive navigation).
 * ---------------------------------------------------------------------- */
const FISCAL_BASE = "/fiscal";
const FISCAL_SECTIONS = [
  { key: "factures", icon: "receipt", label: "Factures" },
  { key: "graphique", icon: "chart", label: "Graphique" },
  { key: "declarations", icon: "landmark", label: "Déclarations" },
];
// Same monochrome line-icon style as the other sidebar entries (SYMBOLIC_ICONS above).
Object.assign(SYMBOLIC_ICONS, {
  receipt: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8M12 17.5v-11"/>',
  chart: '<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="m19 9-5 5-4-4-3 3"/>',
  landmark: '<path d="M3 22h18M6 18v-7M10 18v-7M14 18v-7M18 18v-7M12 2 20 7H4z"/>',
  gear: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  checkCircle: '<circle cx="12" cy="12" r="10"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
  coins: '<circle cx="9" cy="9" r="6"/><path d="M15.5 9.6A6 6 0 1 1 9.6 15.5"/><path d="M9 6.5v5M7.3 8.2h3.4"/>',
});
let fiscalLoading = null;
const fiscalHosts = {};   // section key -> { el, app, sub, stale }

function loadFiscalModule() {
  if (window.GestionEI) return Promise.resolve();
  if (fiscalLoading) return fiscalLoading;
  const assets = ["/static/ds/ds.css", "/static/ei.css"];
  for (const href of assets) {
    document.head.appendChild(el("link", { rel: "stylesheet", href: FISCAL_BASE + href }));
  }
  fiscalLoading = new Promise((resolve, reject) => {
    const sc = document.createElement("script");
    sc.src = FISCAL_BASE + "/static/ei.js";
    sc.onload = () => resolve();
    sc.onerror = () => { fiscalLoading = null; reject(new Error("Finance module not available")); };
    document.head.appendChild(sc);
  });
  return fiscalLoading;
}

function renderFinanceNav() {
  const box = document.getElementById("financeNav");
  if (!box) return;
  box.innerHTML = "";
  for (const it of FISCAL_SECTIONS) {
    box.appendChild(el("div", {
      class: "row-item" + (state.view.type === "fiscal" && state.view.fiscalSection === it.key ? " active" : ""),
      onclick: () => openFiscalView(it.key),
    }, [
      symbolicIcon(it.icon),
      el("span", { class: "ri-label" }, it.label),
    ]));
  }
  box.appendChild(el("div", {
    class: "row-item" + (state.view.type === "revenue" ? " active" : ""),
    onclick: () => openRevenue(),
  }, [symbolicIcon("coins"), el("span", { class: "ri-label" }, "Revenu")]));
}

async function openFiscalView(section) {
  const info = FISCAL_SECTIONS.find((x) => x.key === section) || FISCAL_SECTIONS[0];
  try { await loadFiscalModule(); }
  catch (err) { showToast(err.message); return; }
  const host = fiscalHosts[info.key];
  if (host) host.stale = true;        // re-shown: re-read the data
  state.view = { type: "fiscal", fiscalSection: info.key, title: info.label, subtitle: host ? host.sub || "" : "" };
  renderMain();
  renderSidebar();
}

function renderFiscalView(root) {
  const key = state.view.fiscalSection;
  let host = fiscalHosts[key];
  if (!host) {
    host = fiscalHosts[key] = { el: el("div", {}), app: null, sub: "", stale: false };
    root.appendChild(host.el);        // attach before mounting: charts measure their width
    host.app = window.GestionEI.mount(host.el, {
      base: FISCAL_BASE, layout: "embedded", section: key,
      onTitle: (_title, sub) => {
        host.sub = sub;
        if (state.view.type === "fiscal" && state.view.fiscalSection === key) {
          state.view.subtitle = sub;
          document.getElementById("pageSubtitle").textContent = sub;
        }
      },
    });
    return;
  }
  root.appendChild(host.el);
  if (host.stale) { host.stale = false; host.app.ready.then(() => host.app.refreshCurrent()); }
}

const SMART_TITLES = { inbox: "Inbox", today: "Today", tomorrow: "Tomorrow", urgent: "Urgent" };

function renderTopNav() {
  const box = document.getElementById("topNav");
  box.innerHTML = "";
  const isSmart = (type) => state.view.type === "smart" && state.view.smartType === type;

  // Inbox/Today/Tomorrow/Urgent get their own 2x2 grid of colored blocks,
  // since they're the most-used entry points.
  const smartItems = [
    { key: "inbox", icon: "📥", label: "Inbox", active: isSmart("inbox"), action: () => openSmartView("inbox"), count: state.smartCounts.inbox },
    { key: "today", icon: "☀️", label: "Today", active: isSmart("today"), action: () => openSmartView("today"), count: state.smartCounts.today },
    { key: "tomorrow", icon: "📆", label: "Tomorrow", active: isSmart("tomorrow"), action: () => openSmartView("tomorrow"), count: state.smartCounts.tomorrow },
    { key: "urgent", icon: "🚩", label: "Urgent", active: isSmart("urgent"), action: () => openSmartView("urgent"), count: state.smartCounts.urgent },
  ];
  const grid = el("div", { class: "smart-grid" });
  for (const it of smartItems) {
    grid.appendChild(el("div", {
      class: `smart-tile ${it.key}` + (it.active ? " active" : ""),
      onclick: it.action,
    }, [
      el("div", { class: "tile-top" }, [
        el("span", {}, it.icon),
        it.count ? el("span", { class: "tile-count" }, String(it.count)) : null,
      ]),
      el("div", { class: "tile-label" }, it.label),
    ]));
  }
  box.appendChild(grid);
  box.appendChild(el("div", {
    class: "smart-tile video wide" + (state.view.type === "videoproject" ? " active" : ""),
    onclick: () => openVideoProject(),
  }, [
    el("div", { class: "tile-top" }, [el("span", {}, state.currentVideo ? videoTitleIcon(state.currentVideo.video_template) : "🎬")]),
    el("div", { class: "tile-label vp-tile-title", title: state.currentVideo ? state.currentVideo.title : "Current Video project" },
      state.currentVideo ? state.currentVideo.title : "Current Video project"),
  ]));

  const items = [
    { icon: "calendar", label: "Calendar", active: state.view.type === "calendar", action: () => openCalendar() },
    { icon: "megaphone", label: "Sponsors", active: state.view.type === "sponsors", action: () => openSponsorsView() },
    { icon: "clock", label: "Time report", active: state.view.type === "timereport", action: () => openTimeReport() },
    { icon: "notes", label: "Notes & Scripts", active: state.view.type === "notes", action: () => openNotes() },
  ];
  for (const it of items) {
    box.appendChild(el("div", {
      class: "row-item" + (it.active ? " active" : ""),
      onclick: it.action,
    }, [
      symbolicIcon(it.icon),
      el("span", { class: "ri-label" }, it.label),
      it.count ? el("span", { class: "ri-count" }, String(it.count)) : null,
    ]));
  }
}
