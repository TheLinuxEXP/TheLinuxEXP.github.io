"use strict";

// "AI settings" window: which model answers every AI button (Claude subscription, Anthropic API, a local model
// such as Ollama, or a cloud provider). The prompts are the same whatever the model; only the destination changes.

async function openAiSettings() {
  let cfg;
  try { cfg = await api.get("/api/ai/settings"); } catch (e) { showToast("Couldn't load the AI settings"); return; }
  const byId = Object.fromEntries(cfg.providers.map((p) => [p.id, p]));
  let current = cfg.active;
  const drafts = {};            // provider id -> {model, base_url, vision, api_key} typed but not yet saved

  const sel = el("select", {}, cfg.providers.map((p) => el("option", { value: p.id }, p.label)));
  sel.value = current;
  const help = el("div", { class: "muted", style: "font-size:12px;margin:-6px 0 14px" });
  const modelIn = el("input", { type: "text", list: "aiModelList", autocomplete: "off" });
  const modelList = el("datalist", { id: "aiModelList" });
  const detectBtn = el("button", { class: "btn", type: "button", style: "margin-top:6px", onclick: detectModels }, "Detect available models");
  const urlIn = el("input", { type: "text", autocomplete: "off", placeholder: "http://localhost:11434/v1" });
  const keyIn = el("input", { type: "password", autocomplete: "new-password" });
  const keyNote = el("div", { class: "muted", style: "font-size:12px;margin-top:4px" });
  const visionIn = el("input", { type: "checkbox" });
  const timeoutIn = el("input", { type: "number", min: "30", max: "7200", value: String(cfg.timeout) });
  const status = el("div", { style: "font-size:13px;margin-top:10px;min-height:18px" });

  const fModel = el("div", { class: "field" }, [el("label", {}, "Model"), modelIn, modelList, detectBtn]);
  const fUrl = el("div", { class: "field" }, [el("label", {}, "Server address"), urlIn]);
  const fKey = el("div", { class: "field" }, [el("label", {}, "API key"), keyIn, keyNote]);
  const fVision = el("div", { class: "field" }, [el("label", { style: "display:flex;gap:8px;align-items:center;font-weight:400" },
    [visionIn, "This model can read images (needed to analyse PDF pages)"])]);

  function stash() {
    drafts[current] = { model: modelIn.value, base_url: urlIn.value, vision: visionIn.checked, api_key: keyIn.value };
  }
  function show(pid) {
    current = pid;
    const p = byId[pid], saved = cfg.profiles[pid], d = drafts[pid] || {};
    help.textContent = p.help + (p.web ? "" : " No web search with this provider: it answers from the content it is given.");
    modelIn.value = d.model !== undefined ? d.model : saved.model;
    modelIn.placeholder = p.kind === "claude_cli" ? "Default model (or sonnet / opus)" : (p.model || "Model name");
    urlIn.value = d.base_url !== undefined ? d.base_url : saved.base_url;
    keyIn.value = d.api_key || "";
    keyNote.textContent = saved.has_key ? "A key is saved (leave empty to keep it)." : "";
    visionIn.checked = d.vision !== undefined ? d.vision : saved.vision;
    fUrl.style.display = p.kind === "claude_cli" ? "none" : "";
    fKey.style.display = p.kind === "claude_cli" || (!p.needs_key && p.local) ? "none" : "";
    fVision.style.display = p.kind === "claude_cli" ? "none" : "";
    detectBtn.style.display = p.kind === "claude_cli" ? "none" : "";
    modelList.innerHTML = "";
    status.textContent = "";
  }
  async function detectModels() {
    stash();
    status.style.color = "var(--muted)";
    status.textContent = "Looking…";
    await save(false);
    try {
      const r = await api.get(`/api/ai/models?provider=${encodeURIComponent(current)}`);
      modelList.innerHTML = "";
      for (const m of r.models) modelList.appendChild(el("option", { value: m }));
      status.textContent = r.error ? r.error : (r.models.length ? `${r.models.length} models found: start typing in the Model field to pick one.` : "No model reported by the server.");
      status.style.color = r.error ? "var(--danger, #c0392b)" : "var(--muted)";
    } catch (e) { status.textContent = "Couldn't ask the server."; }
  }
  async function save(close) {
    stash();
    const d = drafts[current];
    try {
      cfg = await api.send("PUT", "/api/ai/settings", {
        active: current, timeout: parseInt(timeoutIn.value, 10) || null,
        profile: { id: current, model: d.model, base_url: d.base_url, vision: d.vision, api_key: d.api_key },
      });
      drafts[current].api_key = "";
      keyIn.value = "";
      keyNote.textContent = cfg.profiles[current].has_key ? "A key is saved (leave empty to keep it)." : "";
    } catch (e) {
      status.style.color = "var(--danger, #c0392b)";
      try { status.textContent = JSON.parse(e.message).error; } catch (_) { status.textContent = e.message; }
      return false;
    }
    if (close) { closeModal(); showToast(`AI: ${byId[current].label}`); }
    return true;
  }
  async function test() {
    status.style.color = "var(--muted)";
    status.textContent = "Testing…";
    if (!(await save(false))) return;
    try {
      const r = await api.send("POST", "/api/ai/test", {});
      status.style.color = r.ok ? "var(--success, #2e8b57)" : "var(--danger, #c0392b)";
      status.textContent = r.ok ? `Works (${r.seconds}s). Reply: “${r.reply}”` : r.error;
    } catch (e) { status.style.color = "var(--danger, #c0392b)"; status.textContent = "Test failed."; }
  }

  sel.addEventListener("change", () => { stash(); show(sel.value); });
  show(current);
  openModal("AI settings", [
    el("div", { class: "field" }, [el("label", {}, "AI used by every AI button"), sel]),
    help, fModel, fUrl, fKey, fVision,
    el("div", { class: "field" }, [el("label", {}, "Time limit per request (seconds)"), timeoutIn,
      el("div", { class: "muted", style: "font-size:12px;margin-top:4px" }, "Local models can be slow: raise it if requests time out.")]),
    status,
  ], [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", { class: "btn", onclick: test }, "Test"),
    el("button", { class: "btn primary", onclick: () => save(true) }, "Save"),
  ]);
}

function wireAiSettings() {
  const b = document.getElementById("aiSettingsBtn");
  if (b) b.addEventListener("click", openAiSettings);
}
