"use strict";

// Smart views (Inbox / Today / Tomorrow / Urgent), navigation, sponsors.

/* ---------------------------------------------------------------------- *
 * Smart views: Inbox / Today / Tomorrow / Urgent — tasks from every
 * project, grouped into collapsible per-project sections.
 * ---------------------------------------------------------------------- */
function smartViewParams(type) {
  const params = new URLSearchParams();
  if (type === "inbox") params.set("no_due_date", "1");
  else if (type === "today") { params.set("due_date", todayIso()); params.set("include_overdue", "1"); }
  else if (type === "tomorrow") params.set("due_date", tomorrowIso());
  else if (type === "urgent") params.set("urgent", "1");
  return params;
}

async function loadSmartTasks(type) {
  if (type === "today" || type === "tomorrow" || type === "urgent") {
    const data = await api.get("/api/tasks/smart?" + smartViewParams(type).toString());
    state.tasks = data.tasks;
    state.orphanSubtasks = data.orphan_subtasks || [];
    state.orphanParents = data.orphan_parents || [];
    state.completedOccurrences = data.completed_occurrences || [];
    state.otherToday = type === "today" ? await api.get("/api/other-tasks") : null;
    if (type === "today") await loadProjectOther();
  } else {
    state.tasks = await api.get("/api/tasks?" + smartViewParams(type).toString());
    state.orphanSubtasks = [];
    state.orphanParents = [];
    state.completedOccurrences = [];
  }
}

async function openSmartView(type) {
  state.view = { type: "smart", smartType: type, title: SMART_TITLES[type] };
  await loadSmartTasks(type);
  renderMain();
  renderSidebar();
}

// A main task counts as "fully done" (hide-worthy when Show completed is
// off) only if it's checked AND, when it has subtasks, every one of those
// is checked too -- a task checked off by hand while a subtask is still
// open, or with only some subtasks done, isn't really finished yet and
// should stay visible.
function isTaskFullyDone(t) {
  if (!t.checked) return false;
  if (t.subtasks && t.subtasks.length) return t.subtasks.every((s) => s.checked);
  return true;
}

function completedOccurrenceRow(c) {
  // A finished occurrence of a recurring task, with the subtasks it had when
  // it was finished (snapshot) in a foldable list underneath.
  const subs = c.subtasks || [];
  const key = "occ:" + c.id;
  const expanded = state.expandedSubtasks.has(key);
  const list = subs.length ? el("div", { class: "subtask-list" + (expanded ? " expanded" : "") }) : null;
  for (const s of subs) {
    list.appendChild(el("div", { class: "subtask-row", onclick: () => openOccurrenceDetail(c) }, [
      el("div", { class: "checkbox small disabled" + (s.checked ? " checked" : "") }, s.checked ? "✓" : ""),
      el("div", { class: "task-main" }, [
        el("div", { class: "task-content" + (s.checked ? " done" : "") }, s.title),
        s.time_spent_seconds ? el("div", { class: "task-meta" },
          [el("span", { class: "duration-chip" }, "⏱ " + formatElapsed(s.time_spent_seconds))]) : null,
      ]),
    ]));
  }
  const foldToggle = subs.length ? el("button", {
    class: "fold-toggle" + (expanded ? " expanded" : ""),
    title: expanded ? "Hide subtasks" : "Show subtasks",
    onclick: (e) => {
      e.stopPropagation();
      const now = !state.expandedSubtasks.has(key);
      if (now) state.expandedSubtasks.add(key); else state.expandedSubtasks.delete(key);
      foldToggle.classList.toggle("expanded", now);
      list.classList.toggle("expanded", now);
    },
  }, "▸") : el("span", { class: "fold-toggle placeholder" });
  const metaBits = [
    el("span", {}, "🔁 finished " + formatDue(c.occurrence_date).text),
    (c.time_spent_seconds || subs.some((x) => x.time_spent_seconds))
      ? el("span", { class: "duration-chip" }, "⏱ " + formatElapsed((c.time_spent_seconds || 0) + subs.reduce((n, x) => n + (x.time_spent_seconds || 0), 0))) : null,
  ];
  if (subs.length) metaBits.push(el("span", { class: "muted" }, `☑ ${subs.filter((x) => x.checked).length}/${subs.length}`));
  const row = el("div", { class: "task-row", onclick: () => openOccurrenceDetail(c) }, [
    foldToggle,
    el("div", { class: "checkbox checked disabled", title: "This occurrence is finished" }, "✓"),
    el("div", { class: "task-main" }, [
      el("div", { class: "task-title done" }, [
        c.is_video ? el("span", { class: "video-badge" }, videoTitleIcon(c.video_template) + " ") : null,
        c.title,
      ]),
      el("div", { class: "task-meta" }, metaBits),
    ]),
  ]);
  return list ? el("div", { class: "task-with-subtasks" }, [row, list]) : row;
}

// The projects' "Other tasks": reloaded with every view that shows them (a timer may have been changed from the widget)
async function loadProjectOther() {
  try { state.projectOther = await api.get("/api/project-other-tasks"); } catch (e) { /* keep the last known state */ }
}

// One project's permanent "Other tasks" row: time typed or timed on the project outside any of its tasks. In the Today
// view (opts.showProject) the project is named; inside a project / list it is implied.
function projectOtherRow(o, opts = {}) {
  const entity = { id: `${o.project_id}/${o.day}`, time_spent_seconds: o.time_spent_seconds, timer_state: o.timer_state };
  const when = o.day !== todayIso() ? ` (${o.day}, still running)` : "";
  return el("div", { class: "task-row project-other-row", style: "cursor:default", "data-project": o.project_id }, [
    el("span", { class: "dot", style: `background:${safeColor(o.color, "#7f8c8d")};margin-top:6px` }),
    el("div", { class: "task-main", style: "flex:1;min-width:0" }, [
      el("div", { class: "task-content" }, opts.showProject ? ["Other tasks", el("span", { class: "muted", style: "font-weight:400" }, " · " + o.project_name)] : "Other tasks"),
      el("div", { class: "task-meta" }, [
        el("span", {}, "Time on this project outside any task" + when),
        timeEditor(entity, "project-other-tasks"),
      ]),
    ]),
    timerControls(entity, "project-other-tasks"),
  ]);
}

function otherTasksRow(o) {
  const entity = { id: o.day, time_spent_seconds: o.time_spent_seconds, timer_state: o.timer_state };
  const when = o.day !== todayIso() ? ` (${o.day}, still running)` : "";
  return el("div", { class: "task-row other-tasks-row", style: "cursor:default" }, [
    el("span", { class: "dot", style: "background:var(--muted, #888);margin-top:6px" }),
    el("div", { class: "task-main", style: "flex:1;min-width:0" }, [
      el("div", { class: "task-content" }, "Other tasks"),
      el("div", { class: "task-meta" }, [
        el("span", {}, "Time spent outside any task or project" + when),
        timeEditor(entity, "other-tasks"),
      ]),
    ]),
    timerControls(entity, "other-tasks"),
  ]);
}

function renderSmartView(type, tasks, orphanSubtasks = [], orphanParents = []) {
  let finished = [];
  if (!state.showCompleted) {
    tasks = tasks.filter((t) => !isTaskFullyDone(t));
    orphanSubtasks = orphanSubtasks.filter((s) => !s.checked);
    orphanParents = orphanParents.filter((p) => orphanSubtasks.some((s) => s.parent_task_id === p.id));
  } else {
    finished = state.completedOccurrences || [];
  }
  const wrap = el("div", {});

  // "Other tasks": time that belongs to no task, always first in Today so it can be timed or typed in
  if (type === "today" && state.otherToday) wrap.appendChild(otherTasksRow(state.otherToday));
  // ... then the "Other tasks" of every project
  if (type === "today") for (const o of state.projectOther || []) wrap.appendChild(projectOtherRow(o, { showProject: true }));

  if (type === "today" || type === "tomorrow") {
    const totalMinutes = tasks.filter((t) => !t.checked).reduce((sum, t) => sum + (t.duration_minutes || 0), 0)
      + orphanSubtasks.filter((s) => !s.checked).reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
    if (totalMinutes) {
      wrap.appendChild(el("div", { class: "muted", style: "margin-bottom:14px" },
        `Estimated total: ${formatHoursTotal(totalMinutes)}`));
    }
  }

  if (!tasks.length && !orphanParents.length && !finished.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("checkCircle"),
      el("div", {}, "Nothing here"),
    ]));
    return wrap;
  }

  const byProject = new Map();
  const groupFor = (key) => {
    if (!byProject.has(key)) byProject.set(key, { tasks: [], parents: [], finished: [] });
    return byProject.get(key);
  };
  for (const t of tasks) groupFor(t.project_id || "none").tasks.push(t);
  for (const p of orphanParents) groupFor(p.project_id || "none").parents.push(p);
  for (const c of finished) groupFor(c.project_id || "none").finished.push(c);

  for (const [pid, group] of byProject) {
    const proj = state.projects.find((p) => p.id === pid);
    const groupKey = `${type}:${pid}`;
    const collapsed = state.collapsedGroups.has(groupKey);
    const caret = el("span", { class: "caret" + (collapsed ? "" : " open") }, "▶");
    const header = el("div", { class: "group-header" }, [
      caret,
      proj ? el("span", { class: "dot", style: `background:${proj.color}` }) : null,
      el("span", { class: "ri-label" }, proj ? proj.name : "No project"),
      el("span", { class: "ri-count" }, String(group.tasks.length + group.parents.length + group.finished.length)),
    ]);
    wrap.appendChild(header);
    const body = el("div", { class: "group-body" + (collapsed ? "" : " expanded") });
    for (const t of group.tasks) {
      if (t.subtasks && t.subtasks.some((s) => s.matches_filter)) state.expandedSubtasks.add(t.id);
      body.appendChild(taskRow(t, { showListHint: true, smartType: type }));
    }
    // main tasks that are only here because one of their subtasks matches
    for (const p of group.parents) {
      state.expandedSubtasks.add(p.id);
      body.appendChild(taskRow(p, { showListHint: true, contextParent: true, smartType: type }));
    }
    for (const c of group.finished) body.appendChild(completedOccurrenceRow(c));
    wrap.appendChild(body);
    header.addEventListener("click", () => {
      const nowCollapsed = !state.collapsedGroups.has(groupKey);
      if (nowCollapsed) state.collapsedGroups.add(groupKey); else state.collapsedGroups.delete(groupKey);
      caret.classList.toggle("open", !nowCollapsed);
      body.classList.toggle("expanded", !nowCollapsed);
    });
  }
  return wrap;
}

function orphanSubtaskRow(s) {
  // A subtask matching the current Today/Tomorrow/Urgent filter whose parent
  // task does not itself match -- shown as its own row (tagged with its
  // parent task's title) since it would otherwise never surface in this view.
  const checked = !!s.checked;
  const due = formatDue(s.due_date);

  const checkbox = el("div", {
    class: "checkbox small" + (checked ? " checked" : ""),
    onclick: async (e) => {
      e.stopPropagation();
      await api.post(`/api/subtasks/${s.id}/toggle`, { checked: !checked });
      refreshCurrentView();
    },
  }, checked ? "✓" : "");

  const metaBits = [];
  if (due.text) metaBits.push(el("span", { class: due.overdue ? "overdue" : "" }, due.text));
  if (s.duration_minutes) metaBits.push(el("span", { class: "duration-chip" }, "⏱ " + formatDuration(s.duration_minutes)));
  metaBits.push(el("span", { class: "muted" }, "↳ " + s.parent_title));

  const titleBits = [
    (!checked && due.overdue) ? el("span", { class: "overdue-clock", title: "Overdue" }, "⏰ ") : null,
    s.urgent ? el("span", { class: "urgent-flag", title: "Urgent" }, "🚩 ") : null,
    s.is_video ? el("span", { class: "video-badge", title: templateLabel(s.parent_video_template) },
      videoTitleIcon(s.parent_video_template) + " ") : null,
    s.title,
  ];

  return el("div", { class: "task-row orphan-subtask-row", onclick: () => openTaskDetail(s.parent_task_id) }, [
    el("span", { class: "fold-toggle placeholder" }),
    checkbox,
    el("div", { class: "task-main" }, [
      el("div", { class: "task-content" + (checked ? " done" : "") }, titleBits),
      metaBits.length ? el("div", { class: "task-meta" }, metaBits) : null,
    ]),
    timerControls(s, "subtasks"),
  ]);
}

function renderProjectsTree() {
  const box = document.getElementById("projectsTree");
  box.innerHTML = "";
  for (const p of state.projects) box.appendChild(projectBlock(p));
  document.getElementById("addProjectBtn").onclick = () => openProjectDialog(null);
}

function projectBlock(p) {
  const open = state.expanded.has(p.id);
  const active = state.view.type === "project" && state.view.projectId === p.id;
  const lists = state.todoLists.filter((l) => l.project_id === p.id);

  const toggleFold = () => {
    const nowOpen = !state.expanded.has(p.id);
    if (nowOpen) state.expanded.add(p.id); else state.expanded.delete(p.id);
    caret.classList.toggle("open", nowOpen);
    children.classList.toggle("expanded", nowOpen);
  };

  const caret = el("span", {
    class: "caret" + (open ? " open" : ""),
    onclick: (e) => { e.stopPropagation(); toggleFold(); },
  }, "▶");

  const head = el("div", { class: "project-head" + (active ? " active" : "") }, [
    caret,
    el("span", { class: "dot", style: `background:${p.color}` }),
    el("span", {
      class: "ri-label",
      title: "Show all tasks in this project",
      onclick: (e) => { e.stopPropagation(); openProjectView(p); },
    }, p.name),
    el("span", { class: "ri-count" }, p.task_count > 0 ? String(p.task_count) : ""),
    el("button", {
      class: "icon-btn small", title: "Add list",
      onclick: (e) => { e.stopPropagation(); openListDialog(p.id); },
    }, "＋"),
    (() => {
      const btn = el("button", {
        class: "icon-btn small",
        onclick: (e) => {
          e.stopPropagation();
          openDropdown(btn, [
            el("button", { onclick: () => openProjectDialog(p) }, "Edit project"),
            el("button", {
              class: "danger",
              onclick: async () => {
                if (!(await confirmModal({ title: "Delete project?", message: `“${p.name}” and all its lists and tasks will be deleted.`, confirmLabel: "Delete", danger: true }))) return;
                await api.del(`/api/projects/${p.id}`);
                await refreshSidebarData();
                if (state.view.type === "list" && !state.todoLists.find((l) => l.id === state.view.todoListId)) {
                  openFirstAvailable();
                }
              },
            }, "Delete project"),
          ]);
        },
      }, "⋮");
      return btn;
    })(),
  ]);
  head.addEventListener("click", toggleFold);

  const children = el("div", { class: "list-children" + (open ? " expanded" : "") });
  for (const l of lists) children.appendChild(listRow(l));
  if (lists.length === 0) {
    children.appendChild(el("div", { class: "muted small", style: "padding:6px 8px" }, "No lists yet"));
  }

  return el("div", { class: "project-block" }, [head, children]);
}

// Drag & drop of the lists of a project (same project only): a line shows where the list will land.
let listDrag = null;   // { id, project_id }

function clearListDropMarks() {
  document.querySelectorAll(".row-item.drop-before, .row-item.drop-after, .row-item.dragging")
    .forEach((n) => n.classList.remove("drop-before", "drop-after", "dragging"));
}

async function dropList(targetId, after) {
  const drag = listDrag;
  listDrag = null;
  clearListDropMarks();
  if (!drag || drag.id === targetId) return;
  const ids = state.todoLists.filter((x) => x.project_id === drag.project_id).map((x) => x.id).filter((i) => i !== drag.id);
  let at = ids.indexOf(targetId);
  if (at < 0) return;
  ids.splice(after ? at + 1 : at, 0, drag.id);
  try { await api.post("/api/todolists/reorder", { project_id: drag.project_id, ids }); }
  catch (e) { showToast("Couldn't reorder the lists"); }
  await refreshSidebarData();
  renderSidebar();
}

function wireListDrag(row, l) {
  row.setAttribute("draggable", "true");
  row.addEventListener("dragstart", (e) => {
    listDrag = { id: l.id, project_id: l.project_id };
    e.dataTransfer.effectAllowed = "move";
    try { e.dataTransfer.setData("text/plain", l.name); } catch { /* ignore */ }
    row.classList.add("dragging");
  });
  row.addEventListener("dragend", () => { listDrag = null; clearListDropMarks(); });
  row.addEventListener("dragover", (e) => {
    if (!listDrag || listDrag.project_id !== l.project_id || listDrag.id === l.id) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    const r = row.getBoundingClientRect();
    const after = e.clientY > r.top + r.height / 2;
    row.classList.toggle("drop-after", after);
    row.classList.toggle("drop-before", !after);
  });
  row.addEventListener("dragleave", (e) => { if (!row.contains(e.relatedTarget)) row.classList.remove("drop-before", "drop-after"); });
  row.addEventListener("drop", (e) => {
    if (!listDrag || listDrag.project_id !== l.project_id) return;
    e.preventDefault();
    const r = row.getBoundingClientRect();
    dropList(l.id, e.clientY > r.top + r.height / 2);
  });
}

function listRow(l) {
  const active = state.view.type === "list" && state.view.todoListId === l.id;
  const row = el("div", {
    class: "row-item" + (active ? " active" : ""),
    onclick: () => openTodoList(l),
  }, [
    symbolicIcon("list"),
    el("span", { class: "ri-label" }, l.name),
    el("span", { class: "ri-count" }, l.task_count > 0 ? String(l.task_count) : ""),
  ]);
  const kebabBtn = el("button", {
    class: "icon-btn small",
    style: "flex:0 0 auto",
    onclick: (e) => {
      e.stopPropagation();
      openDropdown(kebabBtn, [
        el("button", {
          onclick: async () => {
            const name = await promptModal({ title: "Rename list", value: l.name });
            if (name && name.trim()) api.patch(`/api/todolists/${l.id}`, { name: name.trim() }).then(refreshAfterStructureChange);
          },
        }, "Rename"),
        el("button", {
          class: "danger",
          onclick: async () => {
            if (!(await confirmModal({ title: "Delete list?", message: `“${l.name}” and all its tasks will be deleted.`, confirmLabel: "Delete", danger: true }))) return;
            await api.del(`/api/todolists/${l.id}`);
            await refreshSidebarData();
            if (state.view.todoListId === l.id) openFirstAvailable();
          },
        }, "Delete"),
      ]);
    },
  }, "⋮");
  row.appendChild(kebabBtn);
  wireListDrag(row, l);
  return row;
}

async function refreshAfterStructureChange() {
  await refreshSidebarData();
  if (state.view.type === "list" && state.view.todoListId) {
    const l = state.todoLists.find((x) => x.id === state.view.todoListId);
    if (l) state.view.title = l.name;
  }
  renderMain();
}

function openFirstAvailable() {
  if (state.todoLists.length) openTodoList(state.todoLists[0]);
  else { state.view = { type: "list", todoListId: null, title: "Tasks" }; state.tasks = []; renderMain(); renderSidebar(); }
}

/* ---------------------------------------------------------------------- *
 * Navigation
 * ---------------------------------------------------------------------- */
async function openTodoList(list) {
  const project = state.projects.find((p) => p.id === list.project_id);
  state.expanded.add(list.project_id);
  state.view = { type: "list", todoListId: list.id, title: list.name, project };
  state.tasks = await api.get(`/api/tasks?todo_list_id=${list.id}&include_done=${state.showCompleted ? 1 : 0}`);
  await loadProjectOther();
  renderMain();
  renderSidebar();
}

async function openProjectView(project) {
  state.expanded.add(project.id);
  state.view = { type: "project", projectId: project.id, title: project.name, project };
  state.tasks = await api.get(`/api/tasks?project_id=${project.id}&include_done=${state.showCompleted ? 1 : 0}`);
  await loadProjectOther();
  renderMain();
  renderSidebar();
}

function renderProjectView(tasks, project) {
  const wrap = el("div", {});
  const mine = (state.projectOther || []).find((o) => project && o.project_id === project.id);
  if (mine) wrap.appendChild(projectOtherRow(mine));          // the project's own "Other tasks", always first
  if (!tasks.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("list"),
      el("div", {}, "Nothing here yet"),
    ]));
    return wrap;
  }

  const byList = new Map();
  for (const t of tasks) {
    const key = t.todo_list_id || "none";
    if (!byList.has(key)) byList.set(key, []);
    byList.get(key).push(t);
  }

  for (const [lid, group] of byList) {
    const list = state.todoLists.find((l) => l.id === lid);
    const groupKey = `project:${lid}`;
    const collapsed = state.collapsedGroups.has(groupKey);
    const caret = el("span", { class: "caret" + (collapsed ? "" : " open") }, "▶");
    const header = el("div", { class: "group-header" }, [
      caret,
      el("span", { class: "ri-label" }, list ? list.name : "No list"),
      el("span", { class: "ri-count" }, String(group.length)),
    ]);
    wrap.appendChild(header);
    const body = el("div", { class: "group-body" + (collapsed ? "" : " expanded") });
    for (const t of group) body.appendChild(taskRow(t));
    wrap.appendChild(body);
    header.addEventListener("click", () => {
      const nowCollapsed = !state.collapsedGroups.has(groupKey);
      if (nowCollapsed) state.collapsedGroups.add(groupKey); else state.collapsedGroups.delete(groupKey);
      caret.classList.toggle("open", !nowCollapsed);
      body.classList.toggle("expanded", !nowCollapsed);
    });
  }
  return wrap;
}

async function openCalendar(year, month) {
  const now = new Date();
  state.calendar.year = year || now.getFullYear();
  state.calendar.month = month || (now.getMonth() + 1);
  state.view = { type: "calendar", title: "Calendar" };
  await loadCalendar();
  renderSidebar();
}

async function loadCalendar() {
  if (state.calendar.mode === "week") {
    const start = state.calendar.weekStart || startOfWeekIso(todayIso());
    state.calendar.weekStart = start;
    const end = addDaysIso(start, 6);
    const [entries, timeByDay, otherByDay, projectOtherByDay] = await Promise.all([
      api.get(`/api/calendar/range?start=${start}&end=${end}`),
      api.get(`/api/calendar/time-by-day?start=${start}&end=${end}`),
      api.get(`/api/other-tasks?start=${start}&end=${end}`),
      api.get(`/api/project-other-tasks?start=${start}&end=${end}`),
    ]);
    state.calendar.data = entries;
    state.calendar.timeByDay = timeByDay;
    state.calendar.otherByDay = otherByDay;
    state.calendar.projectOtherByDay = projectOtherByDay;
  } else {
    const ov = state.calendar.onlyVideos ? "&only_videos=1" : "";
    state.calendar.data = await api.get(`/api/calendar?year=${state.calendar.year}&month=${state.calendar.month}${ov}`);
  }
  renderMain();
}

/* ---------------------------------------------------------------------- *
 * Sponsors — tags, how many (main) tasks carry each one in a given month,
 * and those tasks' due dates.
 * ---------------------------------------------------------------------- */
// Two tabs: "Publication Calendar" (the monthly view below) and "Contracts and
// Billing" (every tag with its contract: download it, or upload one).
function openNotes() {
  state.view = { type: "notes", title: "Notes & Scripts" };
  renderSidebar();
  renderMain();
}
