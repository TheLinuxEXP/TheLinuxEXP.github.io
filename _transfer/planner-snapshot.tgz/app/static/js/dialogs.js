"use strict";

// Quick add, date picker, modal helper, project / list dialogs.

/* ---------------------------------------------------------------------- *
 * Quick add (header row + FAB dialog)
 * ---------------------------------------------------------------------- */
function wireQuickAdd() {
  const input = document.getElementById("quickAddInput");
  input.addEventListener("keydown", async (e) => {
    if (e.key !== "Enter" || !input.value.trim() || !state.view.todoListId) return;
    const title = input.value.trim();
    input.value = "";
    await api.post("/api/tasks", { todo_list_id: state.view.todoListId, title });
    refreshCurrentView();
  });

  document.getElementById("fab").addEventListener("click", (e) => { e.stopPropagation(); openFabMenu(); });
}

// The "+" FAB opens a little submenu: a plain task, or one of the video
// templates that stamp out a main task plus its usual subtasks.
function openFabMenu() {
  closeDropdowns(true);
  const fab = document.getElementById("fab");
  const rect = fab.getBoundingClientRect();
  const dd = el("div", { class: "dropdown opens-up" }, [
    el("button", { onclick: () => { closeDropdowns(); openQuickAddModal(); } }, "📝 Task"),
    ...state.templates.map((t) => el("button", {
      onclick: () => { closeDropdowns(); openTemplateModal(t.key); },
    }, `${t.menu_icon || t.icon || "🎥"} ${t.label}`)),
  ]);
  dd.style.position = "fixed";
  dd.style.bottom = `${window.innerHeight - rect.top + 8}px`;
  dd.style.right = `${Math.max(4, window.innerWidth - rect.right)}px`;
  dd.addEventListener("click", (e) => e.stopPropagation());
  document.body.appendChild(dd);
}

function openTemplateModal(key) {
  const listOptions = state.todoLists.map((l) => {
    const proj = state.projects.find((p) => p.id === l.project_id);
    return el("option", { value: l.id, selected: l.id === state.view.todoListId || undefined }, `${proj ? proj.name : "?"} / ${l.name}`);
  });
  if (!listOptions.length) { showToast("Create a project and a list first"); return; }
  const listSelect = el("select", {}, listOptions);
  const fixedList = (templateByKey(key) || {}).target_list_id;       // this template always goes to one list
  if (fixedList && state.todoLists.some((l) => l.id === fixedList)) { listSelect.value = fixedList; listSelect.disabled = true; }
  openModal(`Create "${templateLabel(key)}"`, [
    el("div", { class: "field" }, [el("label", {}, "List"), listSelect]),
    el("div", { class: "muted small" }, templateIsUnscheduled(key)
      ? "This creates the main task plus its usual subtasks, with no due date set -- schedule it yourself whenever you like."
      : "This creates the main task plus its usual subtasks, scheduled automatically."),
  ], [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", {
      class: "btn primary",
      onclick: async () => {
        await api.post(`/api/templates/${key}`, { todo_list_id: listSelect.value });
        closeModal();
        showToast(`${templateLabel(key)} created`);
        refreshCurrentView();
      },
    }, "Create"),
  ]);
}

// What a task created from the current view should start with: Today/Tomorrow
// give it that due date, Urgent flags it urgent.
function smartViewDefaults() {
  if (state.view.type !== "smart") return {};
  if (state.view.smartType === "today") return { due_date: todayIso() };
  if (state.view.smartType === "tomorrow") return { due_date: tomorrowIso() };
  if (state.view.smartType === "urgent") return { urgent: true };
  return {};
}

function openQuickAddModal() {
  const listOptions = state.todoLists.map((l) => {
    const proj = state.projects.find((p) => p.id === l.project_id);
    return el("option", { value: l.id, selected: l.id === state.view.todoListId || undefined }, `${proj ? proj.name : "?"} / ${l.name}`);
  });
  if (!listOptions.length) { showToast("Create a project and a list first"); return; }
  const titleInput = el("input", { type: "text", placeholder: "Task title" });
  const listSelect = el("select", {}, listOptions);
  const defaults = smartViewDefaults();
  const hint = defaults.due_date ? `Due date: ${defaults.due_date === todayIso() ? "today" : "tomorrow"}`
    : (defaults.urgent ? "Will be marked urgent" : "");
  openModal("Add task", [
    el("div", { class: "field" }, [el("label", {}, "Title"), titleInput]),
    el("div", { class: "field" }, [el("label", {}, "List"), listSelect]),
    hint ? el("div", { class: "muted small" }, hint) : null,
  ].filter(Boolean), [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", {
      class: "btn primary",
      onclick: async () => {
        if (titleInput.value.trim()) {
          await api.post("/api/tasks", { todo_list_id: listSelect.value, title: titleInput.value.trim(), ...defaults });
          closeModal();
          refreshCurrentView();
        }
      },
    }, "Add"),
  ]);
  setTimeout(() => titleInput.focus(), 30);
  titleInput.addEventListener("keydown", (e) => { if (e.key === "Enter") document.querySelector(".modal .btn.primary").click(); });
}

/* ---------------------------------------------------------------------- *
 * Popup date picker — a small floating month calendar used in place of a
 * native <input type="date">. The native picker's calendar-icon indicator
 * doesn't reliably adapt to a dark background (it stays a fixed dark glyph
 * in most browsers), so it all but disappears in dark mode; this is also
 * just closer to what was asked for ("a little popup calendar").
 * ---------------------------------------------------------------------- */
function formatDateDisplay(iso) {
  if (!iso) return "No due date";
  return parseIso(iso).toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" });
}

function openDatePickerPopup(anchorEl, selectedIso, onSelect) {
  closeDropdowns();
  const base = selectedIso ? parseIso(selectedIso) : parseIso(todayIso());
  let viewYear = base.getFullYear();
  let viewMonth = base.getMonth() + 1; // 1-12

  const rect = anchorEl.getBoundingClientRect();
  const pop = el("div", { class: "dropdown date-popup" });
  pop.style.position = "fixed";
  pop.style.top = `${rect.bottom + 4}px`;
  pop.style.left = `${Math.max(4, rect.left)}px`;

  function render() {
    pop.innerHTML = "";
    pop.appendChild(el("div", { class: "date-popup-header" }, [
      el("button", { class: "icon-btn small", type: "button", onclick: (e) => { e.stopPropagation(); navigate(-1); } }, "‹"),
      el("strong", {}, `${MONTH_NAMES[viewMonth - 1]} ${viewYear}`),
      el("button", { class: "icon-btn small", type: "button", onclick: (e) => { e.stopPropagation(); navigate(1); } }, "›"),
    ]));

    const grid = el("div", { class: "date-popup-grid" });
    for (const wd of WEEKDAY_NAMES) grid.appendChild(el("div", { class: "date-popup-wd" }, wd[0]));

    const firstOfMonth = new Date(viewYear, viewMonth - 1, 1);
    const startOffset = (firstOfMonth.getDay() + 6) % 7;
    const daysInMonth = new Date(viewYear, viewMonth, 0).getDate();
    const daysInPrevMonth = new Date(viewYear, viewMonth - 1, 0).getDate();
    const todayStr = todayIso();

    const cells = [];
    for (let i = 0; i < startOffset; i++) cells.push({ dayNum: daysInPrevMonth - startOffset + 1 + i, outside: true });
    for (let d = 1; d <= daysInMonth; d++) {
      cells.push({ dayNum: d, outside: false, iso: `${viewYear}-${String(viewMonth).padStart(2, "0")}-${String(d).padStart(2, "0")}` });
    }
    while (cells.length % 7 !== 0) cells.push({ dayNum: cells.length - (startOffset + daysInMonth) + 1, outside: true });

    for (const cell of cells) {
      if (cell.outside) { grid.appendChild(el("div", { class: "date-popup-day outside" }, String(cell.dayNum))); continue; }
      const classes = ["date-popup-day"];
      if (cell.iso === todayStr) classes.push("today");
      if (cell.iso === selectedIso) classes.push("selected");
      grid.appendChild(el("div", {
        class: classes.join(" "),
        onclick: (e) => { e.stopPropagation(); onSelect(cell.iso); closeDropdowns(); },
      }, String(cell.dayNum)));
    }
    pop.appendChild(grid);

    pop.appendChild(el("div", { class: "date-popup-actions" }, [
      el("button", { class: "btn", type: "button", onclick: (e) => { e.stopPropagation(); onSelect(todayIso()); closeDropdowns(); } }, "Today"),
      el("button", { class: "btn", type: "button", onclick: (e) => { e.stopPropagation(); onSelect(null); closeDropdowns(); } }, "Clear"),
    ]));
  }

  function navigate(delta) {
    viewMonth += delta;
    if (viewMonth < 1) { viewMonth = 12; viewYear -= 1; }
    if (viewMonth > 12) { viewMonth = 1; viewYear += 1; }
    render();
  }

  render();
  pop.addEventListener("click", (e) => e.stopPropagation());
  document.body.appendChild(pop);
}

// A button that shows the current due date and opens the popup picker when
// clicked. `onChange(iso|null)` is called with the new value; the caller is
// responsible for re-rendering whatever displays the chosen date.
function dateField(initialIso, onChange) {
  const btn = el("button", { type: "button", class: "btn date-field" }, "📅 " + formatDateDisplay(initialIso));
  btn._value = initialIso;
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    openDatePickerPopup(btn, btn._value, (iso) => {
      btn._value = iso;
      btn.textContent = "📅 " + formatDateDisplay(iso);
      onChange(iso);
    });
  });
  return btn;
}

/* ---------------------------------------------------------------------- *
 * Generic modal helper
 * ---------------------------------------------------------------------- */
function openModal(title, bodyNodes, buttonNodes) {
  const overlay = document.getElementById("modalOverlay");
  const body = document.getElementById("modalBody");
  body.innerHTML = "";
  body.classList.remove("modal-wide", "modal-ai");
  body.appendChild(el("h2", {}, title));
  for (const n of bodyNodes) body.appendChild(n);
  body.appendChild(el("div", { class: "btn-row" }, buttonNodes));
  overlay.classList.remove("hidden");
  overlay.classList.add("modal-center");
  overlay.onclick = (e) => { if (e.target === overlay) closeModal(); };
}
function confirmDeleteTask(task) {
  const n = (task.subtasks || []).length;
  return confirmModal({
    title: "Delete task?",
    message: `“${task.title}” will be deleted` + (n ? ` along with its ${n} subtask${n > 1 ? "s" : ""}` : "") + ".",
    confirmLabel: "Delete", danger: true,
  });
}

function closeModal() {
  document.getElementById("modalOverlay").classList.add("hidden");
}

// In-app replacement for window.prompt(): same sheet with a text field.
// Resolves the entered text, or null on Cancel / Escape.
const promptModal = (opts) => confirmModal({ confirmLabel: "Save", ...opts, input: { value: opts.value || "" } });

// In-app replacement for window.confirm(): a sheet that slides down from the
// top of the app. Resolves true when the person confirms, false on Cancel /
// Escape / clicking outside it. Usage:
//   if (await confirmModal({ title: "Delete task?", message: "...", confirmLabel: "Delete", danger: true })) ...
function confirmModal({ title, message, confirmLabel = "Confirm", danger = false, choices = null, input = null }) {
  return new Promise((resolve) => {
    let settled = false;
    const inputEl = input ? el("input", { type: "text", class: "sheet-input", value: input.value || "", placeholder: input.placeholder || "" }) : null;
    let chosen = choices ? choices[0].value : null;
    const finish = (value) => {
      if (settled) return;
      if (choices && value) value = chosen;
      if (inputEl) value = value ? inputEl.value : null;
      settled = true;
      document.removeEventListener("keydown", onKey, true);
      overlay.classList.remove("open");                 // slides back up
      setTimeout(() => overlay.remove(), 260);
      resolve(value);
    };
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(false); }
      else if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); finish(true); }
    };
    const confirmBtn = el("button", { class: "btn " + (danger ? "danger" : "primary"), onclick: () => finish(true) }, confirmLabel);
    const overlay = el("div", { class: "sheet-overlay", onclick: (e) => { if (e.target === overlay) finish(false); } }, [
      el("div", { class: "sheet", role: "dialog", "aria-modal": "true" }, [
        el("div", { class: "sheet-text" }, [
          el("div", { class: "sheet-title" }, title),
          message ? el("div", { class: "muted sheet-message" }, message) : null,
          inputEl,
          choices ? el("div", { class: "sheet-choices" }, choices.map((c, i) => {
            const input = el("input", { type: "radio", name: "sheetChoice", checked: i === 0 || undefined });
            input.addEventListener("change", () => { chosen = c.value; });
            return el("label", { class: "sheet-choice" }, [input, el("span", {}, c.label)]);
          })) : null,
        ]),
        el("div", { class: "sheet-buttons" }, [
          el("button", { class: "btn", onclick: () => finish(false) }, "Cancel"),
          confirmBtn,
        ]),
      ]),
    ]);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", onKey, true);
    void overlay.offsetWidth;        // render the closed (raised) state first so the drop-down animates
    requestAnimationFrame(() => { overlay.classList.add("open"); (inputEl || confirmBtn).focus(); if (inputEl) inputEl.select(); });
  });
}

/* ---------------------------------------------------------------------- *
 * Project / list dialogs
 * ---------------------------------------------------------------------- */
function openProjectDialog(project) {
  const isEdit = !!project;
  const nameInput = el("input", { type: "text", value: project ? project.name : "", placeholder: "Project name" });
  let selectedColor = project ? project.color : PROJECT_COLORS[0];
  const swatchRow = el("div", { class: "swatch-row" });
  function paintSwatches() {
    swatchRow.innerHTML = "";
    for (const c of PROJECT_COLORS) {
      swatchRow.appendChild(el("div", {
        class: "swatch" + (c === selectedColor ? " selected" : ""),
        style: `background:${c}`,
        onclick: () => { selectedColor = c; paintSwatches(); },
      }));
    }
  }
  paintSwatches();

  openModal(isEdit ? "Edit project" : "New project", [
    el("div", { class: "field" }, [el("label", {}, "Name"), nameInput]),
    el("div", { class: "field" }, [el("label", {}, "Color"), swatchRow]),
  ], [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", {
      class: "btn primary",
      onclick: async () => {
        if (!nameInput.value.trim()) return;
        if (isEdit) {
          await api.patch(`/api/projects/${project.id}`, { name: nameInput.value.trim(), color: selectedColor });
        } else {
          const res = await api.post("/api/projects", { name: nameInput.value.trim(), color: selectedColor });
          await api.post("/api/todolists", { project_id: res.id, name: "Tasks" });
          state.expanded.add(res.id);
        }
        closeModal();
        await refreshSidebarData();
      },
    }, isEdit ? "Save" : "Create"),
  ]);
  setTimeout(() => nameInput.focus(), 30);
}

function openListDialog(projectId) {
  const nameInput = el("input", { type: "text", placeholder: "List name" });
  openModal("New list", [el("div", { class: "field" }, [nameInput])], [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", {
      class: "btn primary",
      onclick: async () => {
        if (!nameInput.value.trim()) return;
        await api.post("/api/todolists", { project_id: projectId, name: nameInput.value.trim() });
        state.expanded.add(projectId);
        closeModal();
        refreshSidebarData();
      },
    }, "Add"),
  ]);
  setTimeout(() => nameInput.focus(), 30);
}
