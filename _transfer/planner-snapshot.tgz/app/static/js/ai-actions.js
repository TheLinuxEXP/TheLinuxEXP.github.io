"use strict";

// AI-powered subtask actions (buttons, modals).

/* ---------------------------------------------------------------------- *
 * AI-powered subtask actions — order topics, generate tags, thumbnail
 * ideas, script planning, PowerPoint generation. Most read the parent
 * task's linked notes file (or, for script planning, its own Notes field)
 * server-side and call Claude, showing the result in a copyable popup.
 * "Generate" (Create powerpoint) is the exception -- it opens its own modal
 * to collect links/a document/a prompt first; see openGeneratePptxModal.
 * ---------------------------------------------------------------------- */
function subtaskAIButtons(title, task, subId) {
  const t = (title || "").trim().toLowerCase();
  // Tasks created from a template: the buttons are the ones configured on the
  // matching template subtask (Utilities > Templates), even if there are none.
  const tpl = task && task.video_template ? templateByKey(task.video_template) : null;
  // The link (template_sub_id) survives renames; when it points to nothing any more (template reset / re-created /
  // restored from a backup gave its subtasks new ids), fall back on the title instead of dropping the buttons.
  const byTitle = () => tpl.subtasks.find((x) => (x.title || "").trim().toLowerCase() === t);
  const ts = tpl ? (tpl.subtasks.find((x) => subId && x.id === subId) || byTitle() || null) : null;
  if (ts) {
    return (ts.ai_buttons || []).map((b) => (b.kind === "powerpoint"
      ? { label: b.label, kind: "powerpoint" }
      : b.kind === "list_to_ppt" ? { label: b.label, kind: "list_to_ppt" }
      : { label: b.label, endpoint: "run", buttonId: b.id, applyToNote: !!b.apply_to_note, kind: b.kind }));
  }
  // Tasks with no template (or whose subtask is no longer in it): the original buttons.
  if (t === "order topics") return [{ label: "Order topics", endpoint: "order-topics" }];
  if (t.startsWith("publish video")) return [{ label: "Generate tags", endpoint: "generate-tags" }];
  if (t === "make 3 thumbnails") return [{ label: "Generate ideas", endpoint: "generate-thumbnails" }];
  if (t === "write script") return [{ label: "Plan out this script", endpoint: "plan-script" }];
  if (t === "create powerpoint") return [{ label: "Generate", endpoint: "generate-pptx" }];
  return [];
}

async function runSubtaskAI(btnEl, subtaskId, endpoint, label, buttonId) {
  const original = btnEl.textContent;
  btnEl.disabled = true;
  btnEl.textContent = "Working…";
  const aiTaskId = startAiTask(label);
  try {
    const res = await api.post(`/api/subtasks/${subtaskId}/ai/${endpoint}`, buttonId ? { button_id: buttonId } : {});
    if (!res.silent) openAIResultModal(label, res.result, { subtaskId, endpoint, applyToNote: endpoint === "order-topics" || !!res.apply_to_note });
  } catch (e) {
    let msg = "Something went wrong.";
    try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
    showToast(msg, { sticky: true });
  } finally {
    btnEl.disabled = false;
    btnEl.textContent = original;
    finishAiTask(aiTaskId);
  }
}

function renderAIMarkdown(text) {
  const view = el("div", { class: "ai-result-md" });
  try {
    const md = window.markdownit({ html: false, breaks: true, linkify: true });
    view.innerHTML = md.render(text || "");
    view.querySelectorAll("a").forEach((a) => { a.target = "_blank"; a.rel = "noopener"; });
  } catch {
    view.textContent = text;
  }
  return view;
}

// Result of an AI button: shown formatted (markdown rendered) by default, with
// a switch to the raw markdown; Copy always copies the raw text. `opts.subtaskId`
// + `opts.endpoint === "order-topics"` adds the two buttons that write the
// result into the task's linked note.
function openAIResultModal(title, text, opts = {}) {
  const raw = el("textarea", { readonly: "readonly", class: "ai-result-box" });
  raw.value = text;
  const formatted = renderAIMarkdown(text);
  const body = el("div", { class: "ai-result-wrap" }, [formatted]);
  let showRaw = false;
  const toggle = el("button", {
    type: "button", class: "btn small",
    onclick: () => {
      showRaw = !showRaw;
      body.replaceChildren(showRaw ? raw : formatted);
      toggle.textContent = showRaw ? "Show formatted" : "Show markdown";
    },
  }, "Show markdown");

  const buttons = [el("button", { class: "btn", onclick: closeModal }, "Close")];
  if (opts.subtaskId && opts.applyToNote) {
    const apply = (mode, label, btn) => async () => {
      btn.disabled = true;
      try {
        const res = await api.post(`/api/subtasks/${opts.subtaskId}/ai/apply-order-topics`, { mode, content: text });
        showToast(res.summary || "Note updated");
        closeModal();
      } catch (e) {
        let msg = "Couldn't update the note.";
        try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
        showToast(msg, { sticky: true });
        btn.disabled = false;
      }
    };
    const replaceBtn = el("button", { class: "btn" }, "Replace Note content");
    const appendBtn = el("button", { class: "btn" }, "Append to Note");
    replaceBtn.onclick = apply("replace", "Replace", replaceBtn);
    appendBtn.onclick = apply("append", "Append", appendBtn);
    buttons.push(replaceBtn, appendBtn);
  }
  buttons.push(el("button", {
    class: "btn primary",
    onclick: async () => {
      try {
        await navigator.clipboard.writeText(text);
        showToast("Copied to clipboard");
      } catch {
        showToast("Couldn't copy automatically — select the text and copy manually");
      }
    },
  }, "Copy"));

  openModal(title, [el("div", { class: "ai-result-bar" }, [toggle]), body], buttons);
  document.getElementById("modalBody").classList.add("modal-wide", "modal-ai");
}

// "Generate" (the Create powerpoint subtask's AI button): collects any
// number of pasted links, an optional reference document, and a free-text
// prompt, then asks the server to plan slides from all of that and stamp
// them out onto copies of the project's own presentation.pptx so the
// result matches its look (see app/pptx_gen.py). The modal stays open after
// a successful generation so the person can download the result.
function openGeneratePptxModal(subtaskId, label) {
  const linksInput = el("textarea", { rows: "3", placeholder: "One link per line (optional)" });
  const fileInput = el("input", { type: "file", accept: ".pdf,.docx,.txt,.md" });
  const promptInput = el("textarea", { rows: "3", placeholder: "Describe what you want in the presentation (optional)" });
  const ocrBox = el("input", { type: "checkbox" });
  const statusLine = el("div", { class: "muted small", style: "margin-top:4px" }, "");

  const generateBtn = el("button", {
    class: "btn primary",
    onclick: async () => {
      const fd = new FormData();
      fd.append("links", linksInput.value);
      fd.append("prompt", promptInput.value);
      if (fileInput.files[0]) fd.append("file", fileInput.files[0]);
      if (ocrBox.checked) fd.append("force_ocr", "1");

      generateBtn.disabled = true;
      generateBtn.textContent = "Working…";
      statusLine.textContent = "";
      const aiTaskId = startAiTask(label);
      try {
        const res = await api.postForm(`/api/subtasks/${subtaskId}/ai/generate-pptx`, fd);
        statusLine.innerHTML = "";
        statusLine.appendChild(el("a", {
          href: res.download_url,
          target: "_blank",
          class: "btn primary",
        }, `⬇ Download .pptx (${res.slide_count} slides)`));
        const notes = [];
        if (res.ocr_pages) notes.push(`OCR used on ${res.ocr_pages} page${res.ocr_pages === 1 ? "" : "s"}`);
        const kinds = { datasheet: "datasheet", detachment_rule: "detachment rule", enhancements: "enhancements", stratagems: "stratagem slide" };
        const found = Object.entries(res.blocks_found || {}).map(([k, n]) => `${n} ${kinds[k] || k}${n === 1 ? "" : "s"}`);
        if (found.length) notes.push("Found in the PDF: " + found.join(", "));
        if (notes.length) statusLine.appendChild(el("div", { class: "muted small", style: "margin-top:6px" }, notes.join(" · ")));
      } catch (e) {
        let msg = "Something went wrong.";
        try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
        statusLine.textContent = msg;
      } finally {
        generateBtn.disabled = false;
        generateBtn.textContent = "Generate";
        finishAiTask(aiTaskId);
      }
    },
  }, "Generate");

  openModal("Generate PowerPoint", [
    el("div", { class: "field" }, [el("label", {}, "Links"), linksInput]),
    el("div", { class: "field" }, [el("label", {}, "Reference document (PDF, Word, or text)"), fileInput,
      el("label", { class: "muted small", style: "display:block;margin-top:4px;font-weight:normal" }, [ocrBox,
        " Force OCR (scanned PDF; pages without text are OCR'd automatically). From a PDF, each datasheet, detachment rule, enhancements block and set of 3 stratagems becomes one slide (picture + French recap). Use the prompt to choose which, or to adjust the text."])]),
    el("div", { class: "field" }, [el("label", {}, "Prompt"), promptInput]),
    statusLine,
  ], [
    el("button", { class: "btn", onclick: closeModal }, "Close"),
    generateBtn,
  ]);
}

// "List to PPT" (Warhammer Video, Create powerpoint): paste an army list exported from the Games Workshop app, get a
// PowerPoint in the usual template (see app/army_list.py). Rules are read from Wahapedia by Claude, so it can take a
// few minutes the first time; results are cached for next time.
function openListToPptModal(subtaskId, label) {
  const input = el("textarea", { rows: "16", placeholder: "Collez ici votre liste d'armée (format de l'application Games Workshop)", style: "width:100%;font-family:monospace;font-size:12px" });
  const status = el("div", { class: "muted small", style: "margin-top:8px" }, "");
  const modeSelect = el("select", { style: "width:auto;min-width:220px" }, [
    el("option", { value: "ppt" }, "PPT complet (slides + images)"),
    el("option", { value: "images" }, "Images seulement (zip)"),
  ]);
  const btnLabel = () => (modeSelect.value === "images" ? "Create images" : "Create PPT");
  modeSelect.addEventListener("change", () => { createBtn.textContent = btnLabel(); });
  const createBtn = el("button", {
    class: "btn primary",
    onclick: async () => {
      if (!input.value.trim()) { status.textContent = "Collez d'abord une liste."; return; }
      const imagesOnly = modeSelect.value === "images";
      createBtn.disabled = true;
      cancelBtn.disabled = true;
      modeSelect.disabled = true;
      createBtn.textContent = "Création…";
      status.textContent = "Lecture de Wahapedia et création des slides : cela peut prendre quelques minutes (plus rapide ensuite, grâce au cache).";
      const aiTaskId = startAiTask(label);
      try {
        const res = await api.post(`/api/subtasks/${subtaskId}/ai/list-to-ppt`, { text: input.value, mode: imagesOnly ? "images" : "ppt" });
        status.innerHTML = "";
        if (res.images_only) {
          const row = el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;align-items:center" });
          row.appendChild(el("a", { href: res.download_url, target: "_blank", class: "btn primary" }, `⬇ Télécharger le zip (${res.slide_count} images)`));
          const folderMsg = el("span", { class: "muted small" }, "");
          row.appendChild(el("button", { class: "btn", onclick: async () => {
            try { await api.post(`/api/subtasks/${subtaskId}/ai/list-to-ppt/open-folder`, {}); folderMsg.textContent = ""; }
            catch (e) { let m = "Impossible d'ouvrir le dossier."; try { const j = JSON.parse(e.message); m = j.error || m; if (j.path) m += " " + j.path; } catch { /* keep */ } folderMsg.textContent = m; }
          } }, "📂 Ouvrir le dossier du zip"));
          row.appendChild(folderMsg);
          status.appendChild(row);
        } else {
          status.appendChild(el("a", { href: res.download_url, target: "_blank", class: "btn primary" }, `⬇ Télécharger le PPT (${res.slide_count} slides)`));
        }
        if ((res.warnings || []).length) {
          status.appendChild(el("div", { class: "muted small", style: "margin-top:8px" }, "À vérifier :"));
          status.appendChild(el("ul", { class: "muted small", style: "margin:4px 0 0 18px" }, res.warnings.map((w) => el("li", {}, w))));
        }
      } catch (e) {
        let msg = "Une erreur est survenue.";
        try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
        status.textContent = msg;
      } finally {
        createBtn.disabled = false;
        cancelBtn.disabled = false;
        modeSelect.disabled = false;
        createBtn.textContent = btnLabel();
        finishAiTask(aiTaskId);
      }
    },
  }, "Create PPT");
  const cancelBtn = el("button", { class: "btn", onclick: closeModal }, "Cancel");
  openModal(label || "List to PPT", [
    el("div", { class: "field" }, [el("label", {}, "Liste d'armée Warhammer 40K"), input]),
    el("div", { class: "field" }, [el("label", {}, "Mode"), modeSelect]),
    status,
  ], [cancelBtn, createBtn]);
}

function renderRecurrenceField(task, patch) {
  const wrap = el("div", { class: "field" });
  const enabled = !!task.recurrence;
  const rule = task.recurrence || { unit: "week", interval: 1, weekdays: [], end_date: null };

  const enableCheckbox = el("input", { type: "checkbox", checked: enabled || undefined });
  const body = el("div", { class: "field recurrence-body", style: `margin-top:8px; ${enabled ? "" : "display:none"}` });   // "field": same input styling as the other task fields

  const intervalInput = el("input", { type: "number", min: "1", value: String(rule.interval || 1), style: "width:70px" });
  const unitSelect = el("select", { style: "width:auto;min-width:110px" }, ["day", "week", "month", "year"].map((u) => el("option", { value: u, selected: u === rule.unit || undefined }, u + "(s)")));
  const weekdayRow = el("div", { class: "weekday-row" });
  const selectedWeekdays = new Set(rule.weekdays || []);
  function paintWeekdays() {
    weekdayRow.innerHTML = "";
    WEEKDAY_NAMES.forEach((name, idx) => {
      weekdayRow.appendChild(el("button", {
        type: "button",
        class: "weekday-btn" + (selectedWeekdays.has(idx) ? " selected" : ""),
        onclick: () => { selectedWeekdays.has(idx) ? selectedWeekdays.delete(idx) : selectedWeekdays.add(idx); paintWeekdays(); commit(); },
      }, name[0]));
    });
  }
  const weekdayField = el("div", { class: "field", style: unitSelect.value === "week" ? "" : "display:none" }, [el("label", {}, "On days"), weekdayRow]);
  paintWeekdays();

  const preview = el("div", { class: "muted small", style: "margin-top:6px" });
  function updatePreview() {
    preview.textContent = describeRecurrence({ unit: unitSelect.value, interval: intervalInput.value, weekdays: [...selectedWeekdays] });
  }
  updatePreview();

  function commit() {
    weekdayField.style.display = unitSelect.value === "week" ? "block" : "none";
    updatePreview();
    if (!enableCheckbox.checked) { patch({ recurrence: null }); return; }
    patch({
      recurrence: {
        unit: unitSelect.value,
        interval: Math.max(1, parseInt(intervalInput.value || "1", 10)),
        weekdays: unitSelect.value === "week" ? [...selectedWeekdays] : [],
        end_date: null,
      },
    });
  }

  enableCheckbox.addEventListener("change", () => { body.style.display = enableCheckbox.checked ? "block" : "none"; commit(); });
  intervalInput.addEventListener("change", commit);
  unitSelect.addEventListener("change", commit);

  body.appendChild(el("div", { style: "display:flex;gap:8px;align-items:center" }, [el("span", {}, "Every"), intervalInput, unitSelect]));
  body.appendChild(weekdayField);
  body.appendChild(preview);

  const repeatChip = el("label", { class: "flag-chip repeat" + (enabled ? " on" : "") }, [
    enableCheckbox, el("span", { class: "flag-chip-icon" }, "🔁"), el("span", {}, "Repeats"),
  ]);
  enableCheckbox.addEventListener("change", () => repeatChip.classList.toggle("on", enableCheckbox.checked));
  const chipField = el("div", { class: "field", style: "flex:0 0 auto" }, [repeatChip]);
  body.style.marginBottom = "12px";
  return { chipField, body };
}
