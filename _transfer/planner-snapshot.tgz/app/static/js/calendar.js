"use strict";

// Calendar and week views.

/* ---------------------------------------------------------------------- *
 * Calendar view
 * ---------------------------------------------------------------------- */
function renderCalendar() {
  const wrap = el("div", {});
  wrap.appendChild(el("div", { class: "sponsors-tabs" }, [
    el("div", { class: "seg" }, [
      el("button", {
        type: "button",
        class: "seg-btn" + (state.calendar.mode !== "week" ? " active" : ""),
        onclick: () => { state.calendar.mode = "month"; loadCalendar(); },
      }, "Month"),
      el("button", {
        type: "button",
        class: "seg-btn" + (state.calendar.mode === "week" ? " active" : ""),
        onclick: () => {
          state.calendar.mode = "week";
          if (!state.calendar.weekStart) state.calendar.weekStart = startOfWeekIso(todayIso());
          loadCalendar();
        },
      }, "Week"),
    ]),
  ]));
  wrap.appendChild(state.calendar.mode === "week" ? renderWeekGrid() : renderMonthGrid());
  return wrap;
}

function renderMonthGrid() {
  const { year, month, data } = state.calendar;
  const wrap = el("div", {});

  wrap.appendChild(el("div", { class: "calendar-header" }, [
    el("button", { class: "icon-btn", onclick: () => navMonth(-1) }, "‹"),
    el("h2", {}, `${MONTH_NAMES[month - 1]} ${year}`),
    el("button", { class: "icon-btn", onclick: () => navMonth(1) }, "›"),
  ]));

  const grid = el("div", { class: "calendar-grid" });
  for (const wd of WEEKDAY_NAMES) grid.appendChild(el("div", { class: "calendar-weekday" }, wd));

  const firstOfMonth = new Date(year, month - 1, 1);
  const startOffset = (firstOfMonth.getDay() + 6) % 7; // Monday=0
  const daysInMonth = new Date(year, month, 0).getDate();
  const daysInPrevMonth = new Date(year, month - 1, 0).getDate();
  const todayStr = todayIso();

  const cells = [];
  for (let i = 0; i < startOffset; i++) {
    const dayNum = daysInPrevMonth - startOffset + 1 + i;
    cells.push({ dayNum, outside: true });
  }
  for (let d = 1; d <= daysInMonth; d++) cells.push({ dayNum: d, outside: false, iso: `${year}-${String(month).padStart(2, "0")}-${String(d).padStart(2, "0")}` });
  while (cells.length % 7 !== 0) {
    cells.push({ dayNum: cells.length - (startOffset + daysInMonth) + 1, outside: true });
  }

  for (const cell of cells) {
    if (cell.outside) {
      grid.appendChild(el("div", { class: "calendar-cell outside" }, [el("div", { class: "calendar-daynum" }, String(cell.dayNum))]));
      continue;
    }
    let dayTasks = data[cell.iso] || [];
    if (state.calendar.onlyVideos) dayTasks = dayTasks.filter((t) => t.is_video && !t.is_subtask);
    const isToday = cell.iso === todayStr;
    const cellEl = el("div", { class: "calendar-cell" + (isToday ? " today" : "") }, [
      el("div", { class: "calendar-daynum", style: "cursor:pointer", onclick: () => openDayModal(cell.iso, dayTasks) }, String(cell.dayNum)),
    ]);
    const totalMinutes = dayTasks.reduce((sum, t) => sum + (t.checked ? 0 : (t.duration_minutes || 0)), 0);
    if (totalMinutes) {
      const heavy = totalMinutes >= 8 * 60;
      cellEl.appendChild(el("div", { class: "day-load" + (heavy ? " heavy" : "") }, `⏱ ${formatHoursTotal(totalMinutes)}`));
    }
    const shown = dayTasks.slice(0, 3);
    for (const t of shown) {
      cellEl.appendChild(el("div", {
        class: "calendar-task" + (t.is_video ? " video" : "") + (t.checked ? " done" : "")
          + (t.is_projected ? " projected" : "") + (t.is_subtask ? " subtask" : ""),
        title: t.is_projected ? "Future occurrence of a recurring task" : (t.is_subtask ? `Subtask of "${t.parent_title}"` : ""),
        onclick: () => openEntryDetail(t),
      }, [
        t.project_color ? el("span", { class: "dot", style: `background:${t.project_color}`, title: t.project_name || "" }) : null,
        t.urgent ? el("span", { class: "flag" }, "🚩") : null,
        t.is_video ? el("span", { class: "flag" }, "🎥") : null,
        t.is_projected ? el("span", { class: "flag", title: "Upcoming occurrence" }, "🔁") : null,
        el("span", { class: "label" }, (t.is_subtask ? "↳ " : "") + t.title),
      ]));
    }
    if (dayTasks.length > shown.length) {
      cellEl.appendChild(el("div", { class: "calendar-more", onclick: () => openDayModal(cell.iso, dayTasks) }, `+${dayTasks.length - shown.length} more`));
    }
    grid.appendChild(cellEl);
  }

  wrap.appendChild(grid);
  return wrap;
}

/* ---------------------------------------------------------------------- *
 * Week view — an hourly grid, one column per day, with tasks/subtasks that
 * have a start_time shown as draggable blocks positioned by time. Tasks
 * with no start_time sit in an all-day strip above the grid; dragging one
 * into the grid gives it a time, dragging a timed block into the strip
 * clears it. Dropping onto an occupied slot pushes whatever was already
 * there (and anything that, in turn, overlaps with ITS new slot) later the
 * same day — the cascade is computed and persisted together on drop.
 * ---------------------------------------------------------------------- */
function renderWeekGrid() {
  const wrap = el("div", { class: "week-wrap" });
  const start = state.calendar.weekStart || startOfWeekIso(todayIso());
  const days = [];
  for (let i = 0; i < 7; i++) days.push(addDaysIso(start, i));
  const todayStr = todayIso();

  wrap.appendChild(el("div", { class: "calendar-header" }, [
    el("button", { class: "icon-btn", onclick: () => { state.calendar.weekStart = addDaysIso(start, -7); loadCalendar(); } }, "‹"),
    el("h2", {}, `${formatDateDisplay(days[0])} – ${formatDateDisplay(days[6])}`),
    el("button", { class: "icon-btn", onclick: () => { state.calendar.weekStart = addDaysIso(start, 7); loadCalendar(); } }, "›"),
  ]));

  const grid = el("div", { class: "week-grid" });

  const headerRow = el("div", { class: "week-header-row" }, [el("div", { class: "week-gutter-cell" })]);
  for (const d of days) {
    const daySeconds = (state.calendar.timeByDay || {})[d] || 0;
    headerRow.appendChild(el("div", { class: "week-day-head" + (d === todayStr ? " today" : "") }, [
      el("div", { class: "week-day-name" }, WEEKDAY_NAMES[(parseIso(d).getDay() + 6) % 7]),
      el("div", { class: "week-day-num" }, String(parseIso(d).getDate())),
      daySeconds ? el("button", {
        type: "button", class: "week-day-hours clickable", title: "Click to see what this time was tracked on",
        onclick: (e) => { e.stopPropagation(); openDayTimeSheet(d); },
      }, formatElapsed(daySeconds)) : null,
    ]));
  }
  grid.appendChild(headerRow);

  // All-day / untimed strip
  const allDayRow = el("div", { class: "week-allday-row" }, [el("div", { class: "week-gutter-cell" })]);
  for (const d of days) {
    const cell = el("div", { class: "week-allday-cell" + (d === todayStr ? " today" : "") });
    // "Other tasks": standalone time bucket, always first in the day's strip
    const other = (state.calendar.otherByDay || {})[d];
    const otherState = other ? other.timer_state : "idle";
    cell.appendChild(el("div", {
      class: "week-untimed-pill week-other-pill",
      title: "Other tasks -- time recorded outside any task list or project",
    }, [
      el("span", { class: "dot", style: "background:var(--muted, #888)" }),
      "Other tasks",
      el("span", { class: "week-other-time" },
        (otherState === "running" ? "▶ " : otherState === "paused" ? "⏸ " : "") +
        formatElapsed(other ? other.time_spent_seconds : 0)),
    ]));
    // The projects' "Other tasks" that have time on this day (those with none are not drawn: they exist every day, in the lists)
    for (const o of (state.calendar.projectOtherByDay || {})[d] || []) {
      cell.appendChild(el("div", {
        class: "week-untimed-pill week-other-pill", title: `Other tasks of ${o.project_name} -- time recorded on the project outside any task`,
      }, [
        el("span", { class: "dot", style: `background:${safeColor(o.color, "#7f8c8d")}` }),
        `Other tasks · ${o.project_name}`,
        el("span", { class: "week-other-time" },
          (o.timer_state === "running" ? "▶ " : o.timer_state === "paused" ? "⏸ " : "") + formatElapsed(o.time_spent_seconds)),
      ]));
    }
    // Untimed entries, plus timed ones outside the visible hours (e.g. a
    // 20:00 show), which would otherwise be drawn off the grid and vanish.
    for (const t of (state.calendar.data[d] || []).filter((t) => !t.start_time || weekOutsideHours(t))) {
      cell.appendChild(weekUntimedPill(t, d));
    }
    cell.addEventListener("dragover", (e) => { e.preventDefault(); if (weekDrag) cell.classList.add("drop-target"); });
    cell.addEventListener("dragleave", (e) => { if (!cell.contains(e.relatedTarget)) cell.classList.remove("drop-target"); });
    cell.addEventListener("drop", (e) => { cell.classList.remove("drop-target"); onWeekUntimedDrop(e, d); });
    allDayRow.appendChild(cell);
  }
  grid.appendChild(allDayRow);

  // Hourly body -- only the working-hours range (HOUR_START..HOUR_END) is shown
  const body = el("div", { class: "week-body" });
  const gutter = el("div", { class: "week-gutter" });
  for (let h = HOUR_START; h < HOUR_END; h++) {
    gutter.appendChild(el("div", { class: "week-hour-label", style: `height:${HOUR_HEIGHT}px` }, `${String(h).padStart(2, "0")}:00`));
  }
  body.appendChild(gutter);

  for (const d of days) {
    const col = el("div", { class: "week-day-col" + (d === todayStr ? " today" : ""), style: `height:${HOUR_HEIGHT * (HOUR_END - HOUR_START)}px` });
    for (let h = HOUR_START; h < HOUR_END; h++) {
      col.appendChild(el("div", { class: "week-hour-line", style: `top:${(h - HOUR_START) * HOUR_HEIGHT}px` }));
    }
    col.addEventListener("dragover", (e) => { e.preventDefault(); showWeekDropGhost(e, col); });
    col.addEventListener("dragleave", (e) => { if (!col.contains(e.relatedTarget)) clearWeekDropGhost(); });
    col.addEventListener("drop", (e) => { clearWeekDropGhost(); onWeekDrop(e, d, col); });

    for (const t of (state.calendar.data[d] || []).filter((t) => t.start_time && !weekOutsideHours(t))) {
      col.appendChild(weekBlockEl(t, d));
    }
    body.appendChild(col);
  }
  grid.appendChild(body);
  wrap.appendChild(grid);

  return wrap;
}

// Where inside the dragged block the pointer grabbed it (px from its top
// edge). The drop time is defined by the block's TOP edge, not the pointer.
let weekGrabOffsetY = 0;

// What is being dragged right now (dataTransfer can't be read during
// dragover), used to draw the drop preview.
let weekDrag = null;
let weekGhost = null;

function weekDropStartMin(e, colEl) {
  const rect = colEl.getBoundingClientRect();
  let startMin = ((e.clientY - weekGrabOffsetY - rect.top) / HOUR_HEIGHT) * 60 + HOUR_START * 60;
  startMin = Math.round(startMin / 15) * 15;
  return Math.max(HOUR_START * 60, Math.min(HOUR_END * 60 - 15, startMin));
}

// Preview of the slot the dragged task would land in: a dashed block with
// the resulting time range, snapped to 15 minutes, in the column under the pointer.
function showWeekDropGhost(e, colEl) {
  if (!weekDrag) return;
  const startMin = weekDropStartMin(e, colEl);
  const dur = weekDrag.duration || 30;
  if (!weekGhost) {
    weekGhost = el("div", { class: "week-drop-ghost" }, [el("span", { class: "week-drop-ghost-time" })]);
  }
  if (weekGhost.parentNode !== colEl) colEl.appendChild(weekGhost);
  weekGhost.style.top = `${(startMin / 60 - HOUR_START) * HOUR_HEIGHT}px`;
  weekGhost.style.height = `${Math.max(22, (dur / 60) * HOUR_HEIGHT)}px`;
  weekGhost.firstChild.textContent = `${minutesToTime(startMin)} – ${minutesToTime(startMin + dur)}`;
  weekGhost.classList.toggle("video", !!weekDrag.video);
}

function clearWeekDropGhost() {
  if (weekGhost && weekGhost.parentNode) weekGhost.parentNode.removeChild(weekGhost);
}

function endWeekDrag() {
  clearWeekDropGhost();
  weekDrag = null;
  document.querySelectorAll(".week-allday-cell.drop-target").forEach((c) => c.classList.remove("drop-target"));
  document.querySelectorAll(".week-block.dragging, .week-untimed-pill.dragging").forEach((c) => c.classList.remove("dragging"));
}

function beginWeekDrag(e, t, dayIso, node) {
  e.stopPropagation();
  weekGrabOffsetY = e.clientY - node.getBoundingClientRect().top;
  e.dataTransfer.setData("text/plain", weekDragPayload(t, dayIso));
  e.dataTransfer.effectAllowed = "move";
  weekDrag = { duration: t.duration_minutes || 30, video: !!t.is_video };
  setTimeout(() => node.classList.add("dragging"), 0);
  node.addEventListener("dragend", endWeekDrag, { once: true });
}

function weekDragPayload(t, dayIso) {
  return JSON.stringify({ id: t.id, isSubtask: !!t.is_subtask, duration: t.duration_minutes || 30, fromDay: dayIso,
    occ: t.is_projected ? (t.occurrence_date || t.due_date) : null });
}

function weekBlockEl(t, dayIso) {
  const startMin = timeToMinutes(t.start_time);
  const duration = t.duration_minutes || 30;
  const top = (startMin / 60 - HOUR_START) * HOUR_HEIGHT;
  const height = Math.max(22, (duration / 60) * HOUR_HEIGHT);
  const draggable = !t.is_completed_occurrence;

  const block = el("div", {
    class: "week-block" + (t.is_video ? " video" : "") + (t.checked ? " done" : "")
      + (t.is_subtask ? " subtask" : "") + (t.is_projected ? " projected" : ""),
    style: `top:${top}px; height:${height}px;`,
    draggable,
    title: `${t.title} — ${t.start_time}${t.duration_minutes ? " (" + formatDuration(t.duration_minutes) + ")" : ""}`,
    onclick: () => openEntryDetail(t),
  }, [
    t.project_color ? el("span", { class: "dot", style: `background:${t.project_color}`, title: t.project_name || "" }) : null,
    t.urgent ? el("span", { class: "flag" }, "🚩") : null,
    t.is_video ? el("span", { class: "flag" }, "🎥") : null,
    el("span", { class: "label" }, (t.is_subtask ? "↳ " : "") + t.title),
  ]);
  if (draggable) {
    block.addEventListener("dragstart", (e) => beginWeekDrag(e, t, dayIso, block));
  }
  return block;
}

// Sheet listing what a day's tracked-time total is made of.
async function openDayTimeSheet(day) {
  const data = await api.get(`/api/calendar/time-day?day=${day}`);
  const d = parseIso(day);
  const heading = `${WEEKDAY_NAMES[(d.getDay() + 6) % 7]} ${d.getDate()} ${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}`;
  const close = () => {
    document.removeEventListener("keydown", onKey, true);
    overlay.classList.remove("open");
    setTimeout(() => overlay.remove(), 260);
  };
  const onKey = (e) => { if (e.key === "Escape" || e.key === "Enter") { e.preventDefault(); e.stopPropagation(); close(); } };
  const list = el("div", { class: "day-time-list" });
  if (!data.items.length) list.appendChild(el("div", { class: "muted" }, "No time tracked on this day."));
  // One group per main task: its subtasks underneath, with a subtotal.
  const groups = new Map();
  for (const it of data.items) {
    const key = it.kind === "other" ? "other:" + it.id : it.task_id;        // the general bucket and each project's bucket stay apart
    const title = it.kind === "subtask" ? it.parent_title : (it.kind === "other" && it.parent_title ? `${it.title} · ${it.parent_title}` : it.title);
    if (!groups.has(key)) groups.set(key, { task_id: it.task_id, title, subs: [], own: 0, seconds: 0 });
    const g = groups.get(key);
    g.seconds += it.seconds;
    if (it.kind === "subtask") g.subs.push(it); else g.own += it.seconds;
  }
  const row = (cls, name, secs, taskId) => el("div", {
    class: cls + (taskId != null ? " clickable" : ""),
    onclick: taskId != null ? () => { close(); openTaskDetail(taskId); } : null,
  }, [el("div", { class: "day-time-name" }, name), el("div", { class: "day-time-secs" }, formatElapsed(secs))]);
  for (const g of [...groups.values()].sort((x, y) => y.seconds - x.seconds)) {
    const box = el("div", { class: "day-time-group" });
    box.appendChild(row("day-time-row day-time-head", g.title, g.seconds, g.task_id));
    if (g.own && g.subs.length) box.appendChild(row("day-time-row day-time-sub", "(on the task itself)", g.own, g.task_id));
    for (const sub of g.subs.sort((x, y) => y.seconds - x.seconds)) {
      box.appendChild(row("day-time-row day-time-sub", "↳ " + sub.title, sub.seconds, g.task_id));
    }
    list.appendChild(box);
  }
  const closeBtn = el("button", { class: "btn primary", onclick: close }, "Close");
  const overlay = el("div", { class: "sheet-overlay", onclick: (e) => { if (e.target === overlay) close(); } }, [
    el("div", { class: "sheet sheet-list", role: "dialog", "aria-modal": "true" }, [
      el("div", { class: "sheet-list-head" }, [
        el("div", { class: "sheet-title" }, heading),
        el("div", { class: "muted" }, `Total tracked: ${formatElapsed(data.total_seconds)}`),
      ]),
      list,
      el("div", { class: "sheet-buttons", style: "justify-content:flex-end" }, [closeBtn]),
    ]),
  ]);
  document.body.appendChild(overlay);
  document.addEventListener("keydown", onKey, true);
  void overlay.offsetWidth;          // render the closed (raised) state first so the drop-down animates
  requestAnimationFrame(() => { overlay.classList.add("open"); closeBtn.focus(); });
}

// A timed entry that starts before / after the hours the week grid shows.
function weekOutsideHours(t) {
  const m = timeToMinutes(t.start_time);
  return m != null && (m < HOUR_START * 60 || m >= HOUR_END * 60);
}

function weekUntimedPill(t, dayIso) {
  const draggable = !t.is_completed_occurrence;
  const pill = el("div", {
    class: "week-untimed-pill" + (t.is_subtask ? " subtask" : "") + (t.checked ? " done" : ""),
    draggable,
    title: t.start_time ? `${t.title} — ${t.start_time} (outside the hours shown)` : t.title,
    onclick: () => openEntryDetail(t),
  }, [
    t.project_color ? el("span", { class: "dot", style: `background:${t.project_color}`, title: t.project_name || "" }) : null,
    (t.urgent ? "🚩 " : "") + (t.is_subtask ? "↳ " : "") + (t.start_time ? `${t.start_time} · ` : "") + t.title,
  ]);
  if (draggable) {
    pill.addEventListener("dragstart", (e) => beginWeekDrag(e, t, dayIso, pill));
  }
  return pill;
}

function weekEntryKey(t) { return `${t.is_subtask ? "s" : "t"}:${t.id}`; }

// Dropping a block in the hourly grid: compute a start time from the drop
// position, then cascade — anything already on that day that the dropped
// block now overlaps gets pushed to start right when the previous one ends,
// and so on, until a gap is found. Everything is persisted together here,
// on drop, which is also what "confirms" the cascaded moves.
async function onWeekDrop(e, targetDay, colEl) {
  e.preventDefault();
  let payload;
  try { payload = JSON.parse(e.dataTransfer.getData("text/plain")); } catch { return; }
  if (!payload) return;

  const startMin = weekDropStartMin(e, colEl);

  const movedKey = `${payload.isSubtask ? "s" : "t"}:${payload.id}`;
  const movedDuration = payload.duration || 30;

  const others = (state.calendar.data[targetDay] || [])
    .filter((t) => weekEntryKey(t) !== movedKey && t.start_time && t.duration_minutes && !t.is_projected && !t.is_completed_occurrence)
    .map((t) => ({ id: t.id, isSubtask: !!t.is_subtask, start: timeToMinutes(t.start_time), duration: t.duration_minutes }))
    .sort((a, b) => a.start - b.start);

  const changes = [{ id: payload.id, isSubtask: payload.isSubtask, start: startMin, isMoved: true, occ: payload.occ }];
  let cursorEnd = startMin + movedDuration;
  for (const other of others) {
    if (other.start < cursorEnd) {
      changes.push({ id: other.id, isSubtask: other.isSubtask, start: cursorEnd });
      cursorEnd += other.duration;
    } else {
      break;
    }
  }

  // A task pushed by the overlap cascade that would end up outside the
  // visible day (before HOUR_START / ending after HOUR_END) loses its start
  // time instead and goes back to the untimed strip.
  const dur = new Map(others.map((o) => [`${o.isSubtask ? "s" : "t"}:${o.id}`, o.duration]));
  let unscheduled = 0;
  for (const c of changes) {
    const url = c.isSubtask ? `/api/subtasks/${c.id}` : `/api/tasks/${c.id}`;
    const outside = !c.isMoved && (c.start < HOUR_START * 60
      || c.start + (dur.get(`${c.isSubtask ? "s" : "t"}:${c.id}`) || 30) > HOUR_END * 60);
    // occurrence_only: on a recurring task, only THIS occurrence moves; the rest of the series stays put.
    const body = { start_time: outside ? null : minutesToTime(c.start), occurrence_only: true };
    if (outside) unscheduled++;
    if (c.isMoved) body.due_date = targetDay;
    if (c.occ) body.occurrence_date = c.occ;       // a future occurrence: only that one moves
    await api.patch(url, body);
  }
  showToast(changes.length > 1
    ? `Moved, and rescheduled ${changes.length - 1 - unscheduled} overlapping task(s)`
      + (unscheduled ? `; ${unscheduled} pushed outside ${HOUR_START}:00–${HOUR_END}:00 lost their start time` : "")
    : "Task moved");
  await loadCalendar();
}

// Dropping onto the all-day strip just clears the time (and moves the day).
async function onWeekUntimedDrop(e, targetDay) {
  e.preventDefault();
  let payload;
  try { payload = JSON.parse(e.dataTransfer.getData("text/plain")); } catch { return; }
  if (!payload) return;
  const url = payload.isSubtask ? `/api/subtasks/${payload.id}` : `/api/tasks/${payload.id}`;
  await api.patch(url, { start_time: null, due_date: targetDay, occurrence_only: true,
    ...(payload.occ ? { occurrence_date: payload.occ } : {}) });
  showToast("Task moved");
  await loadCalendar();
}

function navMonth(delta) {
  let { year, month } = state.calendar;
  month += delta;
  if (month < 1) { month = 12; year -= 1; }
  if (month > 12) { month = 1; year += 1; }
  openCalendar(year, month);
}

function openDayModal(iso, tasks) {
  const { text } = formatDue(iso);
  const list = el("div", {}, tasks.length
    ? tasks.map((t) => (t.is_subtask ? subtaskCalendarRow(t) : taskRow(t, { suppressSubtasks: true })))
    : [el("div", { class: "muted" }, "No tasks")]);
  const defaultListId = state.view.todoListId || (state.todoLists[0] && state.todoLists[0].id);
  const addInput = el("input", { type: "text", placeholder: "Add a task for this day" });
  const addRow = defaultListId ? el("div", { class: "inline-add-row" }, [
    addInput,
    el("button", {
      class: "btn",
      onclick: async () => {
        if (addInput.value.trim()) {
          await api.post("/api/tasks", { todo_list_id: defaultListId, title: addInput.value.trim(), due_date: iso });
          closeModal();
          await loadCalendar();
        }
      },
    }, "Add"),
  ]) : null;
  openModal(`${text || iso} — ${iso}`, [list, addRow].filter(Boolean), [
    el("button", { class: "btn primary", onclick: closeModal }, "Close"),
  ]);
}

// A subtask shown as its own entry in the day modal (it has its own due
// date/duration/urgency and inherits the video flag, but there's no
// standalone subtask detail view — clicking it opens the parent task).
function subtaskCalendarRow(t) {
  const checked = !!t.checked;
  const metaBits = [];
  if (t.duration_minutes) metaBits.push(el("span", { class: "duration-chip" }, "⏱ " + formatDuration(t.duration_minutes)));
  metaBits.push(el("span", { class: "muted" }, "from " + t.parent_title));

  const checkbox = el("div", {
    class: "checkbox" + (checked ? " checked" : ""),
    onclick: async (e) => {
      e.stopPropagation();
      await api.post(`/api/subtasks/${t.id}/toggle`, { checked: !checked });
      await loadCalendar();
    },
  }, checked ? "✓" : "");

  return el("div", { class: "task-row", onclick: () => openTaskDetail(t.parent_task_id) }, [
    checkbox,
    el("div", { class: "task-main" }, [
      el("div", { class: "task-content" + (checked ? " done" : "") }, [
        t.urgent ? el("span", { class: "urgent-flag", title: "Urgent" }, "🚩 ") : null,
        t.is_video ? el("span", { class: "video-badge", title: "Video" }, "🎥 ") : null,
        "↳ " + t.title,
      ]),
      el("div", { class: "task-meta" }, metaBits),
    ]),
  ]);
}
