"use strict";

// Main content rendering and auto order.

/* ---------------------------------------------------------------------- *
 * Main content rendering
 * ---------------------------------------------------------------------- */
function renderMain() {
  document.getElementById("pageTitle").textContent = state.view.title;
  document.getElementById("pageSubtitle").textContent =
    (state.view.type === "list" && state.view.project) ? `in ${state.view.project.name}`
    : (state.view.type === "fiscal" ? (state.view.subtitle || "") : "");
  const fab = document.getElementById("fab");
  if (fab) fab.style.display = (state.view.type === "fiscal" || state.view.type === "templates") ? "none" : "";   // "quick add task" makes no sense on a finance page
  const showHeaderQuickAdd = state.view.type === "list";
  document.getElementById("quickAddRow").style.display = showHeaderQuickAdd ? "flex" : "none";

  renderHeaderActions();

  const root = document.getElementById("viewRoot");
  document.getElementById("contentScroll").classList.toggle("notes-mode", state.view.type === "notes");
  if (state.view.type === "notes") {
    // keep the open editor alive across incidental re-renders
    if (root.firstElementChild && root.firstElementChild.id === "notesHost") return;
    root.innerHTML = "";
    const host = el("div", { id: "notesHost", class: "notes-host" });
    root.appendChild(host);
    NotesApp.mount(host, { toast: showToast, confirm: confirmModal, prompt: promptModal });
    return;
  }
  root.innerHTML = "";

  if (state.view.type === "calendar") { root.appendChild(renderCalendar()); return; }
  if (state.view.type === "fiscal") { renderFiscalView(root); return; }
  if (state.view.type === "smart") {
    root.appendChild(renderSmartView(state.view.smartType, state.tasks, state.orphanSubtasks, state.orphanParents));
    return;
  }
  if (state.view.type === "project") {
    root.appendChild(renderProjectView(state.tasks, state.view.project));
    return;
  }
  if (state.view.type === "sponsors") {
    root.appendChild(renderSponsorsView());
    return;
  }
  if (state.view.type === "videoproject") {
    root.appendChild(renderVideoProject());
    return;
  }
  if (state.view.type === "timereport") {
    root.appendChild(renderTimeReport());
    return;
  }
  if (state.view.type === "revenue") {
    root.appendChild(renderRevenue());
    return;
  }
  if (state.view.type === "backups") {
    root.appendChild(renderBackupsView());
    return;
  }
  if (state.view.type === "account") {
    root.appendChild(renderAccountView());
    return;
  }
  if (state.view.type === "templates") {
    root.appendChild(renderTemplatesView());
    return;
  }
  // list view
  if (!state.view.todoListId) {
    root.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("list"),
      el("div", {}, "Create a project and a list to get started"),
    ]));
    return;
  }
  const mine = (state.projectOther || []).find((o) => state.view.project && o.project_id === state.view.project.id);
  if (mine) root.appendChild(projectOtherRow(mine));            // the project's "Other tasks" on top of its lists
  root.appendChild(renderTaskList(state.tasks, { emptyText: "Nothing here yet", emptyIcon: "checkCircle" }));
}

// The views are rebuilt right after a switch is flipped, which would cut its animation short: wait for it to finish.
function switchSettled() {
  return new Promise((r) => setTimeout(r, REDUCED_MOTION.matches ? 0 : 200));
}

function showCompletedToggle(onToggle) {
  return el("label", { class: "toggle-inline completed-toggle" + (state.showCompleted ? " on" : "") }, [
    el("input", {
      type: "checkbox",
      checked: state.showCompleted ? "checked" : null,
      onchange: async (e) => {
        state.showCompleted = e.target.checked;
        e.target.closest("label").classList.toggle("on", e.target.checked);
        await switchSettled();
        await onToggle();
      },
    }),
    el("span", {}, "Show completed"),
  ]);
}

/* ---------------------------------------------------------------------- *
 * Auto order: gives start times to today's untimed tasks/subtasks, filling
 * the free time of today's grid from the current time on (up to HOUR_END), in list order with
 * urgent ones first. Tasks that already have a start time never move,
 * nothing is placed over them or inside the AUTO_BREAK window, due dates are
 * never touched. What it placed is remembered so Revert can clear exactly
 * those start times again.
 * ---------------------------------------------------------------------- */
const AUTO_BREAK = [9 * 60 + 45, 10 * 60 + 15];   // nothing placed between 9:45 and 10:15
const AUTO_DEFAULT_MINUTES = 30;                  // for tasks with no estimated duration

function autoOrderKey() { return "taskplanner.autoOrder." + todayIso(); }
function loadAutoOrdered() {
  try { return JSON.parse(localStorage.getItem(autoOrderKey()) || "[]"); } catch { return []; }
}
function saveAutoOrdered(list) {
  try {
    if (list.length) localStorage.setItem(autoOrderKey(), JSON.stringify(list));
    else localStorage.removeItem(autoOrderKey());
  } catch { /* storage unavailable: Revert just won't be offered */ }
}

async function autoOrderToday() {
  const today = todayIso();
  const entries = (await api.get(`/api/calendar/range?start=${today}&end=${today}`))[today] || [];
  const busy = entries.filter((t) => t.start_time)
    .map((t) => { const a = timeToMinutes(t.start_time); return [a, a + (t.duration_minutes || AUTO_DEFAULT_MINUTES)]; });
  busy.push(AUTO_BREAK);

  const todo = entries.filter((t) => !t.start_time && !t.checked && !t.is_projected && !t.is_completed_occurrence);
  // urgent first; otherwise keep the order they appear in the list
  todo.sort((a, b) => (b.urgent ? 1 : 0) - (a.urgent ? 1 : 0));

  const placed = [];
  // never earlier than the moment the button is pressed (rounded up to 5 min)
  const nowD = new Date();
  let cursor = Math.max(HOUR_START * 60, Math.ceil((nowD.getHours() * 60 + nowD.getMinutes()) / 5) * 5), skipped = 0;
  for (const t of todo) {
    const dur = t.duration_minutes || AUTO_DEFAULT_MINUTES;
    let start = Math.ceil(cursor / 5) * 5;
    for (let moved = true; moved;) {
      moved = false;
      for (const [a, b] of busy) {
        if (start < b && start + dur > a) { start = Math.ceil(b / 5) * 5; moved = true; }
      }
    }
    if (start + dur > HOUR_END * 60) { skipped++; continue; }
    placed.push({ id: t.id, isSubtask: !!t.is_subtask, start });
    busy.push([start, start + dur]);
    cursor = start + dur;
  }

  for (const c of placed) {
    await api.patch(c.isSubtask ? `/api/subtasks/${c.id}` : `/api/tasks/${c.id}`, { start_time: minutesToTime(c.start) });
  }
  const prev = loadAutoOrdered();
  saveAutoOrdered(prev.concat(placed.map((c) => ({ id: c.id, isSubtask: c.isSubtask }))));
  showToast(placed.length
    ? `Placed ${placed.length} task(s)` + (skipped ? `, ${skipped} didn't fit before ${HOUR_END}:00` : "")
    : (skipped ? `Nothing fit before ${HOUR_END}:00` : "Nothing to place"));
  renderHeaderActions();
  await loadCalendar();
}

async function revertAutoOrder() {
  const list = loadAutoOrdered();
  for (const c of list) {
    try { await api.patch(c.isSubtask ? `/api/subtasks/${c.id}` : `/api/tasks/${c.id}`, { start_time: null }); }
    catch { /* task deleted since: nothing to undo */ }
  }
  saveAutoOrdered([]);
  showToast(`Removed start times from ${list.length} task(s)`);
  renderHeaderActions();
  await loadCalendar();
}
