/* Notes & Scripts -- rich-text Markdown editor over the notes folder.
 *
 * Every note is a plain .md file (see notes_api.py). The editor renders the
 * Markdown with markdown-it into a contentEditable surface and writes it back
 * as Markdown. To keep your files untouched, saving is *block-level*: each
 * top-level block (paragraph, list, table...) you did not edit is written back
 * byte-for-byte from the original file; only the blocks you changed are
 * re-serialized. A "Markdown" mode shows and edits the raw text instead.
 */
(function () {
  "use strict";

  const API = "/api/notes";
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
  };

  /* ------------------------------------------------------------------ *
   * tiny helpers
   * ------------------------------------------------------------------ */
  function h(tag, attrs, children) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (k === "class") n.className = v;
      else if (k === "html") n.innerHTML = v;
      else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2), v);
      else if (v !== false && v !== null && v !== undefined) n.setAttribute(k, v);
    }
    for (const c of [].concat(children || [])) {
      if (c === null || c === undefined) continue;
      n.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return n;
  }
  const escHtml = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const norm = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();

  const ICONS = {
    undo: '<path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/>',
    redo: '<path d="M21 7v6h-6"/><path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7"/>',
    bold: '<path d="M6 4h8a4 4 0 0 1 0 8H6zM6 12h9a4 4 0 0 1 0 8H6z"/>',
    italic: '<path d="M19 4h-9M14 20H5M15 4 9 20"/>',
    strike: '<path d="M16 4H9a3 3 0 0 0-2.83 4M14 12a4 4 0 0 1 0 8H6M4 12h16"/>',
    code: '<path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/>',
    note: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4M10 9H8M16 13H8M16 17H8"/>',
    ul: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    ol: '<path d="M10 6h11M10 12h11M10 18h11M4 6h1v4M4 10h2M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/>',
    task: '<rect x="3" y="5" width="6" height="6" rx="1"/><path d="m3 17 2 2 4-4M13 6h8M13 12h8M13 18h8"/>',
    quote: '<path d="M3 21c3 0 7-1 7-8V5c0-1.25-.76-2-2-2H4c-1.25 0-2 .75-2 2v6c0 1.25.75 2 2 2h4M15 21c3 0 7-1 7-8V5c0-1.25-.76-2-2-2h-4c-1.25 0-2 .75-2 2v6c0 1.25.75 2 2 2h4"/>',
    codeblock: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="m10 10-2 2 2 2M14 10l2 2-2 2"/>',
    table: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>',
    hr: '<path d="M5 12h14"/>',
    save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    folderPlus: '<path d="M12 10v6M9 13h6M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z"/>',
    folder: '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    more: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
    rowAdd: '<path d="M3 5h18v6H3zM3 15h8M7 12v6M15 17h6"/>',
    colAdd: '<path d="M5 3v18h6V3zM15 3h6M18 3v8M14 15h8"/>',
    pin: '<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/>',
    play: '<path d="M6 4v16l14-8z" fill="currentColor"/>',
    stop: '<rect x="5" y="5" width="14" height="14" rx="2" fill="currentColor"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    trash: '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/>',
  };
  function icon(name, size) {
    const s = document.createElement("span");
    s.className = "ne-ico";
    s.innerHTML = `<svg viewBox="0 0 24 24" width="${size || 16}" height="${size || 16}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;
    return s;
  }

  async function call(method, url, body) {
    const opts = { method, headers: {} };
    if (body instanceof FormData) opts.body = body;
    else if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
    const r = await fetch(url, opts);
    let data = null;
    const text = await r.text();
    try { data = JSON.parse(text); } catch (e) { /* html error page */ }
    if (!r.ok) {
      const err = new Error((data && data.error) || (text.match(/<p>([^<]*)<\/p>/) || [])[1] || `HTTP ${r.status}`);
      err.status = r.status; err.data = data;
      throw err;
    }
    return data;
  }

  /* ------------------------------------------------------------------ *
   * Markdown -> HTML (markdown-it + wikilinks, tasks, source map)
   * ------------------------------------------------------------------ */
  let MD = null;
  function md() {
    if (MD) return MD;
    const m = window.markdownit({ html: true, breaks: true, linkify: true, typographer: false });
    m.linkify.set({ fuzzyLink: false, fuzzyEmail: false, fuzzyIP: false });   // only real http(s):// URLs

    // [[Note]] and [[Note|label]]
    m.inline.ruler.before("link", "wikilink", (state, silent) => {
      const s = state.src, pos = state.pos;
      if (s.charCodeAt(pos) !== 0x5B || s.charCodeAt(pos + 1) !== 0x5B) return false;
      const end = s.indexOf("]]", pos + 2);
      if (end < 0) return false;
      const inner = s.slice(pos + 2, end);
      if (!inner || inner.includes("\n") || inner.includes("[")) return false;
      if (!silent) {
        const bar = inner.indexOf("|");
        const tok = state.push("wikilink", "", 0);
        tok.meta = { target: bar < 0 ? inner : inner.slice(0, bar), label: bar < 0 ? null : inner.slice(bar + 1) };
      }
      state.pos = end + 2;
      return true;
    });
    m.renderer.rules.wikilink = (tokens, i) => {
      const { target, label } = tokens[i].meta;
      return `<a class="wikilink" data-wiki="${escHtml(target)}">${escHtml(label === null ? target : label)}</a>`;
    };

    // "- [ ] task" / "- [x] done"
    m.core.ruler.after("inline", "tasklist", (state) => {
      const t = state.tokens;
      for (let i = 2; i < t.length; i++) {
        if (t[i].type !== "inline" || t[i - 1].type !== "paragraph_open" || t[i - 2].type !== "list_item_open") continue;
        const mm = /^\[([ xX])\](?:\s+|$)/.exec(t[i].content);
        const first = t[i].children && t[i].children[0];
        if (!mm || !first || first.type !== "text") continue;
        first.content = first.content.replace(/^\[[ xX]\]\s*/, "");
        t[i - 2].attrJoin("class", "task-item");
        const cb = new state.Token("html_inline", "", 0);
        cb.content = `<input type="checkbox" class="task-cb"${mm[1] === " " ? "" : " checked"}> `;
        t[i].children.unshift(cb);
      }
    });

    // remember which source lines each top-level block came from
    m.core.ruler.push("srcmap", (state) => {
      if (state.env.noMap) return;
      for (const t of state.tokens) {
        if (t.level === 0 && t.map && (t.nesting === 1 || t.nesting === 0) && t.type !== "inline") {
          t.attrSet("data-md", t.map[0] + ":" + t.map[1]);
        }
      }
    });
    const defFence = m.renderer.rules.fence;
    m.renderer.rules.fence = (tokens, i, o, env, self) => {
      const html = defFence(tokens, i, o, env, self);
      const t = tokens[i];
      if (t.level === 0 && t.map && !env.noMap) return html.replace(/^<pre/, `<pre data-md="${t.map[0]}:${t.map[1]}"`);
      return html;
    };
    m.renderer.rules.code_block = (tokens, i, o, env) => {
      const t = tokens[i];
      const at = t.level === 0 && t.map && !env.noMap ? ` data-md="${t.map[0]}:${t.map[1]}"` : "";
      return `<pre${at}><code>${escHtml(t.content)}</code></pre>\n`;
    };
    m.renderer.rules.html_block = (tokens, i, o, env) => {
      const t = tokens[i];
      const at = t.level === 0 && t.map && !env.noMap ? ` data-md="${t.map[0]}:${t.map[1]}"` : "";
      return `<div class="md-html" contenteditable="false"${at}>${t.content}</div>\n`;
    };

    // images: remember the original src, show the file through the API
    const defImage = m.renderer.rules.image;
    m.renderer.rules.image = (tokens, i, o, env, self) => {
      const t = tokens[i];
      const src = t.attrGet("src") || "";
      t.attrSet("data-src", src);
      let display = src;
      if (!/^([a-z]+:|\/\/|\/|data:)/i.test(src)) {
        let dec = src; try { dec = decodeURI(src); } catch (e) {}
        display = `${API}/asset?path=${encodeURIComponent(resolveRel(env.notePath || "", dec))}`;
      }
      t.attrSet("src", display);
      return defImage(tokens, i, o, env, self);
    };
    MD = m;
    return m;
  }

  function dirOf(path) { const i = path.lastIndexOf("/"); return i < 0 ? "" : path.slice(0, i); }
  function resolveRel(notePath, rel) {
    const parts = dirOf(notePath).split("/").filter(Boolean);
    for (const seg of rel.split("/")) {
      if (seg === "" || seg === ".") continue;
      if (seg === "..") parts.pop(); else parts.push(seg);
    }
    return parts.join("/");
  }
  function relativeTo(notePath, target) {
    const from = dirOf(notePath).split("/").filter(Boolean);
    const to = target.split("/").filter(Boolean);
    let i = 0;
    while (i < from.length && i < to.length - 1 && from[i] === to[i]) i++;
    return [...from.slice(i).map(() => ".."), ...to.slice(i)].join("/");
  }

  // Allowlist sanitizer. Notes may contain raw HTML (markdown-it html:true) and
  // note files can come from anywhere, so nothing outside this list survives:
  // unknown elements are unwrapped (their text is kept), dangerous ones are
  // dropped with their content, unknown attributes are removed, and URLs must
  // use a safe scheme (checked AFTER stripping the control characters and
  // whitespace browsers ignore, e.g. "jav&#x09;ascript:").
  const SAN_DROP = new Set(["SCRIPT", "STYLE", "IFRAME", "FRAME", "FRAMESET", "OBJECT", "EMBED", "APPLET", "LINK", "META", "BASE", "FORM", "TEMPLATE", "NOSCRIPT", "SVG", "MATH", "TITLE", "HEAD", "SELECT", "TEXTAREA", "BUTTON", "CANVAS", "DIALOG", "PORTAL", "SLOT"]);
  const SAN_TAGS = new Set(("A ABBR B BDI BDO BLOCKQUOTE BR CAPTION CITE CODE COL COLGROUP DATA DD DEL DETAILS DFN DIV DL DT EM FIGCAPTION FIGURE H1 H2 H3 H4 H5 H6 HR I IMG INS KBD LI MARK OL P PRE Q RP RT RUBY S SAMP SECTION ARTICLE ASIDE HEADER FOOTER NAV SMALL SPAN STRONG SUB SUMMARY SUP TABLE TBODY TD TFOOT TH THEAD TIME TR U UL VAR WBR INPUT AUDIO VIDEO SOURCE CENTER FONT").split(" "));
  const SAN_ATTRS = new Set(["class", "title", "alt", "lang", "dir", "colspan", "rowspan", "align", "valign", "width", "height", "open", "start", "reversed", "type", "checked", "disabled", "datetime", "cite", "controls", "loop", "muted", "poster", "color", "size", "face", "href", "src", "style", "contenteditable", "role"]);
  const SAN_URL_ATTRS = new Set(["href", "src", "cite", "poster"]);
  function safeUrl(v, attr) {
    const c = String(v).replace(/[\u0000-\u0020\u007f-\u009f\u00ad\u200b-\u200f\u2028\u2029\ufeff]/g, "").toLowerCase();
    if (c === "") return true;
    if (/^data:image\/(png|jpe?g|gif|webp|avif|bmp);/.test(c)) return attr !== "href";
    const m = /^([a-z][a-z0-9+.-]*):/.exec(c);
    if (!m) return true;                                   // relative / #anchor / //host
    if (attr === "href") return ["http", "https", "mailto", "tel"].includes(m[1]);
    return ["http", "https"].includes(m[1]);
  }
  function safeStyle(v) {
    const c = String(v).replace(/\/\*[\s\S]*?\*\//g, "").replace(/\\/g, "").toLowerCase();
    return !/(url\s*\(|expression|javascript:|@import|behavior|-moz-binding|image-set|position\s*:\s*(fixed|sticky))/.test(c);
  }
  function sanitizeNode(parent) {
    for (const n of [...parent.childNodes]) {
      if (n.nodeType === 3) continue;
      if (n.nodeType !== 1) { n.remove(); continue; }       // comments, PIs
      const tag = n.tagName.toUpperCase();
      if (SAN_DROP.has(tag) || n.namespaceURI !== "http://www.w3.org/1999/xhtml") { n.remove(); continue; }
      if (!SAN_TAGS.has(tag)) {                              // unwrap: keep the text
        sanitizeNode(n);
        while (n.firstChild) parent.insertBefore(n.firstChild, n);
        n.remove();
        continue;
      }
      for (const a of [...n.attributes]) {
        const name = a.name.toLowerCase();
        const ok = (SAN_ATTRS.has(name) || /^data-[a-z0-9-]+$/.test(name)) &&
          !(SAN_URL_ATTRS.has(name) && !safeUrl(a.value, name)) &&
          !(name === "style" && !safeStyle(a.value));
        if (!ok) n.removeAttribute(a.name);
      }
      if (tag === "INPUT") {                                 // only the task-list checkbox
        if ((n.getAttribute("type") || "").toLowerCase() !== "checkbox") { n.remove(); continue; }
      }
      if (tag === "A") {
        if (n.getAttribute("target")) n.removeAttribute("target");
        n.setAttribute("rel", "noopener noreferrer");
      }
      if (tag === "SOURCE" && !n.hasAttribute("src")) { n.remove(); continue; }
      sanitizeNode(n);
    }
  }
  function sanitizeInto(container, html) {
    const tpl = document.createElement("template");
    tpl.innerHTML = html;
    sanitizeNode(tpl.content);
    container.innerHTML = "";
    container.appendChild(tpl.content);
  }

  /* ------------------------------------------------------------------ *
   * HTML -> Markdown (serializer for edited blocks)
   * ------------------------------------------------------------------ */
  const BLOCK_TAGS = new Set(["P", "DIV", "H1", "H2", "H3", "H4", "H5", "H6", "UL", "OL", "LI", "BLOCKQUOTE", "PRE", "TABLE", "HR", "FIGURE", "SECTION", "ARTICLE", "DETAILS", "ASIDE", "HEADER", "FOOTER", "NAV", "DL"]);

  function escText(s) {
    return s
      .replace(/ /g, " ")
      .replace(/\\(?=[\\`*_{}\[\]()#+\-.!|<>~])/g, "\\\\")
      .replace(/([*`])/g, "\\$1")
      .replace(/(?<![\p{L}\p{N}])_|_(?![\p{L}\p{N}])/gu, "\\_")
      .replace(/~~/g, "\\~~")
      .replace(/<(?=[A-Za-z\/!])/g, "\\<");
  }
  function escLineStarts(s) {
    return s.split("\n").map((l) => l
      .replace(/^(\s*)(#{1,6})(\s)/, "$1\\$2$3")
      .replace(/^(\s*)([-+*])(\s)/, "$1\\$2$3")
      .replace(/^(\s*)(\d+)([.)])(\s)/, "$1$2\\$3$4")
      .replace(/^(\s*)>/, "$1\\>")).join("\n");
  }
  function wrapInline(marker, inner) {
    const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(inner);
    if (!m[2]) return inner;
    return m[1] + marker + m[2] + marker + m[3];
  }

  function inlineNodes(nodes, ctx) {
    let out = "";
    for (const n of nodes) out += inlineNode(n, ctx || {});
    return out;
  }
  function inlineNode(n, ctx) {
    if (n.nodeType === 3) {
      let t = n.nodeValue;
      const prev = n.previousSibling;
      if (prev && prev.nodeName === "BR") t = t.replace(/^\s*\n\s*/, "");
      t = t.replace(/\s*\n\s*/g, " ");
      return ctx.raw ? t.replace(/ /g, " ") : escText(t);
    }
    if (n.nodeType !== 1) return "";
    const tag = n.tagName;
    const kids = () => inlineNodes(n.childNodes, ctx);
    switch (tag) {
      case "BR": {
        if (ctx.table) {
          let nx = n.nextSibling;
          while (nx && nx.nodeType === 3 && !nx.nodeValue.trim()) nx = nx.nextSibling;
          return nx ? "<br>" : "";
        }
        return ctx.heading ? " " : "\n";
      }
      case "STRONG": case "B": return wrapInline("**", kids());
      case "EM": case "I": return wrapInline("*", kids());
      case "DEL": case "S": case "STRIKE": return wrapInline("~~", kids());
      case "CODE": {
        const t = n.textContent.replace(/ /g, " ");
        if (!t) return "";
        const ticks = "`".repeat((Math.max(0, ...(t.match(/`+/g) || []).map((x) => x.length)) || 0) + 1);
        const pad = /^`|`$/.test(t) ? " " : "";
        return ticks + pad + t + pad + ticks;
      }
      case "A": {
        if (n.classList.contains("wikilink")) {
          const target = n.getAttribute("data-wiki") || n.textContent;
          const label = n.textContent;
          return label === target ? `[[${target}]]` : `[[${target}|${label}]]`;
        }
        const href = n.getAttribute("href") || "";
        const text = kids();
        if (!href) return text;
        if (text === href && !n.getAttribute("title")) return href;       // a bare URL stays a bare URL on save
        const dest = /[\s()]/.test(href) ? `<${href}>` : href;
        const title = n.getAttribute("title");
        return `[${text}](${dest}${title ? ` "${title.replace(/"/g, '\\"')}"` : ""})`;
      }
      case "IMG": {
        const src = n.getAttribute("data-src") || n.getAttribute("src") || "";
        const alt = (n.getAttribute("alt") || "").replace(/[\[\]]/g, "");
        const dest = /[\s()]/.test(src) ? `<${src}>` : src;
        const title = n.getAttribute("title");
        return `![${alt}](${dest}${title ? ` "${title.replace(/"/g, '\\"')}"` : ""})`;
      }
      case "INPUT": return "";
      case "U": case "MARK": case "SUP": case "SUB": case "KBD": {
        const t = tag.toLowerCase();
        return `<${t}>${kids()}</${t}>`;
      }
      case "SPAN": case "FONT": {
        const st = n.style || {};
        let inner = kids();
        if (st.fontWeight === "bold" || parseInt(st.fontWeight, 10) >= 600) inner = wrapInline("**", inner);
        if (st.fontStyle === "italic") inner = wrapInline("*", inner);
        if ((st.textDecorationLine || st.textDecoration || "").includes("line-through")) inner = wrapInline("~~", inner);
        return inner;
      }
      default:
        if (BLOCK_TAGS.has(tag)) return kids();
        return kids();
    }
  }

  function trimBlankLines(s) { return s.replace(/^\s*\n/, "").replace(/\s+$/, "").replace(/^[ \t]+(?=\S)/, (m) => m); }

  // Serializes a list of sibling nodes (mixed text/inline/block) to Markdown.
  function blocksOf(nodes, opts) {
    opts = opts || {};
    const out = [];
    let run = [];
    const flush = () => {
      if (!run.length) return;
      let s = inlineNodes(run, {});
      run = [];
      s = s.replace(/^\s+/, "").replace(/\s+$/, "");
      if (s) out.push(escLineStarts(s));
    };
    for (const n of nodes) {
      if (n.nodeType === 1 && (BLOCK_TAGS.has(n.tagName) || n.tagName === "DETAILS")) {
        flush();
        const s = blockEl(n);
        if (s !== "") out.push(s);
      } else if (n.nodeType === 3 || n.nodeType === 1) {
        run.push(n);
      }
    }
    flush();
    return out.join(opts.sep || "\n\n");
  }

  function indentLines(text, pad, firstPrefix) {
    const lines = text.split("\n");
    return lines.map((l, i) => (i === 0 ? firstPrefix + l : (l === "" ? "" : pad + l))).join("\n");
  }

  function blockEl(el) {
    const tag = el.tagName;
    if (/^H[1-6]$/.test(tag)) {
      const t = inlineNodes(el.childNodes, { heading: true }).replace(/\s+/g, " ").trim();
      return t ? "#".repeat(+tag[1]) + " " + t : "";
    }
    switch (tag) {
      case "P": {
        const s = inlineNodes(el.childNodes, {}).replace(/^\s+/, "").replace(/\s+$/, "");
        return s ? escLineStarts(s) : "";
      }
      case "DIV":
        if (el.classList.contains("md-html")) return el.innerHTML.trim();
        return blocksOf(el.childNodes);
      case "BLOCKQUOTE": {
        const inner = blocksOf(el.childNodes);
        if (!inner) return "";
        return inner.split("\n").map((l) => (l ? "> " + l : ">")).join("\n");
      }
      case "UL": case "OL": return listEl(el);
      case "LI": return blocksOf(el.childNodes, { sep: "\n" });
      case "PRE": return preEl(el);
      case "HR": return "---";
      case "TABLE": return tableEl(el);
      default:
        return el.outerHTML.trim();
    }
  }

  function listEl(el) {
    const ordered = el.tagName === "OL";
    let n = parseInt(el.getAttribute("start") || "1", 10);
    if (!(n >= 0)) n = 1;
    // Browsers (Chromium's Tab = "indent") nest a sub-list as a <ul>/<ol> sitting DIRECTLY inside the parent list,
    // after the <li> it belongs to, instead of inside it. Those lists are attached to the preceding item here;
    // ignoring them used to drop every sub-bullet when the note was saved.
    const items = [];
    const extra = new Map();            // <li> (or null for a leading orphan list) -> sub-lists that follow it
    for (const c of el.children) {
      if (c.tagName === "LI") items.push(c);
      else if (c.tagName === "UL" || c.tagName === "OL") {
        const owner = items.length ? items[items.length - 1] : null;
        if (!extra.has(owner)) extra.set(owner, []);
        extra.get(owner).push(c);
        if (!items.length) items.push(null);        // an item with no text of its own
      }
    }
    const loose = items.some((li) => li && [...li.children].some((c) => c.tagName === "P"));
    const parts = [];
    for (const li of items) {
      // the checkbox sits straight in the <li> of a tight list, but inside its <p> in a loose one (items separated by blank lines)
      const isCb = (c) => c.nodeType === 1 && c.tagName === "INPUT" && c.type === "checkbox";
      const firstP = li && [...li.children].find((c) => c.tagName === "P");
      const cb = li && ([...li.childNodes].find(isCb) || (firstP && [...firstP.childNodes].find(isCb)));
      const rest = li ? [...li.childNodes].filter((c) => c !== cb) : [];
      let content = blocksOf(rest, { sep: loose ? "\n\n" : "\n" });
      if (cb) content = (cb.checked ? "[x]" : "[ ]") + (content ? " " + content : "");
      for (const sub of extra.get(li) || []) {
        const subText = listEl(sub);
        if (subText) content += (content ? "\n" : "") + subText;
      }
      const marker = ordered ? `${n}. ` : "- ";
      n++;
      parts.push(content ? indentLines(content, " ".repeat(marker.length), marker) : marker.trimEnd());
    }
    return parts.join(loose ? "\n\n" : "\n");
  }

  function preEl(el) {
    const code = el.querySelector("code");
    let t = (code || el).textContent.replace(/ /g, " ").replace(/\n$/, "");
    const m = code && /(?:^|\s)language-([\w+#.-]+)/.exec(code.className || "");
    const longest = Math.max(2, ...(t.match(/`{3,}/g) || []).map((x) => x.length));
    const fence = "`".repeat(longest + 1);
    return `${fence}${m ? m[1] : ""}\n${t}\n${fence}`;
  }

  function tableEl(el) {
    const rows = [...el.querySelectorAll("tr")];
    if (!rows.length) return "";
    const cellText = (c) => inlineNodes(c.childNodes, { table: true }).replace(/\s+/g, " ").replace(/\|/g, "\\|").trim();
    const grid = rows.map((r) => [...r.children].filter((c) => /^T[HD]$/.test(c.tagName)));
    const cols = Math.max(...grid.map((r) => r.length));
    const aligns = [];
    for (let i = 0; i < cols; i++) {
      const c = grid[0][i];
      const a = c && ((c.style && c.style.textAlign) || c.getAttribute("align") || "");
      aligns.push(a === "center" ? ":---:" : a === "right" ? "---:" : a === "left" ? ":---" : "---");
    }
    const line = (cells) => "| " + Array.from({ length: cols }, (_, i) => (cells[i] ? cellText(cells[i]) : "")).join(" | ") + " |";
    const out = [line(grid[0]), "| " + aligns.join(" | ") + " |"];
    for (const r of grid.slice(1)) out.push(line(r));
    return out.join("\n");
  }

  /* ------------------------------------------------------------------ *
   * safety net: what is on screen vs. what would be written to the file
   * ------------------------------------------------------------------ */
  // The text a person can see in a container, without spaces / zero-width characters (formatting is ignored on purpose).
  function textSig(root) { return root.textContent.replace(/[\s\u200b\u00a0\ufeff]+/g, ""); }

  // Counts of what carries no text of its own: task checkboxes (with their state), pictures, links, table rows, bullets, code blocks.
  function structSig(root) {
    const n = (sel) => root.querySelectorAll(sel).length;
    const cbs = [...root.querySelectorAll("input[type=checkbox]")].map((i) => (i.checked ? "x" : "o")).join("");
    // an empty bullet / code block (just typed "- " or "```", nothing after it yet) holds nothing that could be lost: not counted
    const filled = (sel) => [...root.querySelectorAll(sel)].filter((e) => /\S/.test(e.textContent.replace(/[\u200b\ufeff]/g, "")) || e.querySelector("img, input, table")).length;
    return `checkboxes ${cbs || "-"}, images ${n("img")}, links ${n("a[href]")}, rows ${n("tr")}, bullets ${filled("li")}, code ${filled("pre")}`;
  }

  // A readable plain-text outline of the editor (bullets indented by depth): used to rescue the text when the editor cannot
  // be converted to Markdown without losing some of it.
  function outlineText(root) {
    const own = (el) => { const c = el.cloneNode(true); c.querySelectorAll("ul, ol").forEach((x) => x.remove()); return c.textContent.replace(/[\u200b\ufeff]/g, "").replace(/\s+/g, " ").trim(); };
    const lines = [];
    for (const el of root.querySelectorAll("li, p, h1, h2, h3, h4, h5, h6, pre, tr, div.md-html")) {
      if (el.tagName === "P" && el.closest("li")) continue;                       // counted with its list item
      if (el.tagName === "LI") {
        let d = 0; for (let a = el.parentElement; a && a !== root; a = a.parentElement) if (a.tagName === "UL" || a.tagName === "OL") d++;
        const t = own(el); if (t) lines.push("  ".repeat(Math.max(0, d - 1)) + "- " + t);
      } else if (el.tagName === "TR") {
        lines.push("| " + [...el.children].map((c) => own(c)).join(" | ") + " |");
      } else if (el.tagName === "PRE") {
        lines.push("```", el.textContent.replace(/\n$/, ""), "```");
      } else if (/^H[1-6]$/.test(el.tagName)) {
        const t = own(el); if (t) lines.push("#".repeat(+el.tagName[1]) + " " + t);
      } else if (el.closest("li, td, th") ) {
        continue;
      } else {
        const t = own(el); if (t) lines.push(t);
      }
    }
    return lines.join("\n");
  }

  /* ------------------------------------------------------------------ *
   * front matter
   * ------------------------------------------------------------------ */
  function splitFrontMatter(text) {
    const m = /^(---[ \t]*\r?\n[\s\S]*?\r?\n(?:---|\.\.\.)[ \t]*(?:\r?\n|$))/.exec(text);
    if (!m || m[1].split("\n").length > 80) return { fm: "", body: text };
    return { fm: m[1], body: text.slice(m[1].length) };
  }

  /* ------------------------------------------------------------------ *
   * the editor instance
   * ------------------------------------------------------------------ */
  let INSTANCE = null;
  const OPENED_FOLDERS = new Set();   // unfolded note folders (in memory only: everything starts folded)

  /* ------------------------------------------------------------------ *
   * teleprompter: the text under the "Content" heading, scrolling
   * ------------------------------------------------------------------ */
  function extractContent(text) {
    const { body } = splitFrontMatter(text);
    const lines = body.split("\n");
    let fence = false, start = -1, level = 0;
    for (let i = 0; i < lines.length; i++) {
      if (/^\s*(```|~~~)/.test(lines[i])) { fence = !fence; continue; }
      if (fence) continue;
      const m = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(lines[i]);
      if (!m) continue;
      if (start < 0) {
        if (norm(m[2]).replace(/[^a-z]/g, "") === "content") { start = i + 1; level = m[1].length; }
      } else if (m[1].length <= level) {
        return lines.slice(start, i).join("\n").trim();
      }
    }
    return start < 0 ? null : lines.slice(start).join("\n").trim();
  }

  function openPrompter(text, notePath, title) {
    const content = extractContent(text);
    const speedKey = "notes.prompter.speed", sizeKey = "notes.prompter.size";
    let speed = Math.min(300, Math.max(5, parseInt(LS.get(speedKey, "60"), 10) || 60));
    let size = Math.min(140, Math.max(24, parseInt(LS.get(sizeKey, "56"), 10) || 56));
    let running = false, raf = 0, last = 0, pos = 0;

    const view = h("div", { class: "pr-view" }, [h("div", { class: "pr-guide" }), h("div", { class: "pr-text" })]);
    const textEl = view.querySelector(".pr-text");
    if (content === null || !content) {
      textEl.innerHTML = `<p class="pr-empty">${content === null ? "This note has no “Content” heading." : "The “Content” section is empty."}</p>`;
    } else {
      sanitizeInto(textEl, md().render(content, { noMap: true, notePath }));
    }
    textEl.style.fontSize = size + "px";

    const playBtn = h("button", { class: "btn primary pr-btn", type: "button", onclick: () => start() }, [icon("play", 16), "Play"]);
    const stopBtn = h("button", { class: "btn pr-btn", type: "button", onclick: () => stop() }, [icon("stop", 16), "Stop"]);
    const speedLbl = h("span", { class: "pr-val" }, "");
    const slider = h("input", { type: "range", min: "5", max: "300", step: "5", value: String(speed), class: "pr-slider", "aria-label": "Speed",
      oninput: () => { speed = +slider.value; LS.set(speedKey, String(speed)); paintSpeed(); } });
    const sizeLbl = h("span", { class: "pr-val" }, "");
    const paintSpeed = () => { speedLbl.textContent = `${speed} px/s`; slider.value = String(speed); };
    const paintSize = () => { sizeLbl.textContent = String(size); textEl.style.fontSize = size + "px"; };
    const paintState = () => { playBtn.disabled = running; stopBtn.disabled = !running; overlay.classList.toggle("running", running); };
    const setSize = (d) => { size = Math.min(140, Math.max(24, size + d)); LS.set(sizeKey, String(size)); paintSize(); };

    function frame(t) {
      if (!running) return;
      const dt = Math.min(0.1, (t - last) / 1000); last = t;
      pos += speed * dt;
      const max = view.scrollHeight - view.clientHeight;
      if (pos >= max) { pos = max; view.scrollTop = pos; stop(); return; }
      view.scrollTop = pos;
      raf = requestAnimationFrame(frame);
    }
    function start() {
      if (running) return;
      pos = view.scrollTop;
      if (pos >= view.scrollHeight - view.clientHeight - 2) { pos = 0; view.scrollTop = 0; }   // at the end: start over
      running = true; last = performance.now(); paintState();
      raf = requestAnimationFrame(frame);
    }
    function stop() { running = false; cancelAnimationFrame(raf); pos = view.scrollTop; paintState(); }
    function toggle() { running ? stop() : start(); }
    function close() { stop(); document.removeEventListener("keydown", onKey, true); overlay.remove(); }

    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); return; }
      if (e.key === " " || e.code === "Space") { e.preventDefault(); e.stopPropagation(); toggle(); if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); return; }
      if (e.key === "ArrowUp" && e.altKey === false && e.target === document.body) { speed = Math.min(300, speed + 5); LS.set(speedKey, String(speed)); paintSpeed(); e.preventDefault(); }
      if (e.key === "ArrowDown" && e.altKey === false && e.target === document.body) { speed = Math.max(5, speed - 5); LS.set(speedKey, String(speed)); paintSpeed(); e.preventDefault(); }
    };
    view.addEventListener("wheel", () => { if (running) setTimeout(() => { pos = view.scrollTop; }, 0); }, { passive: true });
    view.addEventListener("scroll", () => { if (!running) pos = view.scrollTop; }, { passive: true });
    view.addEventListener("click", () => toggle());

    const overlay = h("div", { class: "pr-overlay" }, [
      h("div", { class: "pr-modal", role: "dialog", "aria-modal": "true" }, [
        h("div", { class: "pr-bar" }, [
          h("div", { class: "pr-title" }, title || "Prompter"),
          playBtn, stopBtn,
          h("button", { class: "btn pr-btn", type: "button", title: "Back to the top", onclick: () => { stop(); view.scrollTop = 0; pos = 0; } }, "⟲"),
          h("label", { class: "pr-ctl" }, ["Speed", slider, speedLbl]),
          h("span", { class: "pr-ctl" }, ["Text", h("button", { class: "btn pr-btn", type: "button", onclick: () => setSize(-4) }, "A−"), sizeLbl, h("button", { class: "btn pr-btn", type: "button", onclick: () => setSize(4) }, "A+")]),
          h("button", { class: "btn pr-btn", type: "button", title: "Close (Esc)", onclick: close }, "✕"),
        ]),
        view,
        h("div", { class: "pr-hint" }, "Space: play / stop · ↑ ↓: speed · Esc: close"),
      ]),
    ]);
    document.addEventListener("keydown", onKey, true);
    document.body.appendChild(overlay);
    paintSpeed(); paintSize(); paintState();
    view.focus();
  }

  /* ------------------------------------------------------------------ *
   * keyword matching of note names (suggestions + picker search)
   * ------------------------------------------------------------------ */
  const STOP = new Set(("the and for with from this that your you are was were not but how why what when who into over under about has have had can will " +
    "just its our out all any new one two than then them they their there here more most some very also via per vs " +
    "les des une pour avec dans sur par pas que qui est sont mon ma mes ton ta tes son sa ses nos vos leur leurs aux ces cet cette ceux elle elles nous vous ils plus mais donc car ainsi comme").split(" "));
  function tokens(s) {
    return norm(s).replace(/[^a-z0-9]+/g, " ").split(" ").filter(Boolean)
      .map((t) => (t.length > 4 && t.endsWith("s") && !t.endsWith("ss") ? t.slice(0, -1) : t))
      .filter((t) => (t.length >= 3 || /^\d{2,}$/.test(t)) && !STOP.has(t));
  }
  const tokMatch = (q, t) => q === t || (q.length >= 4 && t.length >= 4 && (t.startsWith(q) || q.startsWith(t)));
  // Notes ordered by how well their name matches the keywords of `query`
  // (no exact match needed; rare words weigh more than common ones).
  function rankNotes(query, notes, minScore) {
    const qt = [...new Set(tokens(query))];
    if (!qt.length) return [];
    const docs = notes.map((n) => ({ n, t: new Set(tokens(n.name)) }));
    const df = new Map();
    for (const d of docs) for (const t of d.t) df.set(t, (df.get(t) || 0) + 1);
    const idf = (t) => Math.log(1 + docs.length / (1 + (df.get(t) || 0)));
    const out = [];
    for (const d of docs) {
      let hit = 0, total = 0;
      const used = new Set();
      for (const q of qt) {
        const w = idf(q); total += w;
        let any = false;
        for (const t of d.t) if (tokMatch(q, t)) { any = true; used.add(t); }
        if (any) hit += w;
      }
      if (!hit) continue;
      let score = 0.7 * (hit / total) + 0.3 * (used.size / Math.max(1, d.t.size));
      if ((d.n.folder || "").split("/")[0].toLowerCase() === "scripts") score *= 1.1;
      if (score >= (minScore || 0)) out.push({ ...d.n, score });
    }
    return out.sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  }

  let TREE_CACHE = { at: 0, data: null };
  async function fetchTree(force) {
    if (!force && TREE_CACHE.data && Date.now() - TREE_CACHE.at < 20000) return TREE_CACHE.data;
    const data = await call("GET", `${API}/tree`);
    TREE_CACHE = { at: Date.now(), data };
    return data;
  }

  // A sheet to choose a note. Resolves the note's path (relative to the
  // notes folder), "" for "unlink", or null when cancelled.
  async function notePicker(opts) {
    opts = opts || {};
    let tree;
    try { tree = await fetchTree(true); } catch (e) { return null; }
    const notes = tree.notes;
    return new Promise((resolve) => {
      const overlay = h("div", { class: "sheet-overlay open" });
      const input = h("input", { type: "text", class: "sheet-input", placeholder: "Search by keywords…" });
      const list = h("div", { class: "ne-wiki-list ne-picker-list" });
      let done = false;
      const finish = (v) => { if (done) return; done = true; document.removeEventListener("keydown", onKey, true); overlay.remove(); resolve(v); };
      const onKey = (e) => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(null); } };
      document.addEventListener("keydown", onKey, true);
      const row = (n, extra) => h("button", { type: "button", class: "ne-pop-item ne-pick-row" + (n.path === opts.current ? " current" : ""), onclick: () => finish(n.path) }, [
        h("span", { class: "ne-pick-name" }, n.name),
        n.folder ? h("span", { class: "muted ne-pick-folder" }, n.folder) : null,
        extra || null,
        n.path === opts.current ? icon("check", 14) : null,
      ]);
      const label = (t) => h("div", { class: "notes-section-label" }, t);
      const paint = () => {
        list.innerHTML = "";
        const q = input.value.trim();
        if (q) {
          let res = rankNotes(q, notes).slice(0, 40);
          if (!res.length) res = notes.filter((n) => norm(n.name).includes(norm(q))).slice(0, 40);
          res.forEach((n) => list.appendChild(row(n)));
          if (!res.length) list.appendChild(h("div", { class: "muted", style: "padding:8px" }, "No matching note"));
          return;
        }
        const sug = opts.query ? rankNotes(opts.query, notes, 0.35).slice(0, 3) : [];
        if (sug.length) {
          list.appendChild(label(`Suggested for “${opts.query}”`));
          sug.forEach((n) => list.appendChild(row(n, h("span", { class: "ne-pick-score" }, "match"))));
        }
        list.appendChild(label("All notes"));
        [...notes].sort((a, b) => a.path.localeCompare(b.path, undefined, { numeric: true, sensitivity: "base" })).slice(0, 80)
          .forEach((n) => list.appendChild(row(n)));
      };
      input.addEventListener("input", paint);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") { const f = list.querySelector(".ne-pick-row"); if (f) f.click(); } });
      overlay.addEventListener("mousedown", (e) => { if (e.target === overlay) finish(null); });
      overlay.appendChild(h("div", { class: "sheet ne-picker" }, [
        h("div", { class: "sheet-text" }, [h("div", { class: "sheet-title" }, opts.title || "Choose a note"), input, list]),
        h("div", { class: "sheet-buttons" }, [
          opts.current ? h("button", { class: "btn danger", onclick: () => finish("") }, "Unlink") : null,
          h("button", { class: "btn", onclick: () => finish(null) }, "Cancel"),
        ]),
      ]));
      document.body.appendChild(overlay);
      paint(); input.focus();
    });
  }

  class NotesEditor {
    constructor(container, opts) {
      this.root = container;
      this.toast = opts.toast || (() => {});
      this.confirm = opts.confirm;
      this.prompt = opts.prompt;
      this.tree = { notes: [], folders: [], root: "", exists: true };
      this.opened = OPENED_FOLDERS;          // folders start folded; what is unfolded lasts until the page is reloaded
      this.filter = "";
      this.folderSel = LS.get("notes.folder", "");
      this.mode = LS.get("notes.mode", "rich");
      this.path = null;
      this.state = { pinned: [], recent: [] };
      this.touchTimer = null;
      this.mtime = null;
      this.text = "";          // last text known to be on disk
      this.fm = "";            // front matter, verbatim
      this.lines = [];         // body lines of the loaded text
      this.blocks = {};        // "start:end" -> {idx,start,end}
      this.blockList = [];
      this.saving = null;
      this.timer = null;
      this.rtBlocked = false;  // a save was refused because the Markdown would not contain everything on screen
      this.destroyed = false;
      this.build();
      this.watch = setInterval(() => this.tick(), 700);
    }

    /* ---------- layout ---------- */
    build() {
      this.root.innerHTML = "";
      this.root.classList.add("notes-app");

      this.listEl = h("div", { class: "notes-tree" });
      this.filterInput = h("input", { type: "search", class: "notes-filter", placeholder: "Filter notes…", oninput: () => { this.filter = this.filterInput.value; this.renderTree(); } });
      const side = h("aside", { class: "notes-side" }, [
        h("div", { class: "notes-side-head" }, [
          this.filterInput,
          h("button", { class: "ne-btn", title: "New note", onclick: () => this.newNote() }, [icon("plus")]),
          h("button", { class: "ne-btn", title: "New folder", onclick: () => this.newFolder() }, [icon("folderPlus")]),
        ]),
        this.listEl,
        this.rootLabel = h("div", { class: "notes-root-label" }),
      ]);

      this.titleInput = h("input", { class: "note-title", spellcheck: "false", "aria-label": "Note name",
        onchange: () => this.rename(this.titleInput.value), onkeydown: (e) => { if (e.key === "Enter") { e.preventDefault(); this.titleInput.blur(); } } });
      this.statusEl = h("span", { class: "note-status" });
      this.modeBtn = h("button", { class: "ne-btn txt", title: "Switch between rich text and raw Markdown", onclick: () => this.setMode(this.mode === "rich" ? "md" : "rich") });
      this.moreBtn = h("button", { class: "ne-btn", title: "More", onclick: (e) => this.noteMenu(e.currentTarget) }, [icon("more")]);
      this.pinBtn = h("button", { class: "ne-btn ne-pinbtn", title: "Pin to the top", onclick: () => this.togglePin(this.path) }, [icon("pin")]);
      this.prompterBtn = h("button", { class: "ne-btn txt", title: "Teleprompter: the “Content” section, scrolling", onclick: () => this.prompter() }, [icon("play", 13), "Prompter"]);
      this.zoomLabel = h("button", { class: "ne-btn ne-zoomval", title: "Reset text size", onclick: () => this.setZoom(1) });
      this.zoomBox = h("span", { class: "ne-group ne-zoom" }, [
        h("button", { class: "ne-btn txt", title: "Smaller text", "aria-label": "Smaller text", onclick: () => this.setZoom(this.zoom - 0.1) }, "A−"),
        this.zoomLabel,
        h("button", { class: "ne-btn txt", title: "Larger text", "aria-label": "Larger text", onclick: () => this.setZoom(this.zoom + 0.1) }, "A+"),
      ]);
      this.head = h("div", { class: "note-head" }, [this.titleInput, this.statusEl, this.prompterBtn, this.pinBtn, this.zoomBox, this.modeBtn,
        h("button", { class: "ne-btn", title: "Save (Ctrl+S)", onclick: () => this.save(true) }, [icon("save")]), this.moreBtn]);

      this.toolbar = this.buildToolbar();
      this.fmBox = h("details", { class: "note-fm hidden" }, [
        h("summary", {}, "Properties (front matter)"),
        this.fmArea = h("textarea", { spellcheck: "false", oninput: () => this.touch() }),
      ]);
      this.editor = h("div", { class: "md-editor", contenteditable: "true", spellcheck: "true" });
      this.src = h("textarea", { class: "md-source hidden", spellcheck: "false", oninput: () => this.touch() });
      this.empty = h("div", { class: "notes-empty" }, [h("div", { class: "emoji" }, "📝"), h("div", {}, "Pick a note on the left, or create one with ＋")]);
      this.countEl = h("div", { class: "note-count", title: "Characters, spaces and line breaks not included" });
      this.warnEl = h("div", { class: "note-warn hidden", role: "alert" });
      this.pane = h("div", { class: "note-pane hidden" }, [this.head, this.toolbar, this.warnEl, h("div", { class: "note-scroll" }, [this.fmBox, this.editor, this.src]), this.countEl]);
      this.zoom = 1;
      { const z = parseFloat(LS.get("notes.zoom")); this.zoom = isFinite(z) ? Math.min(2, Math.max(0.7, z)) : 1; }
      this.applyZoom();
      document.addEventListener("selectionchange", () => { if (this.pane && !this.pane.classList.contains("hidden")) this.updateCount(); });

      this.root.appendChild(h("div", { class: "notes-layout" }, [side, h("section", { class: "notes-main" }, [this.empty, this.pane])]));
      this.bindEditor();
    }

    buildToolbar() {
      const tb = h("div", { class: "ne-toolbar" });
      const btn = (ic, title, fn, key) => {
        const b = h("button", { class: "ne-btn", title, type: "button", "data-cmd": key || "", onmousedown: (e) => e.preventDefault(), onclick: () => { if (this.mode === "rich") { this.editor.focus(); fn(); this.touch(); } } }, [icon(ic)]);
        return b;
      };
      const sep = () => h("span", { class: "ne-sep" });
      this.headingSel = h("select", { class: "ne-select", title: "Paragraph style",
        onmousedown: () => this.saveRange(),
        onchange: () => { this.restoreRange(); this.editor.focus(); this.formatBlock(this.headingSel.value); this.touch(); } },
        [["p", "Paragraph"], ["h1", "Heading 1"], ["h2", "Heading 2"], ["h3", "Heading 3"], ["h4", "Heading 4"], ["h5", "Heading 5"], ["h6", "Heading 6"]]
          .map(([v, l]) => h("option", { value: v }, l)));
      this.tableTools = h("span", { class: "ne-group hidden" }, [
        sep(),
        btn("rowAdd", "Add row below", () => this.tableOp("row+"), "tbl"),
        btn("colAdd", "Add column right", () => this.tableOp("col+"), "tbl"),
        h("button", { class: "ne-btn txt", type: "button", title: "Delete row", onmousedown: (e) => e.preventDefault(), onclick: () => { this.tableOp("row-"); this.touch(); } }, "− row"),
        h("button", { class: "ne-btn txt", type: "button", title: "Delete column", onmousedown: (e) => e.preventDefault(), onclick: () => { this.tableOp("col-"); this.touch(); } }, "− col"),
        btn("trash", "Delete table", () => this.tableOp("del"), "tbl"),
      ]);
      this.richTools = [
        btn("undo", "Undo (Ctrl+Z)", () => document.execCommand("undo")),
        btn("redo", "Redo (Ctrl+Shift+Z)", () => document.execCommand("redo")),
        sep(), this.headingSel, sep(),
        btn("bold", "Bold (Ctrl+B)", () => document.execCommand("bold"), "bold"),
        btn("italic", "Italic (Ctrl+I)", () => document.execCommand("italic"), "italic"),
        btn("strike", "Strikethrough", () => document.execCommand("strikeThrough"), "strikeThrough"),
        btn("code", "Inline code", () => this.inlineCode()),
        sep(),
        btn("link", "Link (Ctrl+K)", () => this.linkDialog()),
        btn("note", "Link to another note [[…]]", () => this.wikiPicker()),
        h("button", { class: "ne-btn", type: "button", title: "Image", onmousedown: (e) => { e.preventDefault(); this.saveRange(); }, onclick: (e) => this.imageMenu(e.currentTarget) }, [icon("image")]),
        sep(),
        btn("ul", "Bulleted list", () => document.execCommand("insertUnorderedList"), "insertUnorderedList"),
        btn("ol", "Numbered list", () => document.execCommand("insertOrderedList"), "insertOrderedList"),
        btn("task", "Task list", () => this.toggleTask()),
        btn("quote", "Quote", () => this.toggleQuote()),
        btn("codeblock", "Code block", () => this.codeBlock()),
        btn("table", "Table", () => this.insertTable()),
        btn("hr", "Horizontal rule", () => this.insertHr()),
        this.tableTools,
      ];
      this.richTools.forEach((n) => tb.appendChild(n));
      return tb;
    }

    /* ---------- tree / sidebar ---------- */
    async loadTree(keepOpen) {
      try {
        this.tree = await call("GET", `${API}/tree`);
      } catch (e) { this.toast("Could not load the notes: " + e.message); return; }
      try { this.state = await call("GET", `${API}/state`); } catch (e) { /* keep the previous lists */ }
      TREE_CACHE = { at: Date.now(), data: this.tree };
      this.renderTree();
      this.updatePinBtn();
      this.rootLabel.textContent = this.tree.exists ? this.tree.root : `Folder not found: ${this.tree.root}`;
      if (!keepOpen && !this.path) {
        const last = LS.get("notes.last", "");
        if (last && this.tree.notes.some((n) => n.path === last)) this.open(last);
      }
    }

    // A note just saved becomes the most recent of its folder: update its date in the loaded tree (shared with the cache)
    // and redraw the list only if that changes the order, keeping the scroll position.
    bumpNote(path, mtime) {
      const n = this.tree && this.tree.notes && this.tree.notes.find((x) => x.path === path);
      if (!n || !(mtime > n.mtime)) return;
      const overtaken = this.tree.notes.some((x) => x.folder === n.folder && x !== n && x.mtime > n.mtime);
      n.mtime = mtime;
      if (!overtaken) return;
      const top = this.listEl.scrollTop;
      this.renderTree();
      this.listEl.scrollTop = top;
    }

    renderTree() {
      const box = this.listEl;
      box.innerHTML = "";
      if (!this.tree.exists) {
        box.appendChild(h("div", { class: "notes-note-empty" }, "The notes folder does not exist. Set NOTES_DIR or create it."));
        return;
      }
      const q = norm(this.filter.trim());
      const byFolder = new Map();
      for (const n of this.tree.notes) {
        if (q && !norm(n.name).includes(q) && !norm(n.folder).includes(q)) continue;
        if (!byFolder.has(n.folder)) byFolder.set(n.folder, []);
        byFolder.get(n.folder).push(n);
      }
      const cmp = (a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" });
      // Notes of a folder: most recently modified first (the mtime comes with the tree: no extra request), name as tie-break.
      const recentFirst = (a, b) => (b.mtime - a.mtime) || cmp(a.name, b.name);
      const HIDDEN_FOLDERS = new Set(["media", "attachments", "assets"]);   // image stores, not notes
      const folders = new Set(this.tree.folders.filter((f) => !HIDDEN_FOLDERS.has(f.split("/").pop().toLowerCase())));
      for (const k of byFolder.keys()) folders.add(k);
      folders.delete("");
      const kids = (parent) => [...folders].filter((f) => dirOf(f) === parent).sort(cmp);
      const hasContent = (f) => !q || [...byFolder.keys()].some((k) => k === f || k.startsWith(f + "/"));
      const renderFolder = (f, depth) => {
        if (!hasContent(f)) return;
        const open = q ? true : this.opened.has(f);
        const count = (byFolder.get(f) || []).length;
        const folderRow = h("div", {
          class: "notes-folder" + (this.folderSel === f ? " sel" : ""), style: `padding-left:${8 + depth * 14}px`,
          onclick: () => {
            this.folderSel = f; LS.set("notes.folder", f);
            if (this.opened.has(f)) this.opened.delete(f); else this.opened.add(f);
            this.renderTree();
          },
        }, [h("span", { class: "nf-caret" + (open ? " open" : "") }, [icon("chevron", 12)]), icon("folder", 14), h("span", { class: "nf-name" }, f.split("/").pop()), h("span", { class: "nf-count" }, String(count || ""))]);
        this.wireFolderDrop(folderRow, f);
        box.appendChild(folderRow);
        if (open) {
          for (const sub of kids(f)) renderFolder(sub, depth + 1);
          for (const n of (byFolder.get(f) || []).sort(recentFirst)) box.appendChild(this.noteRow(n, depth + 1));
        }
      };
      if (!q) {
        const byPath = new Map(this.tree.notes.map((n) => [n.path, n]));
        const section = (label, paths) => {
          const items = paths.map((p) => byPath.get(p)).filter(Boolean);
          if (!items.length) return false;
          box.appendChild(h("div", { class: "notes-section-label" }, label));
          items.forEach((n) => box.appendChild(this.noteRow(n, 0, { showFolder: true })));
          return true;
        };
        const a = section("Épinglées", this.state.pinned || []);
        const b = section("Récents", (this.state.recent || []).slice(0, 5));
        if (a || b) box.appendChild(h("div", { class: "notes-section-label" }, "Toutes les notes"));
      }
      for (const f of kids("")) renderFolder(f, 0);
      for (const n of (byFolder.get("") || []).sort(recentFirst)) box.appendChild(this.noteRow(n, 0));
      if (!box.children.length) box.appendChild(h("div", { class: "notes-note-empty" }, q ? "No matching note" : "No notes yet"));
    }

    noteRow(n, depth, opts) {
      opts = opts || {};
      const pinned = (this.state.pinned || []).includes(n.path);
      const row = h("div", {
        class: "notes-note" + (n.path === this.path ? " active" : ""), style: `padding-left:${opts.showFolder ? 8 : 8 + depth * 14 + 14}px`, title: n.path,
        onclick: () => this.open(n.path),
      }, [icon("note", 14), h("span", { class: "nn-name" }, n.name),
        opts.showFolder && n.folder ? h("span", { class: "nn-folder" }, n.folder.split("/").pop()) : null,
        h("button", { class: "nn-pin" + (pinned ? " on" : ""), type: "button", title: pinned ? "Unpin" : "Pin to the top",
          onclick: (e) => { e.stopPropagation(); this.togglePin(n.path); } }, [icon("pin", 13)])]);
      row.setAttribute("draggable", "true");
      row.addEventListener("dragstart", (e) => this.beginNoteDrag(e, n, row));
      row.addEventListener("dragend", () => this.endNoteDrag());
      return row;
    }

    /* ---------- drag a note onto a folder (or onto the "notes folder root" bar shown while dragging) ---------- */
    beginNoteDrag(e, n, row) {
      this.dragPath = n.path;
      e.dataTransfer.effectAllowed = "move";
      try { e.dataTransfer.setData("text/plain", n.name); } catch (err) { /* ignore */ }
      row.classList.add("dragging");
      setTimeout(() => {                      // after the drag has started (changing the DOM inside dragstart can cancel it)
        if (!this.dragPath || this.listEl.querySelector(".notes-root-drop")) return;
        const bar = h("div", { class: "notes-root-drop" }, [icon("folder", 14), h("span", {}, "Notes folder (root)")]);
        this.wireFolderDrop(bar, "");
        this.listEl.appendChild(bar);          // sticky at the bottom of the list: nothing above it moves
      }, 0);
    }

    endNoteDrag() {
      this.dragPath = null;
      this.listEl.querySelectorAll(".notes-root-drop").forEach((n) => n.remove());
      this.listEl.querySelectorAll(".dragging, .drop-target").forEach((n) => n.classList.remove("dragging", "drop-target"));
    }

    wireFolderDrop(elm, folder) {
      elm.addEventListener("dragover", (e) => {
        if (!this.dragPath) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
        elm.classList.add("drop-target");
      });
      elm.addEventListener("dragleave", (e) => { if (!elm.contains(e.relatedTarget)) elm.classList.remove("drop-target"); });
      elm.addEventListener("drop", (e) => {
        if (!this.dragPath) return;
        e.preventDefault();
        const path = this.dragPath;
        this.endNoteDrag();
        this.moveNoteTo(path, folder);
      });
    }

    // Scrolls the list (smoothly) so the open note sits in the middle of it.
    revealActive() {
      requestAnimationFrame(() => {
        const box = this.listEl;
        if (!box || !box.isConnected) return;
        const rows = box.querySelectorAll(".notes-note.active");
        const row = rows[rows.length - 1];                       // the one in the folder tree, not the Pinned / Recent shortcut
        if (!row) return;
        const br = box.getBoundingClientRect(), rr = row.getBoundingClientRect();
        const top = box.scrollTop + (rr.top - br.top) - (br.height - rr.height) / 2;
        const calm = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
        box.scrollTo({ top: Math.max(0, top), behavior: calm ? "auto" : "smooth" });
      });
    }

    // unfolds a folder and its parents
    unfold(folder) {
      for (let f = folder; f; f = f.includes("/") ? f.slice(0, f.lastIndexOf("/")) : "") this.opened.add(f);
    }

    async moveNoteTo(path, folder) {
      const from = path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "";
      if (from === folder) return;
      const isOpen = this.path === path;
      if (isOpen && !(await this.flush())) return;
      try {
        const r = await call("POST", `${API}/move`, { path, folder });
        if (isOpen) {
          this.path = r.path; LS.set("notes.last", r.path);
          this.mtime = (await call("GET", `${API}/file?path=${encodeURIComponent(this.path)}`)).mtime;
        }
        if (folder) this.unfold(folder);                       // show where the note went
        await this.loadTree(true);
      } catch (err) { this.toast(err.message); }
    }

    async togglePin(path) {
      if (!path) return;
      const now = !(this.state.pinned || []).includes(path);
      try {
        const r = await call("POST", `${API}/pin`, { path, pinned: now });
        this.state.pinned = r.pinned;
        this.renderTree(); this.updatePinBtn();
      } catch (e) { this.toast("Could not pin: " + e.message); }
    }

    updatePinBtn() {
      if (!this.pinBtn) return;
      const on = !!this.path && (this.state.pinned || []).includes(this.path);
      this.pinBtn.classList.toggle("on", on);
      this.pinBtn.title = on ? "Unpin" : "Pin to the top";
    }

    // the note counts as "worked on" (Récents) once edited, or after a few seconds open
    async markWorked(path) {
      if (!path || this.destroyed) return;
      try {
        const r = await call("POST", `${API}/touch`, { path });
        this.state.recent = r.recent;
        this.renderTree();
      } catch (e) { /* the note may have just been renamed */ }
    }

    /* ---------- open / save ---------- */
    async open(path) {
      if (this.path === path) return;
      if (!(await this.flush())) return;
      let data;
      try { data = await call("GET", `${API}/file?path=${encodeURIComponent(path)}`); }
      catch (e) { this.toast("Could not open the note: " + e.message); return; }
      this.path = path;
      LS.set("notes.last", path);
      clearTimeout(this.touchTimer);
      this.touchTimer = setTimeout(() => { if (this.path === path) this.markWorked(path); }, 4000);
      this.mtime = data.mtime;
      this.load(data.content);
      this.pane.classList.remove("hidden");
      this.empty.classList.add("hidden");
      this.titleInput.value = path.split("/").pop().replace(/\.md$/i, "");
      this.setStatus("");
      this.opened.clear();                                                           // only the folder of the open note stays unfolded
      if (path.includes("/")) this.unfold(path.slice(0, path.lastIndexOf("/")));
      this.renderTree();
      this.updatePinBtn();
      this.revealActive();
      this.pane.querySelector(".note-scroll").scrollTop = 0;
    }

    load(text) {
      this.hideWarning();
      this.text = text;
      const { fm, body } = splitFrontMatter(text);
      this.fm = fm;
      this.fmArea.value = fm;
      this.fmBox.classList.toggle("hidden", !fm);
      this.lines = body.split("\n");
      this.src.value = text;
      this.modeBtn.textContent = this.mode === "rich" ? "Markdown" : "Rich text";
      this.applyModeVisibility();
      if (this.mode === "rich") this.renderRich(body);
    }

    renderRich(body) {
      const env = { notePath: this.path };
      sanitizeInto(this.editor, md().render(body, env));
      // map of original blocks
      this.blocks = {}; this.blockList = [];
      [...this.editor.children].forEach((c) => {
        const key = c.getAttribute("data-md");
        if (!key) return;
        const [start, end] = key.split(":").map(Number);
        const b = { key, idx: this.blockList.length, start, end };
        this.blocks[key] = b; this.blockList.push(b);
        c.dataset.base = blockEl(c);
      });
      if (!this.editor.children.length) this.editor.innerHTML = "<p><br></p>";
      this.editor.querySelectorAll("img").forEach((img) => {
        img.addEventListener("error", () => {
          if (img.dataset.retried) return;
          img.dataset.retried = "1";
          const s = img.getAttribute("data-src") || "";
          if (s && !/^([a-z]+:|\/\/|\/|data:)/i.test(s)) img.src = `${API}/asset?path=${encodeURIComponent(resolveRel("", decodeURI(s)))}`;
        });
      });
    }

    // Current content as Markdown text (front matter + body).
    build_markdown() {
      if (this.mode === "md") return this.src.value;
      const fm = this.fmBox.classList.contains("hidden") ? this.fm : this.fmArea.value;
      const items = [];
      const seen = new Set();
      let run = [];
      const flushRun = () => {
        if (!run.length) return;
        const s = blocksOf(run);
        run = [];
        if (s) items.push({ idx: null, text: s });
      };
      for (const n of this.editor.childNodes) {
        if (n.nodeType === 1 && (BLOCK_TAGS.has(n.tagName))) {
          flushRun();
          const key = n.getAttribute("data-md");
          const meta = key && !seen.has(key) ? this.blocks[key] : null;
          if (key) seen.add(key);
          const cur = blockEl(n);
          if (meta && cur === n.dataset.base) {
            items.push({ idx: meta.idx, text: this.lines.slice(meta.start, meta.end).join("\n"), src: true });
          } else if (cur !== "") {
            items.push({ idx: meta ? meta.idx : null, text: cur });
          }
        } else if (n.nodeType === 3 || n.nodeType === 1) {
          run.push(n);
        }
      }
      flushRun();
      let body;
      if (!this.blockList.length) {
        body = items.length ? items.map((i) => i.text).join("\n\n") + "\n" : this.lines.join("\n");
      } else {
        const first = this.blockList[0], last = this.blockList[this.blockList.length - 1];
        const lead = this.lines.slice(0, first.start);
        const tail = this.lines.slice(last.end);
        body = lead.length ? lead.join("\n") + "\n" : "";
        items.forEach((it, i) => {
          if (i > 0) {
            const prev = items[i - 1];
            if (prev.idx !== null && it.idx !== null && it.idx === prev.idx + 1) {
              const gap = this.lines.slice(this.blockList[prev.idx].end, this.blockList[it.idx].start);
              // Adjacent original blocks: put back the lines that sat between them. A list's source range ends AFTER its
              // trailing blank line, so when that list was edited (re-serialized) the blank line is gone with it: without
              // one, the next paragraph / table would be glued to the last bullet when the note is reopened.
              if (gap.length) body += "\n" + gap.join("\n") + "\n";
              else if (prev.src && it.src) body += "\n";
              else body += /\n$/.test(prev.text) ? "\n" : "\n\n";
            } else body += "\n\n";
          }
          body += it.text;
        });
        body += tail.length ? "\n" + tail.join("\n") : "";
        if (!items.length) body = lead.join("\n") + (tail.length ? "\n" + tail.join("\n") : "");
      }
      // an edited front-matter box that lost its last line break would glue "---" to the first line of the note
      return (fm && body && !/\n$/.test(fm) ? fm + "\n" : fm) + body;
    }

    isDirty() {
      if (!this.path) return false;
      try { return this.build_markdown() !== this.text; } catch (e) { return false; }
    }

    setZoom(z) {
      this.zoom = Math.min(2, Math.max(0.7, Math.round(z * 10) / 10));
      LS.set("notes.zoom", String(this.zoom));
      this.applyZoom();
    }
    applyZoom() {
      this.pane.style.setProperty("--ne-scale", String(this.zoom));
      this.zoomLabel.textContent = Math.round(this.zoom * 100) + "%";
    }
    updateCount() {
      if (!this.countEl) return;
      const rich = this.mode === "rich";
      const all = rich ? (this.editor.innerText || "") : this.src.value;
      const n = (t) => (t.match(/\S/gu) || []).length;
      let txt = n(all).toLocaleString("fr-FR") + " caractères (sans espaces)";
      let sel = "";
      if (rich) { const s = window.getSelection(); if (s && !s.isCollapsed && this.editor.contains(s.anchorNode)) sel = s.toString(); }
      else if (this.src.selectionEnd > this.src.selectionStart) sel = this.src.value.slice(this.src.selectionStart, this.src.selectionEnd);
      if (sel && n(sel)) txt += " · sélection : " + n(sel).toLocaleString("fr-FR");
      this.countEl.textContent = txt;
    }
    touch() {
      this.updateCount();
      if (!this.path) return;
      clearTimeout(this.timer);
      this.setStatus("Editing…");
      this.timer = setTimeout(() => { if (this.isDirty()) this.save(); else this.setStatus(""); }, 1400);
      this.updateToolbarState();
    }

    setStatus(t) { this.statusEl.textContent = t; }

    // Compares what the person sees with what `content` would show once reopened. null = identical; otherwise how much text
    // would be lost. Every serializer bug that used to eat text silently (sub-bullets, table cells...) ends up here.
    verify(content) {
      if (this.mode !== "rich") return null;
      const tmp = document.createElement("div");
      sanitizeInto(tmp, md().render(splitFrontMatter(content).body, { noMap: true, notePath: this.path }));
      const a = textSig(this.editor), b = textSig(tmp);
      if (a !== b) {
        let i = 0; while (i < a.length && i < b.length && a[i] === b[i]) i++;
        return { missing: Math.max(0, a.length - b.length), at: a.slice(Math.max(0, i - 15), i + 40) };
      }
      // same text: also the things that carry no text (checkboxes and their state, pictures, links, table rows, bullets)
      const x = structSig(this.editor), y = structSig(tmp);
      if (x !== y) return { missing: 0, at: `${x} → ${y}`.slice(0, 60) };
      return null;
    }

    hideWarning() { this.rtBlocked = false; this.warnText = null; if (this.warnEl) { this.warnEl.classList.add("hidden"); this.warnEl.innerHTML = ""; } }

    showWarning(info) {
      this.rtBlocked = true;
      const what = info.missing ? `about ${info.missing} characters` : "some text";
      const msg = `⚠ Not saved: this note contains something the editor can't write back to Markdown without losing ${what}` + (info.at ? ` (near “${info.at.slice(0, 40)}”)` : "") + ". Everything is still on screen; the file on disk is untouched.";
      this.setStatus("⚠ Not saved");
      // already showing: only refresh the text - rebuilding the buttons while the mouse is going down on one (the click
      // first blurs the editor, which saves, which lands here) would make the click miss
      if (!this.warnEl.classList.contains("hidden") && this.warnText) { this.warnText.textContent = msg; return; }
      this.warnEl.innerHTML = "";
      this.warnEl.classList.remove("hidden");
      this.warnText = h("div", { class: "note-warn-text" }, msg);
      this.warnEl.append(this.warnText,
        h("div", { class: "note-warn-actions" }, [
          h("button", { class: "ne-btn txt", type: "button", onclick: () => this.saveRecoveryCopy() }, "Save the text as a new note"),
          h("button", { class: "ne-btn txt", type: "button", onclick: () => { this.save(true, true); } }, "Save anyway"),
        ]));
    }

    async saveRecoveryCopy(quiet) {
      const text = outlineText(this.editor);
      if (!text.trim()) return null;
      const folder = this.path.includes("/") ? this.path.slice(0, this.path.lastIndexOf("/")) : "";
      try {
        const r = await call("POST", `${API}/new`, { folder, name: `${this.titleInput.value || "Note"} (recovered text)`, content: text + "\n" });
        this.toast(`Text saved as “${r.name}”`);
        this.loadTree(true);
        return r.path;
      } catch (e) { if (!quiet) this.toast("Could not save the copy: " + e.message); return null; }
    }

    async save(manual, force) {
      if (!this.path) return true;
      if (this.saving) { try { await this.saving; } catch (e) {} }
      clearTimeout(this.timer);
      let content;
      try { content = this.build_markdown(); }
      catch (e) { this.setStatus("⚠ Not saved"); this.toast("Could not prepare the note for saving: " + e.message); return false; }
      if (content === this.text) { if (manual) this.setStatus("Saved"); this.hideWarning(); return true; }
      if (!force) {
        const bad = this.verify(content);
        if (bad) { this.showWarning(bad); return false; }
      }
      this.hideWarning();
      const path = this.path;
      this.setStatus("Saving…");
      const p = (async () => {
        try {
          const r = await call("PUT", `${API}/file`, { path, content, mtime: this.mtime });
          this.mtime = r.mtime; this.text = content; this.bumpNote(path, r.mtime);
          if (this.mode === "md") { /* source mode: keep structures in sync lazily */ }
          this.setStatus("Saved");
          this.markWorked(path);
          return true;
        } catch (e) {
          if (e.status === 409) {
            const choice = await this.confirm({
              title: "This note changed on disk", message: "It was modified outside the editor (another app or a sync).",
              confirmLabel: "Continue", choices: [
                { label: "Keep my version (overwrite the file)", value: "mine" },
                { label: "Load the version on disk (discard my edits)", value: "disk" }],
            });
            if (choice === "mine") {
              const r = await call("PUT", `${API}/file`, { path, content, force: true });
              this.mtime = r.mtime; this.text = content; this.bumpNote(path, r.mtime); this.setStatus("Saved");
              return true;
            }
            if (choice === "disk") { await this.reloadFromDisk(); return true; }
            this.setStatus("Not saved");
            return false;
          }
          this.setStatus("Save failed");
          this.toast("Could not save: " + e.message);
          return false;
        }
      })();
      this.saving = p;
      const ok = await p;
      this.saving = null;
      return ok;
    }

    async flush() {
      if (!this.path) return true;
      if (this.isDirty()) return this.save();
      return true;
    }

    async reloadFromDisk() {
      if (!this.path) return;
      const data = await call("GET", `${API}/file?path=${encodeURIComponent(this.path)}`);
      this.mtime = data.mtime;
      const top = this.pane.querySelector(".note-scroll").scrollTop;
      this.load(data.content);
      this.pane.querySelector(".note-scroll").scrollTop = top;
      this.setStatus("Reloaded");
    }

    // polling: detects navigation away (flush), and outside changes
    async tick() {
      if (this.destroyed) return;
      if (!this.root.isConnected) { await this.destroy(); return; }
    }

    async destroy() {
      if (this.destroyed) return;
      this.destroyed = true;
      clearInterval(this.watch);
      clearTimeout(this.timer);
      clearTimeout(this.touchTimer);
      document.removeEventListener("selectionchange", this._sel);
      window.removeEventListener("focus", this._focus);
      window.removeEventListener("beforeunload", this._unload);
      const ok = await this.flush();
      if (!ok && this.rtBlocked) await this.saveRecoveryCopy(true);      // leaving a note that could not be saved: keep its text
    }

    async checkDisk() {
      if (!this.path || this.destroyed) return;
      try {
        const data = await call("GET", `${API}/file?path=${encodeURIComponent(this.path)}`);
        if (data.mtime !== this.mtime && !this.isDirty()) await this.reloadFromDisk();
      } catch (e) { /* file removed or server restarting */ }
      this.loadTree(true);
    }

    /* ---------- note actions ---------- */
    async newNote(folder) {
      const f = folder !== undefined ? folder : this.folderSel;
      const name = await this.prompt({ title: "New note", message: f ? `In “${f}”` : "In the notes folder", value: "", confirmLabel: "Create" });
      if (!name || !name.trim()) return;
      const isScript = f.split("/")[0].toLowerCase() === "scripts";
      try {
        const r = await call("POST", `${API}/new`, { folder: f, name: name.trim(), content: isScript ? "## Titles\n\n## Timestamps\n\n## Content\n\n" : "" });
        await this.loadTree(true);
        await this.open(r.path);
        this.editor.focus();
      } catch (e) { this.toast("Could not create the note: " + e.message); }
    }

    async newFolder() {
      const name = await this.prompt({ title: "New folder", message: this.folderSel ? `Inside “${this.folderSel}”` : "At the root of the notes folder", value: "", confirmLabel: "Create" });
      if (!name || !name.trim()) return;
      try {
        const r = await call("POST", `${API}/folder`, { parent: this.folderSel, name: name.trim() });
        this.folderSel = r.path; LS.set("notes.folder", r.path);
        await this.loadTree(true);
      } catch (e) { this.toast("Could not create the folder: " + e.message); }
    }

    async rename(name) {
      name = (name || "").trim();
      const cur = this.path.split("/").pop().replace(/\.md$/i, "");
      if (!name || name === cur) { this.titleInput.value = cur; return; }
      if (!(await this.flush())) return;
      try {
        const r = await call("POST", `${API}/rename`, { path: this.path, name });
        this.path = r.path; LS.set("notes.last", r.path);
        this.titleInput.value = r.name;
        const data = await call("GET", `${API}/file?path=${encodeURIComponent(this.path)}`);
        this.mtime = data.mtime;
        await this.loadTree(true);
      } catch (e) { this.toast(e.message); this.titleInput.value = cur; }
    }

    noteMenu(anchor) {
      this.popover(anchor, [
        { label: (this.state.pinned || []).includes(this.path) ? "Unpin" : "Pin to the top", run: () => this.togglePin(this.path) },
        { label: "Rename", run: () => { this.titleInput.focus(); this.titleInput.select(); } },
        { label: "Move to folder…", run: () => this.moveDialog() },
        { label: "Copy file path", run: () => { const p = this.tree.root.replace(/\/$/, "") + "/" + this.path; (navigator.clipboard ? navigator.clipboard.writeText(p) : Promise.reject()).then(() => this.toast("Path copied"), () => this.toast(p)); } },
        { label: "Delete note", danger: true, run: () => this.deleteNote() },
      ]);
    }

    async moveDialog() {
      const folders = ["", ...this.tree.folders];
      const choice = await this.confirm({
        title: "Move note", message: "Choose the destination folder", confirmLabel: "Move",
        choices: folders.map((f) => ({ label: f || "(notes folder root)", value: f })),
      });
      if (choice === false || choice === null || choice === undefined) return;
      if (!(await this.flush())) return;
      try {
        const r = await call("POST", `${API}/move`, { path: this.path, folder: choice });
        this.path = r.path; LS.set("notes.last", r.path);
        this.mtime = (await call("GET", `${API}/file?path=${encodeURIComponent(this.path)}`)).mtime;
        await this.loadTree(true);
      } catch (e) { this.toast(e.message); }
    }

    async deleteNote() {
      const ok = await this.confirm({ title: "Delete this note?", message: `“${this.titleInput.value}” will be moved to the .trash folder inside your notes folder.`, confirmLabel: "Delete", danger: true });
      if (!ok) return;
      try {
        await call("DELETE", `${API}/file?path=${encodeURIComponent(this.path)}`);
        this.path = null; this.text = ""; LS.set("notes.last", "");
        this.pane.classList.add("hidden"); this.empty.classList.remove("hidden");
        await this.loadTree(true);
      } catch (e) { this.toast("Could not delete: " + e.message); }
    }

    popover(anchor, items) {
      if (window.DS && DS.menu) return DS.menu(anchor, items, { align: "right", minWidth: 200 });   // style du design system
      document.querySelectorAll(".ne-pop").forEach((p) => p.remove());
      const r = anchor.getBoundingClientRect();
      const pop = h("div", { class: "ne-pop", style: `top:${r.bottom + 4}px;left:${Math.max(8, r.right - 200)}px` },
        items.map((it) => h("button", { class: "ne-pop-item" + (it.danger ? " danger" : ""), type: "button",
          onclick: () => { pop.remove(); it.run(); } }, it.label)));
      document.body.appendChild(pop);
      const away = (e) => { if (!pop.contains(e.target)) { pop.remove(); document.removeEventListener("mousedown", away, true); } };
      setTimeout(() => document.addEventListener("mousedown", away, true), 0);
      return pop;
    }

    /* ---------- modes ---------- */
    applyModeVisibility() {
      const rich = this.mode === "rich";
      this.editor.classList.toggle("hidden", !rich);
      this.src.classList.toggle("hidden", rich);
      this.toolbar.classList.toggle("disabled", !rich);
      this.fmBox.classList.toggle("hidden", !rich || !this.fm);
      this.modeBtn.textContent = rich ? "Markdown" : "Rich text";
      this.updateCount();
    }

    prompter() {
      if (!this.path) return;
      openPrompter(this.build_markdown(), this.path, this.titleInput.value);
    }

    async setMode(mode) {
      if (mode === this.mode) return;
      if (this.path) {
        const content = this.build_markdown();             // from the mode we are leaving
        const bad = mode === "md" ? this.verify(content) : null;
        if (bad && !(await this.confirm({ title: "Some text would be lost", message: `The Markdown view cannot show about ${bad.missing || "some"} characters of this note (near “${bad.at.slice(0, 40)}”). Switch anyway?`, confirmLabel: "Switch anyway", danger: true }))) return;
        this.mode = mode;
        LS.set("notes.mode", mode);
        if (mode === "md") {
          this.src.value = content;
          this.applyModeVisibility();
          this.src.focus();
        } else {
          // re-parse the raw text the person edited
          const prevText = this.text;
          this.text = prevText;                              // disk version stays the baseline
          const { fm, body } = splitFrontMatter(content);
          this.fm = fm; this.fmArea.value = fm;
          this.lines = body.split("\n");
          this.applyModeVisibility();
          this.renderRich(body);
          // baseline for block comparison is the *edited* text: dirty if it differs from disk
          this.touch();
        }
      } else {
        this.mode = mode; LS.set("notes.mode", mode); this.applyModeVisibility();
      }
    }

    /* ---------- editor commands ---------- */
    saveRange() { const s = getSelection(); this._range = s.rangeCount ? s.getRangeAt(0).cloneRange() : null; }
    restoreRange() {
      if (!this._range) return;
      const s = getSelection(); s.removeAllRanges(); s.addRange(this._range);
    }
    inEditor(node) { return node && this.editor.contains(node); }
    closest(sel) {
      const s = getSelection();
      if (!s.rangeCount) return null;
      let n = s.anchorNode;
      if (n && n.nodeType === 3) n = n.parentNode;
      if (!this.inEditor(n)) return null;
      return n.closest(sel);
    }

    formatBlock(tag) {
      const inPre = this.closest("pre");
      if (inPre && tag !== "pre") {
        const text = inPre.textContent.replace(/\n$/, "");
        const p = document.createElement(tag === "p" ? "p" : tag);
        p.textContent = text || "";
        if (!text) p.innerHTML = "<br>";
        inPre.replaceWith(p);
        const r = document.createRange(); r.selectNodeContents(p); r.collapse(false);
        const s = getSelection(); s.removeAllRanges(); s.addRange(r);
        return;
      }
      document.execCommand("formatBlock", false, tag);
    }

    inlineCode() {
      const code = this.closest("code");
      if (code && !code.closest("pre")) {
        const t = document.createTextNode(code.textContent);
        code.replaceWith(t);
        return;
      }
      const sel = getSelection();
      const text = sel.toString() || "code";
      document.execCommand("insertHTML", false, `<code>${escHtml(text)}</code>&#8203;`);
    }

    toggleQuote() {
      if (this.closest("blockquote")) document.execCommand("outdent");
      else document.execCommand("formatBlock", false, "blockquote");
    }

    toggleTask() {
      let li = this.closest("li");
      if (!li) { document.execCommand("insertUnorderedList"); li = this.closest("li"); }
      if (!li) return;
      const list = li.parentElement;
      const items = list ? [...list.children].filter((c) => c.tagName === "LI") : [li];
      const sel = getSelection();
      const targets = items.filter((it) => sel.containsNode(it, true) || it === li);
      const want = !(li.querySelector(":scope > input.task-cb"));
      for (const it of targets) {
        const cb = it.querySelector(":scope > input.task-cb");
        if (want && !cb) {
          const c = document.createElement("input"); c.type = "checkbox"; c.className = "task-cb";
          it.insertBefore(document.createTextNode(" "), it.firstChild);
          it.insertBefore(c, it.firstChild);
          it.classList.add("task-item");
        } else if (!want && cb) {
          cb.nextSibling && cb.nextSibling.nodeType === 3 && (cb.nextSibling.nodeValue = cb.nextSibling.nodeValue.replace(/^\s/, ""));
          cb.remove(); it.classList.remove("task-item");
        }
      }
    }

    codeBlock() {
      const pre = this.closest("pre");
      if (pre) { this.formatBlock("p"); return; }
      const sel = getSelection();
      let text = sel.toString();
      if (!text) { const b = this.closest("p,h1,h2,h3,h4,h5,h6,div"); text = b && b !== this.editor ? b.textContent : ""; if (b && b !== this.editor && !sel.toString()) { const r = document.createRange(); r.selectNodeContents(b); sel.removeAllRanges(); sel.addRange(r); } }
      document.execCommand("insertHTML", false, `<pre><code>${escHtml(text || "")}${text ? "" : "<br>"}</code></pre><p><br></p>`);
    }

    insertHr() {
      document.execCommand("insertHTML", false, "<hr><p><br></p>");
    }

    insertTable() {
      const cell = (t, tag) => `<${tag}><br></${tag}>`;
      const head = `<tr>${[1, 2, 3].map(() => cell("", "th")).join("")}</tr>`;
      const row = `<tr>${[1, 2, 3].map(() => cell("", "td")).join("")}</tr>`;
      document.execCommand("insertHTML", false, `<table><thead>${head}</thead><tbody>${row}${row}</tbody></table><p><br></p>`);
      const t = this.editor.querySelector("table:not([data-md]) th, table:not([data-md]) td");
      const last = [...this.editor.querySelectorAll("table")].find((x) => !x.hasAttribute("data-md"));
      const c = last && last.querySelector("th");
      if (c) { const r = document.createRange(); r.selectNodeContents(c); r.collapse(true); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }
    }

    tableOp(op) {
      const cell = this.closest("td,th");
      const table = this.closest("table");
      if (!cell || !table) return;
      const row = cell.parentElement;
      const col = [...row.children].indexOf(cell);
      const mk = (tag) => { const c = document.createElement(tag); c.innerHTML = "<br>"; return c; };
      if (op === "row+") {
        const nr = document.createElement("tr");
        [...row.children].forEach(() => nr.appendChild(mk("td")));
        const body = row.parentElement.tagName === "THEAD" ? (table.tBodies[0] || table.appendChild(document.createElement("tbody"))) : row.parentElement;
        if (row.parentElement.tagName === "THEAD") body.insertBefore(nr, body.firstChild); else row.after(nr);
      } else if (op === "col+") {
        table.querySelectorAll("tr").forEach((r) => { const ref = r.children[col]; const c = mk(r.parentElement.tagName === "THEAD" || (ref && ref.tagName === "TH") ? "th" : "td"); if (ref) ref.after(c); else r.appendChild(c); });
      } else if (op === "row-") {
        if (table.querySelectorAll("tr").length <= 1) { table.remove(); return; }
        if (row.parentElement.tagName === "THEAD") { const nx = table.tBodies[0] && table.tBodies[0].rows[0]; if (nx) [...nx.children].forEach((c) => { const th = mk("th"); th.innerHTML = c.innerHTML; c.replaceWith(th); row.parentElement.appendChild(nx); }); }
        row.remove();
      } else if (op === "col-") {
        if (row.children.length <= 1) { table.remove(); return; }
        table.querySelectorAll("tr").forEach((r) => r.children[col] && r.children[col].remove());
      } else if (op === "del") { table.remove(); }
      if (!this.editor.lastElementChild || this.editor.lastElementChild.tagName === "TABLE") this.editor.appendChild(Object.assign(document.createElement("p"), { innerHTML: "<br>" }));
    }

    async linkDialog() {
      this.saveRange();
      const a = this.closest("a:not(.wikilink)");
      const cur = a ? a.getAttribute("href") : "";
      const url = await this.prompt({ title: a ? "Edit link" : "Insert link", message: "Address (URL). Leave empty to remove the link.", value: cur || "https://", confirmLabel: "OK" });
      if (url === null || url === false) return;
      this.editor.focus(); this.restoreRange();
      const v = url.trim();
      if (!v || v === "https://") { if (a) document.execCommand("unlink"); this.touch(); return; }
      if (getSelection().isCollapsed && !a) document.execCommand("insertHTML", false, `<a href="${escHtml(v)}">${escHtml(v)}</a>`);
      else if (a) a.setAttribute("href", v);
      else document.execCommand("createLink", false, v);
      this.touch();
    }

    wikiPicker() {
      this.saveRange();
      const overlay = h("div", { class: "sheet-overlay open" });
      const input = h("input", { type: "text", class: "sheet-input", placeholder: "Find a note…" });
      const list = h("div", { class: "ne-wiki-list" });
      const close = () => { overlay.remove(); this.editor.focus(); this.restoreRange(); };
      const paint = () => {
        list.innerHTML = "";
        const q = norm(input.value);
        const res = this.tree.notes.filter((n) => !q || norm(n.name).includes(q)).slice(0, 40);
        res.forEach((n) => list.appendChild(h("button", { type: "button", class: "ne-pop-item", onclick: () => {
          close();
          document.execCommand("insertHTML", false, `<a class="wikilink" data-wiki="${escHtml(n.name)}">${escHtml(n.name)}</a>&nbsp;`);
          this.touch();
        } }, [n.name, n.folder ? h("span", { class: "muted" }, "  " + n.folder) : null])));
        if (!res.length) list.appendChild(h("div", { class: "muted", style: "padding:8px" }, "No matching note"));
      };
      input.addEventListener("input", paint);
      input.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); else if (e.key === "Enter") { const f = list.querySelector("button"); if (f) f.click(); } });
      overlay.addEventListener("mousedown", (e) => { if (e.target === overlay) close(); });
      overlay.appendChild(h("div", { class: "sheet" }, [h("div", { class: "sheet-text" }, [h("div", { class: "sheet-title" }, "Link to a note"), input, list])]));
      document.body.appendChild(overlay);
      paint(); input.focus();
    }

    imageMenu(anchor) {
      this.popover(anchor, [
        { label: "Upload image…", run: () => this.pickImage() },
        { label: "From a URL or path…", run: () => this.imageFromUrl() },
      ]);
    }
    pickImage() {
      const inp = h("input", { type: "file", accept: "image/*", multiple: "multiple", style: "display:none" });
      inp.addEventListener("change", async () => { for (const f of inp.files) await this.insertImageFile(f); inp.remove(); });
      document.body.appendChild(inp); inp.click();
    }
    async imageFromUrl() {
      const url = await this.prompt({ title: "Insert image", message: "Image URL, or path relative to this note", value: "", confirmLabel: "Insert" });
      if (!url || !url.trim()) return;
      this.editor.focus(); this.restoreRange();
      this.insertImage(url.trim(), "");
    }
    async insertImageFile(file) {
      try {
        const fd = new FormData(); fd.append("file", file, file.name || "image.png");
        const r = await call("POST", `${API}/media`, fd);
        this.editor.focus(); this.restoreRange();
        this.insertImage(relativeTo(this.path, r.path), (file.name || "").replace(/\.[^.]+$/, ""));
      } catch (e) { this.toast("Could not add the image: " + e.message); }
    }
    insertImage(src, alt) {
      let display = src;
      if (!/^([a-z]+:|\/\/|\/|data:)/i.test(src)) display = `${API}/asset?path=${encodeURIComponent(resolveRel(this.path || "", src))}`;
      document.execCommand("insertHTML", false, `<img src="${escHtml(display)}" data-src="${escHtml(src)}" alt="${escHtml(alt || "")}">`);
      this.touch();
    }

    /* ---------- editor events ---------- */
    bindEditor() {
      const ed = this.editor;
      try { document.execCommand("defaultParagraphSeparator", false, "p"); document.execCommand("styleWithCSS", false, false); } catch (e) {}
      ed.addEventListener("input", (e) => { this.normalizeRoot(); this.autoFormat(e); this.autoLink(e); this.touch(); });
      ed.addEventListener("change", () => this.touch());
      ed.addEventListener("click", (e) => this.onClick(e));
      ed.addEventListener("keydown", (e) => this.onKey(e));
      ed.addEventListener("paste", (e) => this.onPaste(e));
      ed.addEventListener("copy", (e) => this.onCopy(e, false));
      ed.addEventListener("cut", (e) => this.onCopy(e, true));
      ed.addEventListener("drop", (e) => this.onDrop(e));
      ed.addEventListener("blur", () => { if (this.isDirty()) this.save(); });
      this.src.addEventListener("blur", () => { if (this.isDirty()) this.save(); });
      this.src.addEventListener("keydown", (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") { e.preventDefault(); this.save(true); }
        if (e.key === "Tab") { e.preventDefault(); const s = this.src, a = s.selectionStart; s.setRangeText("  ", a, s.selectionEnd, "end"); this.touch(); }
      });
      this._sel = () => { if (this.mode === "rich" && this.root.isConnected) this.updateToolbarState(); };
      document.addEventListener("selectionchange", this._sel);
      this._focus = () => this.checkDisk();
      window.addEventListener("focus", this._focus);
      this._unload = () => {
        try {
          if (!this.isDirty()) return;
          const content = this.build_markdown();
          if (this.verify(content)) return;                  // would lose text: the file on disk stays as it is
          fetch(`${API}/file`, { method: "PUT", keepalive: true, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ path: this.path, content, mtime: this.mtime }) });
        } catch (e) { /* closing anyway */ }
      };
      window.addEventListener("beforeunload", this._unload);
    }

    updateToolbarState() {
      if (this.mode !== "rich") return;
      const s = getSelection();
      const inside = s.rangeCount && this.inEditor(s.anchorNode);
      this.tableTools.classList.toggle("hidden", !(inside && this.closest("table")));
      if (!inside) return;
      const blk = this.closest("h1,h2,h3,h4,h5,h6");
      this.headingSel.value = blk ? blk.tagName.toLowerCase() : "p";
      this.toolbar.querySelectorAll("[data-cmd]").forEach((b) => {
        const c = b.getAttribute("data-cmd");
        if (!c || c === "tbl") return;
        let on = false; try { on = document.queryCommandState(c); } catch (e) {}
        b.classList.toggle("on", !!on);
      });
    }

    onClick(e) {
      const a = e.target.closest && e.target.closest("a");
      if (a && this.editor.contains(a)) {
        if (a.classList.contains("wikilink")) { e.preventDefault(); this.openWiki(a.getAttribute("data-wiki")); return; }
        // a plain click opens the link (Alt+click puts the caret inside it instead; dragging to select doesn't open it)
        const sel = getSelection();
        if (!e.altKey && (e.ctrlKey || e.metaKey || !sel || sel.isCollapsed)) {
          e.preventDefault();
          const href = a.getAttribute("href");
          if (href) window.open(href, "_blank", "noopener");
          return;
        }
      }
      if (e.target.classList && e.target.classList.contains("task-cb")) setTimeout(() => this.touch(), 0);
    }

    async openWiki(name) {
      const want = norm(name.replace(/\.md$/i, "").split("/").pop());
      const hit = this.tree.notes.find((n) => norm(n.name) === want) || this.tree.notes.find((n) => norm(n.path.replace(/\.md$/i, "")) === norm(name));
      if (hit) { await this.open(hit.path); return; }
      const ok = await this.confirm({ title: "Note not found", message: `There is no note called “${name}”. Create it?`, confirmLabel: "Create" });
      if (!ok) return;
      try {
        const r = await call("POST", `${API}/new`, { folder: this.folderSel, name, content: "" });
        await this.loadTree(true); await this.open(r.path);
      } catch (err) { this.toast(err.message); }
    }

    onKey(e) {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "s") { e.preventDefault(); this.save(true); return; }
      if (mod && e.key.toLowerCase() === "k") { e.preventDefault(); this.linkDialog(); return; }
      if (mod && e.shiftKey && e.key.toLowerCase() === "x") { e.preventDefault(); document.execCommand("strikeThrough"); this.touch(); return; }
      if (mod && e.key.toLowerCase() === "e") { e.preventDefault(); this.inlineCode(); this.touch(); return; }
      const li = this.closest("li");
      if (e.key === "Tab") {
        e.preventDefault();
        if (li) { document.execCommand(e.shiftKey ? "outdent" : "indent"); this.touch(); }
        else if (this.closest("pre")) document.execCommand("insertText", false, "  ");
        else if (this.closest("td,th")) this.moveCell(e.shiftKey ? -1 : 1);
        return;
      }
      if (e.key === "Enter" && !e.shiftKey && !mod) {
        if (li && li.classList.contains("task-item")) {
          const rest = [...li.childNodes].filter((n) => !(n.nodeType === 1 && n.tagName === "INPUT")).map((n) => n.textContent).join("").replace(/\u200b/g, "").trim();
          if (!rest) {
            e.preventDefault();
            const cb = li.querySelector(":scope > input.task-cb"); if (cb) cb.remove();
            li.classList.remove("task-item");
            li.innerHTML = "<br>";
            const r = document.createRange(); r.setStart(li, 0); r.collapse(true); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
            document.execCommand("outdent");
            this.touch(); return;
          }
        }
        const qp = this.closest("blockquote p, blockquote div");
        if (qp && !qp.textContent.replace(/\u200b/g, "").trim()) {
          e.preventDefault();
          document.execCommand("outdent");
          this.touch(); return;
        }
        const pre = this.closest("pre");
        if (pre) {
          // Enter on an empty last line leaves the code block
          const t = pre.textContent;
          const s = getSelection();
          const r = s.getRangeAt(0);
          const atEnd = (() => { const x = document.createRange(); x.selectNodeContents(pre); x.setStart(r.endContainer, r.endOffset); return x.toString().replace(/\n$/, "") === ""; })();
          if (atEnd && /\n$/.test(t.replace(/​/g, ""))) {
            e.preventDefault();
            const code = pre.querySelector("code") || pre;
            code.textContent = t.replace(/\n+$/, "");
            if (!code.textContent) code.appendChild(document.createElement("br"));
            const p = document.createElement("p"); p.innerHTML = "<br>";
            pre.after(p);
            const nr = document.createRange(); nr.setStart(p, 0); nr.collapse(true); s.removeAllRanges(); s.addRange(nr);
            this.touch();
          } else { e.preventDefault(); this.newlineInPre(pre); this.touch(); }
          return;
        }
        const blk = this.closest("p,div");
        if (blk && blk !== this.editor && !this.closest("li,td,th,blockquote")) {
          const txt = blk.textContent.replace(/​/g, "").trim();
          if (/^```[\w+#.-]*$/.test(txt)) {
            e.preventDefault();
            const lang = txt.slice(3);
            blk.outerHTML = `<pre><code${lang ? ` class="language-${escHtml(lang)}"` : ""}><br></code></pre>`;
            const code = this.editor.querySelector("pre:not([data-md]) code:last-child") || null;
            const all = [...this.editor.querySelectorAll("pre")]; const target = all.find((x) => !x.hasAttribute("data-md") && x.textContent === "") || all[all.length - 1];
            if (target) { const nr = document.createRange(); nr.selectNodeContents(target.querySelector("code")); nr.collapse(true); const s = getSelection(); s.removeAllRanges(); s.addRange(nr); }
            this.touch(); return;
          }
          if (/^(---|\*\*\*|___)$/.test(txt)) {
            e.preventDefault();
            blk.outerHTML = "<hr><p><br></p>";
            const hrs = [...this.editor.querySelectorAll("hr")]; const hr = hrs.find((x) => !x.hasAttribute("data-md")) || hrs[hrs.length - 1];
            const p = hr && hr.nextElementSibling;
            if (p) { const nr = document.createRange(); nr.setStart(p, 0); nr.collapse(true); const s = getSelection(); s.removeAllRanges(); s.addRange(nr); }
            this.touch(); return;
          }
        }
      }
      if (e.key === "Backspace") {
        // at the start of an empty task item: drop the checkbox first
        if (li && li.querySelector(":scope > input.task-cb")) {
          const s = getSelection();
          if (s.isCollapsed && s.anchorOffset <= 1) {
            const before = document.createRange(); before.selectNodeContents(li); before.setEnd(s.anchorNode, s.anchorOffset);
            if (before.toString().trim() === "") { e.preventDefault(); const cb = li.querySelector(":scope > input.task-cb"); cb.remove(); li.classList.remove("task-item"); this.touch(); }
          }
        }
      }
    }

    // Wraps loose text/inline nodes sitting directly in the editor into <p>
    // (list/quote outdent can leave them bare), keeping the caret.
    normalizeRoot() {
      const ed = this.editor;
      const loose = [...ed.childNodes].some((n) => (n.nodeType === 3 && n.nodeValue.trim()) || (n.nodeType === 1 && !BLOCK_TAGS.has(n.tagName) && n.tagName !== "BR"));
      const brRoot = [...ed.childNodes].some((n) => n.nodeType === 1 && n.tagName === "BR");
      if (!loose && !brRoot) return;
      const sel = getSelection();
      const keep = sel.rangeCount && this.inEditor(sel.anchorNode) ? { n: sel.anchorNode, o: sel.anchorOffset } : null;
      let run = [];
      const flush = (before) => {
        if (!run.length) return;
        const p = document.createElement("p");
        ed.insertBefore(p, before);
        run.forEach((x) => p.appendChild(x));
        run = [];
      };
      for (const n of [...ed.childNodes]) {
        const isBlock = n.nodeType === 1 && BLOCK_TAGS.has(n.tagName);
        if (isBlock) { flush(n); continue; }
        if (n.nodeType === 3 && !n.nodeValue.trim() && !run.length) continue;
        run.push(n);
      }
      flush(null);
      if (keep) {
        try { const r = document.createRange(); r.setStart(keep.n, keep.o); r.collapse(true); sel.removeAllRanges(); sel.addRange(r); } catch (e) {}
      }
    }

    newlineInPre(pre) {
      const s = getSelection();
      const r = s.getRangeAt(0);
      r.deleteContents();
      const nl = document.createTextNode("\n");
      r.insertNode(nl);
      const code = pre.querySelector("code") || pre;
      if (!code.lastChild || code.lastChild.nodeName !== "BR") code.appendChild(document.createElement("br"));
      r.setStartAfter(nl); r.collapse(true);
      s.removeAllRanges(); s.addRange(r);
    }

    moveCell(dir) {
      const cell = this.closest("td,th"); if (!cell) return;
      const cells = [...cell.closest("table").querySelectorAll("th,td")];
      let i = cells.indexOf(cell) + dir;
      if (i >= cells.length) { this.tableOp("row+"); const c2 = [...cell.closest("table").querySelectorAll("th,td")]; i = cells.length; if (c2[i]) { this.focusCell(c2[i]); } return; }
      if (i >= 0) this.focusCell(cells[i]);
    }
    focusCell(c) { const r = document.createRange(); r.selectNodeContents(c); r.collapse(true); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }

    // "# " -> heading, "- " -> list, "1. " -> numbered, "> " -> quote, "[ ] " -> task
    autoFormat(e) {
      if (e && e.inputType === "insertParagraph") {
        // a new item after a task item is a task item too
        const li = this.closest("li");
        const prev = li && li.previousElementSibling;
        if (li && prev && prev.classList.contains("task-item") && !li.querySelector(":scope > input.task-cb")) {
          const c = document.createElement("input"); c.type = "checkbox"; c.className = "task-cb";
          li.classList.add("task-item");
          li.insertBefore(document.createTextNode(" "), li.firstChild);
          li.insertBefore(c, li.firstChild);
          const r = document.createRange(); r.setStart(li, 2); r.collapse(true);
          const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
        }
        return;
      }
      if (!e || e.inputType !== "insertText" || !(e.data === " " || e.data === " ")) return;
      const blk = this.closest("p,div");
      if (!blk || blk === this.editor || blk.closest("pre,li,td,th")) return;
      const txt = blk.textContent.replace(/ /g, " ").replace(/​/g, "");
      let m, act = null;
      const caretIn = (node) => { const r = document.createRange(); r.setStart(node, 0); r.collapse(true); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); };
      const makeList = (tag, task, start) => {
        const list = document.createElement(tag);
        if (start && start !== 1) list.setAttribute("start", String(start));
        const li = document.createElement("li");
        if (task) { li.className = "task-item"; const c = document.createElement("input"); c.type = "checkbox"; c.className = "task-cb"; li.appendChild(c); li.appendChild(document.createTextNode(" ")); }
        li.appendChild(document.createElement("br"));
        list.appendChild(li);
        blk.replaceWith(list);
        const r = document.createRange(); r.setStart(li, li.childNodes.length - 1); r.collapse(true);
        const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
      };
      if ((m = /^(#{1,6}) $/.exec(txt))) act = () => { blk.innerHTML = "<br>"; caretIn(blk); this.formatBlock("h" + m[1].length); };
      else if (/^[-*+] $/.test(txt)) act = () => makeList("ul", false);
      else if ((m = /^(\d+)[.)] $/.exec(txt))) act = () => makeList("ol", false, parseInt(m[1], 10));
      else if (/^> $/.test(txt)) act = () => {
        const q = document.createElement("blockquote"); const p = document.createElement("p"); p.innerHTML = "<br>"; q.appendChild(p);
        blk.replaceWith(q); caretIn(p);
      };
      else if (/^\[( |x|)\] $/.test(txt)) act = () => makeList("ul", true);
      if (act) act();
    }

    // --- links are detected as soon as they are pasted or typed (a bare https:// address becomes a real link) ---
    autoLink(e) {
      if (this.mode !== "rich" || !e) return;
      const t = e.inputType;
      if (t === "insertText" && e.data && /^\s$/.test(e.data)) {
        // a space typed right after a link that was still "open" ends it: move the space out of the link
        const s = getSelection();
        const n = s && s.anchorNode;
        const a = n && n.parentElement && n.parentElement.closest("a:not(.wikilink)");
        if (a && this.editor.contains(a) && n.nodeType === 3 && /\s$/.test(n.textContent) && a.lastChild === n) {
          const sp = n.textContent.match(/\s+$/)[0];
          n.textContent = n.textContent.slice(0, -sp.length);
          const after = document.createTextNode(sp);
          a.after(after);
          const r = document.createRange(); r.setStart(after, sp.length); r.collapse(true); s.removeAllRanges(); s.addRange(r);
        }
        this.autoLinkNear(false);
      } else if (t === "insertParagraph" || t === "insertLineBreak") {
        this.autoLinkNear(false, true);
      }
    }

    // Links the bare URLs of the block holding the caret (and the one before it, or every block touched by a paste).
    autoLinkNear(whole, previous) {
      const s = getSelection();
      if (!s || !s.rangeCount || !this.inEditor(s.anchorNode)) return;
      let top = s.anchorNode.nodeType === 3 ? s.anchorNode.parentNode : s.anchorNode;
      while (top && top.parentNode !== this.editor) top = top.parentNode;
      if (!top) return;
      const blocks = new Set([top]);
      if (previous && top.previousElementSibling) blocks.add(top.previousElementSibling);
      if (whole) {                                   // pasted text can span several paragraphs
        for (let b = top.previousElementSibling, i = 0; b && i < 30; b = b.previousElementSibling, i++) blocks.add(b);
      }
      for (const b of blocks) if (b.matches && !b.matches("pre, .md-html")) this.linkifyNode(b);
    }

    linkifyNode(root) {
      const rej = "a, pre, code, .md-html, [contenteditable=false]";
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: (n) => (n.parentElement && !n.parentElement.closest(rej) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
      });
      const nodes = []; for (let n = walker.nextNode(); n; n = walker.nextNode()) nodes.push(n);
      const sel = getSelection();
      let cn = sel && sel.rangeCount ? sel.anchorNode : null, co = sel && sel.rangeCount ? sel.anchorOffset : 0;
      let moved = false, changed = false;
      for (const node of nodes) {
        const text = node.textContent;
        const found = [];
        const re = /\bhttps?:\/\/[^\s<>"']+/gi;
        let m;
        while ((m = re.exec(text))) {
          let url = m[0].replace(/[.,;:!?)\]]+$/, "");
          if (url.length <= 8) continue;
          found.push([m.index, m.index + url.length, url]);
        }
        for (let k = found.length - 1; k >= 0; k--) {
          const [st, en, url] = found[k];
          const tail = node.splitText(en);
          const mid = node.splitText(st);
          if (cn === node && co > en) { cn = tail; co -= en; moved = true; }
          const a = document.createElement("a");
          a.setAttribute("href", url);
          a.textContent = url;
          mid.replaceWith(a);
          if (cn === node && co > st) { cn = a.firstChild; co = Math.min(co - st, url.length); moved = true; }
          changed = true;
        }
      }
      if (moved && cn) {
        const r = document.createRange();
        try { r.setStart(cn, co); r.collapse(true); sel.removeAllRanges(); sel.addRange(r); } catch (e) { /* caret stays where the browser put it */ }
      }
      return changed;
    }

    // Copy / cut: besides the plain text, the clipboard gets the selection as clean HTML (marked "data-planner-note") so that
    // pasting it into a note keeps the formatting. Code blocks keep the browser's default (plain text).
    onCopy(e, cut) {
      const sel = getSelection();
      if (!e.clipboardData || !sel || sel.isCollapsed || !sel.rangeCount) return;
      for (let i = 0; i < sel.rangeCount; i++) if (!this.editor.contains(sel.getRangeAt(i).commonAncestorContainer)) return;
      if (this.closest("pre")) return;
      const wrap = document.createElement("div");
      for (let i = 0; i < sel.rangeCount; i++) wrap.appendChild(sel.getRangeAt(i).cloneContents());
      this.cleanClip(wrap);
      if (!wrap.textContent && !wrap.querySelector("img, hr, input")) return;
      e.clipboardData.setData("text/html", `<div data-planner-note="1">${wrap.innerHTML}</div>`);
      e.clipboardData.setData("text/plain", sel.toString());
      e.preventDefault();
      if (cut) { document.execCommand("delete"); this.touch(); }
    }

    // A pasted copy is a new block, not the original one: drop the links to the source lines and the editing leftovers.
    cleanClip(root) {
      root.querySelectorAll("[data-md], [data-base]").forEach((n) => { n.removeAttribute("data-md"); n.removeAttribute("data-base"); });
      root.querySelectorAll("[data-retried]").forEach((n) => n.removeAttribute("data-retried"));
    }

    async onPaste(e) {
      const cd = e.clipboardData;
      if (!cd) return;
      const files = [...(cd.files || [])].filter((f) => f.type.startsWith("image/"));
      if (files.length) { e.preventDefault(); for (const f of files) await this.insertImageFile(f); return; }
      const clip = cd.getData("text/html");
      if (clip && clip.includes("data-planner-note") && !this.closest("pre")) {      // copied / cut from a note: keep its formatting
        const tmp = document.createElement("div");
        sanitizeInto(tmp, clip);
        const root = tmp.querySelector("[data-planner-note]");
        if (root) {
          e.preventDefault();
          const out = document.createElement("div");
          sanitizeInto(out, root.innerHTML);
          this.cleanClip(out);
          document.execCommand("insertHTML", false, out.innerHTML);
          this.autoLinkNear(true);
          this.touch();
          return;
        }
      }
      const text = cd.getData("text/plain");
      if (!text) return;
      e.preventDefault();
      const looksMd = /\n\s*\n|^\s*(#{1,6}\s|[-*+]\s|\d+[.)]\s|>\s|```|\|.*\|)/m.test(text) || /\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\)/.test(text);
      if (this.closest("pre") || !looksMd) {
        const inPre = !!this.closest("pre");
        document.execCommand("insertText", false, text);
        if (!inPre) { this.autoLinkNear(true); this.touch(); }
        return;
      }
      const tmp = document.createElement("div");
      sanitizeInto(tmp, md().render(text, { noMap: true, notePath: this.path }));
      document.execCommand("insertHTML", false, tmp.innerHTML);
      this.touch();
    }

    async onDrop(e) {
      const files = [...((e.dataTransfer && e.dataTransfer.files) || [])].filter((f) => f.type.startsWith("image/"));
      if (!files.length) return;
      e.preventDefault();
      for (const f of files) await this.insertImageFile(f);
    }
  }

  /* ------------------------------------------------------------------ *
   * public API
   * ------------------------------------------------------------------ */
  window.NotesApp = {
    async mount(container, opts) {
      if (INSTANCE) { try { await INSTANCE.destroy(); } catch (e) {} INSTANCE = null; }
      INSTANCE = new NotesEditor(container, opts);
      await INSTANCE.loadTree();
      return INSTANCE;
    },
    async flush() { if (INSTANCE && !INSTANCE.destroyed) return INSTANCE.flush(); return true; },
    // --- used by the task panel to link a task to a note ---
    async root() { return (await fetchTree()).root; },
    async suggest(text, limit) {
      const tree = await fetchTree();
      return rankNotes(text || "", tree.notes, 0.35).slice(0, limit || 3);
    },
    pickNote: notePicker,
    // Creates an empty note (in "Scripts" when that folder exists); resolves its
    // path relative to the notes folder.
    async create(name) {
      const tree = await fetchTree(true);
      const folder = (tree.folders || []).includes("Scripts") ? "Scripts" : "";
      const r = await call("POST", `${API}/new`, { folder, name, content: "" });
      TREE_CACHE = { at: 0, data: null };
      return r.path;
    },
    openNote(rel) {
      LS.set("notes.last", rel);
      if (INSTANCE && !INSTANCE.destroyed && INSTANCE.root.isConnected) return INSTANCE.open(rel);
      if (typeof window.openNotes === "function") window.openNotes();
    },
    // exposed for tests
    _internals: { structSig, outlineText, textSig, extractContent, rankNotes, tokens, md, blockEl, blocksOf, splitFrontMatter, sanitizeInto, instance: () => INSTANCE },
  };
})();
