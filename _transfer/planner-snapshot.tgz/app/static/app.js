"use strict";

/* ---------------------------------------------------------------------- *
 * API helpers
 * ---------------------------------------------------------------------- */
const api = {
  async get(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
  async send(method, url, body) {
    const r = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
  post(url, body) { return this.send("POST", url, body); },
  patch(url, body) { return this.send("PATCH", url, body); },
  del(url) { return this.send("DELETE", url); },
  async upload(url, file) {
    const fd = new FormData();
    fd.append("file", file);
    const r = await fetch(url, { method: "POST", body: fd });
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
  // POST a pre-built FormData (text fields plus an optional file) --
  // used by the "Generate" PowerPoint button, which takes links/prompt
  // text alongside an optional reference document in one multipart request.
  async postForm(url, formData) {
    const r = await fetch(url, { method: "POST", body: formData });
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
};

/* ---------------------------------------------------------------------- *
 * Global state
 * ---------------------------------------------------------------------- */
const state = {
  projects: [],
  todoLists: [],   // flat, all lists across all projects
  tags: [],
  expanded: new Set(),  // expanded project ids in the sidebar tree
  knownProjectIds: new Set(),  // projects already seen once, so they default open exactly once
  collapsedGroups: new Set(),  // collapsed project-group ids within a smart view
  expandedSubtasks: new Set(), // task ids whose subtask list is expanded (folded by default)
  showCompleted: false,
  smartCounts: { inbox: 0, today: 0, tomorrow: 0, urgent: 0 },
  view: { type: "list", todoListId: null, title: "Tasks" },
  tasks: [],
  completedOccurrences: [],  // finished occurrences of recurring tasks (smart views' Show completed)
  orphanParents: [],   // main tasks of those subtasks, listed (collapsible) with the matching subtasks under them
  orphanSubtasks: [],  // subtasks matching the current smart-view filter whose parent task doesn't
  calendar: { year: 0, month: 0, mode: "week", weekStart: null, data: {}, onlyVideos: loadOnlyVideos() },
  sponsors: { year: 0, month: 0, data: [], hidden: [] },
  timeReport: { tab: "activity", gran: "week", anchor: null, selected: null, periods: [], entries: [] },
  backups: { list: [], selected: null, diff: null, loading: false },
  templates: [],   // task templates (Utilities > Templates), loaded from /api/templates
  tplEditor: { key: null, draft: null, dirty: false, isNew: false },
};

const PROJECT_COLORS = ["#3daee9", "#e01b24", "#ff9800", "#2ecc71", "#9b59b6",
  "#f39c12", "#1abc9c", "#e91e63", "#607d8b", "#795548"];
// A task's video_template is stamped on at creation (and survives a rename)
// but can also be set or changed by hand from the task detail panel's
// "Video type" picker. The templates themselves (label, icons, main day,
// subtasks...) are editable in Utilities > Templates and live in state.templates.
const FALLBACK_TEMPLATE_ICONS = { weekly_news: "📅", warhammer_video: "🎲" };
function templateByKey(key) { return state.templates.find((t) => t.key === key) || null; }
function templateLabel(key) { const t = templateByKey(key); return t ? t.label : (key || "Video"); }
// Templates with a main day get their dates scheduled automatically; the others
// are created with no due date.
function templateIsUnscheduled(key) { const t = templateByKey(key); return !!t && t.main_weekday === null; }
async function refreshTemplates() {
  try { state.templates = await api.get("/api/templates"); } catch (e) { console.error(e); }
}

// The icon shown next to a video task's title (set per template; plain camera by default).
function videoTitleIcon(videoTemplate) {
  const t = templateByKey(videoTemplate);
  return (t && t.icon) || FALLBACK_TEMPLATE_ICONS[videoTemplate] || "🎥";
}
const WEEKDAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"];
const HOUR_HEIGHT = 64; // px per hour in the week view
const HOUR_START = 8;   // first hour row shown in the week view (8am)
const HOUR_END = 19;    // last hour row shown ends here (7pm) -- working hours only

/* ---------------------------------------------------------------------- *
 * Small utilities
 * ---------------------------------------------------------------------- */
function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else if (v !== false && v !== null && v !== undefined) node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

// Makes a <textarea> grow to fit its content as you type, instead of
// scrolling internally -- used for the notes field so everything typed
// stays visible at once.
function autoGrowTextarea(ta) {
  const grow = () => { ta.style.height = "auto"; ta.style.height = ta.scrollHeight + "px"; };
  ta.addEventListener("input", grow);
  setTimeout(grow, 0);
  return ta;
}

function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function parseIso(dateStr) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function toIso(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function tomorrowIso() {
  const d = parseIso(todayIso());
  d.setDate(d.getDate() + 1);
  return toIso(d);
}

function addDaysIso(iso, days) {
  const d = parseIso(iso);
  d.setDate(d.getDate() + days);
  return toIso(d);
}

function startOfWeekIso(iso) {
  const d = parseIso(iso);
  const dow = (d.getDay() + 6) % 7; // Monday=0 .. Sunday=6
  d.setDate(d.getDate() - dow);
  return toIso(d);
}

function timeToMinutes(hhmm) {
  if (!hhmm) return null;
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

function minutesToTime(mins) {
  mins = Math.max(0, Math.min(23 * 60 + 59, Math.round(mins)));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

function formatDue(dateStr) {
  if (!dateStr) return { text: "", overdue: false };
  const today = parseIso(todayIso());
  const due = parseIso(dateStr);
  const diffDays = Math.round((due - today) / 86400000);
  const overdue = diffDays < 0;
  let text;
  if (diffDays === 0) text = "Today";
  else if (diffDays === 1) text = "Tomorrow";
  else if (diffDays === -1) text = "Yesterday";
  else if (diffDays > 1 && diffDays < 7) text = due.toLocaleDateString(undefined, { weekday: "long" });
  else text = due.toLocaleDateString(undefined, { day: "numeric", month: "short", year: diffDays < -300 || diffDays > 300 ? "numeric" : undefined });
  return { text, overdue };
}

function formatDuration(minutes) {
  if (!minutes && minutes !== 0) return "";
  minutes = parseInt(minutes, 10);
  if (!minutes) return "";
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h && m) return `${h}h ${m}m`;
  if (h) return `${h}h`;
  return `${m}m`;
}

function formatElapsed(totalSeconds) {
  const s = Math.max(0, Math.round(totalSeconds || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h) return `${h}h ${m}m`;
  return `${m}m`;
}

/* ---------------------------------------------------------------------- *
 * Time tracking: a Start/Stop/Pause/Resume control + elapsed-time label,
 * shared by task and subtask rows in every list view (project, todo list,
 * inbox/today/tomorrow/urgent -- not the calendar, which has its own
 * per-day hours total instead). The elapsed label ticks live client-side
 * while running (see wireTimerTicker), computed from the seconds the
 * server reported plus time elapsed since that read, so it stays accurate
 * without polling the server every second.
 * ---------------------------------------------------------------------- */
function timerControls(entity, kind, onDone) {
  const timerState = entity.timer_state || "idle";
  const wrap = el("div", { class: "timer-controls" });

  const act = async (action, e) => {
    e.stopPropagation();
    await api.post(`/api/${kind}/${entity.id}/timer`, { action });
    refreshActiveTimers();
    if (onDone) onDone(); else refreshCurrentView();
  };

  // A main task with subtasks reports its own time PLUS every subtask's.
  const hasTotal = kind === "tasks" && entity.subtasks && entity.subtasks.length && entity.total_time_seconds != null;
  const shownSeconds = hasTotal ? entity.total_time_seconds : (entity.time_spent_seconds || 0);
  const rate = hasTotal ? (entity.running_timers || 0) : (timerState === "running" ? 1 : 0);
  const labelAttrs = { class: "timer-elapsed" };
  if (rate > 0) {
    labelAttrs["data-running"] = "1";
    labelAttrs["data-base-seconds"] = String(shownSeconds);
    labelAttrs["data-rate"] = String(rate);
    labelAttrs["data-since-ms"] = String(Date.now());
  }
  if (hasTotal) labelAttrs.title = `Total: this task ${formatElapsed(entity.own_time_seconds)} + subtasks ${formatElapsed(entity.total_time_seconds - entity.own_time_seconds)}`;
  wrap.appendChild(el("span", labelAttrs, formatElapsed(shownSeconds)));

  const ICONS = {
    start: '<path d="M8 5v14l11-7z"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
    resume: '<path d="M8 5v14l11-7z"/>',
  };
  const TITLES = { start: "Start timer", stop: "Stop timer", pause: "Pause timer", resume: "Resume timer" };
  const iconBtn = (action, ghost) => {
    const b = el("button", { class: "btn small timer-btn icon-only" + (ghost ? " ghost" : "") + ` t-${action}`, title: TITLES[action], "aria-label": TITLES[action], onclick: (e) => act(action, e) });
    b.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true">${ICONS[action]}</svg>`;
    return b;
  };
  if (timerState === "idle") {
    wrap.appendChild(iconBtn("start"));
  } else {
    wrap.appendChild(iconBtn("stop"));
    if (timerState === "running") wrap.appendChild(iconBtn("pause", true));
    else if (timerState === "paused") wrap.appendChild(iconBtn("resume", true));
  }
  return wrap;
}

// One editable field, in minutes, for the actual measured time on a task /
// subtask (not the estimated duration). Saving sets the value directly (a
// running timer keeps counting on top of it).
function timeEditor(entity, kind, onDone) {
  const input = el("input", {
    type: "number", min: "0", step: "1", class: "time-edit-input",
    value: String(Math.round((entity.time_spent_seconds || 0) / 60)),
    title: "Time actually spent, in minutes",
  });
  input.addEventListener("change", async () => {
    const minutes = Math.max(0, parseFloat(input.value) || 0);
    await api.patch(`/api/${kind}/${entity.id}`, { time_spent_seconds: Math.round(minutes * 60) });
    refreshActiveTimers();
    if (onDone) onDone(); else refreshCurrentView();
  });
  return el("span", { class: "time-editor", title: "Time actually spent, in minutes", onclick: (e) => e.stopPropagation() },
    [input, " min spent"]);
}

// Ticks every running timer-elapsed label once a second, purely client-side
// (base seconds + time since that value was read), so running timers feel
// live without re-fetching from the server on an interval.
function wireTimerTicker() {
  setInterval(() => {
    for (const label of document.querySelectorAll('.timer-elapsed[data-running="1"]')) {
      const base = parseInt(label.dataset.baseSeconds, 10) || 0;
      const since = parseInt(label.dataset.sinceMs, 10) || Date.now();
      const rate = parseInt(label.dataset.rate, 10) || 1;
      label.textContent = formatElapsed(base + rate * (Date.now() - since) / 1000);
    }
  }, 1000);
}

/* ---------------------------------------------------------------------- *
 * Header status indicators: active timers + in-flight AI generations.
 * Both render into #statusIndicators, top-right of the main header --
 * unlike #headerActions (view-specific, rebuilt by renderHeaderActions),
 * this is independent of the current view and keeps its own refresh loop.
 * ---------------------------------------------------------------------- */
state.activeTimers = [];
state.aiTasks = []; // client-side only: { id, label } -- one per in-flight AI call this tab

function startAiTask(label) {
  const id = (startAiTask._next = (startAiTask._next || 1) + 1);
  state.aiTasks.push({ id, label });
  renderStatusIndicators();
  return id;
}
function finishAiTask(id) {
  state.aiTasks = state.aiTasks.filter((t) => t.id !== id);
  renderStatusIndicators();
}

async function refreshActiveTimers() {
  try {
    state.activeTimers = await api.get("/api/timers/active");
  } catch (e) {
    // transient failure -- keep showing the last known snapshot
  }
  renderStatusIndicators();
}

function wireStatusIndicators() {
  refreshActiveTimers();
  setInterval(refreshActiveTimers, 5000);
}

function indicatorRow({ title, sub, status, statusClass, meta, onClick }) {
  return el("div", { class: "indicator-row" + (onClick ? " clickable" : ""), onclick: onClick || undefined }, [
    el("div", { class: "indicator-row-main" }, [
      el("div", { class: "indicator-row-title" }, title),
      sub ? el("div", { class: "indicator-row-sub" }, sub) : null,
    ]),
    el("div", { class: "indicator-row-end" }, [
      el("span", { class: "indicator-status " + statusClass }, status),
      meta ? el("span", { class: "indicator-meta" }, meta) : null,
    ]),
  ]);
}

function indicatorPanel(rows) {
  return el("div", { class: "indicator-panel" },
    rows.length ? rows : [el("div", { class: "indicator-row-empty" }, "Nothing here")]);
}

function renderStatusIndicators() {
  const box = document.getElementById("statusIndicators");
  if (!box) return;
  box.innerHTML = "";

  if (state.activeTimers.length) {
    box.appendChild(el("button", {
      type: "button",
      class: "indicator-btn",
      title: "Active timers",
      onclick: (e) => {
        e.stopPropagation();
        openDropdown(e.currentTarget, [indicatorPanel(state.activeTimers.map((entry) => indicatorRow({
          title: entry.title,
          sub: entry.is_subtask ? `↳ ${entry.parent_title || ""}` : null,
          status: entry.timer_state === "paused" ? "Paused" : "Running",
          statusClass: entry.timer_state === "paused" ? "paused" : "running",
          meta: formatElapsed(entry.time_spent_seconds),
          onClick: entry.is_other ? undefined : () => { closeDropdowns(); openTaskDetail(entry.task_id); },
        })))]);
      },
    }, [
      el("span", { class: "indicator-icon" }, "⏱"),
      el("span", { class: "indicator-count" }, String(state.activeTimers.length)),
    ]));
  }

  if (state.aiTasks.length) {
    box.appendChild(el("button", {
      type: "button",
      class: "indicator-btn",
      title: "AI generation in progress",
      onclick: (e) => {
        e.stopPropagation();
        openDropdown(e.currentTarget, [indicatorPanel(state.aiTasks.map((t) => indicatorRow({
          title: t.label,
          status: "Working…",
          statusClass: "working",
        })))]);
      },
    }, [
      el("span", { class: "indicator-icon" }, "✨"),
      el("span", { class: "indicator-count" }, String(state.aiTasks.length)),
    ]));
  }
}

function formatHoursTotal(totalMinutes) {
  if (!totalMinutes) return "";
  const hrs = totalMinutes / 60;
  const rounded = Math.round(hrs * 10) / 10;
  return `${Number.isInteger(rounded) ? rounded : rounded.toFixed(1)}h`;
}

function describeRecurrence(rule) {
  if (!rule) return "";
  const unit = rule.unit || "day";
  const interval = parseInt(rule.interval || 1, 10);
  const plural = { day: "days", week: "weeks", month: "months", year: "years" }[unit];
  const singular = { day: "day", week: "week", month: "month", year: "year" }[unit];
  let base = interval === 1 ? `Every ${singular}` : `Every ${interval} ${plural}`;
  if (unit === "week" && rule.weekdays && rule.weekdays.length) {
    const names = [...new Set(rule.weekdays)].sort().map((i) => WEEKDAY_NAMES[i]).join(", ");
    base += ` on ${names}`;
  }
  return base;
}

// opts.sticky: stays until the person closes it with the × at its top right (used for AI-button errors).
function showToast(msg, opts = {}) {
  const t = document.getElementById("toast");
  clearTimeout(showToast._t);
  t.classList.toggle("sticky", !!opts.sticky);
  t.textContent = "";
  t.appendChild(el("span", { class: "toast-msg" }, msg));
  if (opts.sticky) {
    t.appendChild(el("button", { type: "button", class: "toast-close", title: "Close", "aria-label": "Close",
      onclick: (e) => { e.stopPropagation(); t.classList.add("hidden"); t.classList.remove("sticky"); } }, "×"));
  } else {
    showToast._t = setTimeout(() => t.classList.add("hidden"), 2200);
  }
  t.classList.remove("hidden");
}

function closeDropdowns() {
  document.querySelectorAll(".dropdown").forEach((d) => d.remove());
}
document.addEventListener("click", closeDropdowns);

// Dropdown menus are appended to <body> and positioned with `fixed`
// coordinates computed from the anchor button's own bounding rect, rather
// than relying on a `position: relative` ancestor + `position: absolute`.
// Several sidebar rows (e.g. a todo-list row) have `overflow: hidden` for
// text-ellipsis purposes, which would silently clip an absolutely-positioned
// dropdown nested inside them to zero visible size.
function openDropdown(anchorBtn, buttons) {
  closeDropdowns();
  const rect = anchorBtn.getBoundingClientRect();
  const dd = el("div", { class: "dropdown" }, buttons);
  dd.style.position = "fixed";
  dd.style.top = `${rect.bottom + 4}px`;
  dd.style.right = `${Math.max(4, window.innerWidth - rect.right)}px`;
  document.body.appendChild(dd);
  return dd;
}

/* ---------------------------------------------------------------------- *
 * "Useful Resources" (top right of every page): the video tasks due in the next 2 weeks with links to their notes,
 * and the 5 most recent notes.
 * ---------------------------------------------------------------------- */
async function openResourcesMenu(btn) {
  if (document.querySelector(".dropdown.res-menu")) { closeDropdowns(); return; }
  const dd = openDropdown(btn, [el("div", { class: "res-empty" }, "Loading…")]);
  dd.classList.add("res-menu");
  let videos = [], recent = [], root = "";
  try {
    const [v, st, r] = await Promise.all([
      api.get(`/api/video-tasks/upcoming?today=${todayIso()}&days=14`),
      api.get("/api/notes/state").catch(() => ({ recent: [] })),
      NotesApp.root().catch(() => ""),
    ]);
    videos = v; recent = (st.recent || []).slice(0, 5); root = (r || "").replace(/\/$/, "");
  } catch (e) {
    dd.innerHTML = "";
    dd.appendChild(el("div", { class: "res-empty" }, "Could not load the resources."));
    return;
  }
  const relOf = (p) => (root && p && p.startsWith(root + "/")) ? p.slice(root.length + 1) : null;
  const openNote = (rel) => { closeDropdowns(); NotesApp.openNote(rel); };
  const noteName = (p) => (p || "").split("/").pop().replace(/\.md$/i, "");
  const noteChip = (icon, path, label) => {
    const rel = relOf(path);
    return rel
      ? el("button", { class: "res-note", type: "button", title: `Open ${noteName(path)}`, onclick: () => openNote(rel) }, `${icon} ${label || noteName(path)}`)
      : el("span", { class: "res-note muted", title: path }, `${icon} ${label || noteName(path)}`);
  };

  dd.innerHTML = "";
  dd.appendChild(el("div", { class: "res-label" }, "Videos in the next 2 weeks"));
  if (!videos.length) dd.appendChild(el("div", { class: "res-empty" }, "No upcoming video."));
  for (const t of videos) {
    const due = formatDue(t.due_date);
    const notes = [];
    if (t.notes_file) notes.push(noteChip("📄", t.notes_file, "Note"));
    if (t.video_note_file) notes.push(noteChip("🎬", t.video_note_file, "Video note"));
    dd.appendChild(el("div", { class: "res-video" }, [
      el("button", { type: "button", class: "res-title", onclick: () => { closeDropdowns(); openTaskDetail(t.id); } }, [
        el("span", {}, t.title), el("span", { class: "res-date" }, due.text || t.due_date),
      ]),
      notes.length ? el("div", { class: "res-notes" }, notes) : el("div", { class: "res-empty", style: "padding-top:0" }, "no linked note"),
    ]));
  }
  dd.appendChild(el("div", { class: "res-label", style: "margin-top:6px" }, "Recent notes"));
  if (!recent.length) dd.appendChild(el("div", { class: "res-empty" }, "No recent note."));
  for (const rel of recent) {
    const parts = rel.split("/");
    dd.appendChild(el("button", { type: "button", class: "res-note-row", onclick: () => openNote(rel) },
      [el("span", {}, noteName(rel)), parts.length > 1 ? el("small", {}, parts.slice(0, -1).join(" / ")) : null]));
  }
}

/* ---------------------------------------------------------------------- *
 * Theme
 * ---------------------------------------------------------------------- */
function initTheme() {
  const saved = localStorage.getItem("taskplanner-theme");
  if (saved) document.documentElement.setAttribute("data-theme", saved);
  document.getElementById("themeToggle").addEventListener("click", () => {
    const cur = document.documentElement.getAttribute("data-theme")
      || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    const next = cur === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("taskplanner-theme", next);
  });
}

/* ---------------------------------------------------------------------- *
 * Sidebar
 * ---------------------------------------------------------------------- */
async function refreshSidebarData() {
  const [projects, todoLists, tags, counts, current] = await Promise.all([
    api.get("/api/projects"),
    api.get("/api/todolists"),
    api.get("/api/tags"),
    api.get(`/api/smartcounts?today=${todayIso()}&tomorrow=${tomorrowIso()}`),
    api.get(`/api/video-project/current?today=${todayIso()}`).catch(() => ({ task: null })),
  ]);
  state.currentVideo = current.task || null;
  state.projects = projects;
  state.todoLists = todoLists;
  state.tags = tags;
  state.smartCounts = counts;
  // Projects are unfolded by default. A project collapsed by the user stays
  // collapsed across refreshes (it's removed from `expanded`, not re-added),
  // but a project seen for the first time this session starts open.
  for (const p of projects) {
    if (!state.knownProjectIds.has(p.id)) {
      state.knownProjectIds.add(p.id);
      state.expanded.add(p.id);
    }
  }
  renderSidebar();
}

// Monochrome (currentColor) line icons for the sidebar entries.
const SYMBOLIC_ICONS = {
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  megaphone: '<path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  notes: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4M10 9H8M16 13H8M16 17H8"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5M3 12a9 3 0 0 0 18 0"/>',
  sparkles: '<path d="M9.94 14.06 12 21l2.06-6.94L21 12l-6.94-2.06L12 3 9.94 9.94 3 12z"/>',
  layout: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
};
// Big monochrome icon for the "Nothing here" style empty states.
function emptyStateIcon(name) {
  const box = el("div", { class: "empty-ico" });
  box.innerHTML = `<svg viewBox="0 0 24 24" width="44" height="44" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SYMBOLIC_ICONS[name] || ""}</svg>`;
  return box;
}
function symbolicIcon(name) {
  const span = el("span", { class: "ri-icon sym" });
  span.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SYMBOLIC_ICONS[name] || ""}</svg>`;
  return span;
}

function renderSidebar() {
  if (state.view && state.view.type && !state.bootPending) saveCurrentView();
  const bb = document.getElementById("backupsBtn");
  if (bb) bb.classList.toggle("active", state.view.type === "backups");
  const tb = document.getElementById("templatesBtn");
  if (tb) tb.classList.toggle("active", state.view.type === "templates");
  renderTopNav();
  renderFinanceNav();
  renderProjectsTree();
}

/* ---------------------------------------------------------------------- *
 * Finances (Gestion fiscale EI) -- a self-contained module served by its own
 * Flask blueprint under /fiscal (see gestion_ei_web/). Its assets are loaded
 * on first use; each section is mounted once and kept (so a half-filled
 * dialog, the selected tab or the chart's hidden series survive navigation).
 * ---------------------------------------------------------------------- */
const FISCAL_BASE = "/fiscal";
const FISCAL_SECTIONS = [
  { key: "factures", icon: "receipt", label: "Factures" },
  { key: "graphique", icon: "chart", label: "Graphique" },
  { key: "declarations", icon: "landmark", label: "Déclarations" },
];
// Same monochrome line-icon style as the other sidebar entries (SYMBOLIC_ICONS above).
Object.assign(SYMBOLIC_ICONS, {
  receipt: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8M12 17.5v-11"/>',
  chart: '<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="m19 9-5 5-4-4-3 3"/>',
  landmark: '<path d="M3 22h18M6 18v-7M10 18v-7M14 18v-7M18 18v-7M12 2 20 7H4z"/>',
  gear: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  checkCircle: '<circle cx="12" cy="12" r="10"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
  coins: '<circle cx="9" cy="9" r="6"/><path d="M15.5 9.6A6 6 0 1 1 9.6 15.5"/><path d="M9 6.5v5M7.3 8.2h3.4"/>',
});
let fiscalLoading = null;
const fiscalHosts = {};   // section key -> { el, app, sub, stale }

function loadFiscalModule() {
  if (window.GestionEI) return Promise.resolve();
  if (fiscalLoading) return fiscalLoading;
  const assets = ["/static/ds/ds.css", "/static/ei.css"];
  for (const href of assets) {
    document.head.appendChild(el("link", { rel: "stylesheet", href: FISCAL_BASE + href }));
  }
  fiscalLoading = new Promise((resolve, reject) => {
    const sc = document.createElement("script");
    sc.src = FISCAL_BASE + "/static/ei.js";
    sc.onload = () => resolve();
    sc.onerror = () => { fiscalLoading = null; reject(new Error("Finance module not available")); };
    document.head.appendChild(sc);
  });
  return fiscalLoading;
}

function renderFinanceNav() {
  const box = document.getElementById("financeNav");
  if (!box) return;
  box.innerHTML = "";
  for (const it of FISCAL_SECTIONS) {
    box.appendChild(el("div", {
      class: "row-item" + (state.view.type === "fiscal" && state.view.fiscalSection === it.key ? " active" : ""),
      onclick: () => openFiscalView(it.key),
    }, [
      symbolicIcon(it.icon),
      el("span", { class: "ri-label" }, it.label),
    ]));
  }
  box.appendChild(el("div", {
    class: "row-item" + (state.view.type === "revenue" ? " active" : ""),
    onclick: () => openRevenue(),
  }, [symbolicIcon("coins"), el("span", { class: "ri-label" }, "Revenue")]));
}

async function openFiscalView(section) {
  const info = FISCAL_SECTIONS.find((x) => x.key === section) || FISCAL_SECTIONS[0];
  try { await loadFiscalModule(); }
  catch (err) { showToast(err.message); return; }
  const host = fiscalHosts[info.key];
  if (host) host.stale = true;        // re-shown: re-read the data
  state.view = { type: "fiscal", fiscalSection: info.key, title: info.label, subtitle: host ? host.sub || "" : "" };
  renderMain();
  renderSidebar();
}

function renderFiscalView(root) {
  const key = state.view.fiscalSection;
  let host = fiscalHosts[key];
  if (!host) {
    host = fiscalHosts[key] = { el: el("div", {}), app: null, sub: "", stale: false };
    root.appendChild(host.el);        // attach before mounting: charts measure their width
    host.app = window.GestionEI.mount(host.el, {
      base: FISCAL_BASE, layout: "embedded", section: key,
      onTitle: (_title, sub) => {
        host.sub = sub;
        if (state.view.type === "fiscal" && state.view.fiscalSection === key) {
          state.view.subtitle = sub;
          document.getElementById("pageSubtitle").textContent = sub;
        }
      },
    });
    return;
  }
  root.appendChild(host.el);
  if (host.stale) { host.stale = false; host.app.ready.then(() => host.app.refreshCurrent()); }
}

const SMART_TITLES = { inbox: "Inbox", today: "Today", tomorrow: "Tomorrow", urgent: "Urgent" };

function renderTopNav() {
  const box = document.getElementById("topNav");
  box.innerHTML = "";
  const isSmart = (type) => state.view.type === "smart" && state.view.smartType === type;

  // Inbox/Today/Tomorrow/Urgent get their own 2x2 grid of colored blocks,
  // since they're the most-used entry points.
  const smartItems = [
    { key: "inbox", icon: "📥", label: "Inbox", active: isSmart("inbox"), action: () => openSmartView("inbox"), count: state.smartCounts.inbox },
    { key: "today", icon: "☀️", label: "Today", active: isSmart("today"), action: () => openSmartView("today"), count: state.smartCounts.today },
    { key: "tomorrow", icon: "📆", label: "Tomorrow", active: isSmart("tomorrow"), action: () => openSmartView("tomorrow"), count: state.smartCounts.tomorrow },
    { key: "urgent", icon: "🚩", label: "Urgent", active: isSmart("urgent"), action: () => openSmartView("urgent"), count: state.smartCounts.urgent },
  ];
  const grid = el("div", { class: "smart-grid" });
  for (const it of smartItems) {
    grid.appendChild(el("div", {
      class: `smart-tile ${it.key}` + (it.active ? " active" : ""),
      onclick: it.action,
    }, [
      el("div", { class: "tile-top" }, [
        el("span", {}, it.icon),
        it.count ? el("span", { class: "tile-count" }, String(it.count)) : null,
      ]),
      el("div", { class: "tile-label" }, it.label),
    ]));
  }
  box.appendChild(grid);
  box.appendChild(el("div", {
    class: "smart-tile video wide" + (state.view.type === "videoproject" ? " active" : ""),
    onclick: () => openVideoProject(),
  }, [
    el("div", { class: "tile-top" }, [el("span", {}, state.currentVideo ? videoTitleIcon(state.currentVideo.video_template) : "🎬")]),
    el("div", { class: "tile-label vp-tile-title", title: state.currentVideo ? state.currentVideo.title : "Current Video project" },
      state.currentVideo ? state.currentVideo.title : "Current Video project"),
  ]));

  const items = [
    { icon: "calendar", label: "Calendar", active: state.view.type === "calendar", action: () => openCalendar() },
    { icon: "megaphone", label: "Sponsors", active: state.view.type === "sponsors", action: () => openSponsorsView() },
    { icon: "clock", label: "Time report", active: state.view.type === "timereport", action: () => openTimeReport() },
    { icon: "notes", label: "Notes & Scripts", active: state.view.type === "notes", action: () => openNotes() },
  ];
  for (const it of items) {
    box.appendChild(el("div", {
      class: "row-item" + (it.active ? " active" : ""),
      onclick: it.action,
    }, [
      symbolicIcon(it.icon),
      el("span", { class: "ri-label" }, it.label),
      it.count ? el("span", { class: "ri-count" }, String(it.count)) : null,
    ]));
  }
}

/* ---------------------------------------------------------------------- *
 * Smart views: Inbox / Today / Tomorrow / Urgent — tasks from every
 * project, grouped into collapsible per-project sections.
 * ---------------------------------------------------------------------- */
function smartViewParams(type) {
  const params = new URLSearchParams();
  if (type === "inbox") params.set("no_due_date", "1");
  else if (type === "today") { params.set("due_date", todayIso()); params.set("include_overdue", "1"); }
  else if (type === "tomorrow") params.set("due_date", tomorrowIso());
  else if (type === "urgent") params.set("urgent", "1");
  return params;
}

async function loadSmartTasks(type) {
  if (type === "today" || type === "tomorrow" || type === "urgent") {
    const data = await api.get("/api/tasks/smart?" + smartViewParams(type).toString());
    state.tasks = data.tasks;
    state.orphanSubtasks = data.orphan_subtasks || [];
    state.orphanParents = data.orphan_parents || [];
    state.completedOccurrences = data.completed_occurrences || [];
  } else {
    state.tasks = await api.get("/api/tasks?" + smartViewParams(type).toString());
    state.orphanSubtasks = [];
    state.orphanParents = [];
    state.completedOccurrences = [];
  }
}

async function openSmartView(type) {
  state.view = { type: "smart", smartType: type, title: SMART_TITLES[type] };
  await loadSmartTasks(type);
  renderMain();
  renderSidebar();
}

// A main task counts as "fully done" (hide-worthy when Show completed is
// off) only if it's checked AND, when it has subtasks, every one of those
// is checked too -- a task checked off by hand while a subtask is still
// open, or with only some subtasks done, isn't really finished yet and
// should stay visible.
function isTaskFullyDone(t) {
  if (!t.checked) return false;
  if (t.subtasks && t.subtasks.length) return t.subtasks.every((s) => s.checked);
  return true;
}

function completedOccurrenceRow(c) {
  // A finished occurrence of a recurring task, with the subtasks it had when
  // it was finished (snapshot) in a foldable list underneath.
  const subs = c.subtasks || [];
  const key = "occ:" + c.id;
  const expanded = state.expandedSubtasks.has(key);
  const list = subs.length ? el("div", { class: "subtask-list" + (expanded ? " expanded" : "") }) : null;
  for (const s of subs) {
    list.appendChild(el("div", { class: "subtask-row", onclick: () => openOccurrenceDetail(c) }, [
      el("div", { class: "checkbox small disabled" + (s.checked ? " checked" : "") }, s.checked ? "✓" : ""),
      el("div", { class: "task-main" }, [
        el("div", { class: "task-content" + (s.checked ? " done" : "") }, s.title),
        s.time_spent_seconds ? el("div", { class: "task-meta" },
          [el("span", { class: "duration-chip" }, "⏱ " + formatElapsed(s.time_spent_seconds))]) : null,
      ]),
    ]));
  }
  const foldToggle = subs.length ? el("button", {
    class: "fold-toggle" + (expanded ? " expanded" : ""),
    title: expanded ? "Hide subtasks" : "Show subtasks",
    onclick: (e) => {
      e.stopPropagation();
      const now = !state.expandedSubtasks.has(key);
      if (now) state.expandedSubtasks.add(key); else state.expandedSubtasks.delete(key);
      foldToggle.classList.toggle("expanded", now);
      list.classList.toggle("expanded", now);
    },
  }, "▸") : el("span", { class: "fold-toggle placeholder" });
  const metaBits = [
    el("span", {}, "🔁 finished " + formatDue(c.occurrence_date).text),
    (c.time_spent_seconds || subs.some((x) => x.time_spent_seconds))
      ? el("span", { class: "duration-chip" }, "⏱ " + formatElapsed((c.time_spent_seconds || 0) + subs.reduce((n, x) => n + (x.time_spent_seconds || 0), 0))) : null,
  ];
  if (subs.length) metaBits.push(el("span", { class: "muted" }, `☑ ${subs.filter((x) => x.checked).length}/${subs.length}`));
  const row = el("div", { class: "task-row", onclick: () => openOccurrenceDetail(c) }, [
    foldToggle,
    el("div", { class: "checkbox checked disabled", title: "This occurrence is finished" }, "✓"),
    el("div", { class: "task-main" }, [
      el("div", { class: "task-title done" }, [
        c.is_video ? el("span", { class: "video-badge" }, videoTitleIcon(c.video_template) + " ") : null,
        c.title,
      ]),
      el("div", { class: "task-meta" }, metaBits),
    ]),
  ]);
  return list ? el("div", { class: "task-with-subtasks" }, [row, list]) : row;
}

function renderSmartView(type, tasks, orphanSubtasks = [], orphanParents = []) {
  let finished = [];
  if (!state.showCompleted) {
    tasks = tasks.filter((t) => !isTaskFullyDone(t));
    orphanSubtasks = orphanSubtasks.filter((s) => !s.checked);
    orphanParents = orphanParents.filter((p) => orphanSubtasks.some((s) => s.parent_task_id === p.id));
  } else {
    finished = state.completedOccurrences || [];
  }
  const wrap = el("div", {});

  if (type === "today" || type === "tomorrow") {
    const totalMinutes = tasks.filter((t) => !t.checked).reduce((sum, t) => sum + (t.duration_minutes || 0), 0)
      + orphanSubtasks.filter((s) => !s.checked).reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
    if (totalMinutes) {
      wrap.appendChild(el("div", { class: "muted", style: "margin-bottom:14px" },
        `Estimated total: ${formatHoursTotal(totalMinutes)}`));
    }
  }

  if (!tasks.length && !orphanParents.length && !finished.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("checkCircle"),
      el("div", {}, "Nothing here"),
    ]));
    return wrap;
  }

  const byProject = new Map();
  const groupFor = (key) => {
    if (!byProject.has(key)) byProject.set(key, { tasks: [], parents: [], finished: [] });
    return byProject.get(key);
  };
  for (const t of tasks) groupFor(t.project_id || "none").tasks.push(t);
  for (const p of orphanParents) groupFor(p.project_id || "none").parents.push(p);
  for (const c of finished) groupFor(c.project_id || "none").finished.push(c);

  for (const [pid, group] of byProject) {
    const proj = state.projects.find((p) => p.id === pid);
    const groupKey = `${type}:${pid}`;
    const collapsed = state.collapsedGroups.has(groupKey);
    const caret = el("span", { class: "caret" + (collapsed ? "" : " open") }, "▶");
    const header = el("div", { class: "group-header" }, [
      caret,
      proj ? el("span", { class: "dot", style: `background:${proj.color}` }) : null,
      el("span", { class: "ri-label" }, proj ? proj.name : "No project"),
      el("span", { class: "ri-count" }, String(group.tasks.length + group.parents.length + group.finished.length)),
    ]);
    wrap.appendChild(header);
    const body = el("div", { class: "group-body" + (collapsed ? "" : " expanded") });
    for (const t of group.tasks) {
      if (t.subtasks && t.subtasks.some((s) => s.matches_filter)) state.expandedSubtasks.add(t.id);
      body.appendChild(taskRow(t, { showListHint: true, smartType: type }));
    }
    // main tasks that are only here because one of their subtasks matches
    for (const p of group.parents) {
      state.expandedSubtasks.add(p.id);
      body.appendChild(taskRow(p, { showListHint: true, contextParent: true, smartType: type }));
    }
    for (const c of group.finished) body.appendChild(completedOccurrenceRow(c));
    wrap.appendChild(body);
    header.addEventListener("click", () => {
      const nowCollapsed = !state.collapsedGroups.has(groupKey);
      if (nowCollapsed) state.collapsedGroups.add(groupKey); else state.collapsedGroups.delete(groupKey);
      caret.classList.toggle("open", !nowCollapsed);
      body.classList.toggle("expanded", !nowCollapsed);
    });
  }
  return wrap;
}

function orphanSubtaskRow(s) {
  // A subtask matching the current Today/Tomorrow/Urgent filter whose parent
  // task does not itself match -- shown as its own row (tagged with its
  // parent task's title) since it would otherwise never surface in this view.
  const checked = !!s.checked;
  const due = formatDue(s.due_date);

  const checkbox = el("div", {
    class: "checkbox small" + (checked ? " checked" : ""),
    onclick: async (e) => {
      e.stopPropagation();
      await api.post(`/api/subtasks/${s.id}/toggle`, { checked: !checked });
      refreshCurrentView();
    },
  }, checked ? "✓" : "");

  const metaBits = [];
  if (due.text) metaBits.push(el("span", { class: due.overdue ? "overdue" : "" }, due.text));
  if (s.duration_minutes) metaBits.push(el("span", { class: "duration-chip" }, "⏱ " + formatDuration(s.duration_minutes)));
  metaBits.push(el("span", { class: "muted" }, "↳ " + s.parent_title));

  const titleBits = [
    (!checked && due.overdue) ? el("span", { class: "overdue-clock", title: "Overdue" }, "⏰ ") : null,
    s.urgent ? el("span", { class: "urgent-flag", title: "Urgent" }, "🚩 ") : null,
    s.is_video ? el("span", { class: "video-badge", title: templateLabel(s.parent_video_template) },
      videoTitleIcon(s.parent_video_template) + " ") : null,
    s.title,
  ];

  return el("div", { class: "task-row orphan-subtask-row", onclick: () => openTaskDetail(s.parent_task_id) }, [
    el("span", { class: "fold-toggle placeholder" }),
    checkbox,
    el("div", { class: "task-main" }, [
      el("div", { class: "task-content" + (checked ? " done" : "") }, titleBits),
      metaBits.length ? el("div", { class: "task-meta" }, metaBits) : null,
    ]),
    timerControls(s, "subtasks"),
  ]);
}

function renderProjectsTree() {
  const box = document.getElementById("projectsTree");
  box.innerHTML = "";
  for (const p of state.projects) box.appendChild(projectBlock(p));
  document.getElementById("addProjectBtn").onclick = () => openProjectDialog(null);
}

function projectBlock(p) {
  const open = state.expanded.has(p.id);
  const active = state.view.type === "project" && state.view.projectId === p.id;
  const lists = state.todoLists.filter((l) => l.project_id === p.id);

  const toggleFold = () => {
    const nowOpen = !state.expanded.has(p.id);
    if (nowOpen) state.expanded.add(p.id); else state.expanded.delete(p.id);
    caret.classList.toggle("open", nowOpen);
    children.classList.toggle("expanded", nowOpen);
  };

  const caret = el("span", {
    class: "caret" + (open ? " open" : ""),
    onclick: (e) => { e.stopPropagation(); toggleFold(); },
  }, "▶");

  const head = el("div", { class: "project-head" + (active ? " active" : "") }, [
    caret,
    el("span", { class: "dot", style: `background:${p.color}` }),
    el("span", {
      class: "ri-label",
      title: "Show all tasks in this project",
      onclick: (e) => { e.stopPropagation(); openProjectView(p); },
    }, p.name),
    el("span", { class: "ri-count" }, p.task_count > 0 ? String(p.task_count) : ""),
    el("button", {
      class: "icon-btn small", title: "Add list",
      onclick: (e) => { e.stopPropagation(); openListDialog(p.id); },
    }, "＋"),
    (() => {
      const btn = el("button", {
        class: "icon-btn small",
        onclick: (e) => {
          e.stopPropagation();
          openDropdown(btn, [
            el("button", { onclick: () => openProjectDialog(p) }, "Edit project"),
            el("button", {
              class: "danger",
              onclick: async () => {
                if (!(await confirmModal({ title: "Delete project?", message: `“${p.name}” and all its lists and tasks will be deleted.`, confirmLabel: "Delete", danger: true }))) return;
                await api.del(`/api/projects/${p.id}`);
                await refreshSidebarData();
                if (state.view.type === "list" && !state.todoLists.find((l) => l.id === state.view.todoListId)) {
                  openFirstAvailable();
                }
              },
            }, "Delete project"),
          ]);
        },
      }, "⋮");
      return btn;
    })(),
  ]);
  head.addEventListener("click", toggleFold);

  const children = el("div", { class: "list-children" + (open ? " expanded" : "") });
  for (const l of lists) children.appendChild(listRow(l));
  if (lists.length === 0) {
    children.appendChild(el("div", { class: "muted small", style: "padding:6px 8px" }, "No lists yet"));
  }

  return el("div", { class: "project-block" }, [head, children]);
}

// Drag & drop of the lists of a project (same project only): a line shows where the list will land.
let listDrag = null;   // { id, project_id }

function clearListDropMarks() {
  document.querySelectorAll(".row-item.drop-before, .row-item.drop-after, .row-item.dragging")
    .forEach((n) => n.classList.remove("drop-before", "drop-after", "dragging"));
}

async function dropList(targetId, after) {
  const drag = listDrag;
  listDrag = null;
  clearListDropMarks();
  if (!drag || drag.id === targetId) return;
  const ids = state.todoLists.filter((x) => x.project_id === drag.project_id).map((x) => x.id).filter((i) => i !== drag.id);
  let at = ids.indexOf(targetId);
  if (at < 0) return;
  ids.splice(after ? at + 1 : at, 0, drag.id);
  try { await api.post("/api/todolists/reorder", { project_id: drag.project_id, ids }); }
  catch (e) { showToast("Couldn't reorder the lists"); }
  await refreshSidebarData();
  renderSidebar();
}

function wireListDrag(row, l) {
  row.setAttribute("draggable", "true");
  row.addEventListener("dragstart", (e) => {
    listDrag = { id: l.id, project_id: l.project_id };
    e.dataTransfer.effectAllowed = "move";
    try { e.dataTransfer.setData("text/plain", l.name); } catch { /* ignore */ }
    row.classList.add("dragging");
  });
  row.addEventListener("dragend", () => { listDrag = null; clearListDropMarks(); });
  row.addEventListener("dragover", (e) => {
    if (!listDrag || listDrag.project_id !== l.project_id || listDrag.id === l.id) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    const r = row.getBoundingClientRect();
    const after = e.clientY > r.top + r.height / 2;
    row.classList.toggle("drop-after", after);
    row.classList.toggle("drop-before", !after);
  });
  row.addEventListener("dragleave", (e) => { if (!row.contains(e.relatedTarget)) row.classList.remove("drop-before", "drop-after"); });
  row.addEventListener("drop", (e) => {
    if (!listDrag || listDrag.project_id !== l.project_id) return;
    e.preventDefault();
    const r = row.getBoundingClientRect();
    dropList(l.id, e.clientY > r.top + r.height / 2);
  });
}

function listRow(l) {
  const active = state.view.type === "list" && state.view.todoListId === l.id;
  const row = el("div", {
    class: "row-item" + (active ? " active" : ""),
    onclick: () => openTodoList(l),
  }, [
    symbolicIcon("list"),
    el("span", { class: "ri-label" }, l.name),
    el("span", { class: "ri-count" }, l.task_count > 0 ? String(l.task_count) : ""),
  ]);
  const kebabBtn = el("button", {
    class: "icon-btn small",
    style: "flex:0 0 auto",
    onclick: (e) => {
      e.stopPropagation();
      openDropdown(kebabBtn, [
        el("button", {
          onclick: async () => {
            const name = await promptModal({ title: "Rename list", value: l.name });
            if (name && name.trim()) api.patch(`/api/todolists/${l.id}`, { name: name.trim() }).then(refreshAfterStructureChange);
          },
        }, "Rename"),
        el("button", {
          class: "danger",
          onclick: async () => {
            if (!(await confirmModal({ title: "Delete list?", message: `“${l.name}” and all its tasks will be deleted.`, confirmLabel: "Delete", danger: true }))) return;
            await api.del(`/api/todolists/${l.id}`);
            await refreshSidebarData();
            if (state.view.todoListId === l.id) openFirstAvailable();
          },
        }, "Delete"),
      ]);
    },
  }, "⋮");
  row.appendChild(kebabBtn);
  wireListDrag(row, l);
  return row;
}

async function refreshAfterStructureChange() {
  await refreshSidebarData();
  if (state.view.type === "list" && state.view.todoListId) {
    const l = state.todoLists.find((x) => x.id === state.view.todoListId);
    if (l) state.view.title = l.name;
  }
  renderMain();
}

function openFirstAvailable() {
  if (state.todoLists.length) openTodoList(state.todoLists[0]);
  else { state.view = { type: "list", todoListId: null, title: "Tasks" }; state.tasks = []; renderMain(); renderSidebar(); }
}

/* ---------------------------------------------------------------------- *
 * Navigation
 * ---------------------------------------------------------------------- */
async function openTodoList(list) {
  const project = state.projects.find((p) => p.id === list.project_id);
  state.expanded.add(list.project_id);
  state.view = { type: "list", todoListId: list.id, title: list.name, project };
  state.tasks = await api.get(`/api/tasks?todo_list_id=${list.id}&include_done=${state.showCompleted ? 1 : 0}`);
  renderMain();
  renderSidebar();
}

async function openProjectView(project) {
  state.expanded.add(project.id);
  state.view = { type: "project", projectId: project.id, title: project.name, project };
  state.tasks = await api.get(`/api/tasks?project_id=${project.id}&include_done=${state.showCompleted ? 1 : 0}`);
  renderMain();
  renderSidebar();
}

function renderProjectView(tasks, project) {
  const wrap = el("div", {});
  if (!tasks.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("list"),
      el("div", {}, "Nothing here yet"),
    ]));
    return wrap;
  }

  const byList = new Map();
  for (const t of tasks) {
    const key = t.todo_list_id || "none";
    if (!byList.has(key)) byList.set(key, []);
    byList.get(key).push(t);
  }

  for (const [lid, group] of byList) {
    const list = state.todoLists.find((l) => l.id === lid);
    const groupKey = `project:${lid}`;
    const collapsed = state.collapsedGroups.has(groupKey);
    const caret = el("span", { class: "caret" + (collapsed ? "" : " open") }, "▶");
    const header = el("div", { class: "group-header" }, [
      caret,
      el("span", { class: "ri-label" }, list ? list.name : "No list"),
      el("span", { class: "ri-count" }, String(group.length)),
    ]);
    wrap.appendChild(header);
    const body = el("div", { class: "group-body" + (collapsed ? "" : " expanded") });
    for (const t of group) body.appendChild(taskRow(t));
    wrap.appendChild(body);
    header.addEventListener("click", () => {
      const nowCollapsed = !state.collapsedGroups.has(groupKey);
      if (nowCollapsed) state.collapsedGroups.add(groupKey); else state.collapsedGroups.delete(groupKey);
      caret.classList.toggle("open", !nowCollapsed);
      body.classList.toggle("expanded", !nowCollapsed);
    });
  }
  return wrap;
}

async function openCalendar(year, month) {
  const now = new Date();
  state.calendar.year = year || now.getFullYear();
  state.calendar.month = month || (now.getMonth() + 1);
  state.view = { type: "calendar", title: "Calendar" };
  await loadCalendar();
  renderSidebar();
}

async function loadCalendar() {
  if (state.calendar.mode === "week") {
    const start = state.calendar.weekStart || startOfWeekIso(todayIso());
    state.calendar.weekStart = start;
    const end = addDaysIso(start, 6);
    const [entries, timeByDay, otherByDay] = await Promise.all([
      api.get(`/api/calendar/range?start=${start}&end=${end}`),
      api.get(`/api/calendar/time-by-day?start=${start}&end=${end}`),
      api.get(`/api/other-tasks?start=${start}&end=${end}`),
    ]);
    state.calendar.data = entries;
    state.calendar.timeByDay = timeByDay;
    state.calendar.otherByDay = otherByDay;
  } else {
    const ov = state.calendar.onlyVideos ? "&only_videos=1" : "";
    state.calendar.data = await api.get(`/api/calendar?year=${state.calendar.year}&month=${state.calendar.month}${ov}`);
  }
  renderMain();
}

/* ---------------------------------------------------------------------- *
 * Sponsors — tags, how many (main) tasks carry each one in a given month,
 * and those tasks' due dates.
 * ---------------------------------------------------------------------- */
// Two tabs: "Publication Calendar" (the monthly view below) and "Contracts and
// Billing" (every tag with its contract: download it, or upload one).
function openNotes() {
  state.view = { type: "notes", title: "Notes & Scripts" };
  renderSidebar();
  renderMain();
}

/* ---------------------------------------------------------------------- *
 * Current Video project — the video (main) task whose due date is closest to
 * today, its subtasks laid out as the steps of a timeline.
 * ---------------------------------------------------------------------- */
state.videoProject = { task: null, rootPath: "" };
// Project filter of the view ("" = All projects), remembered between sessions.
try { state.videoProject.projectId = localStorage.getItem("taskplanner-vp-project") || ""; } catch { state.videoProject.projectId = ""; }

async function openVideoProject() {
  state.videoProject.taskId = null;                  // the tile always starts on the video closest to today
  state.view = { type: "videoproject", title: "Current Video project" };
  await loadVideoProject();
  renderSidebar();
}

async function loadVideoProject() {
  try {
    const id = state.videoProject.taskId;
    let pid = state.videoProject.projectId || "";
    if (pid && !(state.projects || []).some((p) => p.id === pid)) { pid = state.videoProject.projectId = ""; }   // project deleted since
    const res = await api.get(`/api/video-project/current?today=${todayIso()}` + (id ? `&id=${encodeURIComponent(id)}` : "") + (pid ? `&project_id=${encodeURIComponent(pid)}` : ""));
    state.videoProject.task = res.task;
    state.videoProject.prevId = res.prev_id;
    state.videoProject.nextId = res.next_id;
    if (!id && !pid) state.currentVideo = res.task;
  } catch (e) { state.videoProject.task = null; }
  try { state.videoProject.rootPath = (await NotesApp.root()) || ""; } catch (e) { state.videoProject.rootPath = ""; }
  if (state.view.type === "videoproject") renderMain();
}

function renderVideoProject() {
  const wrap = el("div", { class: "vp" });
  const task = state.videoProject.task;
  const projectSelect = el("select", { class: "vp-project-filter", title: "Filter by project", style: "width:auto;min-width:170px;margin-left:auto" }, [
    el("option", { value: "" }, "All projects"),
    ...(state.projects || []).map((p) => el("option", { value: p.id, selected: p.id === state.videoProject.projectId || undefined }, p.name)),
  ]);
  projectSelect.value = state.videoProject.projectId || "";
  projectSelect.addEventListener("change", () => {
    state.videoProject.projectId = projectSelect.value;
    state.videoProject.taskId = null;                 // back to the video closest to today within this project
    try { localStorage.setItem("taskplanner-vp-project", projectSelect.value); } catch { /* ignore */ }
    loadVideoProject();
  });
  if (!task) {
    wrap.appendChild(el("div", { class: "vp-head" }, [el("span", { class: "muted" }, "Project"), projectSelect]));
    wrap.appendChild(el("div", { class: "empty-state" }, [el("div", {}, state.videoProject.projectId ? "No open video task with a due date in this project." : "No open video task with a due date.")]));
    return wrap;
  }
  const refresh = () => loadVideoProject();
  const root = (state.videoProject.rootPath || "").replace(/\/$/, "");
  const relOf = (p) => (root && p && p.startsWith(root + "/")) ? p.slice(root.length + 1) : null;
  const noteChip = (icon, label, path) => {
    const rel = relOf(path);
    const name = path.split("/").pop().replace(/\.md$/i, "");
    return rel
      ? el("button", { class: "note-link-chip clickable", type: "button", title: `Open ${path}`, onclick: () => NotesApp.openNote(rel) }, [el("span", {}, `${icon} ${name}`)])
      : el("span", { class: "note-link-chip", title: path }, [el("span", {}, `${icon} ${name}`)]);
  };

  // header
  const due = formatDue(task.due_date);
  const go = (id) => { state.videoProject.taskId = id; loadVideoProject(); };
  wrap.appendChild(el("div", { class: "vp-head" }, [
    el("button", { class: "icon-btn vp-arrow", type: "button", title: "Previous video", disabled: !state.videoProject.prevId || undefined,
      onclick: () => go(state.videoProject.prevId) }, "‹"),
    el("button", { class: "icon-btn vp-arrow", type: "button", title: "Next video", disabled: !state.videoProject.nextId || undefined,
      onclick: () => go(state.videoProject.nextId) }, "›"),
    el("h2", { class: "vp-title", onclick: () => openTaskDetail(task.id), title: "Open the task" }, task.title),
    el("span", { class: "muted" }, `Due ${due.text || task.due_date}`),
    projectSelect,
  ]));

  // main info
  const info = el("div", { class: "vp-info" });
  info.appendChild(el("div", { class: "vp-info-row" }, [
    el("span", { class: "vp-info-label" }, "Note"),
    task.notes_file ? noteChip("📄", "Note", task.notes_file) : el("span", { class: "muted small" }, "none linked"),
  ]));
  if (task.video_note_file) {
    info.appendChild(el("div", { class: "vp-info-row" }, [
      el("span", { class: "vp-info-label" }, "Video note"),
      noteChip("🎬", "Video note", task.video_note_file),
    ]));
  }
  const tags = task.tags || [];
  const mention = el("button", {
    type: "button", class: "vp-mention " + (task.mention_approved ? "done" : "todo"),
    title: "Sponsor mention for this month — click to change (same as “Done” in the Sponsors tab)",
    onclick: async () => { await api.patch(`/api/tasks/${task.id}`, { mention_approved: !task.mention_approved }); refresh(); },
  }, task.mention_approved ? "✓ Mention done" : "Mention not done");
  info.appendChild(el("div", { class: "vp-info-row" }, [
    el("span", { class: "vp-info-label" }, "Sponsor"),
    tags.length
      ? el("span", { class: "chip-row" }, tags.map((g) => el("span", { class: "chip selected" }, [el("span", { class: "swatch", style: `background:${g.color};width:9px;height:9px` }), g.name])))
      : el("span", { class: "muted small" }, "no tag"),
    mention,
  ]));
  wrap.appendChild(info);

  // timeline
  const subs = [...(task.subtasks || [])].sort((a, b) =>
    (a.due_date || "9999").localeCompare(b.due_date || "9999") || (a.start_time || "99:99").localeCompare(b.start_time || "99:99") || (a.sort_order || 0) - (b.sort_order || 0));
  const line = el("div", { class: "vp-timeline" });
  for (const s of subs) {
    const done = !!s.checked;
    const d = s.due_date ? formatDue(s.due_date).text : "";
    const head = el("div", { class: "vp-step-head" }, [
      el("div", {
        class: "checkbox small" + (done ? " checked" : ""),
        onclick: async () => { await api.post(`/api/subtasks/${s.id}/toggle`, { checked: !done }); refresh(); },
      }, done ? "✓" : ""),
      el("span", { class: "vp-step-title" + (done ? " done" : "") }, s.title),
      el("span", { class: "muted small" }, [d, s.start_time || ""].filter(Boolean).join(" · ")),
      el("span", { class: "vp-step-status " + (done ? "done" : "todo") }, done ? "Completed" : "To do"),
    ]);
    const body = el("div", { class: "vp-step-body" });
    if (done) {
      body.appendChild(el("span", { class: "muted small" }, `Time spent: ${formatElapsed(s.time_spent_seconds || 0)}`));
    } else {
      body.appendChild(timerControls(s, "subtasks", refresh));
      for (const b of subtaskAIButtons(s.title, task, s.template_sub_id)) {
        body.appendChild(el("button", {
          type: "button", class: "btn ai-btn",
          onclick: (e) => (b.kind === "list_to_ppt" ? openListToPptModal(s.id, b.label)
            : b.kind === "powerpoint" || b.endpoint === "generate-pptx"
            ? openGeneratePptxModal(s.id, b.label)
            : runSubtaskAI(e.currentTarget, s.id, b.endpoint, b.label, b.buttonId)),
        }, `✨ ${b.label}`));
      }
    }
    line.appendChild(el("div", { class: "vp-step" + (done ? " done" : "") }, [el("span", { class: "vp-dot" }), head, body]));
  }
  if (!subs.length) line.appendChild(el("div", { class: "muted" }, "This task has no subtasks."));
  wrap.appendChild(line);
  return wrap;
}

async function openSponsorsView(year, month) {
  const now = new Date();
  state.sponsors.year = year || state.sponsors.year || now.getFullYear();
  state.sponsors.month = month || state.sponsors.month || (now.getMonth() + 1);
  state.view = { type: "sponsors", title: "Sponsors" };
  if (state.sponsors.tab === "contracts") await loadSponsorContracts();
  else await loadSponsorsReport();
  renderSidebar();
}

async function loadSponsorContracts() {
  state.sponsors.contracts = await api.get("/api/tags/contracts");
  renderMain();
}

function setSponsorsTab(tab) {
  state.sponsors.tab = tab;
  if (tab === "contracts") loadSponsorContracts();
  else loadSponsorsReport();
}

function sponsorsTabs() {
  const tab = state.sponsors.tab || "calendar";
  return el("div", { class: "sponsors-tabs" }, [
    el("div", { class: "seg" }, [
      ["calendar", "Publication Calendar"],
      ["contracts", "Contracts and Billing"],
    ].map(([key, label]) => el("button", {
      type: "button",
      class: "seg-btn" + (tab === key ? " active" : ""),
      onclick: () => { if (tab !== key) setSponsorsTab(key); },
    }, label))),
  ]);
}

function renderSponsorContracts() {
  const wrap = el("div", {});
  const tags = state.sponsors.contracts || [];
  if (!tags.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("megaphone"),
      el("div", {}, "No tags yet — add some from a task's tag picker"),
    ]));
    return wrap;
  }
  const list = el("div", { class: "contract-list" });
  for (const tag of tags) {
    const has = !!tag.has_contract;
    const info = [];
    if (has) {
      info.push(tag.total_videos != null ? `${tag.total_videos} video${tag.total_videos === 1 ? "" : "s"}` : "No video total");
      info.push(tag.end_date ? `Ends ${formatDateDisplay(tag.end_date)}` : "No end date");
    }
    if (tag.billing_period) {
      const kind = tag.amount_type === "per_video" ? " per video" : tag.amount_type === "fixed" ? " fixed" : "";
      info.push(`${tag.billing_period === "quarterly" ? "Quarterly" : "Monthly"}${tag.amount ? ` · ${tag.amount}${kind}` : ""}`);
    }
    const download = has
      ? el("a", {
          class: "icon-btn contract-btn",
          href: `/api/tags/${tag.id}/contract`,
          download: tag.file_name || "contract",
          title: `Download the contract (${tag.file_name})`,
        }, [symbolicIcon("download")])
      : null;
    const gear = el("button", {
      type: "button",
      class: "icon-btn contract-btn" + (has ? "" : " none"),
      title: has ? "Contract settings" : "No contract yet — add one",
      "aria-label": "Contract settings",
      onclick: () => openContractSheet(tag),
    }, [symbolicIcon("gear")]);
    const action = el("span", { class: "contract-actions" }, [download, gear]);
    list.appendChild(el("div", { class: "sponsor-tag-card contract-row" }, [
      el("span", { class: "dot", style: `background:${tag.color}` }),
      el("span", { class: "sponsor-tag-name" }, tag.name),
      el("span", { class: "contract-info muted small" }, info.join(" · ")),
      action,
    ]));
  }
  wrap.appendChild(list);
  return wrap;
}

// The contract sheet (gear button): file, video total and end date.
function openContractSheet(tag) {
  const has = !!tag.has_contract;
  const file = el("input", { type: "file", class: has ? "hidden" : "" });
  const videos = el("input", { type: "number", min: "0", step: "1", placeholder: "Leave empty if unknown" });
  const endDate = el("input", { type: "date" });
  if (has) { videos.value = tag.total_videos != null ? tag.total_videos : ""; endDate.value = tag.end_date || ""; }
  // billing: Monthly / Quarterly invoices, Per video / Fixed amount (see "Invoices" tasks created at month / quarter end)
  const period = el("select", {}, [el("option", { value: "" }, "— No automatic invoice —"), el("option", { value: "monthly" }, "Monthly"), el("option", { value: "quarterly" }, "Quarterly")]);
  const amountType = el("select", {}, [el("option", { value: "per_video" }, "Per video"), el("option", { value: "fixed" }, "Fixed")]);
  const amount = el("input", { type: "text", placeholder: "e.g. 500 (empty = invoice without amount)", maxlength: "40", autocomplete: "off" });
  period.value = tag.billing_period || "";
  amountType.value = tag.amount_type || "per_video";
  amount.value = tag.amount || "";
  const paintBilling = () => { amountType.disabled = amount.disabled = !period.value; };
  period.addEventListener("change", paintBilling);
  paintBilling();
  const save = el("button", {
    class: "btn primary",
    onclick: async () => {
      const fd = new FormData();
      if (file.files[0]) fd.append("file", file.files[0]);
      fd.append("total_videos", videos.value);
      fd.append("end_date", endDate.value);
      fd.append("billing_period", period.value);
      fd.append("amount_type", period.value ? amountType.value : "");
      fd.append("amount", period.value ? amount.value : "");
      save.disabled = true;
      try {
        await api.postForm(`/api/tags/${tag.id}/contract`, fd);
        closeModal();
        showToast(has ? `Contract updated for ${tag.name}` : `Contract added for ${tag.name}`);
        await loadSponsorContracts();
      } catch (e) {
        let msg = "Couldn't save the contract.";
        try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
        showToast(msg);
      } finally { save.disabled = false; }
    },
  }, "Save");
  // when a file is already stored: its name, plus icon-only download / replace buttons
  const fileName = el("span", { class: "contract-file-name" }, tag.file_name || "");
  file.addEventListener("change", () => {
    if (has) fileName.textContent = file.files[0] ? `${file.files[0].name} (will replace ${tag.file_name})` : tag.file_name;
  });
  const fileField = has
    ? el("div", { class: "contract-file-row" }, [
        symbolicIcon("notes"), fileName,
        el("a", { class: "icon-btn contract-btn", href: `/api/tags/${tag.id}/contract`, download: tag.file_name || "contract",
          title: "Download the contract", "aria-label": "Download the contract" }, [symbolicIcon("download")]),
        el("button", { type: "button", class: "icon-btn contract-btn", title: "Replace the file", "aria-label": "Replace the file",
          onclick: () => file.click() }, [symbolicIcon("upload")]),
        file,
      ])
    : file;
  openModal(`Contract — ${tag.name}`, [
    el("div", { class: "field" }, [el("label", {}, "Contract file (optional)"), fileField]),
    el("div", { class: "field" }, [el("label", {}, "Total number of videos (optional)"), videos]),
    el("div", { class: "field" }, [el("label", {}, "End date (optional)"), endDate]),
    el("div", { class: "field" }, [el("label", {}, "Billing"), period]),
    el("div", { class: "field" }, [el("label", {}, "Amount type"), amountType]),
    el("div", { class: "field" }, [el("label", {}, "Amount"), amount]),
    el("div", { class: "muted small" }, "At the end of each month (or quarter) an “Invoices …” task is created in The Linux EXP / Tasks with one “Invoice <sponsor> <amount>” subtask. Per video: finished videos tagged with this sponsor and due in the period × the amount. Fixed: the amount as is."),
  ], [el("button", { class: "btn", onclick: closeModal }, "Cancel"), save]);
}

async function loadSponsorsReport() {
  const { year, month } = state.sponsors;
  state.sponsors.data = await api.get(`/api/tags/monthly-report?year=${year}&month=${month}`);
  try { state.sponsors.hidden = (await api.get("/api/sponsors/hidden")).hidden || []; } catch (_) { /* keep what we had */ }
  renderMain();
}

function navSponsorsMonth(delta) {
  let { year, month } = state.sponsors;
  month += delta;
  if (month < 1) { month = 12; year -= 1; }
  else if (month > 12) { month = 1; year += 1; }
  state.sponsors.year = year;
  state.sponsors.month = month;
  loadSponsorsReport();
}

function renderSponsorsView() {
  if (state.sponsors.tab === "contracts") {
    const box = el("div", {}, [sponsorsTabs(), renderSponsorContracts()]);
    return box;
  }
  const { year, month, data } = state.sponsors;
  const wrap = el("div", {});
  wrap.appendChild(sponsorsTabs());

  const hiddenSet = new Set(state.sponsors.hidden || []);
  const hiddenCount = data.filter((t) => hiddenSet.has(t.id)).length;
  wrap.appendChild(el("div", { class: "calendar-header" }, [
    el("button", { class: "icon-btn", onclick: () => navSponsorsMonth(-1) }, "‹"),
    el("h2", {}, `${MONTH_NAMES[month - 1]} ${year}`),
    el("button", { class: "icon-btn", onclick: () => navSponsorsMonth(1) }, "›"),
    el("button", { class: "btn small", style: "margin-left:auto", title: "Choose which sponsors are shown",
      onclick: openSponsorFilter }, hiddenCount ? `Filter (${hiddenCount} hidden)` : "Filter"),
  ]));

  if (!data.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("megaphone"),
      el("div", {}, "No tags yet — add some from a task's tag picker"),
    ]));
    return wrap;
  }
  const visible = data.filter((t) => !hiddenSet.has(t.id));
  if (!visible.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("megaphone"),
      el("div", {}, "All sponsors are hidden"),
      el("button", { class: "btn small", onclick: openSponsorFilter }, "Change the filter"),
    ]));
    return wrap;
  }

  const list = el("div", { class: "sponsor-tag-list" });
  for (const tag of visible) {
    const card = el("div", { class: "sponsor-tag-card" }, [
      el("div", { class: "sponsor-tag-head" }, [
        el("span", { class: "dot", style: `background:${tag.color}` }),
        el("span", { class: "sponsor-tag-name" }, tag.name),
        el("span", { class: "sponsor-tag-count" }, `${tag.count} this month`),
      ]),
    ]);
    if (tag.tasks.length) {
      const dueList = el("div", { class: "sponsor-tag-dues" });
      for (const t of tag.tasks) {
        const row = el("div", { class: "sponsor-tag-due-item" });
        row.appendChild(el("div", {
          class: "sponsor-tag-due-row",
          onclick: () => openTaskDetail(t.id),
        }, [
          el("span", { class: "sponsor-due-date" }, formatDue(t.due_date).text || t.due_date),
          el("span", { class: "sponsor-due-title" + (t.checked ? " done" : "") }, t.title),
          t.checked ? el("span", { class: "sponsor-due-check", title: "Done" }, "✓") : null,
        ]));

        const daysUntil = Math.round((parseIso(t.due_date) - parseIso(todayIso())) / 86400000);
        if (!t.checked && !t.mention_approved && daysUntil <= 14) {
          const alert = el("div", { class: "sponsor-mention-alert" }, [
            el("span", {}, "Do you have the mention done and approved?"),
            el("button", {
              class: "btn small",
              title: 'Creates a task in "Other tasks", due today, 0.5h estimated',
              onclick: async (e) => {
                e.stopPropagation();
                await api.post("/api/sponsors/create-mention-task", { sponsor_name: tag.name });
                showToast(`Task created: "Create sponsored mention for ${tag.name}"`);
              },
            }, "Create Task"),
            el("button", {
              class: "btn primary small",
              onclick: async (e) => {
                e.stopPropagation();
                await api.patch(`/api/tasks/${t.id}`, { mention_approved: true });
                alert.remove();
              },
            }, "Done"),
          ]);
          row.appendChild(alert);
        }
        dueList.appendChild(row);
      }
      card.appendChild(dueList);
    }
    list.appendChild(card);
  }
  wrap.appendChild(list);
  return wrap;
}

// Modal: tick the sponsors to show. Saved on the server as soon as it changes.
function openSponsorFilter() {
  const data = state.sponsors.data || [];
  const hidden = new Set(state.sponsors.hidden || []);
  const save = async () => {
    state.sponsors.hidden = [...hidden];
    try { await api.send("PUT", "/api/sponsors/hidden", { hidden: [...hidden] }); }
    catch (_) { showToast("Could not save the filter"); }
    renderMain();
  };
  const boxes = [];
  const list = el("div", { class: "sponsor-filter-list" });
  for (const t of [...data].sort((a, b) => a.name.localeCompare(b.name))) {
    const cb = el("input", { type: "checkbox" });
    cb.checked = !hidden.has(t.id);
    cb.addEventListener("change", () => { if (cb.checked) hidden.delete(t.id); else hidden.add(t.id); save(); });
    boxes.push([t, cb]);
    list.appendChild(el("label", { class: "sponsor-filter-row" }, [
      cb, el("span", { class: "dot", style: `background:${t.color}` }), el("span", {}, t.name),
    ]));
  }
  const setAll = (show) => { for (const [t, cb] of boxes) { cb.checked = show; if (show) hidden.delete(t.id); else hidden.add(t.id); } save(); };
  openModal("Sponsors shown", [
    el("div", { class: "row", style: "display:flex;gap:8px;margin-bottom:10px" }, [
      el("button", { class: "btn small", onclick: () => setAll(true) }, "Show all"),
      el("button", { class: "btn small", onclick: () => setAll(false) }, "Hide all"),
    ]),
    data.length ? list : el("div", { class: "muted" }, "No sponsors yet."),
  ], [el("button", { class: "btn primary", onclick: closeModal }, "Done")]);
}

async function refreshCurrentView() {
  await refreshSidebarData();
  if (state.view.type === "list" && state.view.todoListId) {
    state.tasks = await api.get(`/api/tasks?todo_list_id=${state.view.todoListId}&include_done=${state.showCompleted ? 1 : 0}`);
    renderMain();
  } else if (state.view.type === "calendar") {
    await loadCalendar();
  } else if (state.view.type === "smart") {
    await loadSmartTasks(state.view.smartType);
    renderMain();
  } else if (state.view.type === "videoproject") {
    await loadVideoProject();
  }
}

/* ---------------------------------------------------------------------- *
 * Main content rendering
 * ---------------------------------------------------------------------- */
function renderMain() {
  document.getElementById("pageTitle").textContent = state.view.title;
  document.getElementById("pageSubtitle").textContent =
    (state.view.type === "list" && state.view.project) ? `in ${state.view.project.name}`
    : (state.view.type === "fiscal" ? (state.view.subtitle || "") : "");
  const fab = document.getElementById("fab");
  if (fab) fab.style.display = (state.view.type === "fiscal" || state.view.type === "templates") ? "none" : "";   // "quick add task" makes no sense on a finance page
  const showHeaderQuickAdd = state.view.type === "list";
  document.getElementById("quickAddRow").style.display = showHeaderQuickAdd ? "flex" : "none";

  renderHeaderActions();

  const root = document.getElementById("viewRoot");
  document.getElementById("contentScroll").classList.toggle("notes-mode", state.view.type === "notes");
  if (state.view.type === "notes") {
    // keep the open editor alive across incidental re-renders
    if (root.firstElementChild && root.firstElementChild.id === "notesHost") return;
    root.innerHTML = "";
    const host = el("div", { id: "notesHost", class: "notes-host" });
    root.appendChild(host);
    NotesApp.mount(host, { toast: showToast, confirm: confirmModal, prompt: promptModal });
    return;
  }
  root.innerHTML = "";

  if (state.view.type === "calendar") { root.appendChild(renderCalendar()); return; }
  if (state.view.type === "fiscal") { renderFiscalView(root); return; }
  if (state.view.type === "smart") {
    root.appendChild(renderSmartView(state.view.smartType, state.tasks, state.orphanSubtasks, state.orphanParents));
    return;
  }
  if (state.view.type === "project") {
    root.appendChild(renderProjectView(state.tasks, state.view.project));
    return;
  }
  if (state.view.type === "sponsors") {
    root.appendChild(renderSponsorsView());
    return;
  }
  if (state.view.type === "videoproject") {
    root.appendChild(renderVideoProject());
    return;
  }
  if (state.view.type === "timereport") {
    root.appendChild(renderTimeReport());
    return;
  }
  if (state.view.type === "revenue") {
    root.appendChild(renderRevenue());
    return;
  }
  if (state.view.type === "backups") {
    root.appendChild(renderBackupsView());
    return;
  }
  if (state.view.type === "templates") {
    root.appendChild(renderTemplatesView());
    return;
  }
  // list view
  if (!state.view.todoListId) {
    root.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("list"),
      el("div", {}, "Create a project and a list to get started"),
    ]));
    return;
  }
  root.appendChild(renderTaskList(state.tasks, { emptyText: "Nothing here yet", emptyIcon: "checkCircle" }));
}

function showCompletedToggle(onToggle) {
  return el("label", { class: "toggle-inline completed-toggle" + (state.showCompleted ? " on" : "") }, [
    el("input", {
      type: "checkbox",
      checked: state.showCompleted ? "checked" : null,
      onchange: async (e) => {
        state.showCompleted = e.target.checked;
        e.target.closest("label").classList.toggle("on", e.target.checked);
        await onToggle();
      },
    }),
    el("span", {}, "Show completed"),
  ]);
}

/* ---------------------------------------------------------------------- *
 * Auto order: gives start times to today's untimed tasks/subtasks, filling
 * the free time of today's grid from the current time on (up to HOUR_END), in list order with
 * urgent ones first. Tasks that already have a start time never move,
 * nothing is placed over them or inside the AUTO_BREAK window, due dates are
 * never touched. What it placed is remembered so Revert can clear exactly
 * those start times again.
 * ---------------------------------------------------------------------- */
const AUTO_BREAK = [9 * 60 + 45, 10 * 60 + 15];   // nothing placed between 9:45 and 10:15
const AUTO_DEFAULT_MINUTES = 30;                  // for tasks with no estimated duration

function autoOrderKey() { return "taskplanner.autoOrder." + todayIso(); }
function loadAutoOrdered() {
  try { return JSON.parse(localStorage.getItem(autoOrderKey()) || "[]"); } catch { return []; }
}
function saveAutoOrdered(list) {
  try {
    if (list.length) localStorage.setItem(autoOrderKey(), JSON.stringify(list));
    else localStorage.removeItem(autoOrderKey());
  } catch { /* storage unavailable: Revert just won't be offered */ }
}

async function autoOrderToday() {
  const today = todayIso();
  const entries = (await api.get(`/api/calendar/range?start=${today}&end=${today}`))[today] || [];
  const busy = entries.filter((t) => t.start_time)
    .map((t) => { const a = timeToMinutes(t.start_time); return [a, a + (t.duration_minutes || AUTO_DEFAULT_MINUTES)]; });
  busy.push(AUTO_BREAK);

  const todo = entries.filter((t) => !t.start_time && !t.checked && !t.is_projected && !t.is_completed_occurrence);
  // urgent first; otherwise keep the order they appear in the list
  todo.sort((a, b) => (b.urgent ? 1 : 0) - (a.urgent ? 1 : 0));

  const placed = [];
  // never earlier than the moment the button is pressed (rounded up to 5 min)
  const nowD = new Date();
  let cursor = Math.max(HOUR_START * 60, Math.ceil((nowD.getHours() * 60 + nowD.getMinutes()) / 5) * 5), skipped = 0;
  for (const t of todo) {
    const dur = t.duration_minutes || AUTO_DEFAULT_MINUTES;
    let start = Math.ceil(cursor / 5) * 5;
    for (let moved = true; moved;) {
      moved = false;
      for (const [a, b] of busy) {
        if (start < b && start + dur > a) { start = Math.ceil(b / 5) * 5; moved = true; }
      }
    }
    if (start + dur > HOUR_END * 60) { skipped++; continue; }
    placed.push({ id: t.id, isSubtask: !!t.is_subtask, start });
    busy.push([start, start + dur]);
    cursor = start + dur;
  }

  for (const c of placed) {
    await api.patch(c.isSubtask ? `/api/subtasks/${c.id}` : `/api/tasks/${c.id}`, { start_time: minutesToTime(c.start) });
  }
  const prev = loadAutoOrdered();
  saveAutoOrdered(prev.concat(placed.map((c) => ({ id: c.id, isSubtask: c.isSubtask }))));
  showToast(placed.length
    ? `Placed ${placed.length} task(s)` + (skipped ? `, ${skipped} didn't fit before ${HOUR_END}:00` : "")
    : (skipped ? `Nothing fit before ${HOUR_END}:00` : "Nothing to place"));
  renderHeaderActions();
  await loadCalendar();
}

async function revertAutoOrder() {
  const list = loadAutoOrdered();
  for (const c of list) {
    try { await api.patch(c.isSubtask ? `/api/subtasks/${c.id}` : `/api/tasks/${c.id}`, { start_time: null }); }
    catch { /* task deleted since: nothing to undo */ }
  }
  saveAutoOrdered([]);
  showToast(`Removed start times from ${list.length} task(s)`);
  renderHeaderActions();
  await loadCalendar();
}

/* ---------------------------------------------------------------------- *
 * Templates (Utilities > Templates) -- edit the task templates behind the "+"
 * menu (main task title, icons, main day, subtasks with duration / day offset /
 * start time, linked-note name) and create new ones. A change only affects
 * tasks created from the template afterwards.
 * ---------------------------------------------------------------------- */
const WEEKDAY_LONG = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

function wireTemplates() {
  document.getElementById("templatesBtn").addEventListener("click", openTemplatesView);
}

function tplEmptyDraft() {
  return { key: null, label: "", icon: "🎥", menu_icon: "🎥", task_title: "", main_weekday: 2, is_video: true,
           note_title: "", builtin: false, subtasks: [{ title: "", duration: 30, offset_days: 0, start_time: null }] };
}
function tplSelect(key) {
  const t = templateByKey(key);
  state.tplEditor = { key: t ? t.key : null, draft: t ? JSON.parse(JSON.stringify(t)) : null, dirty: false, isNew: false };
}
async function openTemplatesView() {
  state.view = { type: "templates", title: "Templates" };
  await refreshTemplates();
  const cur = state.tplEditor;
  if (!(cur.isNew || (cur.key && templateByKey(cur.key)))) tplSelect(state.templates[0] ? state.templates[0].key : null);
  renderMain();
  renderSidebar();
}
function tplErrorMessage(e) {
  let m = (e && e.message) || "Something went wrong";
  try { m = JSON.parse(m).error || m; } catch { /* not JSON */ }
  return m;
}
async function tplConfirmDiscard() {
  if (!state.tplEditor.dirty) return true;
  return confirmModal({ title: "Discard changes?", message: "This template has unsaved changes.", confirmLabel: "Discard", danger: true });
}

// Dates a template would produce if used right now (same rule as the server).
function tplPreview(draft) {
  if (draft.main_weekday === null || draft.main_weekday === undefined) return null;
  const now = new Date(); now.setHours(0, 0, 0, 0);
  const ahead = ((draft.main_weekday + 1) - ((now.getDay() + 6) % 7 + 1) + 7) % 7 || 7;   // Mon=0..Sun=6
  const base = new Date(now); base.setDate(base.getDate() + ahead);
  const fmt = (d) => d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
  const month = base.toLocaleString("en-GB", { month: "long" }), pad = (n) => String(n).padStart(2, "0");
  const title = (draft.task_title || "")
    .replaceAll("{dd}", pad(base.getDate())).replaceAll("{mm}", pad(base.getMonth() + 1)).replaceAll("{month}", month)
    .replaceAll("{yyyy}", String(base.getFullYear())).replaceAll("{yy}", pad(base.getFullYear() % 100));
  return {
    main: fmt(base), title,
    subs: draft.subtasks.map((s) => {
      if (s.offset_days === null || s.offset_days === undefined || s.offset_days === "") return "no date";
      const d = new Date(base); d.setDate(d.getDate() + Number(s.offset_days));
      return fmt(d);
    }),
  };
}

// Editor for the AI buttons of one template subtask (shown under its row).
function tplAiPanel(s, touch, repaint) {
  s.ai_buttons = s.ai_buttons || [];
  const box = el("div", { class: "tpl-ai" });
  box.appendChild(el("div", { class: "muted small" },
    "Buttons shown on this subtask in tasks created from the template. Placeholders usable in the instructions: {title} (task), {subtask}, {due_date}."));
  s.ai_buttons.forEach((b, k) => {
    b.sources = b.sources || { note_sections: [], task_notes: false };
    const card = el("div", { class: "tpl-ai-card" });
    const set = (fn) => { fn(); touch(); };
    const label = el("input", { type: "text", value: b.label || "", placeholder: "Button title", maxlength: "60" });
    label.addEventListener("input", () => set(() => { b.label = label.value; }));
    const kind = el("select", {}, [el("option", { value: "prompt" }, "Ask Claude (instructions)"), el("option", { value: "powerpoint" }, "PowerPoint generator"), el("option", { value: "list_to_ppt" }, "Army list to PowerPoint (Warhammer)"), el("option", { value: "chapters" }, "Chapters from Resolve swooshes"), el("option", { value: "capture" }, "Take captures (VIDEO note)"), el("option", { value: "montage" }, "Base edit in Resolve"), el("option", { value: "timestamps" }, "Timestamps from Resolve (VIDEO note)"), el("option", { value: "text_timestamps" }, "Timestamps + text boxes from Resolve (task note)"), el("option", { value: "thumbnails" }, "Create 3 thumbnails")]);
    kind.value = b.kind || "prompt";
    kind.addEventListener("change", () => { b.kind = kind.value; touch(); repaint(); });
    card.appendChild(el("div", { class: "tpl-ai-head" }, [
      label, kind,
      el("button", { class: "icon-btn small", title: "Remove this button", onclick: () => { s.ai_buttons.splice(k, 1); touch(); repaint(); } }, "✕"),
    ]));
    if (b.kind === "chapters") {
      card.appendChild(el("div", { class: "muted small" }, "Reads the “swoosh” clips on track A2 of the timeline open in DaVinci Resolve, then rewrites the linked note: seconds before each topic in Timestamps (Intro = 0) and MM:SS before each topic in Links. Only the title is configurable."));
    } else if (b.kind === "thumbnails") {
      card.appendChild(el("div", { class: "muted small" }, "Runs “Generate ideas”, then builds 3 thumbnails (1920×1080 PNG) in your usual style: one “Linux & Open Source News”, two with a headline from the ideas and the “Linux Weekly News” label. Logos are downloaded from the web (never AI-generated). Only the title is configurable."));
    } else if (b.kind === "timestamps") {
      card.appendChild(el("div", { class: "muted small" }, "Reads the “swoosh” clips on track A2 of the timeline open in DaVinci Resolve (the one starting with the “Outro new” clip is ignored) and writes MM:SS before each topic in the Timestamps section of the task's “-VIDEO” note (Intro = 00:00; “Sponsor…” lines count as topics and get their own timestamp). Only the title is configurable."));
    } else if (b.kind === "text_timestamps") {
      card.appendChild(el("div", { class: "muted small" }, "Reads the “swoosh” clips on track A2 of the timeline open in DaVinci Resolve and, for each one, the text of the nearest text box on V1, V2 or V3, then writes “MM:SS text” lines in the Timestamps section of the task's linked note (previous lines of this kind are replaced). Only the title is configurable."));
    } else if (b.kind === "capture") {
      card.appendChild(el("div", { class: "muted small" }, "Runs the screenshot script (news_capture.py) on the task's “-VIDEO” note, then shows “Captures finished”. Only the title is configurable."));
    } else if (b.kind === "montage") {
      card.appendChild(el("div", { class: "muted small" }, "Runs the editing script (resolve_build_news.py) on the timeline open in DaVinci Resolve, using the captures of the task's “-VIDEO” note. No message when done. Only the title is configurable."));
    } else if (b.kind === "list_to_ppt") {
      card.appendChild(el("div", { class: "muted small" }, "Opens a dialog to paste a Warhammer 40,000 army list (Games Workshop app format), then builds a PowerPoint in your template: detachment rule, stratagems (3 per slide), force dispositions, one slide per unit, characters attached to their unit. Rules come from Wahapedia, in French. Only the title is configurable."));
    } else if ((b.kind || "prompt") === "powerpoint") {
      card.appendChild(el("div", { class: "muted small" }, "Opens the PowerPoint generator (links, document, prompt). Only the title is configurable."));
    } else {
      const ins = el("textarea", { rows: "8", placeholder: "What should Claude do? e.g. “Write 3 title ideas from the notes below…”", maxlength: "20000" });
      ins.value = b.instructions || "";
      ins.addEventListener("input", () => set(() => { b.instructions = ins.value; }));
      const sys = el("textarea", { rows: "2", placeholder: "Optional system prompt (Claude's role). Empty = YouTube channel assistant.", maxlength: "2000" });
      sys.value = b.system || "";
      sys.addEventListener("input", () => set(() => { b.system = sys.value; }));
      const mode = el("select", {}, [
        el("option", { value: "none" }, "No note content"),
        el("option", { value: "all" }, "Whole linked note"),
        el("option", { value: "sections" }, "Only these note sections"),
      ]);
      const secs = b.sources.note_sections;
      mode.value = secs === "all" ? "all" : (secs && secs.length ? "sections" : "none");
      const secInput = el("input", { type: "text", placeholder: "Timestamps, Links, Content", value: Array.isArray(secs) ? secs.join(", ") : "" });
      secInput.style.display = mode.value === "sections" ? "" : "none";
      mode.addEventListener("change", () => {
        b.sources.note_sections = mode.value === "all" ? "all" : (mode.value === "none" ? [] : secInput.value.split(",").map((x) => x.trim()).filter(Boolean));
        secInput.style.display = mode.value === "sections" ? "" : "none";
        touch();
      });
      secInput.addEventListener("input", () => set(() => { b.sources.note_sections = secInput.value.split(",").map((x) => x.trim()).filter(Boolean); }));
      const notes = el("input", { type: "checkbox", checked: b.sources.task_notes || undefined });
      notes.addEventListener("change", () => set(() => { b.sources.task_notes = notes.checked; }));
      const apply = el("input", { type: "checkbox", checked: b.apply_to_note || undefined });
      apply.addEventListener("change", () => set(() => { b.apply_to_note = apply.checked; }));
      const post = el("select", {}, [el("option", { value: "none" }, "Show the answer as is"), el("option", { value: "youtube_tags" }, "YouTube tags (clean up, max 500 characters)")]);
      post.value = b.post || "none";
      post.addEventListener("change", () => set(() => { b.post = post.value; }));
      card.appendChild(el("div", { class: "field" }, [el("label", {}, "Instructions for Claude"), ins]));
      card.appendChild(el("div", { class: "field" }, [el("label", {}, "System prompt (optional)"), sys]));
      card.appendChild(el("div", { class: "tpl-ai-opts" }, [
        el("div", { class: "field" }, [el("label", {}, "Send the linked note"), mode, secInput]),
        el("div", { class: "field" }, [el("label", {}, "After the answer"), post]),
      ]));
      card.appendChild(el("label", { class: "tpl-check" }, [notes, el("span", {}, "Also send the task's Notes field")]));
      card.appendChild(el("label", { class: "tpl-check" }, [apply, el("span", {}, "Offer “Replace / Append to note” (the answer must keep the same ## headings)")]));
    }
    box.appendChild(card);
  });
  if (s.ai_buttons.length < 6) box.appendChild(el("button", {
    class: "btn small",
    onclick: () => {
      s.ai_buttons.push({ id: "", label: "", kind: "prompt", instructions: "", system: "", sources: { note_sections: [], task_notes: false }, apply_to_note: false, post: "none" });
      touch(); repaint();
    },
  }, "＋ Add an AI button"));
  return box;
}

function renderTemplatesView() {
  const ed = state.tplEditor;
  const wrap = el("div", { class: "tpl-wrap" });

  /* -- left: list -- */
  const list = el("div", { class: "tpl-list" });
  list.appendChild(el("button", {
    class: "btn primary", style: "width:100%;margin-bottom:10px",
    onclick: async () => {
      if (!(await tplConfirmDiscard())) return;
      state.tplEditor = { key: null, draft: tplEmptyDraft(), dirty: true, isNew: true };
      renderMain();
    },
  }, "＋ New template"));
  state.templates.forEach((t, i) => {
    const move = async (dir) => {
      const keys = state.templates.map((x) => x.key);
      const j = i + dir;
      if (j < 0 || j >= keys.length) return;
      [keys[i], keys[j]] = [keys[j], keys[i]];
      state.templates = await api.send("PUT", "/api/template-order", { keys });
      renderMain();
    };
    list.appendChild(el("div", {
      class: "tpl-row" + (!ed.isNew && ed.key === t.key ? " active" : ""),
      onclick: async () => {
        if (!ed.isNew && ed.key === t.key) return;
        if (!(await tplConfirmDiscard())) return;
        tplSelect(t.key);
        renderMain();
      },
    }, [
      el("span", { class: "tpl-row-icon" }, t.menu_icon || t.icon || "🎥"),
      el("span", { class: "tpl-row-label" }, [t.label, t.builtin ? el("span", { class: "tpl-tag" }, "built-in") : null]),
      el("span", { class: "tpl-row-move" }, [
        el("button", { class: "icon-btn small", title: "Move up", disabled: i === 0 || undefined, onclick: (e) => { e.stopPropagation(); move(-1); } }, "↑"),
        el("button", { class: "icon-btn small", title: "Move down", disabled: i === state.templates.length - 1 || undefined, onclick: (e) => { e.stopPropagation(); move(1); } }, "↓"),
      ]),
    ]));
  });
  if (ed.isNew) list.appendChild(el("div", { class: "tpl-row active" }, [
    el("span", { class: "tpl-row-icon" }, ed.draft.menu_icon || "🎥"),
    el("span", { class: "tpl-row-label" }, [ed.draft.label || "New template", el("span", { class: "tpl-tag" }, "unsaved")]),
  ]));
  wrap.appendChild(list);

  /* -- right: editor -- */
  const d = ed.draft;
  const editor = el("div", { class: "tpl-editor" });
  if (!d) {
    editor.appendChild(el("div", { class: "empty-state" }, [el("div", {}, "No template yet — create one with “New template”.")]));
    wrap.appendChild(editor);
    return wrap;
  }

  const saveBtn = el("button", { class: "btn primary" }, "Save");
  const dirtyNote = el("span", { class: "muted small tpl-dirty" }, "");
  const preview = el("div", { class: "tpl-preview muted small" });
  const paintMeta = () => {
    saveBtn.disabled = !ed.dirty;
    dirtyNote.textContent = ed.dirty ? "Unsaved changes" : "";
    const pv = tplPreview(d);
    preview.innerHTML = "";
    if (!pv) { preview.textContent = "No main day: the task and its subtasks are created with no due date; you schedule them yourself."; return; }
    preview.appendChild(el("div", {}, `If created now: “${pv.title || "…"}” on ${pv.main}`));
    d.subtasks.forEach((s, i) => preview.appendChild(el("div", { style: "padding-left:12px" },
      `• ${s.title || "…"} — ${pv.subs[i]}${s.start_time ? " at " + s.start_time : ""}${s.duration ? " (" + formatDuration(s.duration) + ")" : ""}`)));
  };
  const touch = () => { ed.dirty = true; paintMeta(); };
  const bind = (input, key, conv) => { input.addEventListener("input", () => { d[key] = conv ? conv(input.value) : input.value; touch(); }); return input; };
  const field = (label, input, hint) => el("div", { class: "field" }, [el("label", {}, label), input, hint ? el("div", { class: "muted small", style: "margin-top:3px" }, hint) : null]);

  const weekdaySelect = el("select", {}, [
    el("option", { value: "" }, "None — no automatic due date"),
    ...WEEKDAY_LONG.map((n, i) => el("option", { value: String(i) }, n)),
  ]);
  weekdaySelect.value = d.main_weekday === null || d.main_weekday === undefined ? "" : String(d.main_weekday);
  weekdaySelect.addEventListener("change", () => { d.main_weekday = weekdaySelect.value === "" ? null : Number(weekdaySelect.value); touch(); });
  const isVideo = el("input", { type: "checkbox", checked: d.is_video || undefined });
  isVideo.addEventListener("change", () => { d.is_video = isVideo.checked; touch(); });

  editor.appendChild(el("div", { class: "tpl-grid" }, [
    field("Template name", bind(el("input", { type: "text", value: d.label, placeholder: "e.g. Short video", maxlength: "80" }), "label"), "Shown in the “+” menu and in the task's Video type."),
    field("Main task title", bind(el("input", { type: "text", value: d.task_title, placeholder: "e.g. New short", maxlength: "200" }), "task_title"), "Title given to the task when it is created. Placeholders: {dd} {mm} {month} {yy} {yyyy} (date = due date), e.g. “Weekly News Video {dd} {month}”."),
    field("Icon on tasks", bind(el("input", { type: "text", value: d.icon, maxlength: "8", style: "width:90px" }), "icon"), "Next to the task title in lists and the calendar."),
    field("Icon in “+” menu", bind(el("input", { type: "text", value: d.menu_icon, maxlength: "8", style: "width:90px" }), "menu_icon")),
    field("Main task day", weekdaySelect, "The task is due on the next such day; subtask dates are offset from it."),
    field("Linked-note name", bind(el("input", { type: "text", value: d.note_title, placeholder: "Linux News Podcast {dd} {month} {yy}" }), "note_title"),
      "Used by “Create note” on tasks of this type. Placeholders: {dd} {mm} {month} {yy} {yyyy} {title} (date = task due date). Empty = task title."),
  ]));
  editor.appendChild(el("label", { class: "tpl-check" }, [isVideo, el("span", {}, "Created as a video (shows in the “only videos” calendar filter)")]));

  /* subtasks */
  editor.appendChild(el("h3", { class: "tpl-h" }, "Subtasks"));
  const subsBox = el("div", { class: "tpl-subs" });
  const numConv = (v) => (v === "" ? null : Number(v));
  const openAi = new Set();
  function paintSubs() {
    subsBox.innerHTML = "";
    subsBox.appendChild(el("div", { class: "tpl-sub tpl-sub-head muted small" }, [
      el("span", {}, "Title"), el("span", {}, "Duration (min)"), el("span", {}, "Day offset"), el("span", {}, "Start time"), el("span", {}),
    ]));
    d.subtasks.forEach((s, i) => {
      const move = (dir) => { const j = i + dir; if (j < 0 || j >= d.subtasks.length) return; [d.subtasks[i], d.subtasks[j]] = [d.subtasks[j], d.subtasks[i]]; touch(); paintSubs(); };
      const t = el("input", { type: "text", value: s.title, placeholder: "Subtask title", maxlength: "200" });
      const du = el("input", { type: "number", min: "1", value: s.duration ?? "", placeholder: "—" });
      const of = el("input", { type: "number", value: s.offset_days ?? "", placeholder: "none", title: "Days from the main task's date: -1 = the day before, 0 = same day, empty = no date" });
      const st = el("input", { type: "time", value: s.start_time || "" });
      t.addEventListener("input", () => { s.title = t.value; touch(); });
      du.addEventListener("input", () => { s.duration = numConv(du.value); touch(); });
      of.addEventListener("input", () => { s.offset_days = numConv(of.value); touch(); });
      st.addEventListener("input", () => { s.start_time = st.value || null; touch(); });
      const nAi = (s.ai_buttons || []).length;
      const aiToggle = el("button", {
        class: "icon-btn small tpl-ai-toggle" + (nAi ? " has" : ""), title: "AI buttons shown on this subtask",
        onclick: () => { openAi.has(s) ? openAi.delete(s) : openAi.add(s); paintSubs(); },
      }, `✨${nAi || ""}`);
      const row = el("div", { class: "tpl-sub" }, [
        t, du, of, st,
        el("span", { class: "tpl-sub-actions" }, [
          aiToggle,
          el("button", { class: "icon-btn small", title: "Move up", disabled: i === 0 || undefined, onclick: () => move(-1) }, "↑"),
          el("button", { class: "icon-btn small", title: "Move down", disabled: i === d.subtasks.length - 1 || undefined, onclick: () => move(1) }, "↓"),
          el("button", { class: "icon-btn small", title: "Remove", onclick: () => { openAi.delete(s); d.subtasks.splice(i, 1); touch(); paintSubs(); } }, "✕"),
        ]),
      ]);
      subsBox.appendChild(el("div", { class: "tpl-sub-block" }, [row, openAi.has(s) ? tplAiPanel(s, touch, paintSubs) : null]));
    });
    subsBox.appendChild(el("button", {
      class: "btn", style: "margin-top:8px",
      onclick: () => { d.subtasks.push({ title: "", duration: 30, offset_days: d.main_weekday === null ? null : 0, start_time: null }); touch(); paintSubs(); },
    }, "＋ Add subtask"));
    paintMeta();
  }
  weekdaySelect.addEventListener("change", paintMeta);
  editor.appendChild(subsBox);
  paintSubs();
  editor.appendChild(el("div", { class: "tpl-preview-box" }, [el("div", { class: "tpl-h2" }, "Preview"), preview]));

  /* actions */
  saveBtn.addEventListener("click", async () => {
    if (!d.label.trim()) { showToast("Give the template a name"); return; }
    if (!d.task_title.trim()) { showToast("Give the main task a title"); return; }
    if (d.subtasks.some((s) => !s.title.trim())) { showToast("Every subtask needs a title (or remove the empty one)"); return; }
    try {
      const payload = { ...d, subtasks: d.subtasks.map((s) => ({ id: s.id || "", title: s.title, duration: s.duration, offset_days: s.offset_days, start_time: s.start_time, ai_buttons: s.ai_buttons || [] })) };
      const saved = ed.isNew ? await api.post("/api/templates", payload) : await api.send("PUT", `/api/templates/${ed.key}`, payload);
      await refreshTemplates();
      tplSelect(saved.key);
      showToast("Template saved");
      renderMain();
    } catch (e) { showToast(tplErrorMessage(e)); }
  });
  const actions = el("div", { class: "btn-row spread tpl-actions" });
  const left = el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" });
  const right = el("div", { style: "display:flex;gap:8px;align-items:center" }, [dirtyNote, saveBtn]);
  if (!ed.isNew) {
    left.appendChild(el("button", {
      class: "btn", title: "Create a copy of this template to edit",
      onclick: async () => {
        if (!(await tplConfirmDiscard())) return;
        const copy = JSON.parse(JSON.stringify(d));
        copy.key = null; copy.builtin = false; copy.label = `${d.label} (copy)`;
        state.tplEditor = { key: null, draft: copy, dirty: true, isNew: true };
        renderMain();
      },
    }, "Duplicate"));
    if (d.builtin) {
      left.appendChild(el("button", {
        class: "btn", title: "Restore this built-in template's original settings",
        onclick: async () => {
          if (!(await confirmModal({ title: "Reset to default?", message: `“${d.label}” goes back to its original settings. Tasks already created are not changed.`, confirmLabel: "Reset", danger: true }))) return;
          try { await api.post(`/api/templates/${ed.key}/reset`, {}); await refreshTemplates(); tplSelect(ed.key); showToast("Template reset"); renderMain(); }
          catch (e) { showToast(tplErrorMessage(e)); }
        },
      }, "Reset to default"));
    } else {
      left.appendChild(el("button", {
        class: "btn danger",
        onclick: async () => {
          if (!(await confirmModal({ title: "Delete template?", message: `“${d.label}” will be removed from the “+” menu. Tasks already created from it are not changed.`, confirmLabel: "Delete", danger: true }))) return;
          try { await api.del(`/api/templates/${ed.key}`); await refreshTemplates(); tplSelect(state.templates[0] ? state.templates[0].key : null); showToast("Template deleted"); renderMain(); }
          catch (e) { showToast(tplErrorMessage(e)); }
        },
      }, "Delete"));
    }
  } else {
    left.appendChild(el("button", {
      class: "btn",
      onclick: () => { tplSelect(state.templates[0] ? state.templates[0].key : null); renderMain(); },
    }, "Cancel"));
  }
  actions.appendChild(left);
  actions.appendChild(right);
  editor.appendChild(actions);
  editor.appendChild(el("div", { class: "muted small", style: "margin-top:10px" },
    "Dates, durations and subtasks apply to tasks created from now on; existing tasks are left as they are. AI buttons (title and instructions) apply right away, including to existing tasks made from this template."));
  wrap.appendChild(editor);
  return wrap;
}

/* ---------------------------------------------------------------------- *
 * Backups — a backup of the whole database is written automatically after
 * every task/subtask change, creation, completion or deletion. Pick one to
 * see how it differs from the current data, and restore it if wanted.
 * ---------------------------------------------------------------------- */
async function openBackupsView() {
  state.view = { type: "backups", title: "Backups" };
  state.backups.selected = null;
  state.backups.diff = null;
  state.backups.list = await api.get("/api/backups");
  renderMain();
  renderSidebar();
}

async function selectBackup(id) {
  state.backups.selected = id;
  state.backups.diff = null;
  state.backups.loading = true;
  renderMain();
  try {
    state.backups.diff = await api.get(`/api/backups/${id}/diff`);
  } finally {
    state.backups.loading = false;
  }
  renderMain();
}

function formatBackupTime(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { day: "2-digit", month: "short" }) + " "
    + d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

const BACKUP_TABLE_TITLES = {
  projects: "Projects", todo_lists: "Todo lists", tasks: "Tasks", subtasks: "Subtasks",
  tags: "Tags", task_tags: "Tags on tasks", task_completions: "Finished occurrences of recurring tasks",
  other_time: "Other tasks time",
};

function formatBackupValue(prop, v) {
  if (v === null || v === undefined || v === "") return "(empty)";
  if (prop === "time_spent_seconds") return formatElapsed(v);
  if (prop === "checked" || prop === "urgent" || prop === "is_video") return v ? "yes" : "no";
  return String(v);   // full value, never truncated
}

function backupPropsDetails(props) {
  // every property that has a value (empty ones and the internal id are noise), always visible
  const shown = (props || []).filter((p) => p.prop !== "id" && p.value !== null && p.value !== undefined && p.value !== "");
  return el("table", { class: "backup-props" }, shown.map((p) => el("tr", {}, [
    el("td", { class: "backup-prop" }, p.prop),
    el("td", {}, formatBackupValue(p.prop, p.value)),
  ])));
}

function backupSummary(diff) {
  const parts = [];
  const names = { projects: "project", todo_lists: "list", tasks: "task", subtasks: "subtask", tags: "tag",
    task_tags: "tag assignment", task_completions: "finished occurrence", other_time: "“Other tasks” time entry" };
  for (const [table, d] of Object.entries(diff)) {
    const n = names[table] || table;
    if (d.created_since.length) parts.push(`${d.created_since.length} ${n}(s) created since`);
    if (d.deleted_since.length) parts.push(`${d.deleted_since.length} ${n}(s) deleted since`);
    if (d.changed.length) parts.push(`${d.changed.length} ${n}(s) changed`);
  }
  return parts.join(" · ");
}

function renderBackupDiff(result) {
  const box = el("div", { class: "backup-diff" });
  const tables = Object.keys(result.diff);
  if (!tables.length) {
    box.appendChild(el("div", { class: "muted", style: "padding:14px 0" }, "No differences: the current data is identical to this backup."));
    return box;
  }
  for (const table of tables) {
    const d = result.diff[table];
    const section = el("div", { class: "backup-section" }, [
      el("h3", {}, BACKUP_TABLE_TITLES[table] || table),
    ]);
    for (const item of d.deleted_since) {
      section.appendChild(el("div", { class: "backup-item removed" }, [
        el("span", { class: "backup-badge" }, "Deleted since"),
        el("strong", {}, " " + item.label), el("span", { class: "muted" }, " " + (item.context || "")),
        el("div", { class: "muted small" }, "Restoring brings it back."),
        backupPropsDetails(item.props),
      ]));
    }
    for (const item of d.created_since) {
      section.appendChild(el("div", { class: "backup-item added" }, [
        el("span", { class: "backup-badge" }, "Created since"),
        el("strong", {}, " " + item.label), el("span", { class: "muted" }, " " + (item.context || "")),
        el("div", { class: "muted small" }, "Restoring removes it."),
        backupPropsDetails(item.props),
      ]));
    }
    for (const item of d.changed) {
      section.appendChild(el("div", { class: "backup-item changed" }, [
        el("span", { class: "backup-badge" }, "Changed"),
        el("strong", {}, " " + item.label), el("span", { class: "muted" }, " " + (item.context || "")),
        el("table", { class: "backup-props" }, item.props.map((p) => el("tr", {}, [
          el("td", { class: "backup-prop" }, p.prop),
          el("td", {}, formatBackupValue(p.prop, p.backup)),
          el("td", { class: "muted" }, "→"),
          el("td", {}, formatBackupValue(p.prop, p.current)),
        ]))),
      ]));
    }
    box.appendChild(section);
  }
  box.insertBefore(el("div", { style: "margin-bottom:10px" }, [
    el("div", { style: "font-weight:600" }, "Compared with the current data: " + backupSummary(result.diff)),
    el("div", { class: "muted small" }, "Each changed property reads: value in the backup → value now."),
  ]), box.firstChild);
  return box;
}

function renderBackupsView() {
  const wrap = el("div", { class: "backups-wrap" });
  const { list, selected, diff, loading } = state.backups;

  const left = el("div", { class: "backups-list" }, [
    el("button", {
      class: "btn", style: "margin-bottom:8px;width:100%",
      onclick: async () => {
        await api.post("/api/backups", {});
        state.backups.list = await api.get("/api/backups");
        showToast("Backup created");
        renderMain();
      },
    }, "Back up now"),
    el("button", {
      class: "btn", style: "margin-bottom:8px;width:100%",
      onclick: async () => {
        const days = await confirmModal({
          title: "Remove old backups", message: "Backups older than the chosen period are permanently deleted.",
          confirmLabel: "Remove", danger: true,
          choices: [
            { value: 7, label: "Older than a week" },
            { value: 30, label: "Older than a month" },
            { value: 90, label: "Older than 3 months" },
          ],
        });
        if (!days) return;
        const res = await api.post("/api/backups/prune", { older_than_days: days });
        state.backups.list = await api.get("/api/backups");
        if (state.backups.selected && !state.backups.list.some((b) => b.id === state.backups.selected)) {
          state.backups.selected = null; state.backups.diff = null;
        }
        showToast(res.removed ? `Removed ${res.removed} backup${res.removed > 1 ? "s" : ""}` : "No backups that old");
        renderMain();
      },
    }, "Remove old backups"),
  ]);
  if (!list.length) left.appendChild(el("div", { class: "muted" }, "No backups yet — one is created after your next change."));
  for (const b of list) {
    left.appendChild(el("div", {
      class: "backup-row" + (b.id === selected ? " active" : ""),
      onclick: () => selectBackup(b.id),
    }, [
      el("div", { class: "backup-reason" }, b.reason),
      el("div", { class: "muted small" }, `${formatBackupTime(b.created_at)} · ${b.counts.tasks} tasks, ${b.counts.subtasks} subtasks`),
    ]));
  }

  const right = el("div", { class: "backups-detail" });
  if (!selected) {
    right.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("database"),
      el("div", {}, "Pick a backup to see how it differs from your current data"),
    ]));
  } else if (loading || !diff) {
    right.appendChild(el("div", { class: "muted" }, "Comparing…"));
  } else {
    const meta = diff.backup;
    right.appendChild(el("div", { class: "backup-detail-head" }, [
      el("div", {}, [
        el("h2", { style: "margin:0" }, formatBackupTime(meta.created_at)),
        el("div", { class: "muted" }, meta.reason),
      ]),
      el("button", {
        class: "btn danger",
        onclick: async () => {
          if (!(await confirmModal({ title: "Restore this backup?", message: `All data goes back to the state of ${formatBackupTime(meta.created_at)}. The current data is backed up first, so you can undo this from the list.`, confirmLabel: "Restore", danger: true }))) return;
          await api.post(`/api/backups/${meta.id}/restore`, {});
          showToast("Backup restored");
          setTimeout(() => location.reload(), 600);
        },
      }, "Restore this backup"),
    ]));
    right.appendChild(renderBackupDiff(diff));
  }

  wrap.appendChild(left);
  wrap.appendChild(right);
  return wrap;
}

// Month view filter "Only show videos": main tasks of Video type only (no subtasks).
// Remembered across reloads (a per-browser convenience, so just localStorage).
const ONLY_VIDEOS_KEY = "taskplanner.calendar.onlyVideos";
function loadOnlyVideos() {
  try { return localStorage.getItem("taskplanner.calendar.onlyVideos") === "1"; } catch { return false; }  // literal: called while `state` is built, before the const below exists
}
function onlyVideosToggle() {
  const on = state.calendar.onlyVideos;
  return el("label", { class: "toggle-inline completed-toggle" + (on ? " on" : ""), title: "Month view: only main tasks of the Video type (no subtasks)" }, [
    el("input", {
      type: "checkbox",
      checked: on ? "checked" : null,
      onchange: (e) => {
        state.calendar.onlyVideos = e.target.checked;
        try { localStorage.setItem(ONLY_VIDEOS_KEY, e.target.checked ? "1" : "0"); } catch { /* not remembered */ }
        loadCalendar();   // the server returns the main video tasks (even those with subtasks)
      },
    }),
    el("span", {}, "Only show videos"),
  ]);
}

function renderHeaderActions() {
  const box = document.getElementById("headerActions");
  box.innerHTML = "";
  if (state.view.type === "calendar") {
    if (state.calendar.mode !== "week") box.appendChild(onlyVideosToggle());
    box.appendChild(el("button", {
      class: "btn",
      onclick: () => {
        if (state.calendar.mode === "week") { state.calendar.weekStart = startOfWeekIso(todayIso()); loadCalendar(); }
        else openCalendar(new Date().getFullYear(), new Date().getMonth() + 1);
      },
    }, "Today"));
    if (state.calendar.mode === "week") {
      box.appendChild(el("button", {
        class: "btn", title: "Place today's untimed tasks and subtasks in the free slots of today's calendar",
        onclick: autoOrderToday,
      }, "Auto order"));
      if (loadAutoOrdered().length) {
        box.appendChild(el("button", {
          class: "btn", title: "Remove the start times given by the last Auto order",
          onclick: revertAutoOrder,
        }, "Revert"));
      }
    }
    return;
  }
  if (state.view.type === "smart") {
    // Inbox/Today/Tomorrow/Urgent: data is always fetched complete (done
    // items included), and this toggle just decides whether renderSmartView
    // filters them back out -- no refetch needed, so this just re-renders.
    box.appendChild(showCompletedToggle(() => renderMain()));
    return;
  }
  if (state.view.type === "list" && state.view.todoListId) {
    const list = state.todoLists.find((l) => l.id === state.view.todoListId);
    if (!list) return;
    box.appendChild(showCompletedToggle(refreshCurrentView));
    box.appendChild(el("button", {
      class: "btn",
      onclick: async () => {
        const name = await promptModal({ title: "Rename list", value: list.name });
        if (name && name.trim()) api.patch(`/api/todolists/${list.id}`, { name: name.trim() }).then(refreshAfterStructureChange);
      },
    }, "Rename list"));
    box.appendChild(el("button", {
      class: "btn danger",
      onclick: async () => {
        if (!(await confirmModal({ title: "Delete list?", message: `“${list.name}” and all its tasks will be deleted.`, confirmLabel: "Delete", danger: true }))) return;
        await api.del(`/api/todolists/${list.id}`);
        await refreshSidebarData();
        openFirstAvailable();
      },
    }, "Delete list"));
  }
}

/* ---------------------------------------------------------------------- *
 * Task list & rows
 * ---------------------------------------------------------------------- */
function renderTaskList(tasks, opts = {}) {
  const wrap = el("div", {});
  if (!tasks.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon(opts.emptyIcon || "checkCircle"),
      el("div", {}, opts.emptyText || "Nothing here"),
    ]));
    return wrap;
  }
  for (const t of tasks) wrap.appendChild(taskRow(t, opts));
  return wrap;
}

function taskRow(task, opts = {}) {
  const due = formatDue(task.due_date);
  const checked = !!task.checked;
  const finishedOcc = !!task.is_completed_occurrence;
  const projected = !!task.is_projected || finishedOcc;

  const checkbox = el("div", {
    class: "checkbox" + (checked ? " checked" : "") + (projected ? " disabled" : ""),
    title: finishedOcc ? "This occurrence is finished" : (projected ? "This is an upcoming occurrence — open the task to manage it" : ""),
    onclick: async (e) => {
      e.stopPropagation();
      if (projected) {
        showToast(finishedOcc ? "This occurrence is already finished" : "This is a future occurrence — open the task to see its current status");
        return;
      }
      const res = await api.post(`/api/tasks/${task.id}/toggle`, { checked: !checked });
      if (res.result === "recurred") showToast("Task rescheduled to next occurrence");
      refreshCurrentView();
    },
  }, checked ? "✓" : "");

  const metaBits = [];
  if (due.text) metaBits.push(el("span", { class: due.overdue ? "overdue" : "" }, due.text));
  if (task.recurrence) metaBits.push(el("span", {}, "🔁 " + describeRecurrence(task.recurrence)));
  if (task.is_projected) metaBits.push(el("span", { class: "muted" }, "upcoming occurrence"));
  if (task.duration_minutes) metaBits.push(el("span", { class: "duration-chip" }, "⏱ " + formatDuration(task.duration_minutes)));
  // Today / Tomorrow: only the subtasks that are due in that view
  const shownSubs = (opts.smartType === "today" || opts.smartType === "tomorrow")
    ? (task.subtasks || []).filter((s) => s.matches_filter !== false)
    : (task.subtasks || []);
  const hasSubtasks = !opts.suppressSubtasks && shownSubs.length;
  const expanded = state.expandedSubtasks.has(task.id);
  if (shownSubs.length) {
    const done = shownSubs.filter((s) => s.checked).length;
    metaBits.push(el("span", { class: "muted" }, `☑ ${done}/${shownSubs.length}`));
  }
  if (task.attachment_name) metaBits.push(el("span", {}, "📎 " + task.attachment_name));
  for (const g of task.tags || []) {
    metaBits.push(el("span", { class: "task-label-chip", style: `color:${g.color}` }, g.name));
  }
  if (opts.showListHint && task.todo_list_name) {
    metaBits.push(el("span", { style: "margin-left:auto" }, `${task.project_name} / ${task.todo_list_name}`));
  }

  const titleBits = [
    (!checked && due.overdue) ? el("span", { class: "overdue-clock", title: "Overdue" }, "⏰ ") : null,
    task.urgent ? el("span", { class: "urgent-flag", title: "Urgent" }, "🚩 ") : null,
    task.is_video ? el("span", { class: "video-badge", title: templateLabel(task.video_template) },
      videoTitleIcon(task.video_template) + " ") : null,
    task.title,
  ];

  const list = hasSubtasks ? el("div", { class: "subtask-list" + (expanded ? " expanded" : "") }) : null;
  if (hasSubtasks) for (const s of shownSubs) list.appendChild(subtaskRow(s, task, { plain: !!opts.smartType }));

  const foldToggle = hasSubtasks ? el("button", {
    class: "fold-toggle" + (expanded ? " expanded" : ""),
    title: expanded ? "Hide subtasks" : "Show subtasks",
    onclick: (e) => {
      e.stopPropagation();
      const nowExpanded = !state.expandedSubtasks.has(task.id);
      if (nowExpanded) state.expandedSubtasks.add(task.id); else state.expandedSubtasks.delete(task.id);
      foldToggle.classList.toggle("expanded", nowExpanded);
      foldToggle.title = nowExpanded ? "Hide subtasks" : "Show subtasks";
      list.classList.toggle("expanded", nowExpanded);
    },
  }, "▸") : el("span", { class: "fold-toggle placeholder" });

  const row = el("div", { class: "task-row", onclick: () => openTaskDetail(task.id) }, [
    foldToggle,
    checkbox,
    el("div", { class: "task-main" }, [
      el("div", { class: "task-content" + (checked ? " done" : "") }, titleBits),
      metaBits.length ? el("div", { class: "task-meta" }, metaBits) : null,
    ]),
    timerControls(task, "tasks"),
    el("div", { class: "task-actions row-tail" }, [
      el("button", {
        class: "icon-btn small",
        title: "Delete",
        onclick: async (e) => {
          e.stopPropagation();
          if (await confirmDeleteTask(task)) { await api.del(`/api/tasks/${task.id}`); refreshCurrentView(); }
        },
      }, "🗑"),
    ]),
  ]);

  if (!hasSubtasks) return row;
  return el("div", { class: "task-with-subtasks" }, [row, list]);
}

function subtaskRow(sub, parentTask, opts = {}) {
  const checked = !!sub.checked;
  const due = formatDue(sub.due_date);

  const checkbox = el("div", {
    class: "checkbox small" + (checked ? " checked" : ""),
    onclick: async (e) => {
      e.stopPropagation();
      await api.post(`/api/subtasks/${sub.id}/toggle`, { checked: !checked });
      refreshCurrentView();
    },
  }, checked ? "✓" : "");

  const metaBits = [];
  if (due.text) metaBits.push(el("span", { class: due.overdue ? "overdue" : "" }, due.text));
  if (sub.duration_minutes) metaBits.push(el("span", { class: "duration-chip" }, "⏱ " + formatDuration(sub.duration_minutes)));

  return el("div", { class: "subtask-row" + (sub.matches_filter === false && parentTask.context_only ? " out-of-view" : ""), onclick: () => openTaskDetail(parentTask.id) }, [
    checkbox,
    el("div", { class: "task-main" }, [
      el("div", { class: "task-content" + (checked ? " done" : "") }, [
        (!checked && due.overdue) ? el("span", { class: "overdue-clock", title: "Overdue" }, "⏰ ") : null,
        sub.title,
      ]),
      metaBits.length ? el("div", { class: "task-meta" }, metaBits) : null,
    ]),
    timerControls(sub, "subtasks"),
    el("div", { class: "row-tail" }, opts.plain ? [] : [
      el("span", {
        class: "urgent-flag" + (sub.urgent ? "" : " off"),
        title: "Toggle urgent",
        onclick: async (e) => {
          e.stopPropagation();
          await api.patch(`/api/subtasks/${sub.id}`, { urgent: !sub.urgent });
          refreshCurrentView();
        },
      }, "🚩"),
      parentTask.is_video ? el("span", { class: "video-badge", title: "Inherits video flag" },
        videoTitleIcon(parentTask.video_template)) : null,
    ]),
  ]);
}

/* ---------------------------------------------------------------------- *
 * Calendar view
 * ---------------------------------------------------------------------- */
function renderCalendar() {
  const wrap = el("div", {});
  wrap.appendChild(el("div", { class: "sponsors-tabs" }, [
    el("div", { class: "seg" }, [
      el("button", {
        type: "button",
        class: "seg-btn" + (state.calendar.mode !== "week" ? " active" : ""),
        onclick: () => { state.calendar.mode = "month"; loadCalendar(); },
      }, "Month"),
      el("button", {
        type: "button",
        class: "seg-btn" + (state.calendar.mode === "week" ? " active" : ""),
        onclick: () => {
          state.calendar.mode = "week";
          if (!state.calendar.weekStart) state.calendar.weekStart = startOfWeekIso(todayIso());
          loadCalendar();
        },
      }, "Week"),
    ]),
  ]));
  wrap.appendChild(state.calendar.mode === "week" ? renderWeekGrid() : renderMonthGrid());
  return wrap;
}

function renderMonthGrid() {
  const { year, month, data } = state.calendar;
  const wrap = el("div", {});

  wrap.appendChild(el("div", { class: "calendar-header" }, [
    el("button", { class: "icon-btn", onclick: () => navMonth(-1) }, "‹"),
    el("h2", {}, `${MONTH_NAMES[month - 1]} ${year}`),
    el("button", { class: "icon-btn", onclick: () => navMonth(1) }, "›"),
  ]));

  const grid = el("div", { class: "calendar-grid" });
  for (const wd of WEEKDAY_NAMES) grid.appendChild(el("div", { class: "calendar-weekday" }, wd));

  const firstOfMonth = new Date(year, month - 1, 1);
  const startOffset = (firstOfMonth.getDay() + 6) % 7; // Monday=0
  const daysInMonth = new Date(year, month, 0).getDate();
  const daysInPrevMonth = new Date(year, month - 1, 0).getDate();
  const todayStr = todayIso();

  const cells = [];
  for (let i = 0; i < startOffset; i++) {
    const dayNum = daysInPrevMonth - startOffset + 1 + i;
    cells.push({ dayNum, outside: true });
  }
  for (let d = 1; d <= daysInMonth; d++) cells.push({ dayNum: d, outside: false, iso: `${year}-${String(month).padStart(2, "0")}-${String(d).padStart(2, "0")}` });
  while (cells.length % 7 !== 0) {
    cells.push({ dayNum: cells.length - (startOffset + daysInMonth) + 1, outside: true });
  }

  for (const cell of cells) {
    if (cell.outside) {
      grid.appendChild(el("div", { class: "calendar-cell outside" }, [el("div", { class: "calendar-daynum" }, String(cell.dayNum))]));
      continue;
    }
    let dayTasks = data[cell.iso] || [];
    if (state.calendar.onlyVideos) dayTasks = dayTasks.filter((t) => t.is_video && !t.is_subtask);
    const isToday = cell.iso === todayStr;
    const cellEl = el("div", { class: "calendar-cell" + (isToday ? " today" : "") }, [
      el("div", { class: "calendar-daynum", style: "cursor:pointer", onclick: () => openDayModal(cell.iso, dayTasks) }, String(cell.dayNum)),
    ]);
    const totalMinutes = dayTasks.reduce((sum, t) => sum + (t.checked ? 0 : (t.duration_minutes || 0)), 0);
    if (totalMinutes) {
      const heavy = totalMinutes >= 8 * 60;
      cellEl.appendChild(el("div", { class: "day-load" + (heavy ? " heavy" : "") }, `⏱ ${formatHoursTotal(totalMinutes)}`));
    }
    const shown = dayTasks.slice(0, 3);
    for (const t of shown) {
      cellEl.appendChild(el("div", {
        class: "calendar-task" + (t.is_video ? " video" : "") + (t.checked ? " done" : "")
          + (t.is_projected ? " projected" : "") + (t.is_subtask ? " subtask" : ""),
        title: t.is_projected ? "Future occurrence of a recurring task" : (t.is_subtask ? `Subtask of "${t.parent_title}"` : ""),
        onclick: () => openEntryDetail(t),
      }, [
        t.project_color ? el("span", { class: "dot", style: `background:${t.project_color}`, title: t.project_name || "" }) : null,
        t.urgent ? el("span", { class: "flag" }, "🚩") : null,
        t.is_video ? el("span", { class: "flag" }, "🎥") : null,
        t.is_projected ? el("span", { class: "flag", title: "Upcoming occurrence" }, "🔁") : null,
        el("span", { class: "label" }, (t.is_subtask ? "↳ " : "") + t.title),
      ]));
    }
    if (dayTasks.length > shown.length) {
      cellEl.appendChild(el("div", { class: "calendar-more", onclick: () => openDayModal(cell.iso, dayTasks) }, `+${dayTasks.length - shown.length} more`));
    }
    grid.appendChild(cellEl);
  }

  wrap.appendChild(grid);
  return wrap;
}

/* ---------------------------------------------------------------------- *
 * Week view — an hourly grid, one column per day, with tasks/subtasks that
 * have a start_time shown as draggable blocks positioned by time. Tasks
 * with no start_time sit in an all-day strip above the grid; dragging one
 * into the grid gives it a time, dragging a timed block into the strip
 * clears it. Dropping onto an occupied slot pushes whatever was already
 * there (and anything that, in turn, overlaps with ITS new slot) later the
 * same day — the cascade is computed and persisted together on drop.
 * ---------------------------------------------------------------------- */
function renderWeekGrid() {
  const wrap = el("div", { class: "week-wrap" });
  const start = state.calendar.weekStart || startOfWeekIso(todayIso());
  const days = [];
  for (let i = 0; i < 7; i++) days.push(addDaysIso(start, i));
  const todayStr = todayIso();

  wrap.appendChild(el("div", { class: "calendar-header" }, [
    el("button", { class: "icon-btn", onclick: () => { state.calendar.weekStart = addDaysIso(start, -7); loadCalendar(); } }, "‹"),
    el("h2", {}, `${formatDateDisplay(days[0])} – ${formatDateDisplay(days[6])}`),
    el("button", { class: "icon-btn", onclick: () => { state.calendar.weekStart = addDaysIso(start, 7); loadCalendar(); } }, "›"),
  ]));

  const grid = el("div", { class: "week-grid" });

  const headerRow = el("div", { class: "week-header-row" }, [el("div", { class: "week-gutter-cell" })]);
  for (const d of days) {
    const daySeconds = (state.calendar.timeByDay || {})[d] || 0;
    headerRow.appendChild(el("div", { class: "week-day-head" + (d === todayStr ? " today" : "") }, [
      el("div", { class: "week-day-name" }, WEEKDAY_NAMES[(parseIso(d).getDay() + 6) % 7]),
      el("div", { class: "week-day-num" }, String(parseIso(d).getDate())),
      daySeconds ? el("button", {
        type: "button", class: "week-day-hours clickable", title: "Click to see what this time was tracked on",
        onclick: (e) => { e.stopPropagation(); openDayTimeSheet(d); },
      }, formatElapsed(daySeconds)) : null,
    ]));
  }
  grid.appendChild(headerRow);

  // All-day / untimed strip
  const allDayRow = el("div", { class: "week-allday-row" }, [el("div", { class: "week-gutter-cell" })]);
  for (const d of days) {
    const cell = el("div", { class: "week-allday-cell" + (d === todayStr ? " today" : "") });
    // "Other tasks": standalone time bucket, always first in the day's strip
    const other = (state.calendar.otherByDay || {})[d];
    const otherState = other ? other.timer_state : "idle";
    cell.appendChild(el("div", {
      class: "week-untimed-pill week-other-pill",
      title: "Other tasks -- time recorded outside any task list or project",
    }, [
      el("span", { class: "dot", style: "background:var(--muted, #888)" }),
      "Other tasks",
      el("span", { class: "week-other-time" },
        (otherState === "running" ? "▶ " : otherState === "paused" ? "⏸ " : "") +
        formatElapsed(other ? other.time_spent_seconds : 0)),
    ]));
    // Untimed entries, plus timed ones outside the visible hours (e.g. a
    // 20:00 show), which would otherwise be drawn off the grid and vanish.
    for (const t of (state.calendar.data[d] || []).filter((t) => !t.start_time || weekOutsideHours(t))) {
      cell.appendChild(weekUntimedPill(t, d));
    }
    cell.addEventListener("dragover", (e) => { e.preventDefault(); if (weekDrag) cell.classList.add("drop-target"); });
    cell.addEventListener("dragleave", (e) => { if (!cell.contains(e.relatedTarget)) cell.classList.remove("drop-target"); });
    cell.addEventListener("drop", (e) => { cell.classList.remove("drop-target"); onWeekUntimedDrop(e, d); });
    allDayRow.appendChild(cell);
  }
  grid.appendChild(allDayRow);

  // Hourly body -- only the working-hours range (HOUR_START..HOUR_END) is shown
  const body = el("div", { class: "week-body" });
  const gutter = el("div", { class: "week-gutter" });
  for (let h = HOUR_START; h < HOUR_END; h++) {
    gutter.appendChild(el("div", { class: "week-hour-label", style: `height:${HOUR_HEIGHT}px` }, `${String(h).padStart(2, "0")}:00`));
  }
  body.appendChild(gutter);

  for (const d of days) {
    const col = el("div", { class: "week-day-col" + (d === todayStr ? " today" : ""), style: `height:${HOUR_HEIGHT * (HOUR_END - HOUR_START)}px` });
    for (let h = HOUR_START; h < HOUR_END; h++) {
      col.appendChild(el("div", { class: "week-hour-line", style: `top:${(h - HOUR_START) * HOUR_HEIGHT}px` }));
    }
    col.addEventListener("dragover", (e) => { e.preventDefault(); showWeekDropGhost(e, col); });
    col.addEventListener("dragleave", (e) => { if (!col.contains(e.relatedTarget)) clearWeekDropGhost(); });
    col.addEventListener("drop", (e) => { clearWeekDropGhost(); onWeekDrop(e, d, col); });

    for (const t of (state.calendar.data[d] || []).filter((t) => t.start_time && !weekOutsideHours(t))) {
      col.appendChild(weekBlockEl(t, d));
    }
    body.appendChild(col);
  }
  grid.appendChild(body);
  wrap.appendChild(grid);

  return wrap;
}

// Where inside the dragged block the pointer grabbed it (px from its top
// edge). The drop time is defined by the block's TOP edge, not the pointer.
let weekGrabOffsetY = 0;

// What is being dragged right now (dataTransfer can't be read during
// dragover), used to draw the drop preview.
let weekDrag = null;
let weekGhost = null;

function weekDropStartMin(e, colEl) {
  const rect = colEl.getBoundingClientRect();
  let startMin = ((e.clientY - weekGrabOffsetY - rect.top) / HOUR_HEIGHT) * 60 + HOUR_START * 60;
  startMin = Math.round(startMin / 15) * 15;
  return Math.max(HOUR_START * 60, Math.min(HOUR_END * 60 - 15, startMin));
}

// Preview of the slot the dragged task would land in: a dashed block with
// the resulting time range, snapped to 15 minutes, in the column under the pointer.
function showWeekDropGhost(e, colEl) {
  if (!weekDrag) return;
  const startMin = weekDropStartMin(e, colEl);
  const dur = weekDrag.duration || 30;
  if (!weekGhost) {
    weekGhost = el("div", { class: "week-drop-ghost" }, [el("span", { class: "week-drop-ghost-time" })]);
  }
  if (weekGhost.parentNode !== colEl) colEl.appendChild(weekGhost);
  weekGhost.style.top = `${(startMin / 60 - HOUR_START) * HOUR_HEIGHT}px`;
  weekGhost.style.height = `${Math.max(22, (dur / 60) * HOUR_HEIGHT)}px`;
  weekGhost.firstChild.textContent = `${minutesToTime(startMin)} – ${minutesToTime(startMin + dur)}`;
  weekGhost.classList.toggle("video", !!weekDrag.video);
}

function clearWeekDropGhost() {
  if (weekGhost && weekGhost.parentNode) weekGhost.parentNode.removeChild(weekGhost);
}

function endWeekDrag() {
  clearWeekDropGhost();
  weekDrag = null;
  document.querySelectorAll(".week-allday-cell.drop-target").forEach((c) => c.classList.remove("drop-target"));
  document.querySelectorAll(".week-block.dragging, .week-untimed-pill.dragging").forEach((c) => c.classList.remove("dragging"));
}

function beginWeekDrag(e, t, dayIso, node) {
  e.stopPropagation();
  weekGrabOffsetY = e.clientY - node.getBoundingClientRect().top;
  e.dataTransfer.setData("text/plain", weekDragPayload(t, dayIso));
  e.dataTransfer.effectAllowed = "move";
  weekDrag = { duration: t.duration_minutes || 30, video: !!t.is_video };
  setTimeout(() => node.classList.add("dragging"), 0);
  node.addEventListener("dragend", endWeekDrag, { once: true });
}

function weekDragPayload(t, dayIso) {
  return JSON.stringify({ id: t.id, isSubtask: !!t.is_subtask, duration: t.duration_minutes || 30, fromDay: dayIso,
    occ: t.is_projected ? (t.occurrence_date || t.due_date) : null });
}

function weekBlockEl(t, dayIso) {
  const startMin = timeToMinutes(t.start_time);
  const duration = t.duration_minutes || 30;
  const top = (startMin / 60 - HOUR_START) * HOUR_HEIGHT;
  const height = Math.max(22, (duration / 60) * HOUR_HEIGHT);
  const draggable = !t.is_completed_occurrence;

  const block = el("div", {
    class: "week-block" + (t.is_video ? " video" : "") + (t.checked ? " done" : "")
      + (t.is_subtask ? " subtask" : "") + (t.is_projected ? " projected" : ""),
    style: `top:${top}px; height:${height}px;`,
    draggable,
    title: `${t.title} — ${t.start_time}${t.duration_minutes ? " (" + formatDuration(t.duration_minutes) + ")" : ""}`,
    onclick: () => openEntryDetail(t),
  }, [
    t.project_color ? el("span", { class: "dot", style: `background:${t.project_color}`, title: t.project_name || "" }) : null,
    t.urgent ? el("span", { class: "flag" }, "🚩") : null,
    t.is_video ? el("span", { class: "flag" }, "🎥") : null,
    el("span", { class: "label" }, (t.is_subtask ? "↳ " : "") + t.title),
  ]);
  if (draggable) {
    block.addEventListener("dragstart", (e) => beginWeekDrag(e, t, dayIso, block));
  }
  return block;
}

// Sheet listing what a day's tracked-time total is made of.
async function openDayTimeSheet(day) {
  const data = await api.get(`/api/calendar/time-day?day=${day}`);
  const d = parseIso(day);
  const heading = `${WEEKDAY_NAMES[(d.getDay() + 6) % 7]} ${d.getDate()} ${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}`;
  const close = () => {
    document.removeEventListener("keydown", onKey, true);
    overlay.classList.remove("open");
    setTimeout(() => overlay.remove(), 260);
  };
  const onKey = (e) => { if (e.key === "Escape" || e.key === "Enter") { e.preventDefault(); e.stopPropagation(); close(); } };
  const list = el("div", { class: "day-time-list" });
  if (!data.items.length) list.appendChild(el("div", { class: "muted" }, "No time tracked on this day."));
  // One group per main task: its subtasks underneath, with a subtotal.
  const groups = new Map();
  for (const it of data.items) {
    const key = it.kind === "other" ? "other" : it.task_id;
    if (!groups.has(key)) groups.set(key, { task_id: it.task_id, title: it.kind === "subtask" ? it.parent_title : it.title, subs: [], own: 0, seconds: 0 });
    const g = groups.get(key);
    g.seconds += it.seconds;
    if (it.kind === "subtask") g.subs.push(it); else g.own += it.seconds;
  }
  const row = (cls, name, secs, taskId) => el("div", {
    class: cls + (taskId != null ? " clickable" : ""),
    onclick: taskId != null ? () => { close(); openTaskDetail(taskId); } : null,
  }, [el("div", { class: "day-time-name" }, name), el("div", { class: "day-time-secs" }, formatElapsed(secs))]);
  for (const g of [...groups.values()].sort((x, y) => y.seconds - x.seconds)) {
    const box = el("div", { class: "day-time-group" });
    box.appendChild(row("day-time-row day-time-head", g.title, g.seconds, g.task_id));
    if (g.own && g.subs.length) box.appendChild(row("day-time-row day-time-sub", "(on the task itself)", g.own, g.task_id));
    for (const sub of g.subs.sort((x, y) => y.seconds - x.seconds)) {
      box.appendChild(row("day-time-row day-time-sub", "↳ " + sub.title, sub.seconds, g.task_id));
    }
    list.appendChild(box);
  }
  const closeBtn = el("button", { class: "btn primary", onclick: close }, "Close");
  const overlay = el("div", { class: "sheet-overlay", onclick: (e) => { if (e.target === overlay) close(); } }, [
    el("div", { class: "sheet sheet-list", role: "dialog", "aria-modal": "true" }, [
      el("div", { class: "sheet-list-head" }, [
        el("div", { class: "sheet-title" }, heading),
        el("div", { class: "muted" }, `Total tracked: ${formatElapsed(data.total_seconds)}`),
      ]),
      list,
      el("div", { class: "sheet-buttons", style: "justify-content:flex-end" }, [closeBtn]),
    ]),
  ]);
  document.body.appendChild(overlay);
  document.addEventListener("keydown", onKey, true);
  void overlay.offsetWidth;          // render the closed (raised) state first so the drop-down animates
  requestAnimationFrame(() => { overlay.classList.add("open"); closeBtn.focus(); });
}

// A timed entry that starts before / after the hours the week grid shows.
function weekOutsideHours(t) {
  const m = timeToMinutes(t.start_time);
  return m != null && (m < HOUR_START * 60 || m >= HOUR_END * 60);
}

function weekUntimedPill(t, dayIso) {
  const draggable = !t.is_completed_occurrence;
  const pill = el("div", {
    class: "week-untimed-pill" + (t.is_subtask ? " subtask" : "") + (t.checked ? " done" : ""),
    draggable,
    title: t.start_time ? `${t.title} — ${t.start_time} (outside the hours shown)` : t.title,
    onclick: () => openEntryDetail(t),
  }, [
    t.project_color ? el("span", { class: "dot", style: `background:${t.project_color}`, title: t.project_name || "" }) : null,
    (t.urgent ? "🚩 " : "") + (t.is_subtask ? "↳ " : "") + (t.start_time ? `${t.start_time} · ` : "") + t.title,
  ]);
  if (draggable) {
    pill.addEventListener("dragstart", (e) => beginWeekDrag(e, t, dayIso, pill));
  }
  return pill;
}

function weekEntryKey(t) { return `${t.is_subtask ? "s" : "t"}:${t.id}`; }

// Dropping a block in the hourly grid: compute a start time from the drop
// position, then cascade — anything already on that day that the dropped
// block now overlaps gets pushed to start right when the previous one ends,
// and so on, until a gap is found. Everything is persisted together here,
// on drop, which is also what "confirms" the cascaded moves.
async function onWeekDrop(e, targetDay, colEl) {
  e.preventDefault();
  let payload;
  try { payload = JSON.parse(e.dataTransfer.getData("text/plain")); } catch { return; }
  if (!payload) return;

  const startMin = weekDropStartMin(e, colEl);

  const movedKey = `${payload.isSubtask ? "s" : "t"}:${payload.id}`;
  const movedDuration = payload.duration || 30;

  const others = (state.calendar.data[targetDay] || [])
    .filter((t) => weekEntryKey(t) !== movedKey && t.start_time && t.duration_minutes && !t.is_projected && !t.is_completed_occurrence)
    .map((t) => ({ id: t.id, isSubtask: !!t.is_subtask, start: timeToMinutes(t.start_time), duration: t.duration_minutes }))
    .sort((a, b) => a.start - b.start);

  const changes = [{ id: payload.id, isSubtask: payload.isSubtask, start: startMin, isMoved: true, occ: payload.occ }];
  let cursorEnd = startMin + movedDuration;
  for (const other of others) {
    if (other.start < cursorEnd) {
      changes.push({ id: other.id, isSubtask: other.isSubtask, start: cursorEnd });
      cursorEnd += other.duration;
    } else {
      break;
    }
  }

  // A task pushed by the overlap cascade that would end up outside the
  // visible day (before HOUR_START / ending after HOUR_END) loses its start
  // time instead and goes back to the untimed strip.
  const dur = new Map(others.map((o) => [`${o.isSubtask ? "s" : "t"}:${o.id}`, o.duration]));
  let unscheduled = 0;
  for (const c of changes) {
    const url = c.isSubtask ? `/api/subtasks/${c.id}` : `/api/tasks/${c.id}`;
    const outside = !c.isMoved && (c.start < HOUR_START * 60
      || c.start + (dur.get(`${c.isSubtask ? "s" : "t"}:${c.id}`) || 30) > HOUR_END * 60);
    // occurrence_only: on a recurring task, only THIS occurrence moves; the rest of the series stays put.
    const body = { start_time: outside ? null : minutesToTime(c.start), occurrence_only: true };
    if (outside) unscheduled++;
    if (c.isMoved) body.due_date = targetDay;
    if (c.occ) body.occurrence_date = c.occ;       // a future occurrence: only that one moves
    await api.patch(url, body);
  }
  showToast(changes.length > 1
    ? `Moved, and rescheduled ${changes.length - 1 - unscheduled} overlapping task(s)`
      + (unscheduled ? `; ${unscheduled} pushed outside ${HOUR_START}:00–${HOUR_END}:00 lost their start time` : "")
    : "Task moved");
  await loadCalendar();
}

// Dropping onto the all-day strip just clears the time (and moves the day).
async function onWeekUntimedDrop(e, targetDay) {
  e.preventDefault();
  let payload;
  try { payload = JSON.parse(e.dataTransfer.getData("text/plain")); } catch { return; }
  if (!payload) return;
  const url = payload.isSubtask ? `/api/subtasks/${payload.id}` : `/api/tasks/${payload.id}`;
  await api.patch(url, { start_time: null, due_date: targetDay, occurrence_only: true,
    ...(payload.occ ? { occurrence_date: payload.occ } : {}) });
  showToast("Task moved");
  await loadCalendar();
}

function navMonth(delta) {
  let { year, month } = state.calendar;
  month += delta;
  if (month < 1) { month = 12; year -= 1; }
  if (month > 12) { month = 1; year += 1; }
  openCalendar(year, month);
}

function openDayModal(iso, tasks) {
  const { text } = formatDue(iso);
  const list = el("div", {}, tasks.length
    ? tasks.map((t) => (t.is_subtask ? subtaskCalendarRow(t) : taskRow(t, { suppressSubtasks: true })))
    : [el("div", { class: "muted" }, "No tasks")]);
  const defaultListId = state.view.todoListId || (state.todoLists[0] && state.todoLists[0].id);
  const addInput = el("input", { type: "text", placeholder: "Add a task for this day" });
  const addRow = defaultListId ? el("div", { class: "inline-add-row" }, [
    addInput,
    el("button", {
      class: "btn",
      onclick: async () => {
        if (addInput.value.trim()) {
          await api.post("/api/tasks", { todo_list_id: defaultListId, title: addInput.value.trim(), due_date: iso });
          closeModal();
          await loadCalendar();
        }
      },
    }, "Add"),
  ]) : null;
  openModal(`${text || iso} — ${iso}`, [list, addRow].filter(Boolean), [
    el("button", { class: "btn primary", onclick: closeModal }, "Close"),
  ]);
}

// A subtask shown as its own entry in the day modal (it has its own due
// date/duration/urgency and inherits the video flag, but there's no
// standalone subtask detail view — clicking it opens the parent task).
function subtaskCalendarRow(t) {
  const checked = !!t.checked;
  const metaBits = [];
  if (t.duration_minutes) metaBits.push(el("span", { class: "duration-chip" }, "⏱ " + formatDuration(t.duration_minutes)));
  metaBits.push(el("span", { class: "muted" }, "from " + t.parent_title));

  const checkbox = el("div", {
    class: "checkbox" + (checked ? " checked" : ""),
    onclick: async (e) => {
      e.stopPropagation();
      await api.post(`/api/subtasks/${t.id}/toggle`, { checked: !checked });
      await loadCalendar();
    },
  }, checked ? "✓" : "");

  return el("div", { class: "task-row", onclick: () => openTaskDetail(t.parent_task_id) }, [
    checkbox,
    el("div", { class: "task-main" }, [
      el("div", { class: "task-content" + (checked ? " done" : "") }, [
        t.urgent ? el("span", { class: "urgent-flag", title: "Urgent" }, "🚩 ") : null,
        t.is_video ? el("span", { class: "video-badge", title: "Video" }, "🎥 ") : null,
        "↳ " + t.title,
      ]),
      el("div", { class: "task-meta" }, metaBits),
    ]),
  ]);
}

/* ---------------------------------------------------------------------- *
 * Quick add (header row + FAB dialog)
 * ---------------------------------------------------------------------- */
function wireQuickAdd() {
  const input = document.getElementById("quickAddInput");
  input.addEventListener("keydown", async (e) => {
    if (e.key !== "Enter" || !input.value.trim() || !state.view.todoListId) return;
    const title = input.value.trim();
    input.value = "";
    await api.post("/api/tasks", { todo_list_id: state.view.todoListId, title });
    refreshCurrentView();
  });

  document.getElementById("fab").addEventListener("click", (e) => { e.stopPropagation(); openFabMenu(); });
}

// The "+" FAB opens a little submenu: a plain task, or one of the video
// templates that stamp out a main task plus its usual subtasks.
function openFabMenu() {
  closeDropdowns();
  const fab = document.getElementById("fab");
  const rect = fab.getBoundingClientRect();
  const dd = el("div", { class: "dropdown" }, [
    el("button", { onclick: () => { closeDropdowns(); openQuickAddModal(); } }, "📝 Task"),
    ...state.templates.map((t) => el("button", {
      onclick: () => { closeDropdowns(); openTemplateModal(t.key); },
    }, `${t.menu_icon || t.icon || "🎥"} ${t.label}`)),
  ]);
  dd.style.position = "fixed";
  dd.style.bottom = `${window.innerHeight - rect.top + 8}px`;
  dd.style.right = `${Math.max(4, window.innerWidth - rect.right)}px`;
  dd.addEventListener("click", (e) => e.stopPropagation());
  document.body.appendChild(dd);
}

function openTemplateModal(key) {
  const listOptions = state.todoLists.map((l) => {
    const proj = state.projects.find((p) => p.id === l.project_id);
    return el("option", { value: l.id, selected: l.id === state.view.todoListId || undefined }, `${proj ? proj.name : "?"} / ${l.name}`);
  });
  if (!listOptions.length) { showToast("Create a project and a list first"); return; }
  const listSelect = el("select", {}, listOptions);
  const fixedList = (templateByKey(key) || {}).target_list_id;       // this template always goes to one list
  if (fixedList && state.todoLists.some((l) => l.id === fixedList)) { listSelect.value = fixedList; listSelect.disabled = true; }
  openModal(`Create "${templateLabel(key)}"`, [
    el("div", { class: "field" }, [el("label", {}, "List"), listSelect]),
    el("div", { class: "muted small" }, templateIsUnscheduled(key)
      ? "This creates the main task plus its usual subtasks, with no due date set -- schedule it yourself whenever you like."
      : "This creates the main task plus its usual subtasks, scheduled automatically."),
  ], [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", {
      class: "btn primary",
      onclick: async () => {
        await api.post(`/api/templates/${key}`, { todo_list_id: listSelect.value });
        closeModal();
        showToast(`${templateLabel(key)} created`);
        refreshCurrentView();
      },
    }, "Create"),
  ]);
}

// What a task created from the current view should start with: Today/Tomorrow
// give it that due date, Urgent flags it urgent.
function smartViewDefaults() {
  if (state.view.type !== "smart") return {};
  if (state.view.smartType === "today") return { due_date: todayIso() };
  if (state.view.smartType === "tomorrow") return { due_date: tomorrowIso() };
  if (state.view.smartType === "urgent") return { urgent: true };
  return {};
}

function openQuickAddModal() {
  const listOptions = state.todoLists.map((l) => {
    const proj = state.projects.find((p) => p.id === l.project_id);
    return el("option", { value: l.id, selected: l.id === state.view.todoListId || undefined }, `${proj ? proj.name : "?"} / ${l.name}`);
  });
  if (!listOptions.length) { showToast("Create a project and a list first"); return; }
  const titleInput = el("input", { type: "text", placeholder: "Task title" });
  const listSelect = el("select", {}, listOptions);
  const defaults = smartViewDefaults();
  const hint = defaults.due_date ? `Due date: ${defaults.due_date === todayIso() ? "today" : "tomorrow"}`
    : (defaults.urgent ? "Will be marked urgent" : "");
  openModal("Add task", [
    el("div", { class: "field" }, [el("label", {}, "Title"), titleInput]),
    el("div", { class: "field" }, [el("label", {}, "List"), listSelect]),
    hint ? el("div", { class: "muted small" }, hint) : null,
  ].filter(Boolean), [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", {
      class: "btn primary",
      onclick: async () => {
        if (titleInput.value.trim()) {
          await api.post("/api/tasks", { todo_list_id: listSelect.value, title: titleInput.value.trim(), ...defaults });
          closeModal();
          refreshCurrentView();
        }
      },
    }, "Add"),
  ]);
  setTimeout(() => titleInput.focus(), 30);
  titleInput.addEventListener("keydown", (e) => { if (e.key === "Enter") document.querySelector(".modal .btn.primary").click(); });
}

/* ---------------------------------------------------------------------- *
 * Popup date picker — a small floating month calendar used in place of a
 * native <input type="date">. The native picker's calendar-icon indicator
 * doesn't reliably adapt to a dark background (it stays a fixed dark glyph
 * in most browsers), so it all but disappears in dark mode; this is also
 * just closer to what was asked for ("a little popup calendar").
 * ---------------------------------------------------------------------- */
function formatDateDisplay(iso) {
  if (!iso) return "No due date";
  return parseIso(iso).toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" });
}

function openDatePickerPopup(anchorEl, selectedIso, onSelect) {
  closeDropdowns();
  const base = selectedIso ? parseIso(selectedIso) : parseIso(todayIso());
  let viewYear = base.getFullYear();
  let viewMonth = base.getMonth() + 1; // 1-12

  const rect = anchorEl.getBoundingClientRect();
  const pop = el("div", { class: "dropdown date-popup" });
  pop.style.position = "fixed";
  pop.style.top = `${rect.bottom + 4}px`;
  pop.style.left = `${Math.max(4, rect.left)}px`;

  function render() {
    pop.innerHTML = "";
    pop.appendChild(el("div", { class: "date-popup-header" }, [
      el("button", { class: "icon-btn small", type: "button", onclick: (e) => { e.stopPropagation(); navigate(-1); } }, "‹"),
      el("strong", {}, `${MONTH_NAMES[viewMonth - 1]} ${viewYear}`),
      el("button", { class: "icon-btn small", type: "button", onclick: (e) => { e.stopPropagation(); navigate(1); } }, "›"),
    ]));

    const grid = el("div", { class: "date-popup-grid" });
    for (const wd of WEEKDAY_NAMES) grid.appendChild(el("div", { class: "date-popup-wd" }, wd[0]));

    const firstOfMonth = new Date(viewYear, viewMonth - 1, 1);
    const startOffset = (firstOfMonth.getDay() + 6) % 7;
    const daysInMonth = new Date(viewYear, viewMonth, 0).getDate();
    const daysInPrevMonth = new Date(viewYear, viewMonth - 1, 0).getDate();
    const todayStr = todayIso();

    const cells = [];
    for (let i = 0; i < startOffset; i++) cells.push({ dayNum: daysInPrevMonth - startOffset + 1 + i, outside: true });
    for (let d = 1; d <= daysInMonth; d++) {
      cells.push({ dayNum: d, outside: false, iso: `${viewYear}-${String(viewMonth).padStart(2, "0")}-${String(d).padStart(2, "0")}` });
    }
    while (cells.length % 7 !== 0) cells.push({ dayNum: cells.length - (startOffset + daysInMonth) + 1, outside: true });

    for (const cell of cells) {
      if (cell.outside) { grid.appendChild(el("div", { class: "date-popup-day outside" }, String(cell.dayNum))); continue; }
      const classes = ["date-popup-day"];
      if (cell.iso === todayStr) classes.push("today");
      if (cell.iso === selectedIso) classes.push("selected");
      grid.appendChild(el("div", {
        class: classes.join(" "),
        onclick: (e) => { e.stopPropagation(); onSelect(cell.iso); closeDropdowns(); },
      }, String(cell.dayNum)));
    }
    pop.appendChild(grid);

    pop.appendChild(el("div", { class: "date-popup-actions" }, [
      el("button", { class: "btn", type: "button", onclick: (e) => { e.stopPropagation(); onSelect(todayIso()); closeDropdowns(); } }, "Today"),
      el("button", { class: "btn", type: "button", onclick: (e) => { e.stopPropagation(); onSelect(null); closeDropdowns(); } }, "Clear"),
    ]));
  }

  function navigate(delta) {
    viewMonth += delta;
    if (viewMonth < 1) { viewMonth = 12; viewYear -= 1; }
    if (viewMonth > 12) { viewMonth = 1; viewYear += 1; }
    render();
  }

  render();
  pop.addEventListener("click", (e) => e.stopPropagation());
  document.body.appendChild(pop);
}

// A button that shows the current due date and opens the popup picker when
// clicked. `onChange(iso|null)` is called with the new value; the caller is
// responsible for re-rendering whatever displays the chosen date.
function dateField(initialIso, onChange) {
  const btn = el("button", { type: "button", class: "btn date-field" }, "📅 " + formatDateDisplay(initialIso));
  btn._value = initialIso;
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    openDatePickerPopup(btn, btn._value, (iso) => {
      btn._value = iso;
      btn.textContent = "📅 " + formatDateDisplay(iso);
      onChange(iso);
    });
  });
  return btn;
}

/* ---------------------------------------------------------------------- *
 * Generic modal helper
 * ---------------------------------------------------------------------- */
function openModal(title, bodyNodes, buttonNodes) {
  const overlay = document.getElementById("modalOverlay");
  const body = document.getElementById("modalBody");
  body.innerHTML = "";
  body.classList.remove("modal-wide", "modal-ai");
  body.appendChild(el("h2", {}, title));
  for (const n of bodyNodes) body.appendChild(n);
  body.appendChild(el("div", { class: "btn-row" }, buttonNodes));
  overlay.classList.remove("hidden");
  overlay.classList.add("modal-center");
  overlay.onclick = (e) => { if (e.target === overlay) closeModal(); };
}
function confirmDeleteTask(task) {
  const n = (task.subtasks || []).length;
  return confirmModal({
    title: "Delete task?",
    message: `“${task.title}” will be deleted` + (n ? ` along with its ${n} subtask${n > 1 ? "s" : ""}` : "") + ".",
    confirmLabel: "Delete", danger: true,
  });
}

function closeModal() {
  document.getElementById("modalOverlay").classList.add("hidden");
}

// In-app replacement for window.prompt(): same sheet with a text field.
// Resolves the entered text, or null on Cancel / Escape.
const promptModal = (opts) => confirmModal({ confirmLabel: "Save", ...opts, input: { value: opts.value || "" } });

// In-app replacement for window.confirm(): a sheet that slides down from the
// top of the app. Resolves true when the person confirms, false on Cancel /
// Escape / clicking outside it. Usage:
//   if (await confirmModal({ title: "Delete task?", message: "...", confirmLabel: "Delete", danger: true })) ...
function confirmModal({ title, message, confirmLabel = "Confirm", danger = false, choices = null, input = null }) {
  return new Promise((resolve) => {
    let settled = false;
    const inputEl = input ? el("input", { type: "text", class: "sheet-input", value: input.value || "", placeholder: input.placeholder || "" }) : null;
    let chosen = choices ? choices[0].value : null;
    const finish = (value) => {
      if (settled) return;
      if (choices && value) value = chosen;
      if (inputEl) value = value ? inputEl.value : null;
      settled = true;
      document.removeEventListener("keydown", onKey, true);
      overlay.classList.remove("open");                 // slides back up
      setTimeout(() => overlay.remove(), 260);
      resolve(value);
    };
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(false); }
      else if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); finish(true); }
    };
    const confirmBtn = el("button", { class: "btn " + (danger ? "danger" : "primary"), onclick: () => finish(true) }, confirmLabel);
    const overlay = el("div", { class: "sheet-overlay", onclick: (e) => { if (e.target === overlay) finish(false); } }, [
      el("div", { class: "sheet", role: "dialog", "aria-modal": "true" }, [
        el("div", { class: "sheet-text" }, [
          el("div", { class: "sheet-title" }, title),
          message ? el("div", { class: "muted sheet-message" }, message) : null,
          inputEl,
          choices ? el("div", { class: "sheet-choices" }, choices.map((c, i) => {
            const input = el("input", { type: "radio", name: "sheetChoice", checked: i === 0 || undefined });
            input.addEventListener("change", () => { chosen = c.value; });
            return el("label", { class: "sheet-choice" }, [input, el("span", {}, c.label)]);
          })) : null,
        ]),
        el("div", { class: "sheet-buttons" }, [
          el("button", { class: "btn", onclick: () => finish(false) }, "Cancel"),
          confirmBtn,
        ]),
      ]),
    ]);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", onKey, true);
    void overlay.offsetWidth;        // render the closed (raised) state first so the drop-down animates
    requestAnimationFrame(() => { overlay.classList.add("open"); (inputEl || confirmBtn).focus(); if (inputEl) inputEl.select(); });
  });
}

/* ---------------------------------------------------------------------- *
 * Project / list dialogs
 * ---------------------------------------------------------------------- */
function openProjectDialog(project) {
  const isEdit = !!project;
  const nameInput = el("input", { type: "text", value: project ? project.name : "", placeholder: "Project name" });
  let selectedColor = project ? project.color : PROJECT_COLORS[0];
  const swatchRow = el("div", { class: "swatch-row" });
  function paintSwatches() {
    swatchRow.innerHTML = "";
    for (const c of PROJECT_COLORS) {
      swatchRow.appendChild(el("div", {
        class: "swatch" + (c === selectedColor ? " selected" : ""),
        style: `background:${c}`,
        onclick: () => { selectedColor = c; paintSwatches(); },
      }));
    }
  }
  paintSwatches();

  openModal(isEdit ? "Edit project" : "New project", [
    el("div", { class: "field" }, [el("label", {}, "Name"), nameInput]),
    el("div", { class: "field" }, [el("label", {}, "Color"), swatchRow]),
  ], [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", {
      class: "btn primary",
      onclick: async () => {
        if (!nameInput.value.trim()) return;
        if (isEdit) {
          await api.patch(`/api/projects/${project.id}`, { name: nameInput.value.trim(), color: selectedColor });
        } else {
          const res = await api.post("/api/projects", { name: nameInput.value.trim(), color: selectedColor });
          await api.post("/api/todolists", { project_id: res.id, name: "Tasks" });
          state.expanded.add(res.id);
        }
        closeModal();
        await refreshSidebarData();
      },
    }, isEdit ? "Save" : "Create"),
  ]);
  setTimeout(() => nameInput.focus(), 30);
}

function openListDialog(projectId) {
  const nameInput = el("input", { type: "text", placeholder: "List name" });
  openModal("New list", [el("div", { class: "field" }, [nameInput])], [
    el("button", { class: "btn", onclick: closeModal }, "Cancel"),
    el("button", {
      class: "btn primary",
      onclick: async () => {
        if (!nameInput.value.trim()) return;
        await api.post("/api/todolists", { project_id: projectId, name: nameInput.value.trim() });
        state.expanded.add(projectId);
        closeModal();
        refreshSidebarData();
      },
    }, "Add"),
  ]);
  setTimeout(() => nameInput.focus(), 30);
}

/* ---------------------------------------------------------------------- *
 * Task detail panel
 * ---------------------------------------------------------------------- */
// Task panel: the note (a Markdown file of "Notes & Scripts") this task is linked
// to. Stored as the file's full path in task.notes_file, which is what the AI
// buttons read. When nothing is linked, notes whose title shares keywords with
// the task's title are suggested.
function renderNoteLinkField(task, patch) {
  const field = el("div", { class: "field note-link-field" }, [el("label", {}, "Note / script")]);
  const body = el("div", {});
  field.appendChild(body);
  let current = task.notes_file || "";
  let root = "";
  let suggestions = [];
  const base = () => root.replace(/\/$/, "");
  const relOf = (p) => (root && p && p.startsWith(base() + "/")) ? p.slice(base().length + 1) : null;

  async function link(rel) {
    const value = rel ? `${base()}/${rel}` : null;
    await patch({ notes_file: value });
    current = value || ""; task.notes_file = value;
    paint();
  }
  async function choose() {
    const rel = await NotesApp.pickNote({ title: "Link a note", query: task.title, current: relOf(current) });
    if (rel === null) return;
    await link(rel);
  }

  // the template's note name pattern ("Linux News Podcast 14 October 26" for weekly news), else the task title
  function newNoteName() {
    const tpl = templateByKey(task.video_template);
    if (tpl && tpl.note_title && task.due_date) {
      const [y, m, d] = task.due_date.slice(0, 10).split("-").map(Number);
      const month = new Date(y, m - 1, d).toLocaleString("en-GB", { month: "long" });
      const pad = (n) => String(n).padStart(2, "0");
      return tpl.note_title
        .replaceAll("{dd}", pad(d)).replaceAll("{mm}", pad(m)).replaceAll("{month}", month)
        .replaceAll("{yyyy}", String(y)).replaceAll("{yy}", pad(y % 100)).replaceAll("{title}", task.title);
    }
    return task.title;
  }
  async function createNote() {
    try {
      const path = await NotesApp.create(newNoteName());
      await link(path);
      showToast("Note created");
      closeTaskDetail(); NotesApp.openNote(path);
    } catch (e) { showToast("Could not create the note"); }
  }

  async function createVideoNote() {
    try {
      const res = await api.post(`/api/tasks/${task.id}/video-note`, {});
      task.video_note_file = res.path; paint(); paintVideoNote();
      showToast(res.warnings && res.warnings.length ? `“${res.name}” created — ${res.warnings.join(" ")}` : `“${res.name}” created`);
      if (res.rel) { closeTaskDetail(); NotesApp.openNote(res.rel); }
    } catch (e) {
      let msg = "Could not create the video note";
      try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
      showToast(msg);
    }
  }

  // second link, below the main note: the "-VIDEO" note made by "Create Video Note"
  const vbody = el("div", {});
  field.appendChild(vbody);
  function paintVideoNote() {
    vbody.innerHTML = "";
    const vp = task.video_note_file;
    if (!vp) return;
    const rel = relOf(vp);
    const name = vp.split("/").pop().replace(/\.md$/i, "");
    vbody.appendChild(el("div", { class: "note-link-row", style: "margin-top:6px" }, [
      el("span", { class: "muted small" }, "Video note"),
      el(rel ? "button" : "span", rel
        ? { class: "note-link-chip clickable", type: "button", title: `Open ${vp}`, onclick: () => { closeTaskDetail(); NotesApp.openNote(rel); } }
        : { class: "note-link-chip", title: vp }, [el("span", {}, "🎬 " + name)]),
      el("button", { class: "icon-btn small", type: "button", title: "Unlink the video note (the button comes back)", onclick: async () => {
        await patch({ video_note_file: null }); task.video_note_file = null; paint(); paintVideoNote();
      } }, "✕"),
    ]));
  }

  function paint() {
    body.innerHTML = "";
    paintVideoNote();
    if (current) {
      const rel = relOf(current);
      const shown = rel ? rel.replace(/\.md$/i, "") : current.split("/").pop().replace(/\.md$/i, "");
      const name = shown.split("/").pop();
      const folder = rel ? shown.split("/").slice(0, -1).join("/") : "outside the notes folder";
      body.appendChild(el("div", { class: "note-link-row" }, [
        el(rel ? "button" : "span", rel
          ? { class: "note-link-chip clickable", type: "button", title: `Open ${current}`, onclick: () => { closeTaskDetail(); NotesApp.openNote(rel); } }
          : { class: "note-link-chip", title: current }, [
          el("span", {}, "📄 " + name),
          folder ? el("span", { class: "nl-folder" }, folder) : null,
        ]),
        el("button", { class: "btn small", type: "button", onclick: choose }, "Change"),
        task.video_template === "weekly_news" && !task.video_note_file ? el("button", {
          class: "btn small", type: "button", title: "Copy this note as “… -VIDEO” (same folder) and prepare it for the video",
          onclick: createVideoNote,
        }, "Create Video Note") : null,
        el("button", { class: "icon-btn small", type: "button", title: "Unlink", onclick: () => link(null) }, "✕"),
      ]));
      return;
    }
    body.appendChild(el("div", { class: "note-link-row" }, [
      el("button", { class: "btn small", type: "button", onclick: choose }, "🔎 Find a note…"),
      el("button", { class: "btn small", type: "button", onclick: createNote }, "＋ Create Note"),
    ]));
    if (suggestions.length) {
      body.appendChild(el("div", { class: "note-suggest" }, [
        el("span", {}, "Suggested:"),
        ...suggestions.map((n) => el("button", { type: "button", title: `${n.path} — click to link`, onclick: () => link(n.path) }, n.name)),
      ]));
    }
  }

  paint();
  (async () => {
    try {
      root = await NotesApp.root();
      if (!current) suggestions = await NotesApp.suggest(task.title, 3);
      paint();
    } catch (e) { /* notes folder unavailable: the field still works for unlinking */ }
  })();
  return field;
}

async function openTaskDetail(id) {
  const task = await api.get(`/api/tasks/${id}`);
  renderTaskPanel(task);
  document.getElementById("taskDetailOverlay").classList.remove("hidden");
}

// Clicking a calendar entry: a finished occurrence of a recurring task opens
// ITS OWN details, everything else opens the (current) task.
function openEntryDetail(t) {
  if (t.is_completed_occurrence) return openOccurrenceDetail(t);
  return openTaskDetail(t.is_subtask ? t.parent_task_id : t.id);
}

// Read-only details of one finished occurrence (what was recorded when it
// was finished), as opposed to the task's current, rolled-forward state.
function openOccurrenceDetail(c) {
  const panelEl = document.getElementById("taskPanel");
  panelEl.innerHTML = "";
  const panel = { appendChild: (n) => { if (n) panelEl.appendChild(n); } };
  const subs = c.subtasks_snapshot || c.subtasks || [];
  const day = c.occurrence_date || c.due_date;
  const ownSeconds = c.occurrence_time_seconds ?? ownSeconds ?? 0;
  const subTotal = subs.reduce((n, x) => n + (x.time_spent_seconds || 0), 0);
  const row = (label, value) => value ? el("div", { class: "field" }, [el("label", {}, label), el("div", {}, value)]) : null;
  const when = c.completed_at ? new Date(c.completed_at) : null;
  panel.appendChild(el("div", { class: "panel-head" }, [
    el("div", { style: "font-size:16px;font-weight:600;flex:1 1 220px" }, [c.is_video ? videoTitleIcon(c.video_template) + " " : "", c.occurrence_title || c.title]),
    el("button", { class: "icon-btn panel-head-close", onclick: closeTaskDetail }, "✕"),
  ]));
  panel.appendChild(el("div", { class: "muted", style: "margin-bottom:12px" }, "🔁 Finished occurrence of a recurring task — read only"));
  panel.appendChild(row("Occurrence date", day ? formatDue(day).text : null));
  panel.appendChild(row("Finished", when && !isNaN(when) ? when.toLocaleString([], { dateStyle: "medium", timeStyle: "short" }) : null));
  panel.appendChild(row("Project", [c.project_name, c.todo_list_name].filter(Boolean).join(" › ") || null));
  panel.appendChild(row("Time spent", (ownSeconds || subTotal)
    ? `${formatElapsed((ownSeconds || 0) + subTotal)}` + (subs.length && ownSeconds ? ` (task itself ${formatElapsed(ownSeconds)})` : "") : null));
  if (subs.length) {
    const list = el("div", { class: "subtask-list expanded" });
    for (const s of subs) {
      list.appendChild(el("div", { class: "subtask-row", style: "cursor:default" }, [
        el("div", { class: "checkbox small disabled" + (s.checked ? " checked" : "") }, s.checked ? "✓" : ""),
        el("div", { class: "task-main" }, [
          el("div", { class: "task-content" + (s.checked ? " done" : "") }, s.title),
          el("div", { class: "task-meta" }, [
            s.due_date ? el("span", {}, formatDue(s.due_date).text) : null,
            s.time_spent_seconds ? el("span", { class: "duration-chip" }, "⏱ " + formatElapsed(s.time_spent_seconds)) : null,
          ]),
        ]),
      ]));
    }
    panel.appendChild(el("div", { class: "field" }, [el("label", {}, `Subtasks (${subs.filter((x) => x.checked).length}/${subs.length} done)`), list]));
  }
  panel.appendChild(el("div", { class: "btn-row", style: "margin-top:20px" }, [
    el("button", { class: "btn", onclick: () => openTaskDetail(c.task_id) }, "Open current task"),
  ]));
  document.getElementById("taskDetailOverlay").classList.remove("hidden");
}

function closeTaskDetail() {
  document.getElementById("taskDetailOverlay").classList.add("hidden");
}
document.getElementById("taskDetailOverlay").addEventListener("click", (e) => {
  if (e.target.id === "taskDetailOverlay") closeTaskDetail();
});

// Collapsible sections in the task panel. The panel is rebuilt on every
// refresh, so the collapsed state lives here rather than in the DOM.
const collapsedPanelSections = new Set();
function panelSection(key, title, nodes) {
  const section = el("div", { class: "panel-section" + (collapsedPanelSections.has(key) ? " collapsed" : "") });
  const header = el("button", { type: "button", class: "panel-section-header", "aria-expanded": String(!collapsedPanelSections.has(key)) }, [
    el("span", { class: "ps-caret" }, "▶"), el("span", {}, title),
  ]);
  const inner = el("div", { class: "panel-section-inner" }, nodes.filter(Boolean));
  const body = el("div", { class: "panel-section-body" }, [inner]);
  header.addEventListener("click", () => {
    const collapsed = !section.classList.contains("collapsed");
    section.classList.toggle("collapsed", collapsed);
    section.classList.add("animating");
    clearTimeout(section._t);
    section._t = setTimeout(() => section.classList.remove("animating"), 260);
    header.setAttribute("aria-expanded", String(!collapsed));
    if (collapsed) collapsedPanelSections.add(key); else collapsedPanelSections.delete(key);
  });
  section.append(header, body);
  return section;
}

function renderTaskPanel(task) {
  const panel = document.getElementById("taskPanel");
  panel.innerHTML = "";

  const patch = async (fields) => { await api.patch(`/api/tasks/${task.id}`, fields); refreshCurrentView(); };

  const titleInput = el("input", { type: "text", value: task.title, style: "font-size:16px;font-weight:600;border:none;background:transparent;width:100%;color:var(--fg)" });
  titleInput.addEventListener("change", () => patch({ title: titleInput.value }));

  // Urgent / Video toggles, as pill buttons
  const flagChip = (icon, label, field, on, kind) => {
    const input = el("input", { type: "checkbox", checked: on || undefined });
    const chip = el("label", { class: `flag-chip ${kind}` + (on ? " on" : "") }, [
      input, el("span", { class: "flag-chip-icon" }, icon), el("span", {}, label),
    ]);
    input.addEventListener("change", (e) => {
      chip.classList.toggle("on", e.target.checked);
      patch({ [field]: e.target.checked });
    });
    return chip;
  };
  panel.appendChild(el("div", { class: "panel-head" }, [
    titleInput,
    el("div", { class: "field flag-chips panel-head-chips" }, [
      flagChip("🚩", "Urgent", "urgent", task.urgent, "urgent"),
      flagChip("🎥", "Video", "is_video", task.is_video, "video"),
    ]),
    el("button", { class: "icon-btn panel-head-close", onclick: closeTaskDetail }, "✕"),
  ]));

  const organize = [], content = [], timing = [];
  const orgRow = [], timeRow = [];
  const refreshDetail = () => { openTaskDetail(task.id); refreshCurrentView(); };
  const hasSubs = task.subtasks && task.subtasks.length;
  timeRow.push(el("div", { class: "field grow" }, [
    el("label", {}, hasSubs ? "Time spent (this task)" : "Time spent"),
    el("div", { class: "time-spent-line", style: "display:flex;gap:10px;align-items:center" }, [
      timeEditor({ ...task, time_spent_seconds: task.own_time_seconds ?? task.time_spent_seconds }, "tasks", refreshDetail),
      timerControls({ ...task, subtasks: [] }, "tasks", refreshDetail),
    ]),
  ]));
  const totalNote = hasSubs ? el("div", { class: "muted small", style: "margin:4px 0 12px" },
    `Total with subtasks: ${formatElapsed(task.total_time_seconds)}`) : null;

  // Video type -- only meaningful once the task is flagged as a video.
  // Setting this by hand (rather than only at creation from a template)
  // also decides which icon shows next to the title in list views, and
  // whether retitling the task will treat it as a Weekly News Video for
  // things like the "Edit A Roll" subtask backfill.
  if (task.is_video) {
    const known = state.templates.map((t) => el("option", { value: t.key }, t.label));
    if (task.video_template && !templateByKey(task.video_template)) {      // template since deleted: keep the value selectable
      known.push(el("option", { value: task.video_template }, `${task.video_template} (deleted template)`));
    }
    const templateSelect = el("select", { id: "videoTypeSelect" }, [
      el("option", { value: "" }, "— Not set —"),
      ...known,
    ]);
    templateSelect.value = task.video_template || "";
    templateSelect.addEventListener("change", () => patch({ video_template: templateSelect.value || null }));
    orgRow.push(el("div", { class: "field" }, [el("label", {}, "Video type"), templateSelect]));
  }

  const descInput = autoGrowTextarea(el("textarea", { placeholder: "Notes" }, task.notes || ""));
  descInput.value = task.notes || "";
  descInput.addEventListener("change", () => patch({ notes: descInput.value }));
  const notesField = el("div", { class: "field" }, [el("label", {}, "Notes"), descInput]);

  // Due date — a popup mini-calendar rather than a native <input type=date>,
  // whose picker-indicator icon is often invisible in dark mode.
  const dueField = el("div", { class: "field" }, [
    el("label", {}, "Due date"),
    dateField(task.due_date, (iso) => patch({ due_date: iso })),
  ]);

  // Start time — used to place the task in the calendar's week view.
  const startTimeInput = el("input", { type: "time", value: task.start_time || "" });
  startTimeInput.addEventListener("change", () => patch({ start_time: startTimeInput.value || null }));
  timeRow.push(el("div", { class: "field" }, [el("label", {}, "Start time"), startTimeInput]));

  // Estimated duration, entered in hours (e.g. 1.5 for an hour and a half)
  // but stored as minutes so existing display/sum logic doesn't need two units.
  const initialHours = task.duration_minutes ? Math.round((task.duration_minutes / 60) * 100) / 100 : "";
  const durationInput = el("input", { type: "number", min: "0", step: "0.25", value: initialHours, placeholder: "hours" });
  const durationPreview = el("span", { class: "muted small", style: "margin-left:8px" }, formatDuration(task.duration_minutes));
  durationInput.addEventListener("change", () => {
    const hours = durationInput.value ? parseFloat(durationInput.value) : null;
    const minutes = hours ? Math.round(hours * 60) : null;
    durationPreview.textContent = formatDuration(minutes);
    patch({ duration_minutes: minutes });
  });
  timeRow.push(el("div", { class: "field" }, [
    el("label", {}, "Estimated duration (hours)"),
    el("div", { class: "duration-line", style: "display:flex;align-items:center" }, [durationInput, durationPreview]),
  ]));

  // Linked notes file — a markdown file on this computer. The AI buttons on
  // this task's video-related subtasks (order topics, tags, thumbnails) read
  // this file's "Timestamps"/"Links"/"Content" sections.
  content.push(renderNoteLinkField(task, patch));

  // Recurrence
  const rec = renderRecurrenceField(task, patch);
  timing.push(el("div", { class: "field-row due-row" }, [dueField, rec.chipField]), rec.body);

  // Move to list
  const projSelect = el("select", {}, state.projects.map((p) => el("option", { value: p.id, selected: p.id === task.project_id || undefined }, p.name)));
  const listSelect = el("select", {}, []);
  function paintListOptions(projectId, currentListId) {
    listSelect.innerHTML = "";
    for (const l of state.todoLists.filter((x) => x.project_id === projectId)) {
      listSelect.appendChild(el("option", { value: l.id, selected: l.id === currentListId || undefined }, l.name));
    }
  }
  paintListOptions(task.project_id, task.todo_list_id);
  projSelect.addEventListener("change", () => {
    // Changing the project moves the task to that project's first list
    // (the List selector below can then pick another one).
    const lists = state.todoLists.filter((x) => x.project_id === projSelect.value);
    if (!lists.length) {
      projSelect.value = task.project_id;
      showToast("That project has no list yet — create one first");
      return;
    }
    paintListOptions(projSelect.value, lists[0].id);
    patch({ todo_list_id: lists[0].id });
  });
  listSelect.addEventListener("change", () => patch({ todo_list_id: listSelect.value }));
  orgRow.push(el("div", { class: "field" }, [el("label", {}, "Project"), projSelect]));
  orgRow.push(el("div", { class: "field" }, [el("label", {}, "List"), listSelect]));

  // Tags
  const chipRow = el("div", { class: "chip-row" });
  function paintChips() {
    chipRow.innerHTML = "";
    const selectedIds = new Set((task.tags || []).map((g) => g.id));
    for (const g of state.tags) {
      chipRow.appendChild(el("div", {
        class: "chip" + (selectedIds.has(g.id) ? " selected" : ""),
        onclick: async () => {
          const ids = new Set(selectedIds);
          if (ids.has(g.id)) ids.delete(g.id); else ids.add(g.id);
          const updated = await api.post(`/api/tasks/${task.id}/tags`, { tag_ids: [...ids] });
          task.tags = updated.tags;
          paintChips();
          refreshCurrentView();
        },
      }, [el("span", { class: "swatch", style: `background:${g.color};width:9px;height:9px` }), g.name]));
    }
    const newInput = el("input", { type: "text", placeholder: "New tag", style: "width:100px;padding:3px 8px;border-radius:12px;border:1px solid var(--border);background:var(--bg);color:var(--fg);font-size:12px" });
    newInput.addEventListener("keydown", async (e) => {
      if (e.key === "Enter" && newInput.value.trim()) {
        const res = await api.post("/api/tags", { name: newInput.value.trim(), color: PROJECT_COLORS[state.tags.length % PROJECT_COLORS.length] });
        state.tags = await api.get("/api/tags");
        const updated = await api.post(`/api/tasks/${task.id}/tags`, { tag_ids: [...selectedIds, res.id] });
        task.tags = updated.tags;
        paintChips();
        refreshCurrentView();
      }
    });
    chipRow.appendChild(newInput);
  }
  paintChips();
  organize.push(el("div", { class: "field" }, [el("label", {}, "Tags"), chipRow]));

  // Attachment
  content.push(el("div", { class: "field" }, [
    el("label", {}, "Attached file"),
    task.attachment_name
      ? el("div", { class: "attachment-row" }, [
          el("a", { href: `/api/tasks/${task.id}/attachment`, target: "_blank" }, "📎 " + task.attachment_name),
          el("button", { class: "icon-btn small", onclick: async () => { await api.del(`/api/tasks/${task.id}/attachment`); openTaskDetail(task.id); refreshCurrentView(); } }, "🗑"),
        ])
      : (() => {
          const input = el("input", { type: "file" });
          input.addEventListener("change", async () => {
            if (input.files[0]) { await api.upload(`/api/tasks/${task.id}/attachment`, input.files[0]); openTaskDetail(task.id); refreshCurrentView(); }
          });
          return input;
        })(),
  ]));

  content.push(notesField);   // free-text Notes: last field of the Content section
  organize.unshift(el("div", { class: "field-row" }, orgRow));
  timing.splice(2, 0, el("div", { class: "field-row time-row" }, timeRow), totalNote);
  panel.appendChild(panelSection("organize", "Organize", organize));
  panel.appendChild(panelSection("content", "Content", content));
  panel.appendChild(panelSection("timing", "Timing", timing));
  panel.appendChild(panelSection("subtasks", "Subtasks", [renderSubtasksField(task)]));

  // Danger zone
  panel.appendChild(el("div", { class: "btn-row spread", style: "margin-top: 24px" }, [
    el("button", {
      class: "btn",
      onclick: async () => { await api.post(`/api/tasks/${task.id}/toggle`, { checked: !task.checked }); openTaskDetail(task.id); refreshCurrentView(); },
    }, task.checked ? "Mark not done" : "Mark done"),
    el("button", {
      class: "btn danger",
      onclick: async () => { if (await confirmDeleteTask(task)) { await api.del(`/api/tasks/${task.id}`); closeTaskDetail(); refreshCurrentView(); } },
    }, "Delete task"),
  ]));
}

/* ---------------------------------------------------------------------- *
 * Subtasks editor (inside the task panel). Each subtask has its own due
 * date, estimated duration (hours) and urgency flag; the video flag is
 * inherited from the parent task, not editable per subtask.
 * ---------------------------------------------------------------------- */
function renderSubtasksField(task) {
  const wrap = el("div", { class: "field" });
  const list = el("div", { class: "subtask-editor-list" });
  if ((task.subtasks || []).length) {
    list.appendChild(el("div", { class: "subtask-editor-head" },
      ["", "Subtask", "Due", "Start", "Est. (h)", "Spent", "Timer"].map((t) => el("span", {}, t))));
  }
  for (const s of task.subtasks || []) list.appendChild(subtaskEditorRow(s, task));
  wrap.appendChild(list);

  const newInput = el("input", { type: "text", placeholder: "Add a subtask" });
  newInput.addEventListener("keydown", async (e) => {
    if (e.key === "Enter" && newInput.value.trim()) {
      await api.post(`/api/tasks/${task.id}/subtasks`, { title: newInput.value.trim() });
      openTaskDetail(task.id);
      refreshCurrentView();
    }
  });
  wrap.appendChild(el("div", { class: "inline-add-row" }, [newInput]));
  return wrap;
}

function subtaskEditorRow(s, task) {
  const checked = !!s.checked;

  const checkbox = el("div", {
    class: "checkbox small" + (checked ? " checked" : ""),
    onclick: async () => {
      await api.post(`/api/subtasks/${s.id}/toggle`, { checked: !checked });
      openTaskDetail(task.id);
      refreshCurrentView();
    },
  }, checked ? "✓" : "");

  const titleInput = el("input", { type: "text", value: s.title, class: "subtask-editor-title" });
  titleInput.addEventListener("change", async () => {
    await api.patch(`/api/subtasks/${s.id}`, { title: titleInput.value });
    refreshCurrentView();
  });

  const dateBtn = dateField(s.due_date, async (iso) => {
    await api.patch(`/api/subtasks/${s.id}`, { due_date: iso });
    refreshCurrentView();
  });
  dateBtn.classList.add("small");

  const timeInput = el("input", { type: "time", value: s.start_time || "", title: "Start time" });
  timeInput.addEventListener("change", async () => {
    await api.patch(`/api/subtasks/${s.id}`, { start_time: timeInput.value || null });
    refreshCurrentView();
  });

  const hours = s.duration_minutes ? Math.round((s.duration_minutes / 60) * 100) / 100 : "";
  const durInput = el("input", { type: "number", min: "0", step: "0.25", value: hours, placeholder: "h", title: "Estimated duration (hours)" });
  durInput.addEventListener("change", async () => {
    const h = durInput.value ? parseFloat(durInput.value) : null;
    await api.patch(`/api/subtasks/${s.id}`, { duration_minutes: h ? Math.round(h * 60) : null });
    refreshCurrentView();
  });

  const subRefresh = () => { openTaskDetail(task.id); refreshCurrentView(); };
  // display:contents (see app.css): "min spent" and the timer are two separate grid cells
  const subTimerControls = el("span", { class: "sub-time-wrap" }, [
    timeEditor(s, "subtasks", subRefresh),
    timerControls(s, "subtasks", subRefresh),
  ]);

  const mainRow = el("div", { class: "subtask-editor-row" + (checked ? " done" : "") }, [
    checkbox,
    titleInput,
    dateBtn,
    timeInput,
    durInput,
    subTimerControls,
  ]);

  const aiButtons = subtaskAIButtons(s.title, task, s.template_sub_id);
  if (!aiButtons.length) return mainRow;

  const aiRow = el("div", { class: "subtask-ai-row" }, aiButtons.map((b) => el("button", {
    type: "button",
    class: "btn ai-btn",
    onclick: (e) => (b.kind === "list_to_ppt" ? openListToPptModal(s.id, b.label)
      : b.kind === "powerpoint" || b.endpoint === "generate-pptx"
      ? openGeneratePptxModal(s.id, b.label)
      : runSubtaskAI(e.currentTarget, s.id, b.endpoint, b.label, b.buttonId)),
  }, `✨ ${b.label}`)));

  return el("div", {}, [mainRow, aiRow]);
}

/* ---------------------------------------------------------------------- *
 * AI-powered subtask actions — order topics, generate tags, thumbnail
 * ideas, script planning, PowerPoint generation. Most read the parent
 * task's linked notes file (or, for script planning, its own Notes field)
 * server-side and call Claude, showing the result in a copyable popup.
 * "Generate" (Create powerpoint) is the exception -- it opens its own modal
 * to collect links/a document/a prompt first; see openGeneratePptxModal.
 * ---------------------------------------------------------------------- */
function subtaskAIButtons(title, task, subId) {
  const t = (title || "").trim().toLowerCase();
  // Tasks created from a template: the buttons are the ones configured on the
  // matching template subtask (Utilities > Templates), even if there are none.
  const tpl = task && task.video_template ? templateByKey(task.video_template) : null;
  const ts = tpl ? (tpl.subtasks.find((x) => subId && x.id === subId)
    || (subId ? null : tpl.subtasks.find((x) => (x.title || "").trim().toLowerCase() === t))) : null;
  if (ts) {
    return (ts.ai_buttons || []).map((b) => (b.kind === "powerpoint"
      ? { label: b.label, kind: "powerpoint" }
      : b.kind === "list_to_ppt" ? { label: b.label, kind: "list_to_ppt" }
      : { label: b.label, endpoint: "run", buttonId: b.id, applyToNote: !!b.apply_to_note, kind: b.kind }));
  }
  // Tasks with no template (or whose subtask is no longer in it): the original buttons.
  if (t === "order topics") return [{ label: "Order topics", endpoint: "order-topics" }];
  if (t.startsWith("publish video")) return [{ label: "Generate tags", endpoint: "generate-tags" }];
  if (t === "make 3 thumbnails") return [{ label: "Generate ideas", endpoint: "generate-thumbnails" }];
  if (t === "write script") return [{ label: "Plan out this script", endpoint: "plan-script" }];
  if (t === "create powerpoint") return [{ label: "Generate", endpoint: "generate-pptx" }];
  return [];
}

async function runSubtaskAI(btnEl, subtaskId, endpoint, label, buttonId) {
  const original = btnEl.textContent;
  btnEl.disabled = true;
  btnEl.textContent = "Working…";
  const aiTaskId = startAiTask(label);
  try {
    const res = await api.post(`/api/subtasks/${subtaskId}/ai/${endpoint}`, buttonId ? { button_id: buttonId } : {});
    if (!res.silent) openAIResultModal(label, res.result, { subtaskId, endpoint, applyToNote: endpoint === "order-topics" || !!res.apply_to_note });
  } catch (e) {
    let msg = "Something went wrong.";
    try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
    showToast(msg, { sticky: true });
  } finally {
    btnEl.disabled = false;
    btnEl.textContent = original;
    finishAiTask(aiTaskId);
  }
}

function renderAIMarkdown(text) {
  const view = el("div", { class: "ai-result-md" });
  try {
    const md = window.markdownit({ html: false, breaks: true, linkify: true });
    view.innerHTML = md.render(text || "");
    view.querySelectorAll("a").forEach((a) => { a.target = "_blank"; a.rel = "noopener"; });
  } catch {
    view.textContent = text;
  }
  return view;
}

// Result of an AI button: shown formatted (markdown rendered) by default, with
// a switch to the raw markdown; Copy always copies the raw text. `opts.subtaskId`
// + `opts.endpoint === "order-topics"` adds the two buttons that write the
// result into the task's linked note.
function openAIResultModal(title, text, opts = {}) {
  const raw = el("textarea", { readonly: "readonly", class: "ai-result-box" });
  raw.value = text;
  const formatted = renderAIMarkdown(text);
  const body = el("div", { class: "ai-result-wrap" }, [formatted]);
  let showRaw = false;
  const toggle = el("button", {
    type: "button", class: "btn small",
    onclick: () => {
      showRaw = !showRaw;
      body.replaceChildren(showRaw ? raw : formatted);
      toggle.textContent = showRaw ? "Show formatted" : "Show markdown";
    },
  }, "Show markdown");

  const buttons = [el("button", { class: "btn", onclick: closeModal }, "Close")];
  if (opts.subtaskId && opts.applyToNote) {
    const apply = (mode, label, btn) => async () => {
      btn.disabled = true;
      try {
        const res = await api.post(`/api/subtasks/${opts.subtaskId}/ai/apply-order-topics`, { mode, content: text });
        showToast(res.summary || "Note updated");
        closeModal();
      } catch (e) {
        let msg = "Couldn't update the note.";
        try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
        showToast(msg, { sticky: true });
        btn.disabled = false;
      }
    };
    const replaceBtn = el("button", { class: "btn" }, "Replace Note content");
    const appendBtn = el("button", { class: "btn" }, "Append to Note");
    replaceBtn.onclick = apply("replace", "Replace", replaceBtn);
    appendBtn.onclick = apply("append", "Append", appendBtn);
    buttons.push(replaceBtn, appendBtn);
  }
  buttons.push(el("button", {
    class: "btn primary",
    onclick: async () => {
      try {
        await navigator.clipboard.writeText(text);
        showToast("Copied to clipboard");
      } catch {
        showToast("Couldn't copy automatically — select the text and copy manually");
      }
    },
  }, "Copy"));

  openModal(title, [el("div", { class: "ai-result-bar" }, [toggle]), body], buttons);
  document.getElementById("modalBody").classList.add("modal-wide", "modal-ai");
}

// "Generate" (the Create powerpoint subtask's AI button): collects any
// number of pasted links, an optional reference document, and a free-text
// prompt, then asks the server to plan slides from all of that and stamp
// them out onto copies of the project's own presentation.pptx so the
// result matches its look (see app/pptx_gen.py). The modal stays open after
// a successful generation so the person can download the result.
function openGeneratePptxModal(subtaskId, label) {
  const linksInput = el("textarea", { rows: "3", placeholder: "One link per line (optional)" });
  const fileInput = el("input", { type: "file", accept: ".pdf,.docx,.txt,.md" });
  const promptInput = el("textarea", { rows: "3", placeholder: "Describe what you want in the presentation (optional)" });
  const ocrBox = el("input", { type: "checkbox" });
  const statusLine = el("div", { class: "muted small", style: "margin-top:4px" }, "");

  const generateBtn = el("button", {
    class: "btn primary",
    onclick: async () => {
      const fd = new FormData();
      fd.append("links", linksInput.value);
      fd.append("prompt", promptInput.value);
      if (fileInput.files[0]) fd.append("file", fileInput.files[0]);
      if (ocrBox.checked) fd.append("force_ocr", "1");

      generateBtn.disabled = true;
      generateBtn.textContent = "Working…";
      statusLine.textContent = "";
      const aiTaskId = startAiTask(label);
      try {
        const res = await api.postForm(`/api/subtasks/${subtaskId}/ai/generate-pptx`, fd);
        statusLine.innerHTML = "";
        statusLine.appendChild(el("a", {
          href: res.download_url,
          target: "_blank",
          class: "btn primary",
        }, `⬇ Download .pptx (${res.slide_count} slides)`));
        const notes = [];
        if (res.ocr_pages) notes.push(`OCR used on ${res.ocr_pages} page${res.ocr_pages === 1 ? "" : "s"}`);
        const kinds = { datasheet: "datasheet", detachment_rule: "detachment rule", enhancements: "enhancements", stratagems: "stratagem slide" };
        const found = Object.entries(res.blocks_found || {}).map(([k, n]) => `${n} ${kinds[k] || k}${n === 1 ? "" : "s"}`);
        if (found.length) notes.push("Found in the PDF: " + found.join(", "));
        if (notes.length) statusLine.appendChild(el("div", { class: "muted small", style: "margin-top:6px" }, notes.join(" · ")));
      } catch (e) {
        let msg = "Something went wrong.";
        try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
        statusLine.textContent = msg;
      } finally {
        generateBtn.disabled = false;
        generateBtn.textContent = "Generate";
        finishAiTask(aiTaskId);
      }
    },
  }, "Generate");

  openModal("Generate PowerPoint", [
    el("div", { class: "field" }, [el("label", {}, "Links"), linksInput]),
    el("div", { class: "field" }, [el("label", {}, "Reference document (PDF, Word, or text)"), fileInput,
      el("label", { class: "muted small", style: "display:block;margin-top:4px;font-weight:normal" }, [ocrBox,
        " Force OCR (scanned PDF; pages without text are OCR'd automatically). From a PDF, each datasheet, detachment rule, enhancements block and set of 3 stratagems becomes one slide (picture + French recap). Use the prompt to choose which, or to adjust the text."])]),
    el("div", { class: "field" }, [el("label", {}, "Prompt"), promptInput]),
    statusLine,
  ], [
    el("button", { class: "btn", onclick: closeModal }, "Close"),
    generateBtn,
  ]);
}

// "List to PPT" (Warhammer Video, Create powerpoint): paste an army list exported from the Games Workshop app, get a
// PowerPoint in the usual template (see app/army_list.py). Rules are read from Wahapedia by Claude, so it can take a
// few minutes the first time; results are cached for next time.
function openListToPptModal(subtaskId, label) {
  const input = el("textarea", { rows: "16", placeholder: "Collez ici votre liste d'armée (format de l'application Games Workshop)", style: "width:100%;font-family:monospace;font-size:12px" });
  const status = el("div", { class: "muted small", style: "margin-top:8px" }, "");
  const modeSelect = el("select", { style: "width:auto;min-width:220px" }, [
    el("option", { value: "ppt" }, "PPT complet (slides + images)"),
    el("option", { value: "images" }, "Images seulement (zip)"),
  ]);
  const btnLabel = () => (modeSelect.value === "images" ? "Create images" : "Create PPT");
  modeSelect.addEventListener("change", () => { createBtn.textContent = btnLabel(); });
  const createBtn = el("button", {
    class: "btn primary",
    onclick: async () => {
      if (!input.value.trim()) { status.textContent = "Collez d'abord une liste."; return; }
      const imagesOnly = modeSelect.value === "images";
      createBtn.disabled = true;
      cancelBtn.disabled = true;
      modeSelect.disabled = true;
      createBtn.textContent = "Création…";
      status.textContent = "Lecture de Wahapedia et création des slides : cela peut prendre quelques minutes (plus rapide ensuite, grâce au cache).";
      const aiTaskId = startAiTask(label);
      try {
        const res = await api.post(`/api/subtasks/${subtaskId}/ai/list-to-ppt`, { text: input.value, mode: imagesOnly ? "images" : "ppt" });
        status.innerHTML = "";
        if (res.images_only) {
          const row = el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;align-items:center" });
          row.appendChild(el("a", { href: res.download_url, target: "_blank", class: "btn primary" }, `⬇ Télécharger le zip (${res.slide_count} images)`));
          const folderMsg = el("span", { class: "muted small" }, "");
          row.appendChild(el("button", { class: "btn", onclick: async () => {
            try { await api.post(`/api/subtasks/${subtaskId}/ai/list-to-ppt/open-folder`, {}); folderMsg.textContent = ""; }
            catch (e) { let m = "Impossible d'ouvrir le dossier."; try { const j = JSON.parse(e.message); m = j.error || m; if (j.path) m += " " + j.path; } catch { /* keep */ } folderMsg.textContent = m; }
          } }, "📂 Ouvrir le dossier du zip"));
          row.appendChild(folderMsg);
          status.appendChild(row);
        } else {
          status.appendChild(el("a", { href: res.download_url, target: "_blank", class: "btn primary" }, `⬇ Télécharger le PPT (${res.slide_count} slides)`));
        }
        if ((res.warnings || []).length) {
          status.appendChild(el("div", { class: "muted small", style: "margin-top:8px" }, "À vérifier :"));
          status.appendChild(el("ul", { class: "muted small", style: "margin:4px 0 0 18px" }, res.warnings.map((w) => el("li", {}, w))));
        }
      } catch (e) {
        let msg = "Une erreur est survenue.";
        try { msg = JSON.parse(e.message).error || msg; } catch { /* keep default */ }
        status.textContent = msg;
      } finally {
        createBtn.disabled = false;
        cancelBtn.disabled = false;
        modeSelect.disabled = false;
        createBtn.textContent = btnLabel();
        finishAiTask(aiTaskId);
      }
    },
  }, "Create PPT");
  const cancelBtn = el("button", { class: "btn", onclick: closeModal }, "Cancel");
  openModal(label || "List to PPT", [
    el("div", { class: "field" }, [el("label", {}, "Liste d'armée Warhammer 40K"), input]),
    el("div", { class: "field" }, [el("label", {}, "Mode"), modeSelect]),
    status,
  ], [cancelBtn, createBtn]);
}

function renderRecurrenceField(task, patch) {
  const wrap = el("div", { class: "field" });
  const enabled = !!task.recurrence;
  const rule = task.recurrence || { unit: "week", interval: 1, weekdays: [], end_date: null };

  const enableCheckbox = el("input", { type: "checkbox", checked: enabled || undefined });
  const body = el("div", { class: "field recurrence-body", style: `margin-top:8px; ${enabled ? "" : "display:none"}` });   // "field": same input styling as the other task fields

  const intervalInput = el("input", { type: "number", min: "1", value: String(rule.interval || 1), style: "width:70px" });
  const unitSelect = el("select", { style: "width:auto;min-width:110px" }, ["day", "week", "month", "year"].map((u) => el("option", { value: u, selected: u === rule.unit || undefined }, u + "(s)")));
  const weekdayRow = el("div", { class: "weekday-row" });
  const selectedWeekdays = new Set(rule.weekdays || []);
  function paintWeekdays() {
    weekdayRow.innerHTML = "";
    WEEKDAY_NAMES.forEach((name, idx) => {
      weekdayRow.appendChild(el("button", {
        type: "button",
        class: "weekday-btn" + (selectedWeekdays.has(idx) ? " selected" : ""),
        onclick: () => { selectedWeekdays.has(idx) ? selectedWeekdays.delete(idx) : selectedWeekdays.add(idx); paintWeekdays(); commit(); },
      }, name[0]));
    });
  }
  const weekdayField = el("div", { class: "field", style: unitSelect.value === "week" ? "" : "display:none" }, [el("label", {}, "On days"), weekdayRow]);
  paintWeekdays();

  const preview = el("div", { class: "muted small", style: "margin-top:6px" });
  function updatePreview() {
    preview.textContent = describeRecurrence({ unit: unitSelect.value, interval: intervalInput.value, weekdays: [...selectedWeekdays] });
  }
  updatePreview();

  function commit() {
    weekdayField.style.display = unitSelect.value === "week" ? "block" : "none";
    updatePreview();
    if (!enableCheckbox.checked) { patch({ recurrence: null }); return; }
    patch({
      recurrence: {
        unit: unitSelect.value,
        interval: Math.max(1, parseInt(intervalInput.value || "1", 10)),
        weekdays: unitSelect.value === "week" ? [...selectedWeekdays] : [],
        end_date: null,
      },
    });
  }

  enableCheckbox.addEventListener("change", () => { body.style.display = enableCheckbox.checked ? "block" : "none"; commit(); });
  intervalInput.addEventListener("change", commit);
  unitSelect.addEventListener("change", commit);

  body.appendChild(el("div", { style: "display:flex;gap:8px;align-items:center" }, [el("span", {}, "Every"), intervalInput, unitSelect]));
  body.appendChild(weekdayField);
  body.appendChild(preview);

  const repeatChip = el("label", { class: "flag-chip repeat" + (enabled ? " on" : "") }, [
    enableCheckbox, el("span", { class: "flag-chip-icon" }, "🔁"), el("span", {}, "Repeats"),
  ]);
  enableCheckbox.addEventListener("change", () => repeatChip.classList.toggle("on", enableCheckbox.checked));
  const chipField = el("div", { class: "field", style: "flex:0 0 auto" }, [repeatChip]);
  body.style.marginBottom = "12px";
  return { chipField, body };
}

/* ---------------------------------------------------------------------- *
 * Dev convenience: restart the Python process in place, then reload once
 * it's back up, so a code push doesn't require Ctrl+C / rerun by hand.
 * ---------------------------------------------------------------------- */
function formatBytes(n) {
  if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + " MB";
  if (n >= 1024) return Math.round(n / 1024) + " KB";
  return n + " B";
}

// "Clean up": deletes the generated files (PowerPoint decks made by the
// Generate button + the images cropped from PDFs) to free disk space.
function wireCleanup() {
  document.getElementById("cleanupBtn").addEventListener("click", async () => {
    const info = await api.get("/api/cleanup");
    if (!info.files) { showToast("Nothing to clean up"); return; }
    if (!(await confirmModal({
      title: "Clean up generated files?",
      message: `${info.files} files, ${formatBytes(info.bytes)} will be deleted: the PowerPoint decks made by the Generate button and the images cropped from PDFs. `
        + "Your tasks, attachments and backups are not touched, and a deck can be generated again later.",
      confirmLabel: "Delete files", danger: true,
    }))) return;
    const done = await api.post("/api/cleanup", {});
    showToast(`Freed ${formatBytes(done.bytes)} (${done.files} files)`);
  });
}

function wireUtilities() {
  const toggle = document.getElementById("utilitiesToggle");
  const list = document.getElementById("utilitiesList");
  const caret = document.getElementById("utilitiesCaret");
  // monochrome icons for the static Utilities entries
  document.querySelectorAll("[data-sym]").forEach((n) => { if (!n.querySelector("svg")) n.replaceWith(symbolicIcon(n.dataset.sym)); });
  let open = false;   // always folded when the page loads (the toggle only lasts until the next reload)
  const paint = () => {
    list.classList.toggle("open", open);
    caret.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", String(open));
  };
  toggle.addEventListener("click", () => {
    open = !open;
    paint();
  });
  paint();
}

function wireBackups() {
  document.getElementById("backupsBtn").addEventListener("click", openBackupsView);
}

function wireReloadServer() {
  document.getElementById("reloadServerBtn").addEventListener("click", async () => {
    showToast("Restarting server…");
    try {
      await api.post("/api/restart", {});
    } catch (e) {
      // the restart itself may tear the connection down before the response
      // finishes — that's expected, not a failure.
    }
    let attempts = 0;
    const poll = setInterval(async () => {
      attempts += 1;
      try {
        const r = await fetch("/", { cache: "no-store" });
        if (r.ok) { clearInterval(poll); window.location.reload(); }
      } catch (e) {
        // still restarting
      }
      if (attempts > 40) clearInterval(poll); // ~20s: give up quietly
    }, 500);
  });
}

/* ---------------------------------------------------------------------- *
 * Desktop-widget coordination: lets the KDE Plasma "Today" widget reuse this
 * tab instead of always opening a new one. While this tab is loaded, it
 * pings the server every few seconds so the widget can tell a tab is alive;
 * it also polls for a "pending" task id the widget may have left (clicked
 * from the widget while this tab was already open) and jumps to it, pulling
 * itself to the front. A #task=<id> in the URL on load is the fallback path
 * for when the widget had to open a brand-new tab.
 * ---------------------------------------------------------------------- */
function wireDesktopWidgetBridge() {
  // no-store: these are polled every 1.5-3s and must always hit the server,
  // never a browser-cached response, or the widget's "is a tab already
  // open?" check goes stale.
  const pingServer = (url) => fetch(url, { method: "POST", cache: "no-store" }).catch(() => {});
  setInterval(() => pingServer("/api/tab/heartbeat"), 3000);
  pingServer("/api/tab/heartbeat");

  setInterval(async () => {
    try {
      const r = await fetch("/api/tab/pending", { cache: "no-store" });
      if (!r.ok) return;
      const data = await r.json();
      if (data && data.task_id) {
        window.focus();
        openTaskDetail(data.task_id);
      }
    } catch (e) {
      // server hiccup -- try again on the next tick
    }
  }, 1500);

  const m = /#task=([\w-]+)/.exec(window.location.hash);
  if (m) {
    history.replaceState(null, "", window.location.pathname + window.location.search);
    openTaskDetail(m[1]);
  }
}

/* ---------------------------------------------------------------------- *
 * Time report — stacked bar chart of tracked time, per week or per month,
 * grouped by Activity (same subtask name; a main task's own time counts
 * under the task's name) or by Project (same main task name).
 * ---------------------------------------------------------------------- */
const REPORT_COLORS = ["#3daee9", "#f39c12", "#2ecc71", "#9b59b6", "#e91e63", "#1abc9c", "#e67e22", "#5c6bc0"];
const REPORT_OTHER_COLOR = "#9aa0a6";
// bars shown: 5 weeks / 12 months / the 7 days of one week ("thisweek")
const reportPeriodCount = (gran) => (gran === "week" ? 5 : gran === "thisweek" ? 7 : 12);
// how many periods the ‹ › buttons move: a whole window, or one week for "thisweek"
const reportStepCount = (gran) => (gran === "thisweek" ? 1 : reportPeriodCount(gran));
// Colors come from the API and are interpolated into SVG/HTML strings: only plain hex is accepted.
function safeColor(c, fallback = "#7f8c8d") {
  return typeof c === "string" && /^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(c) ? c : fallback;
}
const escHtml = (t) => String(t).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// "thisweek": the anchor is the Monday of the shown week, each bar is one day
function reportPeriodStart(iso, gran) {
  if (gran === "thisweek") return iso;
  return gran === "month" ? iso.slice(0, 8) + "01" : startOfWeekIso(iso);
}
function reportNextPeriod(start, gran) {
  if (gran === "week" || gran === "thisweek") return addDaysIso(start, 7);
  const d = parseIso(start);
  return toIso(new Date(d.getFullYear(), d.getMonth() + 1, 1));
}
function reportPrevPeriod(start, gran) {
  if (gran === "week" || gran === "thisweek") return addDaysIso(start, -7);
  const d = parseIso(start);
  return toIso(new Date(d.getFullYear(), d.getMonth() - 1, 1));
}
function isoWeekNumber(iso) {
  const d = parseIso(iso);
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  t.setUTCDate(t.getUTCDate() + 4 - (t.getUTCDay() || 7));
  return Math.ceil(((t - Date.UTC(t.getUTCFullYear(), 0, 1)) / 86400000 + 1) / 7);
}
function reportWeekRange(start) {
  const a = parseIso(start), b = parseIso(addDaysIso(start, 6));
  const m = (d) => MONTH_NAMES[d.getMonth()].slice(0, 3);
  return a.getMonth() === b.getMonth() ? `${a.getDate()}–${b.getDate()} ${m(b)}` : `${a.getDate()} ${m(a)}–${b.getDate()} ${m(b)}`;
}
function reportPeriodLabel(start, gran, long) {
  const d = parseIso(start);
  if (gran === "thisweek") {
    const wd = WEEKDAY_NAMES[(d.getDay() + 6) % 7];
    return long ? `${wd} ${d.getDate()} ${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}` : wd;
  }
  if (gran === "month") return long ? `${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}` : `${MONTH_NAMES[d.getMonth()].slice(0, 3)} ${String(d.getFullYear()).slice(2)}`;
  const mon = `${d.getDate()} ${MONTH_NAMES[d.getMonth()].slice(0, 3)}`;
  if (!long) return `W${isoWeekNumber(start)}`;
  return `Week ${isoWeekNumber(start)} · ${reportWeekRange(start)} ${parseIso(addDaysIso(start, 6)).getFullYear()}`;
}

async function openTimeReport() {
  const tr = state.timeReport;
  state.view = { type: "timereport", title: "Time report" };
  if (tr.insights) tr.insights.collapsed = true;    // coming back to the page: insights start collapsed
  if (!tr.anchor) tr.anchor = reportAnchorNow(tr.gran);
  renderSidebar();
  await loadTimeReport();
}

// The anchor to show "now": the last period (week / month) or the current week's Monday.
function reportAnchorNow(gran) {
  return gran === "thisweek" ? startOfWeekIso(todayIso()) : reportPeriodStart(todayIso(), gran);
}

async function loadTimeReport() {
  const tr = state.timeReport;
  const periods = [];
  if (tr.gran === "thisweek") {
    for (let i = 0; i < 7; i++) periods.push(addDaysIso(tr.anchor, i));
  } else {
    let p = tr.anchor;
    for (let i = 0; i < reportPeriodCount(tr.gran); i++) { periods.unshift(p); p = reportPrevPeriod(p, tr.gran); }
  }
  tr.periods = periods;
  const end = tr.gran === "thisweek" ? periods[6] : addDaysIso(reportNextPeriod(tr.anchor, tr.gran), -1);
  tr.entries = await api.get(`/api/reports/time?start=${periods[0]}&end=${end}`);
  if (tr.gran === "thisweek") tr.stored = {};       // insights are stored per week / month, not per day
  else {
    try { tr.stored = await api.get(`/api/reports/time/insights?kind=${tr.gran}&start=${periods[0]}&end=${periods[periods.length - 1]}`); }
    catch (_) { tr.stored = {}; }
  }
  if (!tr.selected || !periods.includes(tr.selected)) {
    tr.selected = (tr.gran === "thisweek" && periods.includes(todayIso())) ? todayIso() : periods[periods.length - 1];
  }
  renderMain();
}

// Minimal markdown (## headings, - bullets, **bold**, paragraphs) for the insights text.
function insightsMarkdown(md) {
  const inline = (t) => escHtml(t).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>");
  let html = "", list = null;
  const close = () => { if (list) { html += `</${list}>`; list = null; } };
  for (const raw of String(md).split("\n")) {
    const line = raw.trim();
    let m;
    if (!line) { close(); continue; }
    if ((m = line.match(/^#{1,4}\s+(.*)/))) { close(); html += `<h3>${inline(m[1])}</h3>`; }
    else if ((m = line.match(/^[-*•]\s+(.*)/))) { if (list !== "ul") { close(); html += "<ul>"; list = "ul"; } html += `<li>${inline(m[1])}</li>`; }
    else if ((m = line.match(/^\d+[.)]\s+(.*)/))) { if (list !== "ol") { close(); html += "<ol>"; list = "ol"; } html += `<li>${inline(m[1])}</li>`; }
    else { close(); html += `<p>${inline(line)}</p>`; }
  }
  close();
  return html;
}

// Stored (auto-generated) insights of the selected week / month.
function renderPeriodInsights(tr, period, hasTime) {
  const stored = (tr.stored || {})[period];
  const loadingKey = `${tr.gran}:${period}`;
  const label = tr.gran === "week" ? "week" : "month";
  const box = el("div", { class: "insights-box period-insights" + (tr.periodCollapsed ? " collapsed" : "") });
  const generate = async () => {
    tr.periodLoading = loadingKey; tr.periodError = ""; renderMain();
    try {
      const r = await api.post("/api/reports/time/insights", { kind: tr.gran, start: period });
      (tr.stored || (tr.stored = {}))[period] = { text: r.result, generated_at: r.generated_at };
    } catch (err) { tr.periodError = (err && err.message) || String(err); }
    tr.periodLoading = null; renderMain();
  };
  if (tr.periodLoading === loadingKey) {
    box.appendChild(el("div", { class: "muted" }, `Claude is analysing this ${label}… this can take up to a minute.`));
    return box;
  }
  if (!stored) {
    if (!hasTime) return el("span");
    const when = tr.gran === "week" ? "on Sunday" : "on the 1st of the next month";
    box.appendChild(el("div", { class: "insights-none" }, [
      el("span", { class: "muted" }, `No insights stored for this ${label} yet — they're generated automatically ${when}.`),
      el("button", { class: "btn small", onclick: generate }, "✨ Generate now"),
    ]));
    if (tr.periodError) box.appendChild(el("div", { class: "insights-error" }, tr.periodError));
    return box;
  }
  const head = el("button", { type: "button", class: "insights-head", onclick: () => {
    tr.periodCollapsed = !tr.periodCollapsed;
    box.classList.toggle("collapsed", tr.periodCollapsed);
  } }, [el("span", { class: "insights-chevron" }, "▾"), el("strong", {}, `✨ Insights for this ${label}`),
        el("span", { class: "muted small" }, `generated ${String(stored.generated_at).replace("T", " ")}`)]);
  const body = el("div", { class: "insights-body" });
  body.innerHTML = insightsMarkdown(stored.text);
  const regen = el("button", { class: "btn small", style: "margin-top:8px", onclick: generate }, "Regenerate");
  box.appendChild(head);
  box.appendChild(el("div", { class: "insights-collapse" }, [el("div", { class: "insights-inner" }, [body, regen])]));
  if (tr.periodError) box.appendChild(el("div", { class: "insights-error" }, tr.periodError));
  return box;
}

function renderTimeReport() {
  const tr = state.timeReport;
  const wrap = el("div", { class: "report-wrap" });
  const setTab = (tab) => { tr.tab = tab; renderMain(); };
  const setGran = (gran) => {
    if (tr.gran === gran) return;
    tr.gran = gran; tr.anchor = reportAnchorNow(gran); tr.selected = null; loadTimeReport();
  };
  const seg = (items, current, onPick) => el("div", { class: "seg" }, items.map(([key, label]) =>
    el("button", { type: "button", class: "seg-btn" + (current === key ? " active" : ""), onclick: () => onPick(key) }, label)));

  const thisPeriod = reportAnchorNow(tr.gran);
  wrap.appendChild(el("div", { class: "report-controls" }, [
    seg([["activity", "By Activity"], ["project", "By Project"], ["company", "By Company"]], tr.tab, setTab),
    seg([["thisweek", "This week"], ["week", "Week by week"], ["month", "Month by month"]], tr.gran, setGran),
    el("div", { class: "report-nav" }, [
      el("button", { class: "icon-btn", title: "Earlier", onclick: () => { for (let i = 0; i < reportStepCount(tr.gran); i++) tr.anchor = reportPrevPeriod(tr.anchor, tr.gran); tr.selected = null; loadTimeReport(); } }, "‹"),
      el("button", { class: "btn small", onclick: () => { tr.anchor = thisPeriod; tr.selected = null; loadTimeReport(); } }, "Today"),
      el("button", { class: "icon-btn", title: "Later", onclick: () => { for (let i = 0; i < reportStepCount(tr.gran); i++) tr.anchor = reportNextPeriod(tr.anchor, tr.gran); tr.selected = null; loadTimeReport(); } }, "›"),
    ]),
  ]));

  // Group entries: period start -> group name -> seconds (names merged case-insensitively).
  const byPeriod = new Map(tr.periods.map((p) => [p, new Map()]));
  const display = new Map();      // lower-cased name -> first-seen display name
  const totals = new Map();       // lower-cased name -> total over the window
  for (const e of tr.entries) {
    const per = reportPeriodStart(e.date, tr.gran);   // for "thisweek" this is the day itself
    const bucket = byPeriod.get(per);
    if (!bucket) continue;
    const name = ((tr.tab === "activity" ? e.activity : tr.tab === "company" ? e.company : e.project) || "(untitled)").trim();
    const key = name.toLowerCase();
    if (!display.has(key)) display.set(key, name);
    bucket.set(key, (bucket.get(key) || 0) + e.seconds);
    totals.set(key, (totals.get(key) || 0) + e.seconds);
  }
  const ranked = [...totals.entries()].sort((a, b) => b[1] - a[1]).map(([k]) => k);
  const colorOf = new Map(ranked.slice(0, REPORT_COLORS.length).map((k, i) => [k, REPORT_COLORS[i]]));
  // By Company: each bar uses its app project's own colour ("Other tasks": neutral grey)
  if (tr.tab === "company") {
    for (const k of ranked) {
      const proj = state.projects.find((p) => (p.name || "").trim().toLowerCase() === k);
      colorOf.set(k, proj ? proj.color : (k === "other tasks" ? "#7f8c8d" : REPORT_OTHER_COLOR));
    }
  }
  const colorFor = (k) => safeColor(colorOf.get(k) || REPORT_OTHER_COLOR);
  const periodTotal = (p) => [...byPeriod.get(p).values()].reduce((a, b) => a + b, 0);

  if (!ranked.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [
      emptyStateIcon("clock"),
      el("div", {}, tr.gran === "thisweek" ? "No tracked time this week" : "No tracked time in this period"),
    ]));
    return wrap;
  }

  if (tr.gran === "thisweek") {
    const weekTotal = tr.periods.reduce((a, p) => a + periodTotal(p), 0);
    wrap.appendChild(el("div", { class: "report-detail-head", style: "margin:4px 0 6px" }, [
      el("h3", { style: "margin:0" }, reportPeriodLabel(tr.periods[0], "week", true)),
      el("span", { class: "muted" }, `Week total ${formatElapsed(weekTotal)}`),
    ]));
  }

  // ---- stacked bar chart (SVG) ----
  const W = 760, H = 292, L = 44, R = 8, T = 12, B = 42;
  const maxSec = Math.max(...tr.periods.map(periodTotal), 1);
  const stepH = [0.25, 0.5, 1, 2, 4, 5, 10, 20, 40, 50, 100].find((s) => maxSec / 3600 / s <= 5) || 100;
  const topH = Math.ceil(maxSec / 3600 / stepH) * stepH;
  const plotH = H - T - B, slot = (W - L - R) / tr.periods.length, barW = Math.min(44, slot * 0.64);
  const yOf = (sec) => T + plotH - (sec / 3600 / topH) * plotH;
  let svg = `<svg viewBox="0 0 ${W} ${H}" class="report-chart" role="img" aria-label="Tracked time per ${tr.gran}">`;
  for (let h = 0; h <= topH + 1e-9; h += stepH) {
    const y = yOf(h * 3600);
    svg += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" class="rc-grid"/><text x="${L - 6}" y="${y + 4}" text-anchor="end" class="rc-axis">${+h.toFixed(2)}h</text>`;
  }
  tr.periods.forEach((p, i) => {
    const x = L + slot * i + (slot - barW) / 2;
    const sel = p === tr.selected;
    svg += `<g class="rc-bar${sel ? " sel" : ""}" data-period="${p}">`;
    svg += `<rect x="${L + slot * i}" y="${T}" width="${slot}" height="${plotH}" class="rc-hit"/>`;
    let acc = 0;
    const segs = [...byPeriod.get(p).entries()].sort((a, b) => (ranked.indexOf(a[0]) - ranked.indexOf(b[0])));
    for (const [k, sec] of segs) {
      const y1 = yOf(acc + sec), y0 = yOf(acc);
      svg += `<rect x="${x}" y="${y1}" width="${barW}" height="${Math.max(0.5, y0 - y1)}" fill="${colorFor(k)}" class="rc-seg"><title>${escHtml(display.get(k))} — ${formatElapsed(sec)}</title></rect>`;
      acc += sec;
    }
    const tot = periodTotal(p);
    if (tot > 0) svg += `<text x="${x + barW / 2}" y="${yOf(tot) - 4}" text-anchor="middle" class="rc-total">${formatElapsed(tot)}</text>`;
    svg += `<text x="${x + barW / 2}" y="${H - 24}" text-anchor="middle" class="rc-axis${sel ? " rc-axis-sel" : ""}">${escHtml(reportPeriodLabel(p, tr.gran, false))}</text>`;
    if (tr.gran === "week") svg += `<text x="${x + barW / 2}" y="${H - 10}" text-anchor="middle" class="rc-axis rc-range">${escHtml(reportWeekRange(p))}</text>`;
    if (tr.gran === "thisweek") { const d = parseIso(p); svg += `<text x="${x + barW / 2}" y="${H - 10}" text-anchor="middle" class="rc-axis rc-range">${d.getDate()} ${MONTH_NAMES[d.getMonth()].slice(0, 3)}</text>`; }
    svg += "</g>";
  });
  svg += "</svg>";
  const chart = el("div", { class: "report-chart-box" });
  chart.innerHTML = svg;
  chart.querySelectorAll(".rc-bar").forEach((g) => g.addEventListener("click", () => { tr.selected = g.dataset.period; renderMain(); }));
  wrap.appendChild(chart);

  // ---- legend ----
  const legend = el("div", { class: "report-legend" });
  for (const k of (tr.tab === "company" ? ranked : ranked.slice(0, REPORT_COLORS.length))) {
    legend.appendChild(el("span", { class: "legend-item" }, [el("span", { class: "dot", style: `background:${colorFor(k)}` }), display.get(k)]));
  }
  if (tr.tab !== "company" && ranked.length > REPORT_COLORS.length) legend.appendChild(el("span", { class: "legend-item" }, [el("span", { class: "dot", style: `background:${REPORT_OTHER_COLOR}` }), "Other"]));
  wrap.appendChild(legend);

  // ---- breakdown of the selected period ----
  const sel = tr.selected;
  const rows = [...byPeriod.get(sel).entries()].sort((a, b) => b[1] - a[1]);
  const tot = periodTotal(sel);
  const detail = el("div", { class: "report-detail" }, [
    el("div", { class: "report-detail-head" }, [
      el("h3", { style: "margin:0" }, reportPeriodLabel(sel, tr.gran, true)),
      el("span", { class: "muted" }, `Total ${formatElapsed(tot)}`),
    ]),
  ]);
  if (tr.gran !== "thisweek") detail.appendChild(renderPeriodInsights(tr, sel, rows.length > 0));
  if (!rows.length) detail.appendChild(el("div", { class: "muted" }, "Nothing tracked in this period."));
  for (const [k, sec] of rows) {
    const pct = tot ? (sec / tot) * 100 : 0;
    detail.appendChild(el("div", { class: "report-row" }, [
      el("span", { class: "dot", style: `background:${colorFor(k)}` }),
      el("span", { class: "report-row-name" }, display.get(k)),
      el("span", { class: "report-row-bar" }, [el("span", { style: `width:${pct}%;background:${colorFor(k)}` })]),
      el("span", { class: "report-row-time" }, formatElapsed(sec)),
      el("span", { class: "muted report-row-pct" }, `${Math.round(pct)}%`),
    ]));
  }
  detail.appendChild(el("div", { class: "muted small", style: "margin-top:10px" },
    "Time is counted on the day it was tracked. Time recorded before per-day tracking existed is placed on the best-known day (when it was last tracked or finished)."));
  wrap.appendChild(detail);
  return wrap;
}

/* ---------------------------------------------------------------------- *
 * Finances > Revenue — per client: what was earned, the time worked on its
 * tasks (via the Sponsor tags matched to the client's name) and the hourly
 * rate of the chosen month.
 * ---------------------------------------------------------------------- */
const eur = (n) => (n == null ? "—" : new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", maximumFractionDigits: n % 1 ? 2 : 0 }).format(n));
const hoursText = (sec) => {
  if (!sec) return "—";
  const m = Math.round(sec / 60);
  return `${Math.floor(m / 60)}h${String(m % 60).padStart(2, "0")}`;
};

async function openRevenue() {
  const rv = state.revenue || (state.revenue = { month: todayIso().slice(0, 7), basis: "invoiced", data: null, error: "" });
  state.view = { type: "revenue", title: "Revenue" };
  renderSidebar();
  await loadRevenue();
}

async function loadRevenue() {
  const rv = state.revenue;
  try {
    rv.data = await api.get(`/api/revenue?month=${rv.month}&basis=${rv.basis}`);
    rv.error = "";
  } catch (err) { rv.error = (err && err.message) || String(err); }
  if (state.view.type === "revenue") renderMain();
}

function revenueShiftMonth(rv, delta) {
  const [y, m] = rv.month.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  rv.month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  loadRevenue();
}

function openRevenueMatching() {
  const rv = state.revenue, data = rv.data;
  if (!data) return;
  const body = [el("div", { class: "muted small", style: "margin-bottom:10px" },
    "Each Sponsor tag is matched to a client by name. Fix the ones that are wrong or missing — your choice is remembered.")];
  const list = el("div", { class: "rv-match-list" });
  const rows = [...data.tags].sort((a, b) => (a.client ? 1 : 0) - (b.client ? 1 : 0) || a.name.localeCompare(b.name));
  for (const t of rows) {
    const sel = el("select", {}, [
      el("option", { value: "__auto" }, "Automatic"),
      el("option", { value: "__none" }, "— no client —"),
      ...data.client_names.map((c) => el("option", { value: c }, c)),
    ]);
    const manual = t.how === "manual";
    sel.value = !manual ? "__auto" : (t.client == null ? "__none" : t.client);
    const hint = el("span", { class: "muted small rv-hint" }, "");
    const paintHint = () => {
      hint.textContent = sel.value === "__auto" ? (t.how === "auto" && t.client ? `→ ${t.client}` : "no match found") : "";
    };
    paintHint();
    sel.addEventListener("change", async () => {
      const v = sel.value;
      try {
        await api.post("/api/revenue/match", { tag_id: t.id, client: v === "__auto" ? null : v === "__none" ? "" : v });
        showToast("Match saved");
        rv.dirty = true;
      } catch (err) { showToast("Could not save the match"); }
      paintHint();
    });
    list.appendChild(el("div", { class: "rv-match-row" + (t.client ? "" : " unmatched") }, [
      el("span", { class: "dot", style: `background:${t.color || "#999"}` }),
      el("span", { class: "rv-match-tag" }, t.name),
      sel, hint,
    ]));
  }
  if (!rows.length) list.appendChild(el("div", { class: "muted" }, "No tags yet."));
  body.push(list);
  openModal("Match tags to clients", body, [el("button", { class: "btn primary", onclick: () => { closeModal(); if (rv.dirty) { rv.dirty = false; loadRevenue(); } } }, "Done")]);
  document.getElementById("modalBody").classList.add("modal-wide");
}

function renderRevenue() {
  const rv = state.revenue;
  const wrap = el("div", { class: "report-wrap revenue-wrap" });
  const d = rv.data;
  const [y, m] = rv.month.split("-").map(Number);
  const isNow = rv.month === todayIso().slice(0, 7);
  const monthLabel = `${MONTH_NAMES[m - 1]} ${y}`;
  const seg = (items, current, onPick) => el("div", { class: "seg" }, items.map(([key, label]) =>
    el("button", { type: "button", class: "seg-btn" + (current === key ? " active" : ""), onclick: () => onPick(key) }, label)));

  const unmatchedCount = d ? d.unmatched.length : 0;
  // three fixed zones: month (left) · Invoiced/Cashed (centre) · tag matching (right).
  // Nothing moves when the choices change: "Today" keeps its place (hidden, not removed)
  // and the matching button keeps one width.
  wrap.appendChild(el("div", { class: "rv-bar" }, [
    el("div", { class: "rv-bar-left report-nav" }, [
      el("button", { class: "icon-btn", title: "Previous month", onclick: () => revenueShiftMonth(rv, -1) }, "‹"),
      el("strong", { class: "rv-month" }, monthLabel),
      el("button", { class: "icon-btn", title: "Next month", onclick: () => revenueShiftMonth(rv, 1) }, "›"),
      el("button", { class: "btn small", style: isNow ? "visibility:hidden" : "", tabindex: isNow ? "-1" : "0",
        onclick: () => { rv.month = todayIso().slice(0, 7); loadRevenue(); } }, "Today"),
    ]),
    el("div", { class: "rv-bar-mid" }, [seg([["invoiced", "Invoiced"], ["cashed", "Cashed"]], rv.basis, (b) => { rv.basis = b; loadRevenue(); })]),
    el("div", { class: "rv-bar-right" }, [
      el("button", { class: "btn small", title: "Match Sponsor tags to client names", disabled: d ? null : "disabled",
        onclick: openRevenueMatching }, unmatchedCount ? `🔗 Match tags (${unmatchedCount})` : "🔗 Match tags"),
    ]),
  ]));

  if (rv.error) { wrap.appendChild(el("div", { class: "insights-error" }, rv.error)); return wrap; }
  if (!d) { wrap.appendChild(el("div", { class: "muted" }, "Loading…")); return wrap; }
  if (!d.available || !d.clients.length) {
    wrap.appendChild(el("div", { class: "empty-state" }, [emptyStateIcon("coins"), el("div", {}, "No invoices found")]));
    return wrap;
  }

  const monthTotal = d.clients.reduce((a, c) => a + c.month, 0);
  const monthSec = d.clients.reduce((a, c) => a + c.seconds_month, 0);
  const paidClients = d.clients.filter((c) => c.seconds_month > 0 && c.month > 0);
  const paidSum = paidClients.reduce((a, c) => a + c.month, 0), paidSec = paidClients.reduce((a, c) => a + c.seconds_month, 0);
  const stat = (label, value, sub) => el("div", { class: "rv-stat" }, [
    el("div", { class: "muted small" }, label), el("div", { class: "rv-stat-val" }, value), sub ? el("div", { class: "muted small" }, sub) : null]);
  wrap.appendChild(el("div", { class: "rv-stats" }, [
    stat(`Earned in ${MONTH_NAMES[m - 1]}`, eur(monthTotal), rv.basis === "cashed" ? "cashed (HT)" : "invoiced (HT)"),
    stat("Time on clients' tasks", hoursText(monthSec), "this month"),
    stat("Average hourly rate", paidSec ? eur(Math.round((paidSum / (paidSec / 3600)) * 100) / 100) + "/h" : "—", "clients with both income and time"),
  ]));

  const head = ["Client", "Earned " + MONTH_NAMES[m - 1].slice(0, 3), "Earned total", "Time " + MONTH_NAMES[m - 1].slice(0, 3), "Time total", "Hourly rate"];
  const table = el("div", { class: "rv-table" });
  table.appendChild(el("div", { class: "rv-row rv-head" }, head.map((t, i) => el("span", { class: i ? "num" : "" }, t))));
  for (const c of d.clients) {
    table.appendChild(el("div", { class: "rv-row" }, [
      el("span", { class: "rv-client" }, [
        el("span", { class: "rv-client-name" }, c.client),
        c.tags.length ? el("span", { class: "rv-tags" }, c.tags.map((t) => el("span", {
          class: "task-label-chip", style: `color:${t.color || "inherit"}`,
          title: t.how === "manual" ? "Matched manually" : "Matched automatically" }, t.name + (t.how === "manual" ? " ✎" : "")))) : null,
      ]),
      el("span", { class: "num" }, eur(c.month || null)),
      el("span", { class: "num muted" }, eur(c.total || null)),
      el("span", { class: "num" }, hoursText(c.seconds_month)),
      el("span", { class: "num muted" }, hoursText(c.seconds_total)),
      el("span", { class: "num rv-rate", title: c.rate_total ? `All-time average: ${eur(c.rate_total)}/h` : "" }, c.rate_month == null ? "—" : eur(c.rate_month) + "/h"),
    ]));
  }
  wrap.appendChild(table);

  if (d.unmatched.length) {
    wrap.appendChild(el("div", { class: "muted small", style: "margin-top:12px" },
      `Tags without a client: ${d.unmatched.map((t) => t.name + (t.seconds_total ? ` (${hoursText(t.seconds_total)})` : "")).join(", ")}. Use “Match tags” to assign them.`));
  }
  wrap.appendChild(el("div", { class: "muted small", style: "margin-top:10px" },
    "Amounts are excl. VAT. Time comes from the Sponsor tags of tasks (a task with several tags shares its time between them). The hourly rate is the month's earnings divided by the month's hours, shown when both exist."));
  return wrap;
}

/* ---------------------------------------------------------------------- *
 * Boot
 * ---------------------------------------------------------------------- */
// The current view is remembered per browser tab (sessionStorage): a page
// reload keeps it, while a brand-new tab / fresh launch starts on Today.
const VIEW_KEY = "taskplanner.view";
function saveCurrentView() {
  const v = state.view || {};
  const d = { type: v.type, smartType: v.smartType, todoListId: v.todoListId, projectId: v.projectId, fiscalSection: v.fiscalSection };
  try { sessionStorage.setItem(VIEW_KEY, JSON.stringify(d)); } catch { /* storage unavailable: just not remembered */ }
}
function loadSavedView() {
  try { return JSON.parse(sessionStorage.getItem(VIEW_KEY) || "null"); } catch { return null; }
}

async function openSavedOrToday(saved) {
  const v = saved || {};
  if (v.type === "smart" && v.smartType) return openSmartView(v.smartType);
  if (v.type === "list" && v.todoListId) {
    const l = state.todoLists.find((x) => x.id === v.todoListId);
    if (l) return openTodoList(l);
  }
  if (v.type === "project" && v.projectId) {
    const p = state.projects.find((x) => x.id === v.projectId);
    if (p) return openProjectView(p);
  }
  if (v.type === "calendar") return openCalendar();
  if (v.type === "fiscal" && document.body.dataset.fiscal === "1") return openFiscalView(v.fiscalSection);
  if (v.type === "sponsors") return openSponsorsView();
  if (v.type === "videoproject") return openVideoProject();
  if (v.type === "timereport") return openTimeReport();
  if (v.type === "revenue" && document.body.dataset.fiscal === "1") return openRevenue();
  if (v.type === "backups") return openBackupsView();
  if (v.type === "templates") return openTemplatesView();
  return openSmartView("today");     // first load
}

async function boot() {
  const saved = loadSavedView();   // read before anything renders and overwrites it
  state.bootPending = true;
  initTheme();
  document.getElementById("resourcesBtn").addEventListener("click", (e) => { e.stopPropagation(); openResourcesMenu(e.currentTarget); });
  wireQuickAdd();
  wireReloadServer();
  wireUtilities();
  wireBackups();
  wireTemplates();
  wireCleanup();
  wireDesktopWidgetBridge();
  wireTimerTicker();
  wireStatusIndicators();
  await Promise.all([refreshSidebarData(), refreshTemplates()]);
  if (state.todoLists.length) state.expanded.add(state.todoLists[0].project_id);
  try { await openSavedOrToday(saved); } finally { state.bootPending = false; }
  saveCurrentView();
}

boot().catch((err) => { console.error(err); showToast("Failed to load: " + err.message); });
