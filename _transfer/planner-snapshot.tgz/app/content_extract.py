"""Pulls plain text out of the links and the optional reference document
given to the "Generate" PowerPoint button, so it can be handed to Claude as
context. Best-effort throughout: a failing link is noted and skipped rather
than aborting the whole generation, since the person may have pasted
several and one being unreachable shouldn't block the rest.
"""
from __future__ import annotations
from pathlib import Path

from .ai import AIError

LINK_FETCH_TIMEOUT = 12
MAX_CHARS_PER_LINK = 6000
MAX_DOC_CHARS = 20000


def _public_url_error(url: str):
    """None if `url` is an http(s) address that resolves ONLY to public
    addresses, else a short reason. Stops the server being used to reach
    localhost / the home network / cloud metadata (SSRF)."""
    import ipaddress
    import socket
    from urllib.parse import urlsplit
    try:
        parts = urlsplit(url)
    except ValueError:
        return "invalid address"
    if parts.scheme not in ("http", "https") or not parts.hostname:
        return "only http(s) links are allowed"
    try:
        infos = socket.getaddrinfo(parts.hostname, parts.port or (443 if parts.scheme == "https" else 80),
                                   type=socket.SOCK_STREAM)
    except OSError:
        return "host not found"
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if getattr(ip, "ipv4_mapped", None):
            ip = ip.ipv4_mapped
        if not ip.is_global:
            return "links to local or private addresses are not fetched"
    return None


MAX_LINK_BYTES = 2_000_000


def fetch_link_text(url: str) -> str:
    """Returns a labeled chunk of plain text scraped from `url`, or a short
    note explaining why it couldn't be fetched -- never raises."""
    try:
        import requests
    except ImportError:
        return f"## Link: {url}\n(couldn't fetch -- the 'requests' package isn't installed)\n"
    try:
        from urllib.parse import urljoin
        cur, resp = url, None
        for _ in range(5):                       # follow redirects ourselves, re-checking each hop
            why = _public_url_error(cur)
            if why:
                return f"## Link: {url}\n(not fetched: {why})\n"
            resp = requests.get(cur, timeout=LINK_FETCH_TIMEOUT, headers={"User-Agent": "Mozilla/5.0"},
                                allow_redirects=False, stream=True)
            if resp.is_redirect and resp.headers.get("Location"):
                cur = urljoin(cur, resp.headers["Location"])
                resp.close()
                continue
            break
        else:
            return f"## Link: {url}\n(too many redirects)\n"
        resp.raise_for_status()
        body = b""
        for chunk in resp.iter_content(65536):   # never read more than a couple of MB
            body += chunk
            if len(body) > MAX_LINK_BYTES:
                break
        enc = resp.encoding or resp.apparent_encoding or "utf-8"
        resp_text = body.decode(enc, errors="replace")
    except Exception as e:  # noqa: BLE001 -- surfaced inline, not fatal
        return f"## Link: {url}\n(couldn't fetch this link: {e})\n"

    text = resp_text
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(text, "html.parser")
        for tag in soup(["script", "style", "noscript"]):
            tag.decompose()
        text = soup.get_text("\n")
    except ImportError:
        import re
        text = re.sub(r"(?is)<(script|style).*?</\1>", "", text)
        text = re.sub(r"(?s)<[^>]+>", " ", text)

    lines = [ln.strip() for ln in text.splitlines()]
    text = "\n".join(ln for ln in lines if ln)
    text = text[:MAX_CHARS_PER_LINK]
    return f"## Link: {url}\n{text}\n"


def extract_uploaded_text(file_storage) -> str:
    """file_storage: a werkzeug FileStorage from request.files. Raises
    AIError for an unsupported or unreadable file type."""
    filename = file_storage.filename or "upload"
    suffix = Path(filename).suffix.lower()

    if suffix == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            raise AIError("The 'pypdf' package isn't installed. Run: pip install pypdf")
        try:
            reader = PdfReader(file_storage.stream)
            text = "\n".join((page.extract_text() or "") for page in reader.pages)
        except Exception as e:  # noqa: BLE001
            raise AIError(f"Couldn't read that PDF: {e}")

    elif suffix == ".docx":
        try:
            import docx
        except ImportError:
            raise AIError("The 'python-docx' package isn't installed. Run: pip install python-docx")
        try:
            document = docx.Document(file_storage.stream)
            text = "\n".join(p.text for p in document.paragraphs)
        except Exception as e:  # noqa: BLE001
            raise AIError(f"Couldn't read that Word document: {e}")

    elif suffix in (".txt", ".md"):
        try:
            text = file_storage.stream.read().decode("utf-8", errors="replace")
        except Exception as e:  # noqa: BLE001
            raise AIError(f"Couldn't read that file: {e}")

    else:
        raise AIError(f'Unsupported file type "{suffix or "?"}" -- use a PDF, Word (.docx) or text/markdown file.')

    text = text.strip()
    if not text:
        raise AIError("That document appears to have no extractable text.")
    return text[:MAX_DOC_CHARS]


def extract_document(file_storage, assets_dir: Path, force_ocr: bool = False):
    """Like extract_uploaded_text(), but PDFs go through datasheets.process_pdf:
    pages without a text layer are OCR'd (instead of failing) and unit
    datasheets are cropped into assets_dir. Returns (text, datasheets,
    ocr_page_count); non-PDFs return no blocks."""
    suffix = Path(file_storage.filename or "").suffix.lower()
    if suffix != ".pdf":
        return extract_uploaded_text(file_storage), [], 0
    from . import datasheets as ds
    result = ds.process_pdf(file_storage.stream, assets_dir, force_ocr=force_ocr)
    if not result.text.strip() and not result.blocks:
        raise AIError("Couldn't find any text in that PDF, even with OCR.")
    return result.text, result.blocks, result.ocr_pages
