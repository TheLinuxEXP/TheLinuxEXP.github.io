"""Reads a linked local markdown "notes" file and splits it into sections by
heading (any level of #), so the AI-powered subtask buttons can pull out
specific sections (e.g. "Timestamps", "Links", "Content") the same way the
person already organizes their own video-planning notes.
"""
from __future__ import annotations
import os
import re
import shutil
import threading
import time
from datetime import datetime
from pathlib import Path

_HEADING_RE = re.compile(r"^(#{1,6})[ \t\u00a0]+(.*?)(?:[ \t]+#+)?[ \t]*$")


def read_note_text(path) -> str:
    """The text of a note for the AI buttons. Never lossy: UTF-8 (BOM or not), else Latin-1 (which keeps every byte as a
    character) instead of replacing undecodable bytes with U+FFFD, which got written back into the file. Line endings
    are normalised to LF, as read_text() always did."""
    data = Path(path).expanduser().read_bytes()
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = data.decode("latin-1")
    return text.replace("\r\n", "\n").replace("\r", "\n")


def read_markdown_sections(path: str):
    """Returns (sections, order): sections maps each heading's text to its
    body, order is the headings in the order they appeared. A section's body
    is everything up to the next heading of the SAME OR A HIGHER level, so it
    includes its own sub-headings and what's under them (e.g. a "## Content"
    made of "### Topic" entries). Headings inside code fences are ignored.
    Raises FileNotFoundError if the path is bad."""
    p = Path(path).expanduser()
    if not p.is_file():
        raise FileNotFoundError(str(p))
    text = read_note_text(p)

    lines = text.splitlines()
    heads = []          # (line index, level, title)
    in_fence = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        m = _HEADING_RE.match(stripped)
        if m and m.group(2).strip():
            heads.append((i, len(m.group(1)), m.group(2).strip()))

    sections: dict[str, str] = {}
    order: list[str] = []
    for n, (i, level, title) in enumerate(heads):
        end = len(lines)
        for j, lvl, _t in heads[n + 1:]:
            if lvl <= level:
                end = j
                break
        order.append(title)
        body = "\n".join(lines[i + 1:end]).strip()
        if title not in sections or (not sections[title] and body):
            sections[title] = body
    return sections, order


def find_section(sections: dict, name: str):
    """Case-insensitive lookup, falling back to a substring match (so
    "## Content ideas" still matches a request for "Content")."""
    name_l = name.lower()
    for k, v in sections.items():
        if k.lower() == name_l:
            return v
    for k, v in sections.items():
        if name_l in k.lower():
            return v
    return None


def _heading_spans(lines):
    """[(line index, level, title)] for every heading outside code fences."""
    heads, in_fence = [], False
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("```") or s.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        m = _HEADING_RE.match(s)
        if m and m.group(2).strip():
            heads.append((i, len(m.group(1)), m.group(2).strip()))
    return heads


def trim_from_heading(text: str, name: str = "Timestamps") -> str:
    """The generated text starting at its first `## <name>` heading (drops any
    chatter before it). Returned unchanged if that heading isn't there."""
    lines = (text or "").strip().splitlines()
    for i, _lvl, title in _heading_spans(lines):
        if title.lower() == name.lower():
            return "\n".join(lines[i:]).strip()
    return (text or "").strip()


def replace_sections(note_text: str, generated: str):
    """Swaps the body of every section present in `generated` into the note,
    keeping the note's own heading lines and everything outside those
    sections. Sections the note doesn't have are appended at the end.
    Returns (new_text, replaced_titles, appended_titles)."""
    gen_lines = generated.strip().splitlines()
    gheads = _heading_spans(gen_lines)
    if not gheads:
        return None
    new_sections = []                               # (title, body)
    top = min(h[1] for h in gheads)                  # only top-level sections; deeper ones ride along in their body
    for n, (i, level, title) in enumerate(gheads):
        if level != top:
            continue
        end = len(gen_lines)
        for j, lvl, _t in gheads[n + 1:]:
            if lvl <= level:
                end = j
                break
        new_sections.append((title, gen_lines[i + 1:end], gen_lines[i]))

    lines = note_text.splitlines()
    replaced, appended = [], []
    for title, body, head_line in new_sections:
        heads = _heading_spans(lines)
        hit = None
        for n, (i, level, t) in enumerate(heads):
            if t.lower() == title.lower():
                end = len(lines)
                for j, lvl, _t in heads[n + 1:]:
                    if lvl <= level:
                        end = j
                        break
                hit = (i, end)
                break
        body = list(body)
        while body and not body[0].strip():
            body.pop(0)
        while body and not body[-1].strip():
            body.pop()
        if hit:
            i, end = hit
            tail = lines[end:]
            block = [lines[i], ""] + body + ([""] if tail else [])
            lines = lines[:i] + block + tail
            replaced.append(title)
        else:
            while lines and not lines[-1].strip():
                lines.pop()
            lines += ([""] if lines else []) + [head_line, ""] + body
            appended.append(title)
    return "\n".join(lines).rstrip() + "\n", replaced, appended


def save_note_text(path: Path, previous_text: str, new_text: str, backup_dir: Path) -> None:
    """Overwrite a note with `new_text`: the file as it is on disk (exact bytes, so even an odd encoding or line endings
    survive in the copy) is first copied - best effort, never blocks saving - to `backup_dir` as
    "<timestamp>-<name>", then the file is replaced atomically."""
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dest = backup_dir / f"{stamp}-{path.name}"
        n = 2
        while dest.exists():                       # two writes within the same second must not overwrite each other
            dest = backup_dir / f"{stamp}-{n}-{path.name}"
            n += 1
        if path.exists():
            shutil.copy2(path, dest)
        else:
            dest.write_text(previous_text, encoding="utf-8")
    except Exception:  # noqa: BLE001 -- a failed backup must never block the save
        pass
    from .fsutil import atomic_write_text
    atomic_write_text(path, new_text)
