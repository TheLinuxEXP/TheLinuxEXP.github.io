"""Powers every AI button of the planner (order topics, tags, thumbnails, script planning, time insights,
army-list decks, datasheet detection...).

PROVIDER-INDEPENDENT: all of them call `call_claude(prompt, system, ...)` (the historical name), which hands the
very same prompt + system instructions to whichever model is configured in the "AI settings" window
(see ai_config.py): the Claude subscription (default), the Anthropic API, a local model (Ollama, LM Studio...)
or a cloud provider speaking the OpenAI protocol.

The rest of this docstring describes the default, the Claude Code CLI provider.

By default this shells out to your own locally-installed **Claude Code
CLI** (`claude -p "..."`) rather than calling the Anthropic API directly.
That's the only way a local script can draw on your Claude.ai subscription
(Pro/Max) and its included usage instead of a separately-billed API key —
Claude Code is able to sign in with your claude.ai account; a plain HTTP
call to api.anthropic.com cannot.

One-time setup on this machine:
    1. Install Claude Code: see https://code.claude.com
    2. Sign in with your subscription (NOT `claude auth login --console`,
       which signs in for separate, pay-per-call API billing instead):
           claude auth login
    3. Make sure the `claude` command is on PATH for whatever shell/user
       runs `python3 run.py`.

Each button click runs one `claude -p` subprocess, with web search/fetch
allowed (so it can look things up) but no shell or filesystem tools. It
counts against your subscription's usage the same way typing a prompt into
Claude Code does.

Other providers (Anthropic API key, local model, cloud) are chosen in the AI settings window; the old
TASKPLANNER_AI_BACKEND=api + ANTHROPIC_API_KEY environment variables still work until the window is used.
"""
from __future__ import annotations
import base64
import ipaddress
import json
import os
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

from . import ai_config



class AIError(Exception):
    """Raised for any problem that should be shown to the person as a plain
    message, rather than a stack trace: CLI not installed/logged in, no API
    key, missing package, missing notes file, empty section, or a call
    failure."""


def vision_available() -> bool:
    """Can the active model be handed page images? (Claude CLI: it opens them itself; other providers: only when
    the "this model reads images" box is ticked in the AI settings.)"""
    pr = ai_config.profile()
    if pr["kind"] == "claude_cli":
        return shutil.which("claude") is not None
    return bool(pr["vision"])


# The CLI provider has web search / fetch tools; the others answer from the prompt alone. Their system prompt gets
# this one extra line so a prompt that says "look it up" degrades gracefully instead of the model pretending.
_NO_WEB_NOTE = ("Note: you have no web access and no tools here. Answer from the content provided in the request "
                "and from what you know; do not invent sources.")

_IMG_EXT = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}


def call_claude(prompt: str, system: str | None = None, max_tokens: int = 2000,
                read_dirs: list | None = None) -> str:
    """Send one prompt to the configured model and return its text. Name kept for the existing callers.

    read_dirs: folders of image files the model may look at (pages / cropped blocks of the person's own PDF). With
    the Claude CLI it opens them with its Read tool; with other providers the images named in the prompt are attached
    to the request (only when the provider is marked as reading images). Nothing else on disk is offered."""
    pr = ai_config.profile()
    if pr["kind"] == "claude_cli":
        return _call_via_cli(prompt, system, read_dirs, pr)
    sys_text = f"{system}\n\n{_NO_WEB_NOTE}" if system else _NO_WEB_NOTE
    images = _images_for(prompt, read_dirs) if (read_dirs and pr["vision"]) else []
    if pr["kind"] == "anthropic":
        return _call_via_anthropic(prompt, sys_text, max_tokens, pr, images)
    return _call_via_openai(prompt, sys_text, max_tokens, pr, images)


def _images_for(prompt: str, read_dirs: list, limit: int = 12) -> list[tuple[str, bytes]]:
    """(media type, bytes) of the image files under read_dirs whose path appears in the prompt."""
    out = []
    for d in read_dirs:
        try:
            files = sorted(Path(d).iterdir())
        except OSError:
            continue
        for f in files:
            mt = _IMG_EXT.get(f.suffix.lower())
            if mt and str(f) in prompt and len(out) < limit:
                try:
                    if f.stat().st_size <= 8 * 1024 * 1024:
                        out.append((mt, f.read_bytes()))
                except OSError:
                    pass
    return out


def _call_via_cli(prompt: str, system: str | None, read_dirs: list | None = None, pr: dict | None = None) -> str:
    claude_bin = shutil.which("claude")
    if not claude_bin:
        raise AIError(
            "Couldn't find the 'claude' command on this machine. Install Claude "
            "Code (see code.claude.com), run 'claude auth login' to sign in with "
            "your Claude subscription, then restart this server. (Or pick another AI provider in the AI settings.)"
        )
    timeout = ai_config.timeout_seconds()
    model = (pr or ai_config.profile())["model"] or os.environ.get("ANTHROPIC_MODEL")

    cmd = [
        claude_bin, "-p", prompt,
        "--output-format", "text",
        "--tools", "Read,WebSearch,WebFetch" if read_dirs else "WebSearch,WebFetch",   # web (+ Read for the given image folders) -- no shell
        "--permission-mode", "dontAsk",            # nobody's there to answer a prompt: anything not allowed below is refused
        "--allowedTools", "Read,WebSearch,WebFetch" if read_dirs else "WebSearch,WebFetch",
        "--no-session-persistence",         # don't clutter claude's own session history
        # Note: deliberately NOT passing --bare here -- on at least some
        # installs it breaks reading stored Claude subscription credentials,
        # causing a spurious "Not logged in" error even right after a
        # successful `claude auth login`.
    ]
    for d in read_dirs or []:
        cmd += ["--add-dir", str(d)]
    if system:
        cmd += ["--system-prompt", system]
    if model:
        cmd += ["--model", model]

    # Run from an empty folder: the CLI's Read tool can see its working
    # directory, which must not be the app's own folder (database, source...).
    import tempfile
    with tempfile.TemporaryDirectory(prefix="planner-ai-") as workdir:
        def _run(c):
            return subprocess.run(c, capture_output=True, text=True, timeout=timeout,
                                  stdin=subprocess.DEVNULL, cwd=workdir)
        try:
            result = _run(cmd)
            if result.returncode != 0 and any(w in ((result.stderr or "") + (result.stdout or "")).lower() for w in ("dontask", "permission-mode", "invalid choice", "unknown option")):
                # an older CLI without the dontAsk mode: fall back to the previous behaviour
                # (the tool list above is still limited to read-only tools)
                legacy = [("bypassPermissions" if a == "dontAsk" else a) for a in cmd]
                result = _run(legacy)
        except subprocess.TimeoutExpired:
            raise AIError(f"The Claude Code CLI took too long to respond (timed out after {timeout}s). Try again, or raise the limit in the AI settings.")
        except OSError as e:
            raise AIError(f"Couldn't run the 'claude' command: {e}")

    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip() or "unknown error"
        hint = ""
        if any(word in detail.lower() for word in ("auth", "logged in", "login", "unauthorized")):
            hint = " Run 'claude auth login' on this machine to sign in with your Claude subscription."
        raise AIError(f"Claude Code CLI failed: {detail}.{hint}")

    text = (result.stdout or "").strip()
    if not text:
        raise AIError("Claude Code returned an empty response — try again.")
    return text


# -- plain HTTP providers (no extra Python package needed) ---------------------------------------------------------
def _is_local_host(url: str) -> bool:
    host = (urlsplit(url).hostname or "").lower()
    if host in ("localhost", "host.docker.internal") or host.endswith((".local", ".lan")):
        return True
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_loopback or ip.is_private or ip.is_link_local
    except ValueError:
        return "." not in host            # bare names like "nas"


def _http_json(url: str, payload: dict | None, headers: dict, timeout: int) -> dict:
    """GET (payload None) or POST JSON; returns the decoded JSON, raises AIError with a readable message."""
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", **headers},
                                 method="POST" if payload is not None else "GET")
    # a local server must be reached directly, not through an HTTP(S) proxy configured for the internet
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) if _is_local_host(url) else urllib.request.build_opener()
    try:
        with opener.open(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace") or "{}")
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")[:600]
            msg = (json.loads(body).get("error") or {})
            body = msg.get("message") if isinstance(msg, dict) and msg.get("message") else (msg if isinstance(msg, str) else body)
        except Exception:  # noqa: BLE001 - keep the raw text
            pass
        hint = " Check the API key in the AI settings." if e.code in (401, 403) else (
            " Check the model name in the AI settings." if e.code == 404 else "")
        raise AIError(f"The AI provider answered HTTP {e.code}: {str(body).strip() or e.reason}.{hint}")
    except urllib.error.URLError as e:
        raise AIError(f"Couldn't reach the AI provider at {urlsplit(url).netloc or url}: {e.reason}. "
                      "Is the server running (for a local model) and is the address right?")
    except (TimeoutError, OSError) as e:
        raise AIError(f"The AI provider took too long or the connection dropped ({e}). Raise the time limit in the AI settings if the model is slow.")
    except ValueError:
        raise AIError("The AI provider returned something that isn't JSON — is the address the API one (…/v1)?")


def _call_via_anthropic(prompt: str, system: str | None, max_tokens: int, pr: dict, images: list) -> str:
    if not pr["api_key"]:
        raise AIError("No Anthropic API key: enter it in the AI settings (key from console.anthropic.com), "
                      "or switch back to your Claude subscription there.")
    content = [{"type": "image", "source": {"type": "base64", "media_type": mt, "data": base64.b64encode(b).decode()}}
               for mt, b in images] + [{"type": "text", "text": prompt}]
    payload = {"model": pr["model"], "max_tokens": max_tokens, "messages": [{"role": "user", "content": content}]}
    if system:
        payload["system"] = system
    base = (pr["base_url"] or "https://api.anthropic.com").rstrip("/")
    resp = _http_json(f"{base}/v1/messages", payload, {"x-api-key": pr["api_key"], "anthropic-version": "2023-06-01"},
                      ai_config.timeout_seconds())
    text = "\n".join(b.get("text", "") for b in resp.get("content") or [] if b.get("type") == "text").strip()
    if not text:
        raise AIError("The model returned an empty response — try again.")
    return text


def _call_via_openai(prompt: str, system: str | None, max_tokens: int, pr: dict, images: list) -> str:
    if not pr["base_url"]:
        raise AIError("No server address for the AI provider: set it in the AI settings.")
    if not pr["model"]:
        raise AIError("No model chosen: pick or type the model name in the AI settings.")
    preset = ai_config.PROVIDERS.get(pr["provider"], {})
    if preset.get("needs_key") and not pr["api_key"]:
        raise AIError(f"No API key for {preset.get('label', 'this provider')}: enter it in the AI settings.")
    user = prompt if not images else (
        [{"type": "text", "text": prompt}] +
        [{"type": "image_url", "image_url": {"url": f"data:{mt};base64,{base64.b64encode(b).decode()}"}} for mt, b in images])
    messages = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": user}]
    headers = {"Authorization": f"Bearer {pr['api_key']}"} if pr["api_key"] else {}
    resp = _http_json(pr["base_url"].rstrip("/") + "/chat/completions",
                      {"model": pr["model"], "messages": messages, "max_tokens": max_tokens, "stream": False},
                      headers, ai_config.timeout_seconds())
    try:
        text = (resp["choices"][0]["message"]["content"] or "").strip()
    except (KeyError, IndexError, TypeError):
        raise AIError("The AI provider's reply had an unexpected shape.")
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()     # reasoning models (DeepSeek-R1, Qwen3...)
    if not text:
        raise AIError("The model returned an empty response — try again.")
    return text


def list_models(provider: str | None = None) -> list[str]:
    """Model names the provider's server reports (local servers and most clouds). [] if it can't say."""
    pr = ai_config.profile(provider)
    if pr["kind"] == "claude_cli":
        return ["sonnet", "opus", "haiku"]
    base = (pr["base_url"] or "").rstrip("/")
    if not base:
        return []
    if pr["kind"] == "anthropic":
        resp = _http_json(f"{base}/v1/models", None, {"x-api-key": pr["api_key"], "anthropic-version": "2023-06-01"}, 20)
    else:
        resp = _http_json(f"{base}/models", None, {"Authorization": f"Bearer {pr['api_key']}"} if pr["api_key"] else {}, 20)
    items = resp.get("data") or resp.get("models") or []
    names = [(m.get("id") or m.get("name") or "") if isinstance(m, dict) else str(m) for m in items]
    return sorted({n.split("models/", 1)[-1] for n in names if n})


def test_connection() -> dict:
    """Used by the settings window: one tiny request to the active provider."""
    t0 = time.time()
    reply = call_claude("Réponds uniquement par le mot : OK", system="Tu réponds le plus brièvement possible.", max_tokens=20)
    return {"ok": True, "reply": reply[:200], "seconds": round(time.time() - t0, 1)}


def extract_json_object(text: str):
    """Best-effort JSON-object parse out of a reply that may have a code fence or stray text."""
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.MULTILINE).strip()
    for candidate in (cleaned, cleaned[cleaned.find("{"):cleaned.rfind("}") + 1]):
        try:
            return json.loads(candidate)
        except (json.JSONDecodeError, ValueError):
            continue
    raise AIError("The model's response wasn't valid JSON.")


def _extract_json_array(text: str):
    """Best-effort JSON-array parse out of a Claude reply that may be wrapped
    in a markdown code fence or have stray text around it."""
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    start, end = cleaned.find("["), cleaned.rfind("]")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(cleaned[start:end + 1])
        except json.JSONDecodeError:
            pass
    raise AIError("The model's response wasn't valid JSON — try generating again.")


def generate_slide_plan(context_text: str, user_prompt: str, max_slides: int = 12,
                        datasheets: list | None = None) -> list[dict]:
    """Turns reference material (links/document text) plus a free-text
    prompt into a slide plan: [{"title": str, "bullets": [str, ...]}, ...],
    for pptx_gen.build_presentation() to stamp out onto cloned template
    slides. Raises AIError if Claude's reply can't be parsed."""
    sheet_block = ""
    if datasheets:
        listing = "\n".join(f"{i}: {name} (PDF page {page})" for i, (name, page) in enumerate(datasheets))
        sheet_block = f"""
## Available datasheet images
These unit datasheets were cropped out of the person's PDF and can be shown
as a picture on a slide. Each is numbered:
{listing}

To show datasheets on a slide, add a "datasheets" field to that slide: a list
of 1 or 2 of the numbers above. Use them where the person's prompt asks for
datasheets (e.g. "show the datasheet of each unit", "include the datasheets
for X and Y") or where a unit is discussed in depth; otherwise leave the field
out. A slide with datasheets may have few or no bullets.
"""
    prompt = f"""You are planning the slides for a PowerPoint presentation. Below is
some reference material, followed by what the person wants the presentation
to cover.

## Reference material
{context_text.strip() or "(none provided)"}

## What the person wants
{user_prompt.strip() or "(no specific instructions -- use your best judgement based on the reference material above)"}
{sheet_block}
Plan at most {max_slides} content slides (not counting a cover slide, which
is handled separately). For each slide, give a short, punchy title (a few
words, ALL CAPS reads well for this deck's style) and 2-5 short bullet
points (each a single short line, no sub-bullets).

Reply with ONLY a JSON array, nothing else before or after it, in exactly
this shape:
[
  {{"title": "SLIDE TITLE", "bullets": ["First point", "Second point"], "datasheets": [0]}},
  ...
]
"""
    result = call_claude(prompt, system="You plan clear, well-organized slide decks from reference material.",
                          max_tokens=4000)
    plan = _extract_json_array(result)
    if not isinstance(plan, list) or not plan:
        raise AIError("The model didn't return any slides — try again, maybe with a more specific prompt.")
    cleaned = []
    for item in plan:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "").strip()
        bullets = [str(b).strip() for b in (item.get("bullets") or []) if str(b).strip()]
        sheets = []
        for n in (item.get("datasheets") or []):
            try:
                n = int(n)
            except (TypeError, ValueError):
                continue
            if datasheets and 0 <= n < len(datasheets) and n not in sheets:
                sheets.append(n)
        if title or bullets or sheets:
            cleaned.append({"title": title, "bullets": bullets, "datasheets": sheets[:2]})
    if not cleaned:
        raise AIError("The model didn't return any usable slides — try again, maybe with a more specific prompt.")
    return cleaned[:max_slides]


# ---------------------------------------------------------------------------
# Warhammer "Generate PowerPoint": one slide per picture block cut from a PDF
# ---------------------------------------------------------------------------
_KIND_LABELS = {
    "datasheet": "Datasheet d'unité",
    "detachment_rule": "Règle de détachement",
    "enhancements": "Améliorations",
    "stratagems": "Stratagèmes (jusqu'à 3)",
}


def select_blocks(outline: list[str], user_prompt: str) -> list[int]:
    """Lets the person's prompt choose/reorder which blocks become slides
    ("only the datasheets", "skip enhancements", ...). Returns indices; on any
    doubt, all of them in order."""
    everything = list(range(len(outline)))
    if not user_prompt.strip() or not outline:
        return everything
    listing = "\n".join(f"{i}: {o}" for i, o in enumerate(outline))
    prompt = f"""Voici la liste des blocs (datasheets, règles, améliorations, stratagèmes) extraits d'un PDF Warhammer 40k,
chacun devenant une slide :
{listing}

Consigne de la personne : {user_prompt.strip()}

Réponds UNIQUEMENT par un tableau JSON des numéros des blocs à garder, dans l'ordre voulu pour les slides.
Si la consigne ne parle pas de choisir, filtrer ou réordonner des blocs, renvoie tous les numéros dans l'ordre d'origine."""
    try:
        picked = _extract_json_array(call_claude(prompt, system="Tu aides à préparer des slides. Réponds en JSON strict.",
                                                  max_tokens=1500))
    except AIError:
        return everything
    out = []
    for n in picked if isinstance(picked, list) else []:
        try:
            n = int(n)
        except (TypeError, ValueError):
            continue
        if 0 <= n < len(outline) and n not in out:
            out.append(n)
    return out or everything


def write_block_slides(blocks: list[dict], style_samples: str, user_prompt: str,
                       extra_context: str = "", batch_size: int = 4,
                       read_dir=None, workers: int = 3) -> dict[int, dict]:
    """blocks: [{"i", "kind", "title", "detachment", "page_top", "text", "image"}, ...].
    Returns {i: {"title": str, "lines": [str, ...]}} -- the French recap text
    for each slide. Lines are marked: "# " heading, "- " bullet, "-- "
    sub-bullet, "" blank spacer.
    When read_dir is given (and the CLI backend is in use), Claude opens each
    block's image itself to read it; batches run in parallel."""
    from concurrent.futures import ThreadPoolExecutor
    system = ("Tu écris les slides d'une vidéo YouTube française sur Warhammer 40,000, "
              "dans le ton et le style de la personne (exemples fournis). Réponds en JSON strict.")
    use_images = bool(read_dir) and vision_available()

    def run(chunk):
        items = []
        for b in chunk:
            where = (f"Image à OUVRIR avec l'outil Read et à lire attentivement : {b['image']}\n"
                     if use_images and b.get("image") else "")
            hint = (b.get("text") or "")[:2200]
            items.append(
                f"### BLOC {b['i']} — {_KIND_LABELS.get(b['kind'], b['kind'])}\n"
                f"Titre deviné : {b['title']}\n"
                f"Début de la page du PDF : {b.get('page_top') or '(inconnu)'}\n"
                f"{where}"
                + (f"Texte approximatif (OCR, peut contenir des erreurs) :\n{hint}\n" if hint else ""))
        prompt = f"""Voici des exemples de slides déjà faites par la personne, pour reprendre son TON et son style
(français oral, phrases courtes, commentaires personnels, abréviations du jeu comme PV, E, CT, PA, D, F, Insensible,
noms de règles en VO conservés) :
-----
{style_samples}
-----
{('Contexte supplémentaire (liens / document) :' + chr(10) + extra_context[:4000]) if extra_context.strip() else ''}

Consigne supplémentaire de la personne : {user_prompt.strip() or '(aucune)'}

Pour CHAQUE bloc ci-dessous, une slide va afficher l'image du bloc à droite et TON texte à gauche.
Ton texte doit RÉCAPITULER tout ce qui est dans l'image (profils/stats, armes, règles, effets, restrictions,
coûts en PC, etc.), en français, comme dans les exemples, sans rien inventer d'absent du bloc.
Titre de la slide, en MAJUSCULES :
- datasheet → nom de l'unité ;
- règle de détachement, améliorations, stratagèmes → NOM DU DÉTACHEMENT tel qu'il apparaît en haut de la page du PDF
  (corrige le titre deviné s'il est faux, d'après « Début de la page »).
Texte : 6 à 14 lignes courtes maximum (environ 60 caractères par ligne). Format de chaque ligne :
"# Titre :" pour un intitulé en gras, "- texte" pour une puce, "-- texte" pour une sous-puce, "" pour une ligne vide.
Pour les stratagèmes, une intitulé "# NOM DU STRATAGÈME (coût PC) :" par stratagème, puis ses puces (quand / cible / effet).

{chr(10).join(items)}

Réponds UNIQUEMENT par un tableau JSON, un objet par bloc, dans cette forme exacte :
[{{"i": 12, "title": "TITRE", "lines": ["# Intitulé :", "- puce", "-- sous-puce", ""]}}]"""
        out = {}
        try:
            data = _extract_json_array(call_claude(prompt, system=system, max_tokens=6000,
                                                   read_dirs=[read_dir] if use_images else None))
        except AIError:
            return out          # that batch falls back to image-only slides
        for obj in data if isinstance(data, list) else []:
            if not isinstance(obj, dict):
                continue
            try:
                i = int(obj.get("i"))
            except (TypeError, ValueError):
                continue
            lines = [str(l) for l in (obj.get("lines") or []) if isinstance(l, (str, int, float))]
            out[i] = {"title": str(obj.get("title") or "").strip(), "lines": lines}
        return out

    chunks = [blocks[i:i + batch_size] for i in range(0, len(blocks), batch_size)]
    results: dict[int, dict] = {}
    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        for part in ex.map(run, chunks):
            results.update(part)
    return results
