"""A safety net for files the planner deletes on your behalf (task attachments, sponsor contracts).

Deleting a task or a sponsor removes its rows, and those can be brought back from a database backup - but the PDF /
document attached to them used to be erased for good, so a restored task pointed at a file that no longer existed.
`discard()` moves such a file to `<data dir>/trash/<day>/` instead, and `purge()` (run at start-up) empties what has been
there for more than KEEP_DAYS days. Re-attaching a trashed file is a matter of copying it back out of that folder.
"""
from __future__ import annotations

import os
import shutil
import time
from datetime import datetime, timedelta
from pathlib import Path

from .database import data_dir

KEEP_DAYS = int(os.environ.get("TASKPLANNER_TRASH_DAYS", "90"))


def trash_root() -> Path:
    return data_dir() / "trash"


def discard(path) -> bool:
    """Moves a file (or folder) to the trash. Returns True when it is gone from its place. Anything that cannot be moved
    is left where it is: leaving a stray file is better than erasing a document."""
    try:
        src = Path(path)
        if not (src.is_file() or src.is_dir()) or src.is_symlink():
            return not src.exists() and not src.is_symlink()
        dest_dir = trash_root() / datetime.now().strftime("%Y%m%d")
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / f"{datetime.now():%H%M%S}-{src.parent.name[:12]}-{src.name}"
        n = 2
        while dest.exists():
            dest = dest_dir / f"{datetime.now():%H%M%S}-{src.parent.name[:12]}-{n}-{src.name}"
            n += 1
        shutil.move(str(src), str(dest))
        return True
    except OSError:
        return False


def purge(days: int | None = None) -> int:
    """Deletes the day folders older than `days` (default KEEP_DAYS). Returns how many were removed."""
    root = trash_root()
    if not root.is_dir():
        return 0
    cutoff = (datetime.now() - timedelta(days=days if days is not None else KEEP_DAYS)).strftime("%Y%m%d")
    removed = 0
    for d in root.iterdir():
        if d.is_dir() and d.name.isdigit() and len(d.name) == 8 and d.name < cutoff:
            shutil.rmtree(d, ignore_errors=True)
            removed += 1
    return removed
