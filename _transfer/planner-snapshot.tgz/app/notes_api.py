"""Notes & Scripts: REST API over a folder of Markdown files.

The notes folder is ``$NOTES_DIR`` or ``~/Documents/Notes``. Every note is a
plain ``.md`` file in that structure -- nothing is stored anywhere else, so
the files stay usable from any other editor (Obsidian, QOwnNotes, ...).

Safety rules:
  * every path is resolved and must stay inside the notes folder;
  * hidden folders (``.obsidian``, ``.trash``...) and QOwnNotes' ``trash``
    folder are never listed;
  * "delete" moves the file to ``<notes>/.trash/`` instead of removing it;
  * before a note is overwritten, the previous version is copied to the app's
    data folder (``notes_backups/``): a version at most every couple of minutes
    (at once if the new text is much shorter), thinned over time - the last 20,
    one per hour for 3 days, one per day for 90 days.
"""
from __future__ import annotations

import json
import mimetypes
import os
import shutil
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from flask import abort, jsonify, request, send_file
from werkzeug.utils import secure_filename

from .database import data_dir

SKIP_DIRS = {"trash", "node_modules"}          # + anything starting with "."
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp", ".avif"}
KEEP_VERSIONS = 10


def notes_root() -> Path:
    raw = os.environ.get("NOTES_DIR") or "~/Documents/Notes"
    return Path(raw).expanduser()


def _safe(rel: str, *, must_exist=False, md=False, allow_root=False) -> Path:
    """Resolve ``rel`` inside the notes folder or abort(400/404)."""
    root = notes_root().resolve()
    rel = (rel or "").replace("\\", "/").strip("/")
    if not rel and not allow_root:
        abort(400, "Missing path")
    p = (root / rel).resolve()
    if p != root and root not in p.parents:
        abort(400, "Path outside the notes folder")
    parts = Path(rel).parts
    if any(part.startswith(".") for part in parts) or (parts and parts[0] in SKIP_DIRS):
        abort(400, "Hidden folders are not available")
    if md and p.suffix.lower() != ".md":
        abort(400, "Only .md notes are supported")
    if must_exist and not p.exists():
        abort(404, "Not found")
    return p


def _rel(p: Path) -> str:
    return p.resolve().relative_to(notes_root().resolve()).as_posix()


def _clean_name(name: str) -> str:
    """A file/folder name that is safe on every OS but keeps accents/spaces."""
    name = (name or "").strip().replace("/", "-").replace("\\", "-").replace("\0", "")
    name = name.lstrip(".").strip()
    return name


VERSION_GAP_SECONDS = 120          # a new version at most this often while someone types (autosave runs every ~1.5 s)
KEEP_HOURLY_DAYS = 3
KEEP_DAILY_DAYS = 90
_VERSION_STAMP = "%Y%m%d-%H%M%S"


def _prune_versions(dest_dir: Path):
    """Newest KEEP_VERSIONS stay; older ones thin out to one per hour (3 days), then one per day (90 days)."""
    versions = sorted(dest_dir.glob("*.md"))                      # stamps sort chronologically
    older = versions[:-KEEP_VERSIONS]
    if not older:
        return
    now = datetime.now()
    keep, seen = set(), set()
    for v in reversed(older):                                    # newest first: the latest of each hour / day wins
        try:
            when = datetime.strptime(v.stem[:15], _VERSION_STAMP)
        except ValueError:
            keep.add(v)                                          # a name we don't understand is never deleted
            continue
        age = now - when
        if age <= timedelta(days=KEEP_HOURLY_DAYS):
            bucket = ("h", when.strftime("%Y%m%d%H"))
        elif age <= timedelta(days=KEEP_DAILY_DAYS):
            bucket = ("d", when.strftime("%Y%m%d"))
        else:
            continue
        if bucket not in seen:
            seen.add(bucket)
            keep.add(v)
    for v in older:
        if v not in keep:
            try:
                v.unlink()
            except OSError:
                pass


def _backup_previous(p: Path, new_content: str | None = None):
    """Copies the file about to be overwritten to the app's data folder (exact bytes), unless it is identical to the
    latest copy or a copy was made very recently - except when the new text is much shorter, which is what a bad save
    looks like, and then the old text is always kept."""
    if not p.exists():
        return
    try:
        rel = _rel(p)
        dest_dir = data_dir() / "notes_backups" / Path(rel).parent / (Path(rel).stem + ".versions")
        dest_dir.mkdir(parents=True, exist_ok=True)
        existing = sorted(dest_dir.glob("*.md"))
        old_size = p.stat().st_size
        shrinking = new_content is not None and old_size > 0 and len(new_content.encode("utf-8")) < old_size * 0.8
        if existing and not shrinking:
            last = existing[-1]
            try:
                if time.time() - last.stat().st_mtime < VERSION_GAP_SECONDS:
                    return
                if last.read_bytes() == p.read_bytes():
                    return
            except OSError:
                pass
        stamp = datetime.now().strftime(_VERSION_STAMP)
        n = 1
        dest = dest_dir / f"{stamp}-{n:02d}.md"          # always numbered, so several in one second still sort in order
        while dest.exists():
            n += 1
            dest = dest_dir / f"{stamp}-{n:02d}.md"
        shutil.copy2(p, dest)
        _prune_versions(dest_dir)
    except Exception:
        pass            # a failed backup must never block saving


_path_locks: dict[str, threading.Lock] = {}
_path_locks_guard = threading.Lock()


def _path_lock(p: Path) -> threading.Lock:
    """One lock per file: two requests saving the same note (an autosave and the one sent when the tab closes) must not
    interleave their writes."""
    with _path_locks_guard:
        return _path_locks.setdefault(str(p), threading.Lock())


def _write_atomic(p: Path, content: str):
    from .fsutil import atomic_write_text
    atomic_write_text(p, content)


# -- pinned / recent notes (kept in the app's data folder, not in the notes) --
RECENT_KEEP = 20


def _state_file() -> Path:
    return data_dir() / "notes_state.json"


def _load_state() -> dict:
    try:
        d = json.loads(_state_file().read_text(encoding="utf-8"))
    except Exception:
        d = {}
    return {"pinned": [p for p in d.get("pinned", []) if isinstance(p, str)],
            "recent": [p for p in d.get("recent", []) if isinstance(p, str)]}


def _save_state(st: dict):
    try:
        from .fsutil import atomic_write_text
        atomic_write_text(_state_file(), json.dumps(st, ensure_ascii=False, indent=1))
    except Exception:
        pass


def _state_rename(old: str, new: str | None):
    """Keeps pins/recents pointing at a note that was renamed, moved or deleted."""
    st = _load_state()
    for key in ("pinned", "recent"):
        out = []
        for p in st[key]:
            if p == old:
                if new:
                    out.append(new)
            else:
                out.append(p)
        st[key] = list(dict.fromkeys(out))
    _save_state(st)


def _relink(src: Path, dst: Path):
    """Tasks linked to a note that was renamed or moved keep pointing at it."""
    try:
        from .api.common import db
        db().relink_notes_file(src, dst)
    except Exception:
        pass


def _existing(paths):
    root = notes_root()
    return [p for p in paths if (root / p).is_file()]


def _walk(root: Path):
    notes, folders = [], []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if not d.startswith(".") and d not in SKIP_DIRS)
        d = Path(dirpath)
        if d != root:
            folders.append(d.relative_to(root).as_posix())
        for fn in filenames:
            if fn.startswith(".") or not fn.lower().endswith(".md"):
                continue
            f = d / fn
            try:
                st = f.stat()
            except OSError:
                continue
            notes.append({
                "path": f.relative_to(root).as_posix(),
                "name": fn[:-3],
                "folder": "" if d == root else d.relative_to(root).as_posix(),
                "mtime": st.st_mtime, "size": st.st_size,
            })
    return notes, folders


def _json_body() -> dict:
    """The JSON body, which must be an object: anything else is a 400 (not a 500 from calling .get() on a list)."""
    data = request.get_json(force=True, silent=True)
    if data is None:
        return {}
    if not isinstance(data, dict):
        abort(400, "The request body must be a JSON object.")
    return data


def register(bp):
    @bp.get("/notes/tree")
    def notes_tree():
        root = notes_root()
        if not root.is_dir():
            return jsonify({"root": str(root), "exists": False, "notes": [], "folders": []})
        notes, folders = _walk(root)
        return jsonify({"root": str(root), "exists": True, "notes": notes, "folders": folders})

    @bp.get("/notes/state")
    def notes_state():
        st = _load_state()
        return jsonify({"pinned": _existing(st["pinned"]), "recent": _existing(st["recent"])[:5]})

    @bp.post("/notes/pin")
    def notes_pin():
        body = _json_body()
        p = _safe(body.get("path", ""), must_exist=True, md=True)
        rel = _rel(p)
        st = _load_state()
        st["pinned"] = [x for x in st["pinned"] if x != rel]
        if body.get("pinned", True):
            st["pinned"].append(rel)
        _save_state(st)
        return jsonify({"pinned": _existing(st["pinned"])})

    @bp.post("/notes/touch")
    def notes_touch():
        """Marks a note as one you just worked on (feeds the Récents list)."""
        body = _json_body()
        p = _safe(body.get("path", ""), must_exist=True, md=True)
        rel = _rel(p)
        st = _load_state()
        st["recent"] = [rel] + [x for x in st["recent"] if x != rel]
        st["recent"] = st["recent"][:RECENT_KEEP]
        _save_state(st)
        return jsonify({"recent": _existing(st["recent"])[:5]})

    @bp.get("/notes/file")
    def notes_read():
        p = _safe(request.args.get("path", ""), must_exist=True, md=True)
        data = p.read_bytes()
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            text = data.decode("latin-1")
        return jsonify({"path": _rel(p), "content": text, "mtime": p.stat().st_mtime})

    @bp.put("/notes/file")
    def notes_write():
        body = _json_body()
        p = _safe(body.get("path", ""), md=True)
        if not isinstance(body.get("content"), str):
            abort(400, "Missing content")
        known = body.get("mtime")
        if known is not None:
            try:
                known = float(known)
            except (TypeError, ValueError):
                abort(400, "Invalid mtime")
        with _path_lock(p):
            if p.exists() and known is not None and abs(p.stat().st_mtime - known) > 0.01 \
                    and not body.get("force"):
                # the file changed on disk (sync, other editor...) since it was opened
                return jsonify({"error": "changed", "mtime": p.stat().st_mtime}), 409
            _backup_previous(p, body["content"])
            _write_atomic(p, body["content"])
            return jsonify({"path": _rel(p), "mtime": p.stat().st_mtime})

    @bp.post("/notes/new")
    def notes_new():
        body = _json_body()
        folder = (body.get("folder") or "").strip("/")
        name = _clean_name(body.get("name") or "Untitled")
        if name.lower().endswith(".md"):
            name = name[:-3]
        if not name:
            abort(400, "Missing name")
        base_dir = _safe(folder, allow_root=True)
        p = base_dir / f"{name}.md"
        n = 2
        while p.exists():
            p = base_dir / f"{name} {n}.md"
            n += 1
        _safe(_rel_candidate(p), md=True)
        _write_atomic(p, body.get("content") or "")
        return jsonify({"path": _rel(p), "name": p.stem}), 201

    @bp.post("/notes/rename")
    def notes_rename():
        body = _json_body()
        src = _safe(body.get("path", ""), must_exist=True, md=True)
        name = _clean_name(body.get("name") or "")
        if name.lower().endswith(".md"):
            name = name[:-3]
        if not name:
            abort(400, "Missing name")
        dst = src.with_name(f"{name}.md")
        if dst != src:
            if dst.exists():
                return jsonify({"error": "A note with that name already exists."}), 409
            old_rel = _rel(src)
            src.rename(dst)
            _relink(src, dst)
            _state_rename(old_rel, _rel(dst))
        return jsonify({"path": _rel(dst), "name": dst.stem})

    @bp.post("/notes/move")
    def notes_move():
        body = _json_body()
        src = _safe(body.get("path", ""), must_exist=True, md=True)
        folder = _safe((body.get("folder") or "").strip("/"), allow_root=True)
        dst = folder / src.name
        if dst != src:
            if dst.exists():
                return jsonify({"error": "A note with that name already exists there."}), 409
            folder.mkdir(parents=True, exist_ok=True)
            old_rel = _rel(src)
            src.rename(dst)
            _relink(src, dst)
            _state_rename(old_rel, _rel(dst))
        return jsonify({"path": _rel(dst)})

    @bp.delete("/notes/file")
    def notes_delete():
        p = _safe(request.args.get("path", ""), must_exist=True, md=True)
        trash = notes_root() / ".trash"
        trash.mkdir(exist_ok=True)
        dst = trash / p.name
        n = 2
        while dst.exists():
            dst = trash / f"{p.stem} ({n}){p.suffix}"
            n += 1
        old_rel = _rel(p)
        shutil.move(str(p), str(dst))
        _state_rename(old_rel, None)
        return jsonify({"ok": True})

    @bp.post("/notes/folder")
    def notes_folder():
        body = _json_body()
        parent = (body.get("parent") or "").strip("/")
        name = _clean_name(body.get("name") or "")
        if not name:
            abort(400, "Missing name")
        p = _safe(f"{parent}/{name}" if parent else name)
        p.mkdir(parents=True, exist_ok=True)
        return jsonify({"path": _rel(p)}), 201

    # -- images ----------------------------------------------------------
    @bp.get("/notes/asset")
    def notes_asset():
        """Serves an image referenced by a note (path relative to the notes
        folder). Only image types are served."""
        p = _safe(request.args.get("path", ""), must_exist=True)
        if p.suffix.lower() not in IMAGE_EXTS or not p.is_file():
            abort(404)
        resp = send_file(p, mimetype=mimetypes.guess_type(p.name)[0] or "application/octet-stream")
        # An SVG opened directly (not through <img>) could run scripts in the
        # app's origin: this CSP sandboxes it so it can only be drawn.
        resp.headers["Content-Security-Policy"] = (
            "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        return resp

    @bp.post("/notes/media")
    def notes_media():
        """Stores a pasted/dropped image in <notes>/media/ and returns the
        path relative to the notes folder."""
        f = request.files.get("file")
        if not f or not f.filename:
            abort(400, "No file")
        ext = Path(f.filename).suffix.lower()
        if ext not in IMAGE_EXTS:
            ext = ".png" if (f.mimetype or "").startswith("image/") else ""
        if not ext:
            abort(400, "Not an image")
        stem = secure_filename(Path(f.filename).stem) or "image"
        if stem in ("image", "blob"):
            stem = "image-" + time.strftime("%Y%m%d-%H%M%S")
        media = notes_root() / "media"
        media.mkdir(parents=True, exist_ok=True)
        dst = media / f"{stem}{ext}"
        n = 2
        while dst.exists():
            dst = media / f"{stem}-{n}{ext}"
            n += 1
        f.save(dst)
        return jsonify({"path": _rel(dst)}), 201


def _rel_candidate(p: Path) -> str:
    return p.resolve().relative_to(notes_root().resolve()).as_posix()
