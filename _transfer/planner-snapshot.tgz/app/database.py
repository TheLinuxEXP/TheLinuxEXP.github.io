"""SQLite storage layer for the task planner.

Model: projects -> todo_lists -> tasks, with a user-managed tag taxonomy
(tags <-> tasks is many-to-many). One sqlite3 connection, guarded by a lock
since Flask's dev server can touch it from more than one thread.

The Database class is assembled from topic mixins in app/dbparts/ (backups,
catalog, task queries/writes, subtasks, time tracking, templates, migrations);
schema, constants and helpers live in app/dbparts/core.py; data_dir / new_id are re-exported
here, so `from app.database import data_dir, new_id` keeps working.
"""
from __future__ import annotations
import sqlite3
import threading
from pathlib import Path

from .dbparts.core import (BACKUP_TRIGGERS, PROJECT_COLORS, SCHEMA, _COLOR_RE, _TxConn, _clean_color, data_dir,
                           new_id)  # new_id: re-exported, `from app.database import new_id` is used elsewhere
from .dbparts.backups_ops import BackupsMixin
from .dbparts.billing import BillingMixin
from .dbparts.catalog import CatalogMixin
from .dbparts.task_queries import TaskQueryMixin
from .dbparts.subtasks import SubtaskMixin
from .dbparts.timetracking import TimeTrackingMixin
from .dbparts.templates_ops import TemplatesMixin
from .dbparts.migrations import MigrationsMixin
from .dbparts.task_writes import TaskWriteMixin


class Database(BackupsMixin, BillingMixin, CatalogMixin, TaskQueryMixin, SubtaskMixin, TimeTrackingMixin, TemplatesMixin, MigrationsMixin, TaskWriteMixin):
    def __init__(self, path: Path | None = None):
        self.path = path or (data_dir() / "taskplanner.db")
        # check_same_thread=False + an explicit lock (see
        # _wrap_methods_with_lock below): the server runs multi-threaded so a
        # slow request (an AI button) doesn't block every other request, and
        # a single sqlite3 connection isn't safe to share across threads
        # without serializing access to it ourselves.
        self._raw_conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._raw_conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        self._call_depth = 0
        self._to_unlink = []          # files/folders to delete once a deletion is committed
        # WAL + synchronous=NORMAL: a commit no longer waits for a full fsync of the database file (the app commits after every
        # change), and a reader never blocks the writer. busy_timeout: wait instead of failing if another process holds the file.
        for pragma in ("journal_mode=WAL", "synchronous=NORMAL", "busy_timeout=5000"):
            try:
                self._raw_conn.execute(f"PRAGMA {pragma}")
            except sqlite3.DatabaseError:
                pass                          # e.g. a file system without WAL support: keep SQLite's defaults
        self.conn = _TxConn(self._raw_conn, self)
        from .backups import BackupStore
        self._backups = BackupStore((Path(path).parent if path else data_dir()) / "backups")
        self._call_depth = 0
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        # colors stored before validation existed: rewrite anything that isn't a hex color
        for _tbl in ("projects", "tags"):
            for _r in self.conn.execute(f"SELECT id, color FROM {_tbl}").fetchall():
                if not (isinstance(_r["color"], str) and _COLOR_RE.match(_r["color"])):
                    self.conn.execute(f"UPDATE {_tbl} SET color=? WHERE id=?",
                                      (_clean_color(_r["color"]), _r["id"]))
        self.conn.commit()
        # Lightweight migrations: add columns introduced after someone's
        # database already existed, instead of requiring a fresh DB.
        self._ensure_column("tasks", "start_time", "TEXT")
        self._ensure_column("task_completions", "subtasks_json", "TEXT")
        # Optional rule that places a subtask relative to its recurring main
        # task each occurrence: "same_day" or "weekday_before:N" (Mon=0..Sun=6).
        self._ensure_column("subtasks", "due_rule", "TEXT")
        # 1 = leftover time archived off a still-open occurrence: counts in
        # time totals/reports but is not a finished occurrence to display.
        self._ensure_column("task_completions", "time_only", "INTEGER NOT NULL DEFAULT 0")
        # when the occurrence ran, so moving the CURRENT occurrence never drags finished ones along
        self._ensure_column("task_completions", "slot_start_time", "TEXT")
        self._ensure_column("task_completions", "slot_duration", "INTEGER")
        self._ensure_column("tasks", "time_day", "TEXT")   # last day time was tracked on it
        self._ensure_column("subtasks", "start_time", "TEXT")
        self._ensure_column("subtasks", "template_sub_id", "TEXT")   # template subtask it came from (survives renames)
        self._ensure_column("tasks", "notes_file", "TEXT")
        self._ensure_column("tasks", "video_note_file", "TEXT")   # the "-VIDEO" note made by Create Video Note
        self._ensure_column("subtasks", "notes_file", "TEXT")
        self._ensure_column("tasks", "mention_approved", "INTEGER DEFAULT 0")
        self._ensure_column("tasks", "video_template", "TEXT")
        self._ensure_column("tasks", "time_spent_seconds", "INTEGER DEFAULT 0")
        self._ensure_column("tasks", "timer_started_at", "TEXT")
        self._ensure_column("tasks", "timer_state", "TEXT DEFAULT 'idle'")
        # JSON {"due_date", "start_time"}: where an occurrence that was dragged
        # elsewhere in the calendar ORIGINALLY sat, so the rest of the series
        # keeps its schedule (see move_occurrence).
        self._ensure_column("tasks", "occ_base", "TEXT")
        self._ensure_column("subtasks", "occ_base", "TEXT")
        self._ensure_column("subtasks", "time_spent_seconds", "INTEGER DEFAULT 0")
        self._ensure_column("subtasks", "timer_started_at", "TEXT")
        self._ensure_column("subtasks", "timer_state", "TEXT DEFAULT 'idle'")
        self._ensure_column("video_template_subtasks", "ai_buttons", "TEXT")
        # sponsor billing (see dbparts/billing.py)
        self._ensure_column("tag_contracts", "billing_period", "TEXT")   # monthly | quarterly
        self._ensure_column("tag_contracts", "amount_type", "TEXT")      # per_video | fixed
        self._ensure_column("tag_contracts", "amount", "TEXT")           # free text, as typed
        self._ensure_indexes()
        self._ensure_default_project()
        self._seed_templates()
        self.seed_template_ai_buttons()
        self.seed_template_chapters_button()
        self.seed_template_edit_buttons()
        self.seed_template_timestamps_button()
        self.seed_template_thumbnails_button()
        self.seed_template_title_date()
        self.seed_template_text_timestamps_button()
        self.seed_template_list_to_ppt_button()
        self.seed_weekly_news_setup_edit()
        self.link_subtasks_to_templates()
        self.backfill_template_subtask_start_times()
        self.backfill_video_template_types()
        self.backfill_edit_a_roll_subtask()
        self.backfill_normal_video_edit_a_roll()
        self.repair_wrongly_finished_occurrence()
        self.reset_subtasks_left_over_from_finished_occurrences()
        self.backfill_time_log()
        self.repair_time_after_early_archive()
        self.remove_duplicate_daily_news_hour()
        self.repair_future_time_log()
        self.apply_patroncast_due_rules()
        self.make_patroncast_monday_only()
        self._wrap_methods_with_lock()

    def _queue_unlink(self, path):
        if path:
            self._to_unlink.append(str(path))

    def _flush_unlink(self):
        """Clear away the files left behind by committed deletions. Attachments and contracts go to the trash folder
        (see trash.py) so a deleted task / sponsor restored from a backup still has its documents; generated decks and
        crops, which can be produced again, are erased. Only ever inside the data folders."""
        import shutil
        from . import trash
        roots = {Path(self.path).parent.resolve(), data_dir().resolve()}
        generated = (data_dir() / "generated").resolve()
        pending, self._to_unlink = self._to_unlink, []
        for raw in pending:
            try:
                p = Path(raw).resolve()
                if not any(r in p.parents for r in roots):
                    continue
                if generated in p.parents:
                    if p.is_dir():
                        shutil.rmtree(p, ignore_errors=True)
                    elif p.exists():
                        p.unlink()
                elif p.exists():
                    if not trash.discard(p):
                        continue
                    try:
                        p.parent.rmdir()          # drop the per-task folder once empty
                    except OSError:
                        pass
            except OSError:
                pass

    def _queue_task_files(self, where, params):
        for r in self.conn.execute(f"SELECT id, attachment_path FROM tasks WHERE {where}", params).fetchall():
            self._queue_unlink(r["attachment_path"])
            self._queue_unlink(data_dir() / "attachments" / r["id"])
            for sub in self.conn.execute("SELECT id FROM subtasks WHERE task_id=?", (r["id"],)).fetchall():
                self._queue_unlink(data_dir() / "generated" / sub["id"])

    def _wrap_methods_with_lock(self):
        """Serialize every public method behind self._lock, so the server can
        run multi-threaded (needed so a slow request -- e.g. an AI button
        shelling out to the Claude Code CLI, which can take a while -- doesn't
        block every other request) without two threads touching the single
        shared sqlite3 connection at the same time. The lock is reentrant, so
        one wrapped method calling another (e.g. update_task calling
        get_task) still works fine from the same thread."""
        for name in dir(self.__class__):
            if name.startswith("_"):
                continue
            attr = getattr(self.__class__, name)
            if not callable(attr):
                continue
            bound = getattr(self, name)

            def make_locked(fn, name):
                def locked(*args, **kwargs):
                    with self._lock:
                        self._call_depth += 1
                        try:
                            result = fn(*args, **kwargs)
                        except BaseException:
                            self._call_depth -= 1
                            if self._call_depth == 0:
                                self.conn.rollback()
                                self._to_unlink.clear()
                            raise
                        self._call_depth -= 1
                        if self._call_depth == 0:
                            self.conn.real_commit()
                            self._flush_unlink()
                            # A change made by this (outermost) call: back it up.
                            if name in BACKUP_TRIGGERS:
                                self._auto_backup(name, args, kwargs, result)
                        return result
                return locked

            setattr(self, name, make_locked(bound, name))

    def _ensure_column(self, table, column, decl):
        cols = [r["name"] for r in self.conn.execute(f"PRAGMA table_info({table})").fetchall()]
        if column not in cols:
            self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")
            self.conn.commit()

    # Indexes for the lookups done on every screen (tasks of a list, by due date, subtasks of a task, tags of a task...).
    # Created here, after the column migrations above, because some indexed columns are added by them.
    INDEXES = (
        ("idx_tasks_list", "tasks", "todo_list_id"),
        ("idx_tasks_due", "tasks", "due_date"),
        ("idx_tasks_video_due", "tasks", "is_video, due_date"),
        ("idx_subtasks_task", "subtasks", "task_id"),
        ("idx_subtasks_due", "subtasks", "due_date"),
        ("idx_task_tags_tag", "task_tags", "tag_id"),
        ("idx_todo_lists_project", "todo_lists", "project_id"),
        ("idx_completions_task", "task_completions", "task_id"),
        ("idx_moves_task", "occurrence_moves", "task_id"),
    )

    def _ensure_indexes(self):
        for name, table, cols in self.INDEXES:
            try:
                self.conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {table}({cols})")
            except sqlite3.OperationalError:
                pass                          # a table / column an old database does not have: skip rather than refuse to start
        self.conn.commit()

    def _ensure_default_project(self):
        row = self.conn.execute("SELECT id FROM projects LIMIT 1").fetchone()
        if not row:
            pid = self.add_project("My Project", PROJECT_COLORS[0])
            self.add_todo_list(pid, "Tasks")

    # ------------------------------------------------------------------
    def _update(self, table, row_id, fields: dict):
        if not fields:
            return
        if "color" in fields:
            fields = {**fields, "color": _clean_color(fields["color"])}
        cols = ", ".join(f"{k}=?" for k in fields)
        self.conn.execute(f"UPDATE {table} SET {cols} WHERE id=?", (*fields.values(), row_id))
        self.conn.commit()

