"""« List to PPT » (Warhammer Video) : lit une liste d'armée au format de l'appli Games Workshop (texte collé) et la
transforme en plan de slides.

Ce module ne fait QUE le travail local et déterministe :
  * parse_army_list(texte)  -> la liste structurée (détachements, dispositions, unités, personnages attachés…) ;
  * build_slide_plan(liste) -> l'ordre des slides demandé (détachement, stratagèmes par 3, dispositions, unités, unités attachées) ;
les règles et fiches techniques viennent de Wahapedia (voir army_rules.py), le dessin des cartes de army_cards.py.
"""
from __future__ import annotations
import re

from .ai import AIError

NBSP = "  "
_NUM = r"\d[\d\s" + NBSP + r"]*"
RE_UNIT = re.compile(rf"^(?P<name>.+?)\s*\((?P<pts>{_NUM})\s*(?:Points?|pts?)\)\s*$", re.I)
RE_DETACH = re.compile(rf"^(?P<name>.+?)\s*\((?P<dp>{_NUM})\s*(?:Points? de D[ée]tachement|Detachment Points?)\)\s*$", re.I)
RE_BULLET1 = re.compile(r"^\s{1,4}[•\-\*]\s*(?P<t>.+)$")
RE_BULLET2 = re.compile(r"^\s{5,}[◦○▪\-\*]\s*(?P<t>.+)$")
RE_COUNT = re.compile(r"^(?P<n>\d+)\s*[x×]\s*(?P<t>.+)$", re.I)
RE_ATTACH = re.compile(r"^(?:Attach[ée]e?\s+[àa]|Rejoint|Rejoins|Attached to|Leading|Dirige)\s*:?\s*(?P<t>.+)$", re.I)
RE_ENH = re.compile(r"^(?:Optimisations?|Am[ée]liorations?|Enhancements?)\s*:\s*(?P<t>.+)$", re.I)
RE_WARLORD = re.compile(r"^(?:Seigneur de Guerre|Warlord)$", re.I)
RE_FOOTER = re.compile(r"^(?:Export[ée] avec|Exported with)", re.I)


def _int(s: str) -> int:
    return int(re.sub(r"\D", "", s) or 0)


def _is_header(line: str) -> bool:
    """« PERSONNAGES », « LIGNE », « TRANSPORTS ASSIGNÉS »… : une ligne tout en majuscules, sans points entre parenthèses."""
    s = line.strip()
    return bool(s) and s == s.upper() and any(c.isalpha() for c in s) and "(" not in s and not s.startswith(("•", "◦"))


def _model_name(text: str) -> str:
    """« Vétéran de la Deathwatch avec Marteau Tonnerre Lourd et… » -> « Vétéran de la Deathwatch »."""
    return re.split(r"\s+(?:avec|with)\s+", text, maxsplit=1, flags=re.I)[0].strip().rstrip(".")


def _wargear(items):
    out = []
    for t in items:
        m = RE_COUNT.match(t)
        out.append((int(m["n"]), m["t"].strip()) if m else (1, t.strip()))
    return out


def parse_army_list(text: str) -> dict:
    """-> {"name", "points", "faction", "subfaction", "detachments": [{"name","dp"}], "dispositions": [str],
    "battle_size", "battle_points", "units": [unit…], "warnings": [str]}.
    unit = {"name","points","section","warlord","enhancement","attached_to","wargear":[(n,nom)],"models":[{"count","name","wargear"}],"count"}"""
    lines = [l.rstrip() for l in (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")]
    lines = [l.replace(" ", " ") if False else l for l in lines]
    if not any(l.strip() for l in lines):
        raise AIError("La liste est vide : collez une liste d'armée au format de l'appli Games Workshop.")
    res = {"name": "", "points": 0, "faction": "", "subfaction": "", "detachments": [], "dispositions": [],
           "battle_size": "", "battle_points": 0, "units": [], "warnings": []}

    i, n = 0, len(lines)
    while i < n and not lines[i].strip():
        i += 1
    m = RE_UNIT.match(lines[i].strip()) if i < n else None
    if m:
        res["name"], res["points"] = m["name"].strip(), _int(m["pts"])
        i += 1
    # --- en-tête : faction, (sous-faction), détachements, dispositions, taille de bataille
    head = []
    while i < n and not _is_header(lines[i]) and not RE_BULLET1.match(lines[i]):
        s = lines[i].strip()
        if s:
            head.append(s)
        i += 1
        # la première ligne « Nom (N Points) » SANS détachement qui suit les dispositions est la taille de bataille ;
        # elle termine l'en-tête (les unités commencent après le premier titre de section)
    seen_detachment = False
    for s in head:
        d = RE_DETACH.match(s)
        if d:
            res["detachments"].append({"name": d["name"].strip(), "dp": _int(d["dp"])})
            seen_detachment = True
            continue
        u = RE_UNIT.match(s)
        if u:
            res["battle_size"], res["battle_points"] = u["name"].strip(), _int(u["pts"])
            continue
        if not seen_detachment:
            if not res["faction"]:
                res["faction"] = s
            elif not res["subfaction"]:
                res["subfaction"] = s
            else:
                res["subfaction"] += " / " + s
        else:
            res["dispositions"].append(s)

    # --- unités
    section, cur, last_model = "", None, None
    for raw in lines[i:]:
        if not raw.strip():
            continue
        if RE_FOOTER.match(raw.strip()):
            break
        if _is_header(raw):
            section, cur, last_model = raw.strip(), None, None
            continue
        b2, b1 = RE_BULLET2.match(raw), RE_BULLET1.match(raw)
        if b1 and cur is not None and not b2:
            t = b1["t"].strip()
            if RE_WARLORD.match(t):
                cur["warlord"] = True
            elif RE_ENH.match(t):
                cur["enhancement"] = RE_ENH.match(t)["t"].strip()
            elif RE_ATTACH.match(t):
                cur["attached_to"] = RE_ATTACH.match(t)["t"].strip()
            else:
                m = RE_COUNT.match(t)
                last_model = {"count": int(m["n"]) if m else 1, "name": _model_name(m["t"] if m else t), "wargear": [], "raw": t}
                cur["models"].append(last_model)
            continue
        if b2 and cur is not None:
            t = b2["t"].strip()
            (last_model["wargear"] if last_model else cur["wargear_raw"]).append(t)
            continue
        u = RE_UNIT.match(raw.strip())
        if u and not raw.startswith((" ", "\t")):
            cur = {"name": u["name"].strip(), "points": _int(u["pts"]), "section": section, "warlord": False,
                   "enhancement": "", "attached_to": "", "models": [], "wargear_raw": [], "count": 1}
            res["units"].append(cur)
            last_model = None
            continue
        res["warnings"].append(f"Ligne non reconnue : « {raw.strip()[:60]} »")

    for u in res["units"]:
        for mdl in u["models"]:
            mdl["wargear"] = _wargear(mdl["wargear"])
        u["wargear"] = _wargear(u.pop("wargear_raw"))
        # personnage / véhicule : ses armes sont des puces de niveau 1 (« 1x Lance de veilleur »), sans sous-puces :
        # ce ne sont pas des figurines différentes mais l'équipement de l'unique figurine
        if u["models"] and all(not m["wargear"] for m in u["models"]):
            u["wargear"] += [(m["count"], m["name"]) for m in u["models"]]
            u["models"] = []
    if not res["units"]:
        raise AIError("Aucune unité reconnue dans cette liste. Collez-la telle qu'exportée par l'appli Games Workshop (Partager > Exporter en texte).")
    return res


def _key(u: dict):
    return (u["name"], u["points"], u["enhancement"], tuple(u["wargear"]),
            tuple((m["count"], m["name"], tuple(m["wargear"])) for m in u["models"]), u["attached_to"], u["warlord"])


def group_units(units: list) -> list:
    """Regroupe les unités strictement identiques (même nom, mêmes armes, mêmes options) : une seule slide, « ×2 »."""
    groups, order = {}, []
    for u in units:
        k = _key(u)
        if k in groups:
            groups[k]["count"] += 1
        else:
            groups[k] = dict(u)
            groups[k]["count"] = 1
            order.append(k)
    return [groups[k] for k in order]


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", re.sub(r"[àâä]", "a", re.sub(r"[éèêë]", "e", (s or "").lower())))


def build_slide_plan(parsed: dict) -> list:
    """L'ordre des slides : détachements (règle, puis stratagèmes par 3), dispositions, puis chaque unité ;
    un personnage attaché donne 2 slides (le ou les personnages, puis l'unité rejointe)."""
    plan = []
    for d in parsed["detachments"]:
        plan.append({"kind": "detachment_rule", "detachment": d["name"]})
        plan.append({"kind": "stratagems", "detachment": d["name"]})   # découpé par 3 une fois les stratagèmes connus
    plan.append({"kind": "dispositions"})
    units = group_units(parsed["units"])
    by_name = {}
    for u in units:
        by_name.setdefault(_norm(u["name"]), []).append(u)
    leaders_of = {}          # id(unité rejointe) -> [personnages]
    attached_ids = set()
    for u in units:
        if u["attached_to"]:
            target = next((t for t in by_name.get(_norm(u["attached_to"]), []) if t is not u), None)
            if target is not None:
                leaders_of.setdefault(id(target), []).append(u)
                attached_ids.add(id(u))
    for u in units:
        if id(u) in attached_ids:
            continue
        if id(u) in leaders_of:
            leaders = leaders_of[id(u)]
            plan.append({"kind": "attached_leaders", "units": leaders, "target": u})
            plan.append({"kind": "attached_unit", "unit": u, "leaders": leaders})
        else:
            plan.append({"kind": "unit", "unit": u})
    return plan


# ====================================================================== génération du PPT
STRATS_PER_SLIDE = 3


def _pts(n) -> str:
    return f"{n} pts"


def _gear_text(u: dict) -> str:
    bits = [f"{n}× {w}" for n, w in u["wargear"]]
    for m in u["models"]:
        bits.append(f"{m['count']}× {m['name']}")
    return ", ".join(bits)


def _placeholder_unit(u: dict, note: str = "") -> dict:
    return {"name": u["name"], "faction_line": "", "composition_short": "", "stats": {}, "weapons": [], "core": [], "keywords": [],
            "abilities": [{"name": "Données non trouvées",
                           "text": "La fiche de cette unité n'a pas pu être lue sur Wahapedia" + (f" ({note})" if note else "") +
                                   ". Équipement de la liste : " + (_gear_text(u) or "—") + "."}],
            "recap": [], "found": False}


def _unit_lines(u: dict, d: dict, extra_cost: str = "") -> list:
    lines = []
    cost = f"Coût : {_pts(u['points'])}"
    if u.get("count", 1) > 1:
        cost += f" par unité — {u['count']} unités : {_pts(u['points'] * u['count'])}"
    lines.append("# " + (extra_cost or cost))
    if u.get("warlord"):
        lines.append("- Seigneur de guerre")
    enh = (d.get("enhancement") or {}) if isinstance(d.get("enhancement"), dict) else {}
    if u["enhancement"]:
        lines.append(f"- Optimisation : {u['enhancement']}" + (f" (+{enh['cost']} pts)" if enh.get("cost") else ""))
    recap = d.get("recap") or []
    if not recap:
        recap = [f"Équipement : {_gear_text(u)}"] if _gear_text(u) else []
    lines += ["- " + r for r in recap[:8]]
    if not d.get("found", True):
        lines.append("-- (fiche non trouvée sur Wahapedia : à compléter)")
    return lines


def _unit_info(u: dict, d: dict) -> dict:
    enh = d.get("enhancement") if isinstance(d.get("enhancement"), dict) else None
    if u["enhancement"] and not enh:
        enh = {"name": u["enhancement"]}
    elif enh and not enh.get("name"):
        enh = dict(enh, name=u["enhancement"])
    return {"points": u["points"], "count": u.get("count", 1), "enhancement": enh}


def build_deck_slides(parsed: dict, plan: list, rules: dict, out_dir, warnings: list) -> list:
    """-> [{"title","lines","image"}] prêts pour pptx_gen.build_picture_deck."""
    from pathlib import Path
    from . import army_cards as K
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    slides = []

    def add(title, lines, img):
        p = out_dir / f"card-{len(slides) + 1:02d}.png"
        img.save(p)
        slides.append({"title": title, "lines": lines, "image": p})

    def unit_data(u):
        d = rules["units"].get(id(u))
        if d is None:
            warnings.append(f"« {u['name']} » : fiche non récupérée (erreur ou délai dépassé).")
            return _placeholder_unit(u)
        if not d.get("found"):
            warnings.append(f"« {u['name']} » : fiche introuvable sur Wahapedia.")
            return dict(_placeholder_unit(u), edition_note=d.get("edition_note", ""))
        if d.get("edition_note"):
            warnings.append(f"« {u['name']} » : {d['edition_note']}")
        return d

    for item in plan:
        k = item["kind"]
        if k == "detachment_rule":
            name = item["detachment"]
            d = rules["det"].get(name)
            if not d or not d.get("rule"):
                warnings.append(f"Détachement « {name} » : règle introuvable sur Wahapedia.")
                d = {"rule": {"name": "Règle introuvable", "text": "La règle de ce détachement n'a pas pu être lue sur Wahapedia."}, "rule_recap": []}
            elif d.get("edition_note"):
                warnings.append(f"Détachement « {name} » : {d['edition_note']}")
            title = d.get("name") or name
            add(title, ["# " + (d["rule"].get("name") or "Règle de détachement")] + ["- " + r for r in (d.get("rule_recap") or [])[:7]],
                K.render_rule(d, title))
        elif k == "stratagems":
            name = item["detachment"]
            d = rules["det"].get(name) or {}
            strats = d.get("stratagems") or []
            if not strats:
                warnings.append(f"Détachement « {name} » : aucun stratagème trouvé.")
                continue
            title = d.get("name") or name
            chunks = [strats[i:i + STRATS_PER_SLIDE] for i in range(0, len(strats), STRATS_PER_SLIDE)]
            # 4 stratagèmes -> 2 slides (« 2 slides s'il y en a plus de 3 »), équilibrées si possible ; 5 ou 6 -> 3+2, 3+3
            for n, ch in enumerate(chunks, 1):
                lines = []
                for s in ch:
                    lines.append(f"# {s.get('name', '')}" + (f" — {s['cp']} PC" if s.get("cp") not in (None, "") else ""))
                    lines.append("- " + (s.get("recap") or s.get("effect") or ""))
                suffix = f" ({n}/{len(chunks)})" if len(chunks) > 1 else ""
                add(title + suffix, lines, K.render_stratagems(ch, title + suffix))
        elif k == "dispositions":
            dd = rules.get("disp") or {}
            items = dd.get("items") or [{"name": n, "missions": []} for n in parsed["dispositions"]]
            if not dd.get("found"):
                warnings.append("Dispositions de forces : missions introuvables sur Wahapedia (slide faite à partir de la liste).")
            elif dd.get("edition_note"):
                warnings.append(f"Dispositions : {dd['edition_note']}")
            lines = []
            for it in items:
                lines.append("# " + it["name"])
                lines += [f"- Contre {m['vs']} : {m['mission']}" if m.get("vs") else f"- {m['mission']}" for m in it.get("missions") or []]
            ctx = {"army": "Dispositions", "items": items}
            add("Dispositions", lines, K.render_dispositions(ctx))
        elif k == "unit":
            u = item["unit"]
            d = unit_data(u)
            add(u["name"] + (f" ×{u['count']}" if u["count"] > 1 else ""), _unit_lines(u, d),
                K.render_datasheets([{"data": d, "info": _unit_info(u, d)}]))
        elif k == "attached_leaders":
            leaders = item["units"]
            datas = [unit_data(l) for l in leaders]
            total = sum(l["points"] * l.get("count", 1) for l in leaders)
            lines = [f"# Coût des personnages : {' + '.join(_pts(l['points']) for l in leaders)} = {_pts(total)}"]
            for l, d in zip(leaders, datas):
                lines.append(f"# {l['name']}" + (" (seigneur de guerre)" if l["warlord"] else ""))
                lines += ["- " + r for r in (d.get("recap") or [])[:4]]
                if l["enhancement"]:
                    lines.append(f"- Optimisation : {l['enhancement']}")
            add(" + ".join(l["name"] for l in leaders), lines,
                K.render_datasheets([{"data": d, "info": _unit_info(l, d)} for l, d in zip(leaders, datas)]))
        elif k == "attached_unit":
            u = item["unit"]
            d = unit_data(u)
            total = u["points"] * u.get("count", 1) + sum(l["points"] * l.get("count", 1) for l in item["leaders"])
            add(u["name"], _unit_lines(u, d, f"Coût : {_pts(u['points'])} — avec ses personnages : {_pts(total)}"),
                K.render_datasheets([{"data": d, "info": _unit_info(u, d)}]))
    return slides


def distinct_units(plan: list) -> list:
    seen, out = set(), []
    for item in plan:
        for u in ([item["unit"]] if "unit" in item else []) + list(item.get("units") or []):
            if id(u) not in seen:
                seen.add(id(u))
                out.append(u)
    return out


def _safe_name(t: str) -> str:
    import re
    t = re.sub(r'[\\/:*?"<>|]+', " ", t).strip()
    return re.sub(r"\s+", " ", t)[:80] or "image"


def generate_deck(text: str, out_path, work_dir, progress=None, images_only: bool = False) -> dict:
    """Liste collée -> PPT (ou, en mode « images seulement », un zip des cartes). -> {"slide_count", "warnings", "summary"}"""
    from pathlib import Path
    from . import army_rules, pptx_gen
    parsed = parse_army_list(text)
    plan = build_slide_plan(parsed)
    rules = army_rules.fetch_all(parsed, distinct_units(plan), progress)
    warnings = list(parsed["warnings"]) + [f"Erreur : {e}" for e in rules["errors"]]
    cards_dir = Path(work_dir) / "cards"
    if cards_dir.exists():                                  # pas de restes d'une génération précédente dans le zip
        for old in cards_dir.glob("card-*.png"):
            old.unlink()
    slides = build_deck_slides(parsed, plan, rules, cards_dir, warnings)
    if images_only:
        import zipfile
        with zipfile.ZipFile(Path(out_path), "w", zipfile.ZIP_DEFLATED) as z:
            for i, sl in enumerate(slides, 1):
                z.write(sl["image"], f"{i:02d} - {_safe_name(sl['title'])}.png")
        count = len(slides)
    else:
        count = pptx_gen.build_picture_deck(slides, Path(out_path))
    return {"slide_count": count, "warnings": warnings,
            "summary": {"detachments": len(parsed["detachments"]), "units": len(distinct_units(plan)), "army": parsed["name"]}}
