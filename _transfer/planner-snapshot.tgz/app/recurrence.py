"""Recurrence rule engine: {"unit": "day|week|month|year", "interval": int,
"weekdays": [0-6] (Mon=0), "end_date": "YYYY-MM-DD"|null, "count": int|null}.

A task's recurrence also tracks how many occurrences have fired so "count"
can be enforced; callers pass the current occurrence number in.
"""
from __future__ import annotations
import calendar
from datetime import date, timedelta


def _add_months(d: date, months: int, day: int | None = None) -> date:
    """`day` is the series' own day-of-month (e.g. 31): a short month clips it
    but the next longer month gets it back, instead of drifting to 28."""
    month_index = d.month - 1 + months
    year = d.year + month_index // 12
    month = month_index % 12 + 1
    want = day or d.day
    return date(year, month, min(want, calendar.monthrange(year, month)[1]))


def _anchor(rule: dict):
    try:
        v = int(rule.get("anchor_day") or 0)
    except (TypeError, ValueError):
        return None
    return v if 1 <= v <= 31 else None


def next_occurrence(due: date, rule: dict, occurrence_no: int = 1):
    """Return the next due date after `due`, or None if the rule has ended."""
    if not rule:
        return None
    unit = rule.get("unit", "day")
    interval = max(1, int(rule.get("interval", 1)))
    count = rule.get("count")
    if count and occurrence_no >= int(count):
        return None

    if unit == "week" and rule.get("weekdays"):
        # "every N weeks on these days": the rest of the current week's chosen
        # days first, then the first chosen day N weeks after this week.
        weekdays = sorted({int(w) for w in rule["weekdays"] if 0 <= int(w) <= 6})
        if not weekdays:
            nxt = due + timedelta(weeks=interval)
        else:
            monday = due - timedelta(days=due.weekday())
            later = [w for w in weekdays if w > due.weekday()]
            nxt = monday + timedelta(days=later[0]) if later else \
                monday + timedelta(weeks=interval, days=weekdays[0])
    elif unit == "day":
        nxt = due + timedelta(days=interval)
    elif unit == "week":
        nxt = due + timedelta(weeks=interval)
    elif unit == "month":
        nxt = _add_months(due, interval, _anchor(rule))
    elif unit == "year":
        nxt = _add_months(due, interval * 12, _anchor(rule))
    else:
        return None

    end = rule.get("end_date")
    if end:
        try:
            end_d = date.fromisoformat(end)
            if nxt > end_d:
                return None
        except ValueError:
            pass
    return nxt


WEEKDAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def describe(rule: dict) -> str:
    if not rule:
        return ""
    unit = rule.get("unit", "day")
    interval = int(rule.get("interval", 1))
    plural = {"day": "days", "week": "weeks", "month": "months", "year": "years"}[unit]
    singular = {"day": "day", "week": "week", "month": "month", "year": "year"}[unit]
    base = f"Every {singular}" if interval == 1 else f"Every {interval} {plural}"
    if unit == "week" and rule.get("weekdays"):
        names = ", ".join(WEEKDAY_NAMES[i] for i in sorted(set(rule["weekdays"])))
        base += f" on {names}"
    return base
