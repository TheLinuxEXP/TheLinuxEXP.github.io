from __future__ import annotations
import ipaddress
import os
from pathlib import Path
from urllib.parse import urlsplit
from flask import Flask, abort, request

from .database import Database


def create_app(db_path: Path | None = None) -> Flask:
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config["JSON_SORT_KEYS"] = False
    app.db = Database(db_path)
    try:
        from . import trash
        trash.purge()                         # deleted attachments / contracts are kept for a while (see trash.py)
    except Exception:  # noqa: BLE001 - housekeeping must never stop the app from starting
        pass
    # Upload cap (attachments, pasted images, PDFs, contracts): an oversized request is refused with a 413 instead of
    # filling the disk. TASKPLANNER_MAX_UPLOAD_MB overrides the default (100 MB).
    try:
        max_mb = max(1, int(os.environ.get("TASKPLANNER_MAX_UPLOAD_MB") or 100))
    except ValueError:
        max_mb = 100
    app.config["MAX_CONTENT_LENGTH"] = max_mb * 1024 * 1024

    @app.errorhandler(413)
    def _too_large(_e):
        from flask import jsonify
        return jsonify({"error": f"File too large (limit {max_mb} MB; raise it with TASKPLANNER_MAX_UPLOAD_MB)."}), 413

    # LAN-only guard (TASKPLANNER_LAN_ONLY=1, set in docker-compose.yml): refuse
    # any request whose source address is not a private/loopback/link-local
    # one, so even if the port ever got exposed to the internet by mistake,
    # the app itself would answer 403. (Proxy headers are deliberately ignored.)
    if os.environ.get("TASKPLANNER_LAN_ONLY") == "1":
        @app.before_request
        def _lan_only():
            try:
                ip = ipaddress.ip_address(request.remote_addr or "")
                if getattr(ip, "ipv4_mapped", None):
                    ip = ip.ipv4_mapped
            except ValueError:
                abort(403)
            if not (ip.is_private or ip.is_loopback or ip.is_link_local):
                abort(403)

    # -- browser-facing protections ------------------------------------------
    # The planner has no login (it is a personal tool on localhost / a LAN), so
    # the browser itself must be stopped from being used against it:
    #  * Host check  -> defeats DNS rebinding (evil.example re-pointed at
    #    127.0.0.1 would otherwise be "same-origin" for the page's scripts).
    #  * Origin / Sec-Fetch-Site check on writes -> defeats cross-site forms
    #    and fetches (the API reads JSON with force=True, so a text/plain
    #    <form> from any website could otherwise create/delete things).
    # Non-browser clients (curl, the Plasma widget) send neither header and
    # are unaffected.
    extra_hosts = {h.strip().lower() for h in
                   os.environ.get("TASKPLANNER_ALLOWED_HOSTS", "").split(",") if h.strip()}

    def _host_ok(hostport: str) -> bool:
        host = hostport.strip().lower()
        if host.startswith("["):                       # [::1]:5000
            host = host[1:].split("]")[0]
        else:
            host = host.rsplit(":", 1)[0] if host.count(":") == 1 else host
        if not host:
            return False
        if host in extra_hosts or host == "localhost":
            return True
        try:
            ipaddress.ip_address(host)                 # IP literals can't be rebound
            return True
        except ValueError:
            pass
        if "." not in host:                            # "nas", "raspberrypi"...
            return True
        return host.endswith((".local", ".lan", ".home.arpa", ".internal", ".localdomain"))

    @app.before_request
    def _browser_guard():
        if not _host_ok(request.host or ""):
            abort(403, "Unexpected Host header (set TASKPLANNER_ALLOWED_HOSTS to allow it).")
        if request.method in ("GET", "HEAD", "OPTIONS"):
            return None
        site = request.headers.get("Sec-Fetch-Site")
        if site and site not in ("same-origin", "none"):
            abort(403, "Cross-site request refused.")
        origin = request.headers.get("Origin")
        if origin and origin != "null":
            if urlsplit(origin).netloc.lower() != (request.host or "").lower():
                abort(403, "Cross-origin request refused.")
        elif origin == "null":
            abort(403, "Cross-origin request refused.")
        return None

    # Login (identifier + password, session cookie): see app/auth.py. Registered after the browser guard above.
    from . import auth
    auth.install(app)

    _CSP = ("default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; img-src * data: blob:; "
            "media-src * data: blob:; font-src 'self' data:; connect-src 'self'; "
            "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")

    @app.after_request
    def _security_headers(resp):
        resp.headers.setdefault("Content-Security-Policy", _CSP)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        return resp

    # The page polls /api/tab/heartbeat and /api/timers/active all the time: keep them out of the server log (they were most of it).
    import logging

    class _QuietPolling(logging.Filter):
        def filter(self, record):
            msg = record.getMessage()
            return not ("/api/tab/" in msg or "/api/timers/active" in msg)
    logging.getLogger("werkzeug").addFilter(_QuietPolling())

    from .api import bp as api_bp
    app.register_blueprint(api_bp, url_prefix="/api")

    # Finances: the "Gestion fiscale EI" module (Flask blueprint under /fiscal).
    # Optional -- if the package or its dependencies are missing, the Task
    # Planner starts normally and simply hides the FINANCES sidebar section.
    app.config["FISCAL_ENABLED"] = False
    try:
        import gestion_ei_web
        gestion_ei_web.register(app, url_prefix="/fiscal")
        app.config["FISCAL_ENABLED"] = True
    except Exception as e:  # noqa: BLE001
        app.logger.warning("Finance module disabled: %s", e)

    from flask import render_template

    @app.get("/")
    def index():
        return render_template("index.html", fiscal=app.config["FISCAL_ENABLED"])

    return app
