"""PDF reading for the Warhammer "Generate PowerPoint" feature.

Goes through EVERY page of a codex PDF (clean vector PDFs and photographed /
scanned pages alike) and cuts out the pieces that become slides:

  * every unit datasheet                      -> one picture each
  * every detachment's "Detachment Rules"     -> one picture
  * every detachment's "Enhancements"         -> one picture
  * every detachment stratagem                -> pictures of up to 2 stratagems

How: each page is rendered to an image; text comes from the PDF's text layer
or, if there is none, from OCR. Blocks are found from their dark heading bars
(found by looking at the pixels), classified by OCR'ing each bar on its own
("DETACHMENT RULES", "ENHANCEMENTS", anything else = a stratagem title), and
datasheets from their "KEYWORDS / FACTION KEYWORDS" footer. Everything is
layout heuristics -- no ML -- tuned on the Adeptus Custodes codex.

Dependencies: only command-line tools from the distro (no extra Python
packages; Pillow already comes with python-pptx):
  poppler-utils   pdftotext / pdftoppm        (sudo apt install poppler-utils)
  tesseract-ocr   OCR for pages without text  (sudo apt install tesseract-ocr)
Set TASKPLANNER_OCR_LANG (e.g. "eng+fra") to OCR in other languages.
"""
from __future__ import annotations
import difflib
import os
import re
import shutil
import subprocess
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

from .ai import AIError

RENDER_DPI = 150            # photographed pages are ~150 dpi anyway
RENDER_SCALE = RENDER_DPI / 72.0   # PDF points -> pixels
MIN_NATIVE_CHARS = 25       # a page with less text than this is OCR'd
MAX_PAGES = 400
MAX_BLOCKS = 200
MAX_DOC_CHARS = 20000
STRATS_PER_SLIDE = 2


@dataclass
class Line:
    text: str
    x0: float
    y0: float   # top (pixels, origin top-left)
    x1: float
    y1: float   # bottom

    @property
    def h(self):
        return self.y1 - self.y0

    @property
    def cx(self):
        return (self.x0 + self.x1) / 2

    @property
    def cy(self):
        return (self.y0 + self.y1) / 2


@dataclass
class Block:
    """One picture-worthy chunk of the PDF: becomes one slide."""
    kind: str            # "datasheet" | "detachment_rule" | "enhancements" | "stratagems"
    title: str           # unit name or detachment name (best guess)
    page: int            # 1-based (first page for multi-page groups)
    path: Path           # cropped image (JPEG)
    text: str = ""       # text found inside the crop (text layer or OCR)
    detachment: str | None = None
    page_top: str = ""   # extra hints for the AI to fix a wrong title guess


@dataclass
class PdfResult:
    text: str
    blocks: list = field(default_factory=list)
    ocr_pages: int = 0
    page_count: int = 0


# ------------------------------------------------------------------ tools
_POPPLER_HINT = "Install poppler (Debian/Ubuntu: `sudo apt install poppler-utils`, Arch: `sudo pacman -S poppler`, Fedora: `sudo dnf install poppler-utils`)."
_TESS_HINT = ("This PDF needs OCR. Install Tesseract (Debian/Ubuntu: `sudo apt install tesseract-ocr`, "
              "Arch: `sudo pacman -S tesseract tesseract-data-eng`, Fedora: `sudo dnf install tesseract`).")


def _tool(name, hint):
    path = shutil.which(name)
    if not path:
        raise AIError(f"'{name}' isn't installed. {hint}")
    return path


def _run(cmd, timeout=240):
    env = dict(os.environ, OMP_THREAD_LIMIT="1")   # tesseract: one thread per process, we parallelise pages
    try:
        return subprocess.run(cmd, capture_output=True, timeout=timeout, check=False, env=env)
    except subprocess.TimeoutExpired:
        raise AIError(f"'{cmd[0]}' took too long on this PDF.")


def _ocr_raw(image_path: Path, psm: int, fmt: str = "tsv") -> str:
    exe = _tool("tesseract", _TESS_HINT)
    lang = os.environ.get("TASKPLANNER_OCR_LANG", "eng")
    cmd = [exe, str(image_path), "stdout", "-l", lang, "--psm", str(psm)] + ([fmt] if fmt else [])
    proc = _run(cmd)
    if proc.returncode != 0 and lang != "eng":
        cmd[cmd.index(lang)] = "eng"
        proc = _run(cmd)
    if proc.returncode != 0:
        err = proc.stderr.decode("utf-8", "replace").strip().splitlines()
        raise AIError("OCR failed: " + (err[-1] if err else "tesseract error")
                      + ("" if "data" not in " ".join(err).lower() else
                         " (the Tesseract language data may be missing -- install e.g. tesseract-ocr-eng)"))
    return proc.stdout.decode("utf-8", "replace")


def _ocr_lines(image_path: Path, psm: int = 3) -> list[Line]:
    """OCR a page image with the tesseract CLI -> text lines with pixel boxes."""
    groups: dict[tuple, list] = {}
    for row in _ocr_raw(image_path, psm).splitlines()[1:]:
        cols = row.split("\t")
        if len(cols) < 12 or cols[0] != "5":
            continue
        word = cols[11].strip()
        try:
            conf = float(cols[10])
            l, t, w, h = (int(cols[i]) for i in (6, 7, 8, 9))
        except ValueError:
            continue
        if not word or conf < 20:
            continue
        groups.setdefault((cols[2], cols[3], cols[4]), []).append((l, t, l + w, t + h, word))
    lines = []
    for words in groups.values():
        words.sort(key=lambda w: w[0])
        lines.append(Line(" ".join(w[4] for w in words),
                          min(w[0] for w in words), min(w[1] for w in words),
                          max(w[2] for w in words), max(w[3] for w in words)))
    lines.sort(key=lambda ln: (ln.y0, ln.x0))
    return lines


def _ocr_page(image_path: Path, tmp: Path, pno: int) -> list[Line]:
    """OCR a whole page twice -- as is, and inverted (white-on-dark headings,
    stratagem titles and datasheet banners are only read in the inverted
    pass) -- and merge the two sets of lines."""
    from PIL import Image, ImageOps
    lines = _ocr_lines(image_path)
    inv_path = tmp / f"inv-{pno}.png"
    with Image.open(image_path) as im:
        ImageOps.invert(im.convert("L")).save(inv_path)
    extra = _ocr_lines(inv_path)
    for ln in extra:
        if len(_letters(ln.text)) < 3:
            continue
        if any(o.x0 - 3 <= ln.cx <= o.x1 + 3 and o.y0 - 3 <= ln.cy <= o.y1 + 3 for o in lines):
            continue
        lines.append(ln)
    lines.sort(key=lambda l: (l.y0, l.x0))
    return lines


def _ocr_text_of_crop(image, box, tmp: Path, tag: str, psm: int = 7, invert: bool = True, upscale: int = 2) -> str:
    """OCR one small region (a heading bar, a title) on its own."""
    from PIL import ImageOps
    x0, y0, x1, y1 = (int(v) for v in box)
    pad = 4
    crop = image.crop((max(0, x0 - pad), max(0, y0 - pad), min(image.width, x1 + pad), min(image.height, y1 + pad))).convert("L")
    if invert:
        crop = ImageOps.invert(crop)
    crop = crop.resize((crop.width * upscale, crop.height * upscale))
    path = tmp / f"crop-{tag}.png"
    crop.save(path)
    return " ".join(_ocr_raw(path, psm, fmt="").split())


def _native_pages(pdf_path: Path, last_page: int):
    """[(width_px, height_px, [Line, ...])] per page from poppler's text layer."""
    exe = _tool("pdftotext", _POPPLER_HINT)
    proc = _run([exe, "-bbox-layout", "-l", str(last_page), str(pdf_path), "-"], timeout=300)
    if proc.returncode != 0:
        raise AIError("Couldn't read that PDF: " + proc.stderr.decode("utf-8", "replace").strip()[:200])
    xml = re.sub(rb"<!DOCTYPE[^>]*>", b"", proc.stdout, count=1)
    try:
        root = ET.fromstring(xml)
    except ET.ParseError as e:
        raise AIError(f"Couldn't read that PDF's text: {e}")
    ns = "{http://www.w3.org/1999/xhtml}"
    pages = []
    for page in root.iter(ns + "page"):
        lines = []
        for ln in page.iter(ns + "line"):
            txt = " ".join((w.text or "") for w in ln.iter(ns + "word")).strip()
            if txt:
                lines.append(Line(txt, float(ln.get("xMin")) * RENDER_SCALE, float(ln.get("yMin")) * RENDER_SCALE,
                                  float(ln.get("xMax")) * RENDER_SCALE, float(ln.get("yMax")) * RENDER_SCALE))
        lines.sort(key=lambda l: (l.y0, l.x0))
        pages.append((float(page.get("width")) * RENDER_SCALE, float(page.get("height")) * RENDER_SCALE, lines))
    return pages


def _render_pages(pdf_path: Path, tmp: Path, count: int) -> dict[int, Path]:
    exe = _tool("pdftoppm", _POPPLER_HINT)
    proc = _run([exe, "-r", str(RENDER_DPI), "-l", str(count), "-png", str(pdf_path), str(tmp / "pg")], timeout=600)
    if proc.returncode != 0:
        raise AIError("Couldn't render that PDF's pages.")
    out = {}
    for f in tmp.glob("pg-*.png"):
        m = re.search(r"pg-(\d+)\.png$", f.name)
        if m:
            out[int(m.group(1))] = f
    return out


# ------------------------------------------------------------ text helpers
def _letters(text: str) -> str:
    t = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Z]", "", t.upper())


def _like(text: str, target: str, cutoff: float = 0.78) -> bool:
    """OCR-tolerant comparison of a whole line against a heading ("DETACHNENT RULES")."""
    a = _letters(text)
    return bool(a) and difflib.SequenceMatcher(None, a, target).ratio() >= cutoff


def _upper_ratio(s: str) -> float:
    letters = [c for c in s if c.isalpha()]
    return sum(c.isupper() for c in letters) / len(letters) if letters else 0.0


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-") or "block"


def _text_in_box(lines: list[Line], box) -> str:
    x0, y0, x1, y1 = box
    inside = [ln for ln in lines if y0 <= ln.cy <= y1 and x0 <= ln.cx <= x1]
    inside.sort(key=lambda l: (round(l.y0 / max(1.0, l.h * 0.6)), l.x0))
    return "\n".join(ln.text for ln in inside)


def _text_chain_bottom(lines: list[Line], x0, x1, top, page_h, stop_y):
    """Bottom of the contiguous run of text lines below `top` inside [x0,x1]:
    stops at a big vertical gap (so page numbers / footers aren't swallowed)."""
    inside = sorted((ln for ln in lines
                     if ln.y0 >= top - 2 and x0 <= ln.cx <= x1 and ln.y1 <= page_h * 0.95 and ln.y0 < stop_y
                     and len(ln.text.strip()) >= 3), key=lambda l: l.y0)
    if not inside:
        return top
    hs = sorted(l.h for l in inside)
    gap_limit = max(hs[len(hs) // 2] * 3.2, page_h * 0.03)
    bottom = inside[0].y1
    for ln in inside[1:]:
        if ln.y0 - bottom > gap_limit:
            break
        bottom = max(bottom, ln.y1)
    return bottom


# ------------------------------------------------------- pixel analysis
def find_bars(image, factor=3, dark=95, min_w=135, gap=4, hmin=6, hmax=26):
    """Dark horizontal bars (heading / stratagem title bars) and big dark
    regions (page banners), by scanning a shrunken greyscale copy for runs of
    dark pixels. Returns (bars, big) as full-resolution (x0,y0,x1,y1) boxes."""
    from PIL import Image
    g = image.convert("L")
    w, h = max(1, g.width // factor), max(1, g.height // factor)
    px = list(g.resize((w, h), Image.BOX).getdata())
    active, done = [], []
    for y in range(h):
        row = px[y * w:(y + 1) * w]
        runs, start, last = [], None, None
        for x, v in enumerate(row):
            if v < dark:
                if start is None:
                    start = x
                elif x - last > gap + 1:
                    if last - start + 1 >= min_w // factor:
                        runs.append((start, last))
                    start = x
                last = x
        if start is not None and last - start + 1 >= min_w // factor:
            runs.append((start, last))
        new_active = []
        for r in runs:
            match = None
            for a in active:
                if min(r[1], a[1]) - max(r[0], a[0]) > 0.7 * min(r[1] - r[0], a[1] - a[0]):
                    match = a
                    break
            if match is not None:
                active.remove(match)
                match[0], match[1], match[3] = min(match[0], r[0]), max(match[1], r[1]), y
                new_active.append(match)
            else:
                new_active.append([r[0], r[1], y, y])
        done += active
        active = new_active
    done += active
    full = lambda a: (a[0] * factor, a[2] * factor, (a[1] + 1) * factor, (a[3] + 1) * factor)  # noqa: E731
    bars = [full(a) for a in done if hmin <= a[3] - a[2] + 1 <= hmax]
    big = [full(a) for a in done if a[3] - a[2] + 1 > hmax]
    return bars, big


def _brightness(gray_px, width, height, x, y):
    x = max(0, min(width - 1, int(x)))
    y = max(0, min(height - 1, int(y)))
    return gray_px[y * width + x]


def _scan(gray, x, y, dx, dy, limit, bright=115, run_needed=4):
    """Walk from (x,y) in direction (dx,dy) until `run_needed` consecutive
    bright pixels; returns the coordinate where the dark area ended."""
    px, w, h = gray
    run = 0
    steps = 0
    while steps < limit:
        if _brightness(px, w, h, x, y) > bright:
            run += 1
            if run >= run_needed:
                return (x - dx * run_needed, y - dy * run_needed)
        else:
            run = 0
        x += dx
        y += dy
        steps += 1
        if not (0 <= x < w and 0 <= y < h):
            break
    return (min(max(x, 0), w - 1), min(max(y, 0), h - 1))


def _gray(image):
    g = image.convert("L")
    return (list(g.getdata()), g.width, g.height)


# --------------------------------------------------------------- datasheets
def _find_footers(lines: list[Line], bars=(), page_w: float = 0, page_h: float = 0) -> list[Line]:
    """One merged footer row per datasheet: the 'KEYWORDS: ...' text on the
    left plus the dark 'FACTION KEYWORDS' box on the right (found from its
    OCR text and/or, when OCR misses it, from its dark box)."""
    cands = []
    for ln in lines:
        letters = _letters(ln.text)
        if ("KEYWORD" in letters and len(letters) < 90) or letters.startswith("ACTIONKEY") \
                or (len(letters) <= 20 and difflib.SequenceMatcher(None, letters, "FACTIONKEYWORDS").ratio() >= 0.8) \
                or (letters in ("FACTION", "ADEPTUSCUSTODES") and ln.cx > (page_w or 1e9) * 0.45) \
                or (len(letters) <= 17 and difflib.SequenceMatcher(None, letters, "ADEPTUSCUSTODES").ratio() >= 0.85 and ln.cx > (page_w or 1e9) * 0.45):
            cands.append(ln)
    cands.sort(key=lambda l: (l.y0, l.x0))
    rows: list[list[Line]] = []
    for ln in cands:
        for row in rows:
            ref = row[0]
            if abs(ref.cy - ln.cy) < max(ref.h, ln.h) * 2.6:
                row.append(ln)
                break
        else:
            rows.append([ln])
    footers = []
    for row in rows:
        x0, x1 = min(l.x0 for l in row), max(l.x1 for l in row)
        y0, y1 = min(l.y0 for l in row), max(l.y1 for l in row)
        footers.append(Line("footer", x0, y0, x1, y1))
    # dark FACTION KEYWORDS boxes seen as bars: tall-ish, right-aligned, ~1/3 of the page wide
    for bx0, by0, bx1, by1 in bars:
        if page_w and by1 - by0 >= 45 and page_w * 0.25 <= bx1 - bx0 <= page_w * 0.56 and bx1 >= page_w * 0.7 \
                and page_h * 0.12 < by0 and by1 < page_h * 0.97:
            for f in footers:
                if abs((f.y0 + f.y1) / 2 - (by0 + by1) / 2) < 70:
                    f.x1, f.y1, f.y0 = max(f.x1, bx1), max(f.y1, by1), min(f.y0, by0)
                    break
            else:
                footers.append(Line("footer", bx0, by0, bx1, by1))
    return sorted(footers, key=lambda f: f.y0)


_NOT_NAME = ("RANGED", "MELEE", "ABILITIES", "KEYWORD", "WEAPONS", "COMPOSITION", "WARGEAR", "INVULNERABLE", "CORE", "ARMY")


def _guess_unit_name(lines: list[Line], x0, y0, x1, y1):
    best, best_h = None, 0
    for ln in lines:
        if ln.y0 < y0 or ln.y1 > y1 or ln.cx < x0 or ln.cx > x1:
            continue
        txt = re.sub(r"[^A-Za-z0-9'’ \-]", "", ln.text).strip()
        up = _letters(txt)
        if len(up) < 4 or _upper_ratio(txt) < 0.75 or any(w in up for w in _NOT_NAME):
            continue
        if ln.h > best_h:
            best, best_h = txt, ln.h
    return best


def _detect_datasheets(image, gray, lines: list[Line], bars, page_w, page_h):
    """[(name_or_None, (x0,y0,x1,y1))] datasheet boxes on one page."""
    footers = _find_footers(lines, bars, page_w, page_h)
    boxes = []
    prev_bottom = 0.0
    for f in footers:
        h = max(f.h, 18)
        # a footer found from its dark box already ends exactly at the datasheet's bottom
        bottom = min(page_h, f.y1 + (6 if f.h >= 45 else h * 0.9 + 6))
        region_top = prev_bottom + 4
        # --- header banner: the unit's name line, then its dark band upward
        name_line = None
        best_h = 0
        for ln in lines:
            if region_top - 4 <= ln.y0 and ln.y1 < f.y0 - (f.y0 - region_top) * 0.35 and ln.x0 < page_w * 0.6:
                txt = re.sub(r"[^A-Za-z0-9'’ \-]", "", ln.text).strip()
                up = _letters(txt)
                if len(up) >= 4 and _upper_ratio(txt) >= 0.75 and not any(w in up for w in _NOT_NAME) and ln.h > best_h:
                    name_line, best_h = ln, ln.h
        top = region_top
        left = max(0.0, f.x0 - 18)
        if name_line is not None:
            xs = [name_line.x0 + (name_line.x1 - name_line.x0) * k for k in (0.2, 0.5, 0.8)]
            ups = [_scan(gray, x, name_line.y0 - 2, 0, -1, int(name_line.h * 4))[1] for x in xs]
            top = max(region_top, min(ups) - 3)
            lx = _scan(gray, name_line.x0 - 3, name_line.cy, -1, 0, 120)[0]
            left = min(left, lx - 6)
        # --- right edge: the dark FACTION KEYWORDS box
        right = _scan(gray, f.x1 + 4, (f.y0 + f.y1) / 2, 1, 0, int(page_w * 0.25))[0] + 6
        if right < f.x1 + 20:
            right = min(page_w, f.x1 + page_w * 0.05)
        right = min(page_w, right)
        if bottom - top > page_h * 0.1 and right - left > page_w * 0.3:
            name = _guess_unit_name(lines, left, top, right, top + (bottom - top) * 0.45)
            boxes.append((name, (max(0.0, left), max(0.0, top), right, bottom)))
        prev_bottom = bottom
    return boxes


# ------------------------------------------------------ detachment sections
@dataclass
class _Bar:
    kind: str          # "rule" | "enh" | "strat"
    box: tuple         # (x0, y0, x1, y1) of the heading / title+sub-banner bar itself
    text: str = ""
    det: str = ""      # strat: detachment name read from its "<NAME> STRATAGEM" sub-banner


_STRAT_SUB = re.compile(r"^\W*(.{3,60}?)\s+STRATAGE[MHN]?\W*$", re.I)


def _row_extent(gray, x_from_left, x_from_right, y, limit):
    """Left/right edge of the dark bar crossing row y, walking out from the text."""
    left = _scan(gray, x_from_left, y, -1, 0, int(limit), bright=125, run_needed=10)[0]
    right = _scan(gray, x_from_right, y, 1, 0, int(limit), bright=125, run_needed=10)[0]
    return left, right


def _find_anchors(lines: list[Line], bars, gray, page_w, page_h) -> list[_Bar]:
    """Headings found from their (OCR'd) text: DETACHMENT RULES, ENHANCEMENTS,
    and one '<NAME> STRATAGEM' sub-banner per stratagem; each turned into the
    box of the dark bar it sits on (from the pixel bars when one covers it,
    else estimated from the text and the colour around it)."""
    out: list[_Bar] = []
    for ln in lines:
        text = ln.text.strip()
        letters = _letters(text)
        kind, det = None, ""
        if _like(text, "DETACHMENTRULES") or _like(re.sub(r"^\W*\w{0,2}\s+(?=DETACH)", "", text.upper()), "DETACHMENTRULES"):
            kind = "rule"
        elif _like(text, "ENHANCEMENTS") or ("ENHANCEMENT" in letters and len(letters) < 18):
            kind = "enh"
        else:
            m = _STRAT_SUB.match(text)
            if m and _upper_ratio(m.group(1)) >= 0.7 and len(letters) >= 12 and ln.h < 40:
                kind, det = "strat", m.group(1).strip()
        if not kind:
            continue
        h = max(ln.h, 17)
        cover = next((b for b in bars if b[0] - 6 <= ln.cx <= b[2] + 6 and b[1] - 6 <= ln.cy <= b[3] + 6
                      and b[2] - b[0] >= page_w * 0.18), None)
        if cover is not None:
            box = tuple(float(v) for v in cover)
        elif kind == "strat":
            y_title = ln.y0 - h * 1.1
            x0, x1 = _row_extent(gray, ln.x0 - 4, ln.x1 + 4, y_title, page_w * 0.45)
            box = (float(x0), ln.y0 - h * 2.1 - 4, float(x1), ln.y1 + h * 0.5)
        else:
            x0, x1 = _row_extent(gray, ln.x0 - 4, ln.x1 + 4, ln.cy, page_w * 0.45)
            box = (float(x0), ln.y0 - h * 0.55, float(x1), ln.y1 + h * 0.55)
        if kind == "strat":
            box = (box[0], min(box[1], ln.y0 - h * 1.9), box[2], max(box[3], ln.y1 + h * 0.3))
        if box[2] - box[0] < page_w * 0.15:
            continue
        out.append(_Bar(kind, box, text, det))
    # drop duplicates (the same anchor read twice, e.g. by both OCR passes)
    uniq: list[_Bar] = []
    for a in sorted(out, key=lambda b: b.box[1]):
        if any(a.kind == u.kind and abs(a.box[1] - u.box[1]) < 30 and abs(a.box[0] - u.box[0]) < 60 for u in uniq):
            continue
        uniq.append(a)
    return uniq


def _section_boxes(bars: list[_Bar], lines: list[Line], page_w, page_h):
    """[(bar, box)] -- the block under each bar, down to the next bar in the
    same column or the end of the column's text."""
    out = []
    for a in bars:
        x0, y0, x1, y1 = a.box
        stop = page_h
        for b in bars:
            if b is a or b.box[1] <= y0 + 10:
                continue
            bx0, bx1 = b.box[0], b.box[2]
            if min(x1, bx1) - max(x0, bx0) > 0.5 * min(x1 - x0, bx1 - bx0):
                stop = min(stop, b.box[1] - 6)
        chain = _text_chain_bottom(lines, x0 - 10, x1 + 10, y1, page_h, stop)
        margin = page_h * (0.022 if a.kind == "strat" else 0.012)
        bottom = min(stop, max(chain + margin, y1 + page_h * 0.05))
        # text sticking out of the bar's width still belongs to the block
        bx0, bx1 = x0, x1
        for ln in lines:
            if y0 <= ln.cy <= bottom and bx0 <= ln.cx <= bx1:
                x0, x1 = min(x0, ln.x0 - 4), max(x1, min(ln.x1 + 4, bx1 + page_w * 0.03))
        out.append((a, (max(0.0, x0 - 6), max(0.0, y0 - 6), min(page_w, x1 + 6), bottom)))
    return out


def _banner_name(image, big, tmp: Path, page_no: int, page_w, page_h):
    """The big title at the top of a detachment page (white on a dark banner)."""
    from PIL import ImageOps
    region = (0, 0, int(page_w * 0.8), int(page_h * 0.3))
    crop = image.crop(region).convert("L")
    best, best_h = None, 0
    for tag, img in (("n", crop), ("i", ImageOps.invert(crop))):
        path = tmp / f"banner-{page_no}-{tag}.png"
        img.save(path)
        try:
            lines = _ocr_lines(path, psm=6)
        except AIError:
            continue
        for ln in lines:
            txt = ln.text.strip()
            letters = _letters(txt)
            if len(letters) < 4 or _upper_ratio(txt) < 0.8 or letters.startswith("UNIQUE") or letters.startswith("THE") or ln.h < 36:
                continue
            if ln.h > best_h:
                best, best_h = txt, ln.h
    return best


def _same_name(a, b):
    return bool(a) and bool(b) and difflib.SequenceMatcher(None, _letters(a), _letters(b)).ratio() >= 0.8


def _stack(images, gap=14):
    """Stack crops vertically (scaled to a common width) into one picture."""
    from PIL import Image
    width = sorted(im.width for im in images)[len(images) // 2]
    scaled = [im if im.width == width else im.resize((width, max(1, round(im.height * width / im.width)))) for im in images]
    out = Image.new("RGB", (width, sum(i.height for i in scaled) + gap * (len(scaled) - 1)), (38, 38, 38))
    y = 0
    for im in scaled:
        out.paste(im, (0, y))
        y += im.height + gap
    return out



# ---------------------------------------------------- vision (photographed pages)
_VISION_PROMPT = """Read the image file {path} with the Read tool. It is a photo/scan of ONE page of a Warhammer 40,000 codex
({w}x{h} pixels; it may be tilted or shaded, and a sliver of the neighbouring page can show at an edge).

Find the blocks below and give each one's TIGHT pixel box [x0,y0,x1,y1] in THIS image's coordinates:
- "rule": the whole "DETACHMENT RULES" section (its dark heading bar + all its text, down to just before the next section)
- "enhancements": the whole "ENHANCEMENTS" section (dark heading bar + all enhancements, to the end of their text)
- "stratagem": EACH stratagem separately (dark title bar with the CP cost on the right, the coloured sub-banner and the
  whole box with WHEN/TARGET/EFFECT, down to the bottom of the box). "title" = its name.
- "datasheet": EACH unit datasheet card separately, from the top of its dark banner with the unit name, through the stats,
  weapons, abilities, down to the bottom of the KEYWORDS / FACTION KEYWORDS footer (include that footer). "title" = unit name.
Ignore photos of miniatures, page numbers, margins and the neighbouring page. Include every block fully (all the text) with
a small margin. "detachment_name" = the detachment's name as printed in the big banner title at the top of a detachment
page (on a page without a banner, take it from the "<NAME> STRATAGEM" sub-banners); null for datasheet pages.
"page_type" = "detachment" (rules / enhancements / stratagems), "datasheets", or "other".

Reply with ONLY JSON, no commentary:
{{"page_type": "...", "detachment_name": "..." or null,
  "blocks": [{{"kind": "rule|enhancements|stratagem|datasheet", "title": "...", "box": [x0, y0, x1, y1]}}]}}"""


def _vision_one(page_no: int, image_path: Path, tmp: Path):
    """Ask Claude (CLI, reads the image) for the blocks of one page. Returns the parsed
    dict with boxes mapped back to the full-resolution image, or None on failure."""
    from PIL import Image
    from .ai import call_claude, extract_json_object
    with Image.open(image_path) as im:
        ow, oh = im.size
        scale = min(1.0, 1480.0 / max(ow, oh))
        small = im.convert("RGB").resize((max(1, int(ow * scale)), max(1, int(oh * scale))))
    small_path = tmp / f"vision-{page_no}.png"
    small.save(small_path)
    prompt = _VISION_PROMPT.format(path=small_path, w=small.width, h=small.height)
    data = None
    for attempt in range(2):
        try:
            data = extract_json_object(call_claude(prompt, system="You locate blocks on photographed book pages. Reply with strict JSON only.",
                                                   read_dirs=[tmp]))
            break
        except AIError:
            if attempt == 1:
                return None
    blocks = []
    for b in (data or {}).get("blocks") or []:
        try:
            x0, y0, x1, y1 = (float(v) / scale for v in b["box"])
        except (KeyError, TypeError, ValueError):
            continue
        x0, x1 = sorted((max(0.0, x0), min(float(ow), x1)))
        y0, y1 = sorted((max(0.0, y0), min(float(oh), y1)))
        if x1 - x0 < 80 or y1 - y0 < 40:
            continue
        kind = str(b.get("kind") or "").lower()
        if kind not in ("rule", "enhancements", "stratagem", "datasheet"):
            continue
        # a little margin: the pages are tilted, so tight boxes clip corner letters
        pad_x, pad_y = 16, 10
        blocks.append({"kind": {"enhancements": "enh", "stratagem": "strat"}.get(kind, kind),
                       "title": str(b.get("title") or "").strip(),
                       "box": (max(0.0, x0 - pad_x), max(0.0, y0 - pad_y), min(float(ow), x1 + pad_x), min(float(oh), y1 + pad_y))})
    return {"page_type": (data or {}).get("page_type"), "det": ((data or {}).get("detachment_name") or None), "blocks": blocks,
            "size": (ow, oh)}


def _vision_scan(images: dict, n_pages: int, tmp: Path, progress=None):
    """Every page through Claude's vision (3 pages at a time). Returns the `raw` block list."""
    raw = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(lambda p: _vision_one(p, images[p], tmp), range(1, n_pages + 1)))
    failed = sum(1 for r in results if r is None)
    if failed == n_pages:
        raise AIError("Couldn't read the PDF pages with Claude (is the 'claude' command logged in?).")
    from PIL import Image
    for pno, res in enumerate(results, 1):
        if not res or res["page_type"] == "other" or not res["blocks"]:
            continue
        image = Image.open(images[pno]).convert("RGB")
        pw = float(image.width)
        det = res["det"]
        for blk in sorted(res["blocks"], key=lambda b: (round(b["box"][0] / (pw * 0.4)) if b["kind"] != "datasheet" else 0, b["box"][1])):
            raw.append({"kind": blk["kind"], "page": pno, "title": blk["title"] or None, "box": blk["box"], "image": image,
                        "text": "", "det": det if blk["kind"] != "datasheet" else None,
                        "page_top": f"{det or ''} | " + blk["title"]})
    return raw

# ------------------------------------------------------------------ driver
def process_pdf(source, out_dir: Path, force_ocr: bool = False) -> PdfResult:
    """source: path or file-like (bytes). Goes through every page; returns the
    document text and the picture blocks (datasheets, detachment rules,
    enhancements, stratagems) cropped into out_dir as JPEGs."""
    try:
        from PIL import Image
    except ImportError:
        raise AIError("The 'Pillow' package isn't installed (it normally comes with python-pptx). "
                      "Install your distro's python-pillow package.")
    _tool("pdftotext", _POPPLER_HINT)

    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("*.jpg"):
        old.unlink()

    with tempfile.TemporaryDirectory(prefix="tp-pdf-") as tmpdir:
        tmp = Path(tmpdir)
        pdf_path = tmp / "in.pdf"
        data = source.read() if hasattr(source, "read") else Path(source).read_bytes()
        pdf_path.write_bytes(data)

        native = _native_pages(pdf_path, MAX_PAGES)
        if not native:
            raise AIError("Couldn't read that PDF (no pages found).")
        n_pages = len(native)
        images = _render_pages(pdf_path, tmp, n_pages)

        # Photographed / scanned pages (no text layer): let Claude look at each page --
        # far more reliable on tilted, shaded photos than OCR + pixel heuristics.
        text_pages = sum(1 for _, _, ls in native if sum(len(l.text.replace(" ", "")) for l in ls) >= MIN_NATIVE_CHARS)
        from .ai import vision_available
        if vision_available() and (force_ocr or text_pages < n_pages * 0.5):
            raw = _vision_scan(images, n_pages, tmp)
            result = _assemble(raw, {}, out_dir, n_pages, n_pages)
            return result

        # ---- text for every page: the text layer, or OCR (pages in parallel)
        page_lines: dict[int, list[Line]] = {}
        need_ocr = []
        for pno, (pw, ph, lines) in enumerate(native, 1):
            chars = sum(len(l.text.replace(" ", "")) for l in lines)
            if force_ocr or chars < MIN_NATIVE_CHARS:
                need_ocr.append(pno)
            else:
                page_lines[pno] = lines
        if need_ocr:
            _tool("tesseract", _TESS_HINT)
            workers = max(1, min(4, os.cpu_count() or 2))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for pno, lines in zip(need_ocr, pool.map(lambda p: _ocr_page(images[p], tmp, p), need_ocr)):
                    page_lines[pno] = lines

        # ---- find the blocks on each page
        raw = []   # dicts in page order
        for pno in range(1, n_pages + 1):
            image = Image.open(images[pno]).convert("RGB")
            lines = page_lines.get(pno, [])
            pw, ph = float(image.width), float(image.height)
            gray = _gray(image)
            bars, big = find_bars(image)
            anchors = _find_anchors(lines, bars, gray, pw, ph)
            if anchors:
                allnames = [a.det for a in anchors if a.det]
                det = max(set(allnames), key=allnames.count).title() if allnames else None
                has_rule = any(a.kind == "rule" for a in anchors)
                banner = _banner_name(image, big, tmp, pno, pw, ph) if (has_rule or not det) else None
                if banner and det and not _same_name(banner, det):
                    banner = None          # the sub-banner text is the more reliable of the two
                for bar, box in sorted(_section_boxes(anchors, lines, pw, ph),
                                       key=lambda t: (round(t[0].box[0] / (pw * 0.4)), t[0].box[1])):
                    raw.append({"kind": bar.kind, "page": pno, "box": box, "title": bar.text, "image": image,
                                "text": _text_in_box(lines, box), "det": det or (banner.title() if banner else None),
                                "page_top": f"{banner or ''} | " + " / ".join(allnames[:2])})
                continue
            for name, box in _detect_datasheets(image, gray, lines, bars, pw, ph):
                raw.append({"kind": "datasheet", "page": pno, "title": name, "box": box,
                            "text": _text_in_box(lines, box), "image": image})

    # ---- everything below needs only `raw` (images are still in memory)
    return _assemble(raw, page_lines, out_dir, n_pages, len(need_ocr))


def _assemble(raw, page_lines, out_dir: Path, n_pages: int, ocr_pages: int = 0) -> PdfResult:
    result = PdfResult(text="", page_count=n_pages, ocr_pages=ocr_pages)
    blocks: list[Block] = []
    counter = {"n": 0}

    def save(img, label):
        counter["n"] += 1
        path = out_dir / f"{counter['n']:03d}-{_slug(label)[:40]}.jpg"
        img.convert("RGB").save(path, "JPEG", quality=90)
        return path

    # detachment names: fill gaps from neighbouring pages (e.g. the rule page
    # has a photo banner, the stratagems page names it in its sub-banners)
    page_det: dict[int, str] = {}
    for r in raw:
        if r["kind"] != "datasheet" and r.get("det"):
            page_det.setdefault(r["page"], r["det"])
    det_pages = sorted({r["page"] for r in raw if r["kind"] != "datasheet"})
    for p in det_pages:
        if p not in page_det:
            nxt = next((q for q in det_pages if q > p and q in page_det), None)
            prv = next((q for q in reversed(det_pages) if q < p and q in page_det), None)
            if nxt is not None and nxt == p + 1:
                page_det[p] = page_det[nxt]
            elif prv is not None:
                page_det[p] = page_det[prv]
    # a rule page's own banner guess beats a neighbour's name
    pending: list[tuple] = []          # (detachment, image, text, page)
    current = None

    def flush():
        nonlocal pending
        by_det: dict = {}
        order = []
        for det, img, text, page in pending:
            if det not in by_det:
                by_det[det] = []
                order.append(det)
            by_det[det].append((img, text, page))
        for det in order:
            items = by_det[det]
            for i in range(0, len(items), STRATS_PER_SLIDE):
                group = items[i:i + STRATS_PER_SLIDE]
                img = _stack([g[0] for g in group]) if len(group) > 1 else group[0][0]
                blocks.append(Block("stratagems", det or "Stratagèmes", group[0][2], save(img, f"strat-{det}"),
                                    "\n\n".join(g[1] for g in group), det))
        pending = []

    for r in raw:
        crop = r["image"].crop(tuple(int(v) for v in r["box"]))
        if r["kind"] == "datasheet":
            flush()
            name = r["title"] or f"Datasheet p{r['page']}"
            blocks.append(Block("datasheet", name.title() if name.isupper() else name, r["page"],
                                save(crop, name), r["text"], None, ""))
            continue
        det = r.get("det") or page_det.get(r["page"])
        if current is not None and det and not _same_name(det, current):
            flush()
        if det:
            current = det
        det = current or det
        if r["kind"] == "strat":
            pending.append((det, crop, r["text"], r["page"]))
        elif r["kind"] == "rule":
            flush()
            blocks.append(Block("detachment_rule", det or "Règle de détachement", r["page"],
                                save(crop, f"rule-{det}"), r["text"], det, r.get("page_top", "")))
        else:
            blocks.append(Block("enhancements", det or "Améliorations", r["page"],
                                save(crop, f"enh-{det}"), r["text"], det, r.get("page_top", "")))
    flush()

    result.blocks = blocks[:MAX_BLOCKS]
    result.text = "\n\n".join("\n".join(l.text for l in page_lines.get(p, [])) for p in range(1, n_pages + 1))[:20000]
    return result
