"""Règles et fiches techniques de « List to PPT » : demandées à Claude (Claude Code CLI, avec WebSearch / WebFetch) qui les lit
sur Wahapedia (https://wahapedia.ru/wh40k11ed/) et les rend en JSON français. Un appel par élément (détachement,
dispositions, unité), en parallèle, avec un cache disque (30 jours) : refaire un PPT pour la même liste est quasi instantané.

Rien n'est inventé : si une page est introuvable, Claude le dit (`found: false`) et la slide est faite à partir de la seule
liste, avec la mention « données non trouvées »."""
from __future__ import annotations
import hashlib
import re
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .ai import AIError, call_claude, extract_json_object

WAHAPEDIA = os.environ.get("TASKPLANNER_WAHAPEDIA", "https://wahapedia.ru/wh40k11ed/").rstrip("/") + "/"
FALLBACK_WAHAPEDIA = os.environ.get("TASKPLANNER_WAHAPEDIA_FALLBACK", "https://wahapedia.ru/wh40k10ed/").rstrip("/") + "/"
CACHE_DAYS = 30
CACHE_VER = 2          # change quand le format des données change (invalide le cache)
WORKERS = 3

SYSTEM = ("Tu es un assistant pour un YouTubeur français qui prépare des vidéos sur Warhammer 40,000. Tu lis Wahapedia avec tes "
          "outils web et tu recopies les règles fidèlement, sans rien inventer. Tu réponds uniquement par du JSON valide.")

_STYLE = ("FORMAT : pas de texte descriptif ni d'ambiance, uniquement les règles. Chaque règle est réécrite en puces très courtes "
          "(une idée par puce, 90 caractères max, style télégraphique : « Relance les jets de touche de 1 », « +1 en Force contre Infanterie »). "
          "Garde les chiffres, conditions et mots-clés ; supprime les phrases d'introduction, exemples et rappels.")
_TERMS = ("Terminologie : « Lethal Hits » = « Touches Fatales » ; « Sustained Hits X » = « Touches Soutenues X » ; "
          "« Devastating Wounds » = « Blessures Dévastatrices ». Écris toujours « Touches Fatales » et « Touches Soutenues » "
          "(jamais « frappe fatale », « touches létales »…).")
_FR = ("Traduis tout en français avec la terminologie officielle de Games Workshop (Endurance, Sauvegarde, Points de vie, "
       "Commandement, Contrôle d'objectif, Meneur, Infiltrateurs, Stratagème, Phase de commandement…). Les noms d'unités, "
       "d'armes et d'optimisations sont ceux écrits dans la liste de l'utilisateur. " + _TERMS + " " + _STYLE)
_SOURCE = (f"Source : Wahapedia, édition de référence {WAHAPEDIA} (11e). Si la page n'existe pas encore pour cette édition, "
           f"utilise {FALLBACK_WAHAPEDIA} (10e) et dis-le dans \"edition_note\". Le site est en anglais : retrouve le nom "
           "anglais correspondant à partir du nom français (page de la faction, recherche web). N'invente jamais : si tu "
           "ne trouves pas, mets \"found\": false.")


def _cache_dir() -> Path:
    from .database import data_dir
    d = data_dir() / "armylist_cache"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _cached(kind: str, key: dict, build):
    h = hashlib.sha1(json.dumps([CACHE_VER, kind, WAHAPEDIA, key], sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:20]
    path = _cache_dir() / f"{kind}-{h}.json"
    if path.exists() and time.time() - path.stat().st_mtime < CACHE_DAYS * 86400:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            pass
    data = build()
    if data.get("found", True):
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return data


_FIX = [(re.compile(r"\b(?:frappes?|touches?|coups?)\s+(?:fatale?s?|l[ée]tale?s?|mortelle?s?)\b", re.I), "Touches Fatales"),
        (re.compile(r"\b(?:frappes?|touches?|coups?)\s+(?:soutenue?s?|prolong[ée]e?s?|persistante?s?)\b", re.I), "Touches Soutenues")]


def _fix_terms(v):
    """Corrige la terminologie officielle (Touches Fatales / Touches Soutenues) dans tout le JSON reçu."""
    if isinstance(v, str):
        for rx, rep in _FIX:
            v = rx.sub(rep, v)
        return v
    if isinstance(v, list):
        return [_fix_terms(x) for x in v]
    if isinstance(v, dict):
        return {k: _fix_terms(x) for k, x in v.items()}
    return v


def _ask(prompt: str) -> dict:
    last = None
    for _ in range(2):                                     # une seconde chance si la réponse n'est pas du JSON
        try:
            return _fix_terms(extract_json_object(call_claude(prompt, system=SYSTEM, max_tokens=8000)))
        except AIError as e:
            last = e
            if "valid JSON" not in str(e):
                raise
    raise last


def _s(v) -> str:
    return "" if v is None else str(v).strip()


def _l(v) -> list:
    return [x for x in v if x] if isinstance(v, list) else []


# ------------------------------------------------------------------ unités
UNIT_SCHEMA = """{
  "found": true,
  "name": "nom de l'unité (français, comme dans la liste)",
  "name_en": "nom anglais Wahapedia",
  "edition_note": "",
  "faction_line": "ex. Deathwatch · Personnage · Infanterie",
  "composition_short": "ex. 1 figurine  /  5 à 10 figurines",
  "stats": {"M": "6\\"", "T": "4", "Sv": "2+", "Inv": "4+ ou vide", "W": "5", "Ld": "6+", "OC": "1"},
  "weapons": [{"type": "ranged ou melee", "name": "...", "range": "12\\" (vide pour la mêlée)", "A": "1", "skill": "2+", "S": "4", "AP": "0", "D": "1", "keywords": ["Pistolet"]}],
  "abilities": [{"name": "...", "bullets": ["puce courte", "puce courte"]}],
  "core": ["capacités de base : Meneur, Infiltrateurs…"],
  "faction_abilities": ["..."],
  "leader": "unités que ce personnage peut rejoindre (vide si pas un Meneur)",
  "keywords": ["..."],
  "enhancement": {"name": "...", "cost": 25, "bullets": ["puce courte"]},
  "recap": ["5 à 7 puces courtes (110 caractères max), ton oral de YouTubeur : rôle de l'unité, points forts, armes clés, capacités importantes"]
}"""


def _models_text(u: dict) -> str:
    if u["models"]:
        return "; ".join(f"{m['count']}× {m['name']}" + (f" ({', '.join(f'{n}× {w}' for n, w in m['wargear'])})" if m["wargear"] else "") for m in u["models"])
    return "1 figurine"


def fetch_unit(u: dict, parsed: dict) -> dict:
    gear = ", ".join(f"{n}× {w}" for n, w in u["wargear"]) or "voir la composition"
    enh = (f"\nOptimisation choisie dans la liste : « {u['enhancement']} » (détachement « {(parsed['detachments'] or [{}])[0].get('name', '')} »). "
           "Renseigne le champ \"enhancement\" avec son coût en points et sa règle." if u["enhancement"] else
           "\nAucune optimisation : mets \"enhancement\": null.")
    prompt = (f"Il me faut la fiche technique d'une unité de Warhammer 40,000, telle qu'elle est sur Wahapedia.\n{_SOURCE}\n\n"
              f"Unité : « {u['name']} » — faction : {parsed['faction']} / {parsed['subfaction'] or '—'}.\n"
              f"Composition choisie dans la liste : {_models_text(u)}. Équipement : {gear}.{enh}\n\n"
              "Dans \"weapons\", garde UNIQUEMENT les armes réellement équipées dans cette liste (avec leurs mots-clés), "
              "séparées en distance / mêlée. Dans \"abilities\", mets les capacités propres à l'unité (pas les capacités de base, "
              "qui vont dans \"core\", ni celles de faction, dans \"faction_abilities\").\n"
              f"{_FR}\n\nRéponds UNIQUEMENT par un objet JSON de cette forme (aucun texte autour) :\n{UNIT_SCHEMA}")
    key = {"name": u["name"], "faction": parsed["faction"], "sub": parsed["subfaction"], "enh": u["enhancement"],
           "models": _models_text(u), "gear": gear}
    d = _cached("unit", key, lambda: _ask(prompt))
    return {"found": bool(d.get("found", True)) and bool(d.get("stats") or d.get("weapons") or d.get("abilities")),
            "name": _s(d.get("name")) or u["name"], "name_en": _s(d.get("name_en")), "edition_note": _s(d.get("edition_note")),
            "faction_line": _s(d.get("faction_line")), "composition_short": _s(d.get("composition_short")),
            "stats": d.get("stats") if isinstance(d.get("stats"), dict) else {},
            "weapons": [w for w in _l(d.get("weapons")) if isinstance(w, dict)],
            "abilities": [a for a in _l(d.get("abilities")) if isinstance(a, dict)],
            "core": [_s(x) for x in _l(d.get("core"))], "faction_abilities": [_s(x) for x in _l(d.get("faction_abilities"))],
            "leader": _s(d.get("leader")), "keywords": [_s(x) for x in _l(d.get("keywords"))],
            "enhancement": d.get("enhancement") if isinstance(d.get("enhancement"), dict) else None,
            "recap": [_s(x) for x in _l(d.get("recap"))]}


# ------------------------------------------------------------------ détachement
DET_SCHEMA = """{
  "found": true,
  "name": "nom du détachement (français)",
  "edition_note": "",
  "rule": {"name": "nom de la règle de détachement", "bullets": ["puce courte", "puce courte"]},
  "rule_recap": ["3 à 6 puces courtes (110 caractères max) qui résument la règle, ton oral"],
  "stratagems": [{"name": "...", "cp": 1, "kind": "ex. Stratagème de Bataille – Tir", "when": "quand (court)", "target": "cible (court)", "effect": ["puce courte", "puce courte"], "restrictions": "", "recap": "une phrase courte (100 car. max)"}]
}"""


def fetch_detachment(name: str, parsed: dict) -> dict:
    prompt = (f"Il me faut la règle de détachement et TOUS les stratagèmes d'un détachement de Warhammer 40,000, tels que sur Wahapedia.\n{_SOURCE}\n\n"
              f"Détachement : « {name} » — faction : {parsed['faction']} / {parsed['subfaction'] or '—'}.\n"
              f"{_FR}\nRecopie tous les stratagèmes du détachement, dans l'ordre de la page (pas les optimisations).\n\n"
              f"Réponds UNIQUEMENT par un objet JSON de cette forme (aucun texte autour) :\n{DET_SCHEMA}")
    d = _cached("det", {"name": name, "faction": parsed["faction"], "sub": parsed["subfaction"]}, lambda: _ask(prompt))
    return {"found": bool(d.get("found", True)) and bool(d.get("rule") or d.get("stratagems")), "name": _s(d.get("name")) or name,
            "edition_note": _s(d.get("edition_note")),
            "rule": d.get("rule") if isinstance(d.get("rule"), dict) else {},
            "rule_recap": [_s(x) for x in _l(d.get("rule_recap"))],
            "stratagems": [s for s in _l(d.get("stratagems")) if isinstance(s, dict)]}


# ------------------------------------------------------------------ dispositions
DISP_SCHEMA = """{
  "found": true,
  "edition_note": "",
  "items": [{"name": "nom de la disposition (français)", "missions": [{"vs": "nom de l'autre disposition affrontée", "mission": "nom de la mission jouée dans ce cas"}]}]
}"""


def fetch_dispositions(names: list, parsed: dict) -> dict:
    prompt = (f"Il me faut les règles des « dispositions de forces » suivantes de Warhammer 40,000 (Force Dispositions de la 11e édition), "
              f"telles que sur Wahapedia (section règles / règles de base).\n{_SOURCE}\n\n"
              f"Dispositions de la liste : {', '.join(repr(n) for n in names)}. Taille de bataille : {parsed['battle_size']} ({parsed['battle_points']} pts).\n"
              "Pour chaque disposition de la liste, donne UNIQUEMENT le nom de la mission jouée quand on affronte chacune des autres dispositions "
              "(tableau / matrice des missions selon les dispositions des deux joueurs). Aucun autre texte.\n"
              f"{_FR}\n\nRéponds UNIQUEMENT par un objet JSON de cette forme (aucun texte autour) :\n{DISP_SCHEMA}")
    d = _cached("disp", {"names": names, "size": parsed["battle_size"]}, lambda: _ask(prompt))
    return {"found": bool(d.get("found", True)) and bool(d.get("items")), "edition_note": _s(d.get("edition_note")),
            "items": [{"name": _s(i.get("name")),
                       "missions": [{"vs": _s(m.get("vs")), "mission": _s(m.get("mission"))} for m in _l(i.get("missions")) if isinstance(m, dict) and m.get("mission")]}
                      for i in _l(d.get("items")) if isinstance(i, dict)]}


def fetch_all(parsed: dict, unit_keys: list, progress=None) -> dict:
    """unit_keys : les unités (dict) à chercher. -> {"det": {nom: data}, "disp": data, "units": {id(unité): data}, "errors": [str]}"""
    out = {"det": {}, "disp": None, "units": {}, "errors": []}
    jobs = []
    for d in parsed["detachments"]:
        jobs.append(("det", d["name"], lambda d=d: fetch_detachment(d["name"], parsed)))
    if parsed["dispositions"]:
        jobs.append(("disp", None, lambda: fetch_dispositions(parsed["dispositions"], parsed)))
    for u in unit_keys:
        jobs.append(("unit", id(u), lambda u=u: fetch_unit(u, parsed)))

    def run(job):
        kind, key, fn = job
        try:
            return kind, key, fn(), None
        except AIError as e:
            return kind, key, None, str(e)

    done = 0
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        for kind, key, data, err in ex.map(run, jobs):
            done += 1
            if progress:
                progress(done, len(jobs))
            if err:
                out["errors"].append(err)
                continue
            if kind == "det":
                out["det"][key] = data
            elif kind == "disp":
                out["disp"] = data
            else:
                out["units"][key] = data
    if jobs and len(out["errors"]) == len(jobs):
        raise AIError(out["errors"][0])                    # tout a échoué (CLI absente, pas connecté…) : on le dit tel quel
    return out
