"""Login for the planner: identifier (an email or a name) + password, kept in a signed session cookie.

* Credentials live in `<data dir>/auth.json` (owner-only permissions): the identifier, a salted scrypt hash of the
  password (never the password itself), the key that signs the session cookie, and a counter bumped on every password
  change so older sessions stop working.
* First run: identifier `nicolas`, password `1234`, flagged "must change": a browser that signs in with it can do nothing
  but set a new password (page /change-password) - every other page and API call is refused until then.
* Forgotten password: `python3 -m app.auth reset` (run on the machine) puts the defaults back.
* Non-browser clients on this very machine (the Plasma widget, the Resolve scripts, curl) are let through without
  a login, because they send none of the headers a browser always sends (Sec-Fetch-Site / Origin) and come from
  loopback. Browsers - even on localhost - and anything coming from the network must log in.
  Set TASKPLANNER_AUTH_TRUST_LOCAL=0 to remove that exception, TASKPLANNER_AUTH=0 to turn the login off.
* Failed logins are throttled per client address (5 failures -> a lock that doubles, up to 15 min).
"""
from __future__ import annotations
import ipaddress
import json
import os
import secrets
import sys
import threading
import time
from datetime import timedelta

from flask import Blueprint, abort, current_app, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from .database import data_dir

DEFAULT_IDENTIFIER = "nicolas"
DEFAULT_PASSWORD = "1234"
MIN_PASSWORD_LENGTH = 8
SESSION_DAYS = 30

auth_bp = Blueprint("auth", __name__)
_lock = threading.Lock()


# -- storage --------------------------------------------------------------------------------------------------------
def _path():
    return data_dir() / "auth.json"


def _write(data: dict) -> None:
    p = _path()
    tmp = p.with_suffix(".json.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, p)


def _defaults(keep_secret: str | None = None, version: int = 0) -> dict:
    return {"identifier": DEFAULT_IDENTIFIER, "password_hash": generate_password_hash(DEFAULT_PASSWORD),
            "must_change": True, "secret": keep_secret or secrets.token_hex(32), "version": version + 1}


def load() -> dict:
    with _lock:
        try:
            data = json.loads(_path().read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("password_hash") and data.get("secret"):
                return data
        except (OSError, ValueError):
            pass
        data = _defaults()
        _write(data)
        return data


def reset_to_defaults() -> None:
    with _lock:
        try:
            old = json.loads(_path().read_text(encoding="utf-8"))
        except (OSError, ValueError):
            old = {}
        _write(_defaults(old.get("secret"), int(old.get("version") or 0)))


# -- throttling -----------------------------------------------------------------------------------------------------
_fails: dict[str, list] = {}          # ip -> [failure count, locked until (epoch)]


def _ip() -> str:
    return request.remote_addr or "?"


def _locked_for() -> int:
    with _lock:
        until = (_fails.get(_ip()) or [0, 0])[1]
    return max(0, int(until - time.time()))


def _record(ok: bool) -> None:
    with _lock:
        if ok:
            _fails.pop(_ip(), None)
            return
        n, _ = _fails.get(_ip(), [0, 0])
        n += 1
        lock = min(900, 30 * 2 ** (n - 5)) if n >= 5 else 0
        _fails[_ip()] = [n, time.time() + lock]


def _check(identifier: str, password: str, data: dict) -> bool:
    """Constant-ish time: the hash is always verified, whatever the identifier."""
    ok_pw = check_password_hash(data["password_hash"], password or "")
    ok_id = secrets.compare_digest((identifier or "").strip().lower().encode(), data["identifier"].strip().lower().encode())
    return bool(ok_pw and ok_id)


# -- who is allowed in ----------------------------------------------------------------------------------------------
def _enabled() -> bool:
    return os.environ.get("TASKPLANNER_AUTH", "1") != "0"


def _is_trusted_local() -> bool:
    if os.environ.get("TASKPLANNER_AUTH_TRUST_LOCAL", "1") == "0":
        return False
    if request.headers.get("Sec-Fetch-Site") or request.headers.get("Origin") or request.headers.get("Cookie"):
        return False                  # a browser (they always send Sec-Fetch-Site / Origin on writes)
    try:
        ip = ipaddress.ip_address(request.remote_addr or "")
        if getattr(ip, "ipv4_mapped", None):
            ip = ip.ipv4_mapped
        return ip.is_loopback
    except ValueError:
        return False


def logged_in() -> bool:
    return session.get("v") == load()["version"]


def _start_session(data: dict) -> None:
    session.clear()
    session.permanent = True
    session["v"] = data["version"]


def install(app) -> None:
    """Called from create_app(): signing key, cookie settings, the login guard and the routes."""
    app.secret_key = load()["secret"]
    app.config.update(SESSION_COOKIE_NAME="taskplanner_session", SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Lax", PERMANENT_SESSION_LIFETIME=timedelta(days=SESSION_DAYS))
    app.register_blueprint(auth_bp)

    @app.before_request
    def _login_guard():
        if not _enabled() or request.endpoint in ("static", "auth.login_page", "auth.login_submit", "auth.logout"):
            return None
        if request.path.startswith("/static/") or _is_trusted_local():
            return None
        if logged_in():
            if load().get("must_change") and request.endpoint not in ("auth.change_page", "auth.change", "auth.me"):
                if request.path.startswith(("/api/", "/fiscal/api/")):
                    return jsonify({"error": "Choose a new password first.", "must_change": True}), 403, {"X-Must-Change": "1"}
                return redirect(url_for("auth.change_page"))
            return None
        if request.path.startswith(("/api/", "/fiscal/api/")):
            return jsonify({"error": "Login required."}), 401
        return redirect(url_for("auth.login_page"))


# -- pages and API --------------------------------------------------------------------------------------------------
@auth_bp.get("/login")
def login_page():
    if logged_in():
        return redirect("/")
    return render_template("login.html", error=None, identifier="")


@auth_bp.post("/login")
def login_submit():
    wait = _locked_for()
    if wait:
        return render_template("login.html", error=f"Too many attempts. Try again in {wait} s.", identifier=""), 429
    ident = (request.form.get("identifier") or "").strip()
    data = load()
    ok = _check(ident, request.form.get("password") or "", data)
    _record(ok)
    if not ok:
        return render_template("login.html", error="Wrong identifier or password.", identifier=ident), 401
    _start_session(data)
    return redirect(url_for("auth.change_page") if data.get("must_change") else "/")


@auth_bp.get("/change-password")
def change_page():
    d = load()
    if not d.get("must_change"):
        return redirect("/")
    return render_template("change_password.html", identifier=d["identifier"], min_length=MIN_PASSWORD_LENGTH)


@auth_bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login_page"))


@auth_bp.get("/api/auth/me")
def me():
    d = load()
    return jsonify({"identifier": d["identifier"], "must_change": bool(d.get("must_change")), "enabled": _enabled(),
                    "min_password_length": MIN_PASSWORD_LENGTH})


@auth_bp.post("/api/auth/change")
def change():
    body = request.get_json(force=True, silent=True)
    if not isinstance(body, dict):
        abort(400, "The request body must be a JSON object.")
    wait = _locked_for()
    if wait:
        return jsonify({"error": f"Too many attempts. Try again in {wait} s."}), 429
    d = load()
    # the current password is required even for a logged-in session (a left-open browser must not be enough)
    ok = check_password_hash(d["password_hash"], str(body.get("current_password") or ""))
    _record(ok)
    if not ok:
        return jsonify({"error": "The current password is wrong."}), 400
    ident = str(body.get("identifier") or d["identifier"]).strip()
    if not 2 <= len(ident) <= 120 or any(c in ident for c in "\r\n\t"):
        return jsonify({"error": "The identifier must be 2 to 120 characters (an email or a name)."}), 400
    new_pw = body.get("new_password")
    if new_pw in (None, ""):
        if ident == d["identifier"]:
            return jsonify({"error": "Nothing to change."}), 400
        new_hash, must_change = d["password_hash"], bool(d.get("must_change"))
    else:
        new_pw = str(new_pw)
        if len(new_pw) < MIN_PASSWORD_LENGTH:
            return jsonify({"error": f"The new password must have at least {MIN_PASSWORD_LENGTH} characters."}), 400
        if new_pw == str(body.get("current_password")):
            return jsonify({"error": "The new password must differ from the current one."}), 400
        new_hash, must_change = generate_password_hash(new_pw), False
    d.update(identifier=ident, password_hash=new_hash, must_change=must_change, version=int(d["version"]) + 1)
    with _lock:
        _write(d)
    _start_session(d)                  # this browser stays logged in; every other session is cut off
    return jsonify({"ok": True, "identifier": ident, "must_change": must_change})


if __name__ == "__main__":
    if sys.argv[1:] == ["reset"]:
        reset_to_defaults()
        print(f"Login reset to {DEFAULT_IDENTIFIER} / {DEFAULT_PASSWORD}. Change it in Utilities > Account.")
    else:
        print("Usage: python3 -m app.auth reset")
