"""Automatic backups of the whole database.

A backup is a full JSON dump of every table (gzip-compressed) in
<data dir>/backups/, plus a tiny sidecar .meta.json used to list backups
quickly. One is taken after every task/subtask change, creation, completion
or deletion (see Database._wrap_methods_with_lock), skipping it when nothing
actually differs from the previous backup. Bursts of the same change (typing in a
task's notes saves every second) replace each other instead of piling up. Beyond
the newest MAX_BACKUPS only the last backup of each day is kept (for
KEEP_DAILY_DAYS days), so the history reaches back months, not a day or two.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import secrets
from datetime import datetime, timedelta
from pathlib import Path

MAX_BACKUPS = int(os.environ.get("TASKPLANNER_MAX_BACKUPS", "500"))
KEEP_DAILY_DAYS = int(os.environ.get("TASKPLANNER_KEEP_DAILY_DAYS", "365"))
COALESCE_SECONDS = 60          # identical changes within this delay of the first one replace each other: one backup per minute at most
# Columns that change on their own while a timer runs / carry no user data.
VOLATILE_COLUMNS = {"timer_started_at"}
# Tables compared in the "differences" view, in display order.
DIFF_TABLES = ["projects", "todo_lists", "tasks", "subtasks", "tags", "task_tags", "task_completions", "other_time", "project_time"]
SKIP_TABLES = {"app_flags", "time_log", "time_insights"}   # internal markers / bulk ledger, not shown in the differences view
DISPLAY_NAME = {"projects": "name", "todo_lists": "name", "tasks": "title", "subtasks": "title", "tags": "name"}


def dump_tables(conn) -> dict:
    names = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    return {n: [dict(r) for r in conn.execute(f'SELECT * FROM "{n}"')] for n in names}


def _fingerprint(tables: dict) -> str:
    slim = {t: [{k: v for k, v in row.items() if k not in VOLATILE_COLUMNS} for row in rows]
            for t, rows in tables.items()}
    return hashlib.sha1(json.dumps(slim, sort_keys=True, default=str).encode()).hexdigest()


class BackupStore:
    def __init__(self, directory: Path):
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)

    # -- writing -----------------------------------------------------------
    def create(self, conn, reason: str, force: bool = False) -> dict | None:
        tables = dump_tables(conn)
        fp = _fingerprint(tables)
        latest = self.list(limit=1)
        if not force and latest and latest[0].get("fingerprint") == fp:
            return None
        now = datetime.now()
        superseded = None
        burst = now.isoformat(timespec="seconds")      # when this run of identical changes started
        if not force and latest and latest[0].get("reason") == reason:
            try:
                started = datetime.fromisoformat(latest[0].get("burst") or latest[0]["created_at"])
                if 0 <= (now - started).total_seconds() < COALESCE_SECONDS:
                    superseded, burst = latest[0]["id"], started.isoformat(timespec="seconds")
            except (KeyError, ValueError):
                pass                                   # unreadable date: keep both backups
        bid = now.strftime("%Y%m%d-%H%M%S-") + f"{now.microsecond // 1000:03d}-" + secrets.token_hex(2)
        meta = {
            "id": bid, "created_at": now.isoformat(timespec="seconds"), "reason": reason, "fingerprint": fp, "burst": burst,
            "counts": {t: len(tables.get(t, [])) for t in ("projects", "todo_lists", "tasks", "subtasks")},
        }
        tmp = self.dir / f"{bid}.json.gz.tmp"
        with gzip.open(tmp, "wt", encoding="utf-8") as f:
            json.dump({"meta": meta, "tables": tables}, f, default=str)
        os.replace(tmp, self.dir / f"{bid}.json.gz")
        (self.dir / f"{bid}.meta.json").write_text(json.dumps(meta))
        if superseded:
            self._remove(superseded)
        self._prune()
        return meta

    def _remove(self, bid: str) -> None:
        for p in (self.dir / f"{bid}.meta.json", self.dir / f"{bid}.json.gz"):
            try:
                p.unlink()
            except OSError:
                pass

    def _prune(self):
        """Keeps the newest MAX_BACKUPS as they are; of the older ones only the last backup of each day survives
        (and none after KEEP_DAILY_DAYS days)."""
        if MAX_BACKUPS <= 0:
            return
        metas = sorted(self.dir.glob("*.meta.json"))              # names start with the date: oldest first
        older = metas[:-MAX_BACKUPS]
        if not older:
            return
        last_of_day = {m.name[:8]: m for m in older}              # ascending order -> the latest of each day wins
        cutoff = (datetime.now() - timedelta(days=KEEP_DAILY_DAYS)).strftime("%Y%m%d")
        keep = {m for day, m in last_of_day.items() if day >= cutoff}
        for m in older:
            if m not in keep:
                self._remove(m.name[: -len(".meta.json")])

    def delete_older_than(self, days: int) -> int:
        """Remove backups created more than `days` days ago; returns how many."""
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(days=days)
        removed = 0
        for meta in self.list():
            try:
                created = datetime.fromisoformat(meta["created_at"])
            except (KeyError, ValueError):
                continue
            if created >= cutoff:
                continue
            for name in (f"{meta['id']}.meta.json", f"{meta['id']}.json.gz"):
                try:
                    (self.dir / name).unlink()
                except OSError:
                    pass
            removed += 1
        return removed

    # -- reading -----------------------------------------------------------
    def list(self, limit: int | None = None) -> list[dict]:
        out = []
        for p in sorted(self.dir.glob("*.meta.json"), reverse=True):
            try:
                out.append(json.loads(p.read_text()))
            except (OSError, ValueError):
                continue
            if limit and len(out) >= limit:
                break
        return out

    def load(self, bid: str) -> dict | None:
        if not bid or "/" in bid or "\\" in bid or ".." in bid:
            return None
        path = self.dir / f"{bid}.json.gz"
        if not path.exists():
            return None
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return json.load(f)


def _key(table: str, row: dict):
    if table == "task_tags":
        return (row["task_id"], row["tag_id"])
    return row["id"]


def diff_tables(old: dict, new: dict) -> dict:
    """COMPLETE differences between a backup (`old`) and the current data
    (`new`), per table: rows only in the backup (deleted since), rows only in
    the current data (created since) -- each with all its properties -- and
    rows whose properties differ (every differing property: backup value ->
    current value). References to other rows (project, list, task, tag) are
    shown by name rather than by id."""
    def names(table):
        m = {}
        for src in (old, new):
            for r in src.get(table, []):
                if "id" in r and table in DISPLAY_NAME:
                    m[r["id"]] = r.get(DISPLAY_NAME[table])
        return m
    name_of = {"project_id": names("projects"), "todo_list_id": names("todo_lists"),
               "task_id": names("tasks"), "tag_id": names("tags")}
    proj_names, list_names, task_names, tag_names = (
        name_of["project_id"], name_of["todo_list_id"], name_of["task_id"], name_of["tag_id"])
    list_proj = {}
    for src in (old, new):
        for r in src.get("todo_lists", []):
            list_proj[r["id"]] = r.get("project_id")

    def show(prop, value):
        """Value as shown to the person: ids of referenced rows become names."""
        if prop in name_of and value:
            return name_of[prop].get(value, f"(unknown: {value})")
        return value

    def context(table, row):
        if table == "subtasks":
            return f"in task “{task_names.get(row.get('task_id'), '?')}”"
        if table == "tasks":
            lid = row.get("todo_list_id")
            return f"in {proj_names.get(list_proj.get(lid), '?')} / {list_names.get(lid, '?')}"
        if table == "todo_lists":
            return f"in project {proj_names.get(row.get('project_id'), '?')}"
        return ""

    def label(table, row):
        if table == "task_tags":
            return f"Tag “{tag_names.get(row['tag_id'], '?')}” on task “{task_names.get(row['task_id'], '?')}”"
        if table == "task_completions":
            return f"{row.get('title')} (occurrence of {row.get('occurrence_date')})"
        if table == "other_time":
            return f"Other tasks time, {row.get('id')}"
        if table == "project_time":
            return f"Other tasks time of {proj_names.get(row.get('project_id'), '?')}, {row.get('day')}"
        return row.get(DISPLAY_NAME.get(table, "id")) or row.get("id")

    def full(row):
        return [{"prop": k, "value": show(k, v)} for k, v in sorted(row.items()) if k not in VOLATILE_COLUMNS]

    tables = [t for t in DIFF_TABLES if t not in SKIP_TABLES]
    tables += sorted((set(old) | set(new)) - set(tables) - SKIP_TABLES)
    out = {}
    for table in tables:
        def key(r):
            return (r["task_id"], r["tag_id"]) if table == "task_tags" else r.get("id")
        o = {key(r): r for r in old.get(table, [])}
        n = {key(r): r for r in new.get(table, [])}
        deleted = [{"label": label(table, o[k]), "context": context(table, o[k]), "props": full(o[k])}
                   for k in o if k not in n]
        created = [{"label": label(table, n[k]), "context": context(table, n[k]), "props": full(n[k])}
                   for k in n if k not in o]
        changed = []
        for k in o:
            if k not in n:
                continue
            props = []
            for col in sorted(set(o[k]) | set(n[k])):
                if col in VOLATILE_COLUMNS:
                    continue
                if o[k].get(col) != n[k].get(col):
                    props.append({"prop": col, "backup": show(col, o[k].get(col)),
                                  "current": show(col, n[k].get(col))})
            if props:
                changed.append({"label": label(table, n[k]), "context": context(table, n[k]), "props": props})
        if deleted or created or changed:
            out[table] = {"deleted_since": deleted, "created_since": created, "changed": changed}
    return out
