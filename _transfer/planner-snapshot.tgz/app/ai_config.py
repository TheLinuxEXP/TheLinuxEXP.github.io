"""Which AI the planner talks to, and how: the persisted settings behind the "AI settings" window.

The planner is not tied to one provider. Every AI button goes through `ai.call_claude()` (name kept for the
existing callers), which reads the active provider from here:

* `claude_cli`  - your Claude subscription through the Claude Code CLI (the default; has web search/fetch tools)
* `anthropic`   - the Anthropic API (pay per call, needs an API key)
* `openai_compat` family - anything that speaks the OpenAI "chat/completions" protocol: a LOCAL model (Ollama,
  LM Studio, llama.cpp server, vLLM...) or a cloud provider (OpenAI, Mistral, Groq, OpenRouter, Gemini...)

Settings live in `<data dir>/ai_settings.json` (one profile per provider, so switching back and forth keeps each
provider's model / endpoint / key). The file is written with owner-only permissions; API keys are never sent back
to the browser (only a "key saved" flag).
"""
from __future__ import annotations
import json
import os
import threading
from pathlib import Path

from .database import data_dir

# id -> display name, protocol kind, default endpoint, example model, whether a key is needed
PROVIDERS: dict[str, dict] = {
    "claude_cli": {"label": "Claude - my subscription (Claude Code)", "kind": "claude_cli", "base_url": "",
                   "model": "", "needs_key": False, "local": False, "web": True,
                   "help": "Uses your Claude subscription through the “claude” command (the current setup). "
                           "The only provider with built-in web search and image reading. Model is optional: sonnet, opus..."},
    "anthropic": {"label": "Claude - Anthropic API (API key)", "kind": "anthropic",
                  "base_url": "https://api.anthropic.com", "model": "claude-sonnet-4-5-20250929",
                  "needs_key": True, "local": False, "web": False,
                  "help": "Billed per use, independent from the subscription. Key from console.anthropic.com."},
    "ollama": {"label": "Local model - Ollama", "kind": "openai_compat", "base_url": "http://localhost:11434/v1",
               "model": "", "needs_key": False, "local": True, "web": False,
               "help": "Ollama must be running on this machine (ollama serve). Example models: qwen2.5:14b, llama3.1:8b, mistral-small..."},
    "lmstudio": {"label": "Local model - LM Studio", "kind": "openai_compat", "base_url": "http://localhost:1234/v1",
                 "model": "", "needs_key": False, "local": True, "web": False,
                 "help": "Start LM Studio's local server, then enter the name of the loaded model."},
    "openai": {"label": "Cloud - OpenAI", "kind": "openai_compat", "base_url": "https://api.openai.com/v1",
               "model": "gpt-4o", "needs_key": True, "local": False, "web": False, "help": "Key from platform.openai.com."},
    "mistral": {"label": "Cloud - Mistral", "kind": "openai_compat", "base_url": "https://api.mistral.ai/v1",
                "model": "mistral-large-latest", "needs_key": True, "local": False, "web": False, "help": "Key from console.mistral.ai."},
    "gemini": {"label": "Cloud - Google Gemini", "kind": "openai_compat",
               "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
               "model": "gemini-2.0-flash", "needs_key": True, "local": False, "web": False, "help": "Key from aistudio.google.com."},
    "groq": {"label": "Cloud - Groq", "kind": "openai_compat", "base_url": "https://api.groq.com/openai/v1",
             "model": "llama-3.3-70b-versatile", "needs_key": True, "local": False, "web": False, "help": "Key from console.groq.com."},
    "openrouter": {"label": "Cloud - OpenRouter", "kind": "openai_compat", "base_url": "https://openrouter.ai/api/v1",
                   "model": "", "needs_key": True, "local": False, "web": False,
                   "help": "One account for many models (e.g. anthropic/claude-sonnet-4.5). Key from openrouter.ai."},
    "custom": {"label": "Other - OpenAI-compatible (any address)", "kind": "openai_compat", "base_url": "",
               "model": "", "needs_key": False, "local": False, "web": False,
               "help": "Any server speaking the OpenAI protocol (llama.cpp, vLLM, LiteLLM, a server on your network...)."},
}
DEFAULT_PROVIDER = "claude_cli"
DEFAULT_TIMEOUT = 900

_lock = threading.Lock()
_cache: dict = {"mtime": None, "data": None}


def _path() -> Path:
    return data_dir() / "ai_settings.json"


def _env_defaults() -> dict:
    """Behaviour before the window was ever used: the environment variables keep working."""
    api = os.environ.get("TASKPLANNER_AI_BACKEND", "cli").lower() == "api"
    profiles = {}
    if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_MODEL"):
        profiles["anthropic" if api else "claude_cli"] = {"model": os.environ.get("ANTHROPIC_MODEL", ""),
                                                           "api_key": os.environ.get("ANTHROPIC_API_KEY", "") if api else ""}
    return {"active": "anthropic" if api else DEFAULT_PROVIDER, "profiles": profiles, "timeout": None}


def load() -> dict:
    """The raw settings (including keys). Server-side use only."""
    p = _path()
    try:
        mtime = p.stat().st_mtime_ns
    except OSError:
        return _env_defaults()
    with _lock:
        if _cache["mtime"] == mtime and _cache["data"] is not None:
            return _cache["data"]
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError
        except (OSError, ValueError):
            return _env_defaults()
        _cache.update(mtime=mtime, data=data)
        return data


def timeout_seconds() -> int:
    t = load().get("timeout")
    if t in (None, ""):
        t = os.environ.get("TASKPLANNER_AI_TIMEOUT")
    try:
        return max(30, min(7200, int(t)))
    except (TypeError, ValueError):
        return DEFAULT_TIMEOUT


def active_id() -> str:
    a = load().get("active")
    return a if a in PROVIDERS else DEFAULT_PROVIDER


def profile(pid: str | None = None) -> dict:
    """The effective settings of one provider (defaults filled in)."""
    pid = pid or active_id()
    preset = PROVIDERS.get(pid) or PROVIDERS[DEFAULT_PROVIDER]
    saved = (load().get("profiles") or {}).get(pid) or {}
    return {
        "provider": pid, "kind": preset["kind"],
        "model": (saved.get("model") or "").strip() or (preset["model"] if preset["kind"] != "claude_cli" else ""),
        "base_url": (saved.get("base_url") or "").strip() or preset["base_url"],
        "api_key": saved.get("api_key") or "",
        "vision": bool(saved.get("vision")) if "vision" in saved else preset["kind"] == "claude_cli",
    }


def public_view() -> dict:
    """What the browser may see: no keys, only whether one is saved."""
    profiles = {}
    for pid in PROVIDERS:
        pr = profile(pid)
        profiles[pid] = {"model": pr["model"], "base_url": pr["base_url"], "vision": pr["vision"], "has_key": bool(pr["api_key"])}
    return {"active": active_id(), "timeout": timeout_seconds(), "profiles": profiles,
            "providers": [{"id": k, **{x: v[x] for x in ("label", "kind", "base_url", "model", "needs_key", "local", "web", "help")}}
                          for k, v in PROVIDERS.items()]}


def save(update: dict) -> None:
    """update: {"active": id, "timeout": seconds|None, "profile": {id, model, base_url, vision, api_key?, clear_key?}}.
    api_key left out (or empty) keeps the stored key; clear_key=True removes it."""
    data = json.loads(json.dumps(load()))            # deep copy of what is on disk (or the env defaults)
    data.setdefault("profiles", {})
    pid = update.get("active")
    if pid is not None:
        if pid not in PROVIDERS:
            raise ValueError("Unknown provider.")
        data["active"] = pid
    if "timeout" in update:
        t = update["timeout"]
        data["timeout"] = None if t in (None, "") else max(30, min(7200, int(t)))
    pr = update.get("profile")
    if pr:
        ppid = pr.get("id")
        if ppid not in PROVIDERS:
            raise ValueError("Unknown provider.")
        cur = dict(data["profiles"].get(ppid) or {})
        for k in ("model", "base_url"):
            if k in pr:
                cur[k] = str(pr[k] or "").strip()[:300]
        if "vision" in pr:
            cur["vision"] = bool(pr["vision"])
        if pr.get("clear_key"):
            cur["api_key"] = ""
        elif str(pr.get("api_key") or "").strip():
            cur["api_key"] = str(pr["api_key"]).strip()
        if cur.get("base_url") and not cur["base_url"].lower().startswith(("http://", "https://")):
            raise ValueError("The address must start with http:// or https://.")
        data["profiles"][ppid] = cur
    p = _path()
    tmp = p.with_suffix(".json.tmp")
    with _lock:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, p)
        _cache.update(mtime=None, data=None)
