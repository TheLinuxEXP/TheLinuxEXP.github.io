"""
Adaptateur entre l'interface web et l'application « Gestion fiscale EI ».

PRINCIPE : aucun calcul n'est recopié. Ce module importe gestion_fiscale_ei.py
(l'application KDE elle-même) et appelle ses fonctions telles quelles. Pour
les onglets URSSAF, Impôt/revenu et TVA, dont la logique vit dans des méthodes
de classes Qt (compute / compute_summary), on appelle directement ces mêmes
méthodes avec de petits objets factices à la place des widgets (pavés de
synthèse, zone de texte HTML, champs de saisie) : le HTML et les chiffres
produits sont donc, par construction, ceux de l'application. Si
gestion_fiscale_ei.py évolue, l'interface web suit sans autre modification.

Le seul code propre à l'interface web : les listes/filtres de factures
(l'équivalent des QTableWidget), le graphique (qui construit des QChart dans
l'application, ici converti en données JSON) et le dialogue avec le navigateur.
"""
import os
import sys
import base64
import tempfile
import types
from pathlib import Path
from datetime import date

from . import qt_shim  # noqa: E402

# Le module de l'application importe PySide6 : le serveur n'en a pas besoin
# (ni écran, ni Qt, ni conteneur lourd) — voir qt_shim.py.
qt_shim.install()


def _locate_app_dir():
    """Dossier contenant gestion_fiscale_ei.py : variable EI_APP_DIR, sinon ce
    paquet lui-même (si le fichier y a été copié, ex. serveur unifié), sinon
    les dossiers parents (web/gestion_ei_web -> web -> projet)."""
    candidates = []
    if os.environ.get("EI_APP_DIR"):
        candidates.append(Path(os.environ["EI_APP_DIR"]))
    here = Path(__file__).resolve().parent
    candidates += [here, *list(here.parents)[:3]]
    for c in candidates:
        if (c / "gestion_fiscale_ei.py").exists():
            return c
    raise ImportError(
        "gestion_fiscale_ei.py introuvable : indiquez son dossier avec la variable EI_APP_DIR."
    )


_app_dir = str(_locate_app_dir())
if _app_dir not in sys.path:
    sys.path.insert(0, _app_dir)

import gestion_fiscale_ei as core  # noqa: E402

if os.environ.get("EI_DATA_FILE"):
    core.DATA_FILE = Path(os.environ["EI_DATA_FILE"])
    core.DATA_DIR = core.DATA_FILE.parent
elif os.environ.get("EI_DATA_DIR"):
    core.DATA_DIR = Path(os.environ["EI_DATA_DIR"])
    core.DATA_FILE = core.DATA_DIR / "data.json"

WEB_BUILD = "web-2026-10-07.1"

# --------------------------------------------------------------------------- #
# Icônes : l'application utilise des icônes du thème système KDE ; en web on
# les remplace par de petits SVG blancs (utilisés dans l'en-tête des blocs).
# --------------------------------------------------------------------------- #
_SVG = {
    "document-import": '<path d="M12 3v11M7.5 9.5 12 14l4.5-4.5M4 17v3h16v-3"/>',
    "view-bank-account": '<path d="M3 10 12 4l9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18"/>',
    "office-chart-line": '<path d="M3 3v18h18M6 16l4-5 3 3 5-7"/>',
    "view-calendar-time": '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    "view-financial-account": '<circle cx="12" cy="12" r="9"/><path d="M15.5 9.2a3.6 3.6 0 1 0 0 5.6M8 11h6M8 13h6"/>',
    "view-financial-transfer": '<path d="M4 8h14M14 4l4 4-4 4M20 16H6M10 12l-4 4 4 4"/>',
}


def _first_known(name):
    names = [name] if isinstance(name, str) else list(name)
    for n in names:
        if n in _SVG:
            return n
    return "view-financial-transfer" if "view-financial-transfer" in names else None


def svg_icon(name, size=28):
    key = _first_known(name)
    if not key:
        return ""
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 24 24" '
        f'fill="none" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'
        f"{_SVG[key]}</svg>"
    )


def icon_data_uri(name, size=28, qt_fallback=None):
    svg = svg_icon(name, size)
    if not svg:
        return ""
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode("ascii")


core.icon_data_uri = icon_data_uri  # utilisé par section_html (HTML des blocs)

# --------------------------------------------------------------------------- #
# Données
# --------------------------------------------------------------------------- #
SETTING_DEFAULTS = {
    "urssaf_taux": 45,
    "urssaf_epargne_retraite": 0.0,
    "ir_taux_urssaf": 45,
    "ir_autres_revenus": 23000,
    "ir_parts": 2,
}


class DataFileError(RuntimeError):
    """data.json exists but cannot be read: we refuse to carry on with an empty
    dataset, because the next save would overwrite the real data with it."""


BACKUP_KEEP = 40            # number of recent automatic copies kept as they are
BACKUP_DAILY_DAYS = 365     # older than those: only the last copy of each day is kept, for this many days
BACKUP_MIN_INTERVAL = 600   # seconds between two automatic copies


def _read_strict():
    import json, time
    f = core.DATA_FILE
    if not f.exists():
        return None                       # first run: nothing to protect yet
    last = None
    for attempt in range(4):              # the desktop app may be mid-write
        try:
            text = f.read_text(encoding="utf-8")
            if not text.strip():
                raise ValueError("fichier vide")
            data = json.loads(text)
            if not isinstance(data, dict):
                raise ValueError("le fichier ne contient pas un objet JSON")
            return data
        except Exception as e:            # noqa: BLE001
            last = e
            time.sleep(0.25)
    raise DataFileError(
        f"data.json est illisible ({last}). Rien n'a été modifié : corrigez le fichier "
        f"ou restaurez une copie depuis {core.DATA_DIR / 'backups'}.")


def load():
    _read_strict()          # raises DataFileError if the file exists but is unreadable
    data = core.load_data()
    if core.bootstrap_clients(data):
        save(data)
    return data


def _backup_current():
    """Copy the current data.json to backups/ (throttled, newest N kept)."""
    import shutil, time
    from datetime import datetime, timedelta
    f = core.DATA_FILE
    if not f.exists() or f.stat().st_size == 0:
        return
    bdir = core.DATA_DIR / "backups"
    try:
        bdir.mkdir(parents=True, exist_ok=True)
        existing = sorted(bdir.glob("data-*.json"))
        if existing and time.time() - existing[-1].stat().st_mtime < BACKUP_MIN_INTERVAL:
            return
        shutil.copy2(f, bdir / f"data-{datetime.now():%Y%m%d-%H%M%S}.json")
        older = sorted(bdir.glob("data-*.json"))[:-BACKUP_KEEP]
        last_of_day = {p.name[5:13]: p for p in older}           # data-YYYYMMDD-HHMMSS.json, ascending: the latest of a day wins
        cutoff = (datetime.now() - timedelta(days=BACKUP_DAILY_DAYS)).strftime("%Y%m%d")
        keep = {p for day, p in last_of_day.items() if day >= cutoff}
        for old in older:
            if old not in keep:
                old.unlink()
    except OSError:
        pass                              # a failed backup must never block saving


def save(data):
    # Écriture atomique : on n'écrase jamais data.json par un fichier à moitié écrit.
    core.DATA_DIR.mkdir(parents=True, exist_ok=True)
    _backup_current()
    tmp = core.DATA_FILE.with_suffix(".json.tmp")
    import json
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, core.DATA_FILE)


def get_settings(data):
    s = data.setdefault("settings", {})
    return {k: s.get(k, v) for k, v in SETTING_DEFAULTS.items()}


def set_settings(data, values):
    s = data.setdefault("settings", {})
    for key, default in SETTING_DEFAULTS.items():
        if key in values:
            try:
                s[key] = _finite(values[key], key)
            except (TypeError, ValueError):
                raise ValueError(f"Valeur invalide pour {key}")
    return get_settings(data)


def years_list():
    return list(range(core.FIRST_YEAR, date.today().year + 1))


def app_state(data):
    return {
        "build": WEB_BUILD,
        "app_build": core.APP_BUILD,
        "today": date.today().isoformat(),
        "years": years_list(),
        "mois": core.MOIS_FR,
        "settings": get_settings(data),
        "rates": core.RATES,
        "accent": {
            "blue": core.ACCENT_BLUE, "indigo": core.ACCENT_INDIGO, "violet": core.ACCENT_VIOLET,
            "purple": core.ACCENT_PURPLE, "orange": core.ACCENT_ORANGE, "red": core.ACCENT_RED,
        },
    }


# --------------------------------------------------------------------------- #
# Objets factices à la place des widgets Qt
# --------------------------------------------------------------------------- #
class _Card:
    def __init__(self, label, color):
        self.label, self.color, self.value = label, color, ""

    def set_value(self, value, color=None):
        self.value = value
        if color:
            self.color = color

    def set_title(self, label):
        self.label = label

    def as_dict(self):
        return {"label": self.label, "value": self.value, "color": self.color}


class _Value:
    def __init__(self, v):
        self.v = v

    def value(self):
        return self.v

    def currentData(self):
        return self.v


class _Html:
    def __init__(self):
        self.html = ""

    def setHtml(self, html):
        self.html = html


def _methods(cls, names):
    return {n: cls.__dict__[n] for n in names}


def _run(cls, method_names, attrs, entry):
    """Instancie un objet factice portant les méthodes d'origine de `cls`
    (sans Qt) et appelle `entry`."""
    fake_cls = type("Fake" + cls.__name__, (), _methods(cls, method_names))
    fake = fake_cls()
    for k, v in attrs.items():
        setattr(fake, k, v)
    getattr(fake, entry)()
    return fake


def urssaf_report(data, year):
    s = get_settings(data)
    cards = [
        _Card("Chiffre d'affaires réel", core.ACCENT_BLUE),
        _Card("Charges totales", core.ACCENT_INDIGO),
        _Card("Bénéfice net", core.ACCENT_VIOLET),
        _Card("Cotisations à verser", core.ACCENT_ORANGE),
    ]
    result = _Html()
    _run(
        core.UrssafTab,
        ("compute", "_charges_totales", "_charges_rows", "_rows_table", "_section"),
        {"data": data, "year_spin": _Value(year), "taux_spin": _Value(s["urssaf_taux"]),
         "epargne_spin": _Value(s["urssaf_epargne_retraite"]), "stat_cards": cards, "result": result},
        "compute",
    )
    return {"stats": [c.as_dict() for c in cards], "html": result.html}


def ir_report(data, year):
    s = get_settings(data)
    cards = [
        _Card("Bénéfice net imposable", core.ACCENT_VIOLET),
        _Card("Revenu du foyer", core.ACCENT_BLUE),
        _Card("Impôt brut estimé", core.ACCENT_PURPLE),
        _Card("À provisionner / mois", core.ACCENT_ORANGE),
    ]
    result = _Html()
    _run(
        core.IRTab, ("compute",),
        {"data": data, "year_spin": _Value(year), "taux_urssaf_spin": _Value(s["ir_taux_urssaf"]),
         "autres_spin": _Value(s["ir_autres_revenus"]), "parts_spin": _Value(s["ir_parts"]),
         "stat_cards": cards, "result": result},
        "compute",
    )
    return {"stats": [c.as_dict() for c in cards], "html": result.html}


def _html_safe_copy(data):
    """Copie des données où les textes saisis (client, n° de facture…) sont
    échappés : le rapport TVA les insère tels quels dans du HTML (les
    widgets Qt ne les interprétaient pas comme des balises), alors qu'un
    navigateur le ferait — par exemple pour un nom issu d'une capture OCR."""
    import copy
    import html
    safe = copy.deepcopy(data)
    for kind in ("sales", "purchases"):
        for r in safe.get(kind, []):
            for key in ("tiers", "numero", "statut"):
                if isinstance(r.get(key), str):
                    r[key] = html.escape(r[key])
    safe["client_zone_override"] = {
        html.escape(k): v for k, v in safe.get("client_zone_override", {}).items()
    }
    return safe


def tva_report(data, year, month):
    data = _html_safe_copy(data)
    cards = [
        _Card("TVA collectée — France", core.ACCENT_BLUE),
        _Card("CA Intra-UE (autoliquidation)", core.ACCENT_INDIGO),
        _Card("CA Hors UE (export)", core.ACCENT_VIOLET),
        _Card("TVA nette à verser", core.ACCENT_ORANGE),
    ]
    result = _Html()
    _run(
        core.TvaTab,
        ("compute_summary", "_months_pair", "_selected_year_month", "_month_label", "_effective_zone"),
        {"data": data, "year_spin": _Value(year), "month_combo": _Value(month),
         "stat_cards": cards, "result": result},
        "compute_summary",
    )
    return {"stats": [c.as_dict() for c in cards], "html": result.html}


# --------------------------------------------------------------------------- #
# Factures (équivalent des tableaux InvoiceTab)
# --------------------------------------------------------------------------- #
def _check_kind(kind):
    if kind not in ("sales", "purchases"):
        raise ValueError("Type de facture inconnu")


def invoice_years(data, kind):
    years = set()
    for r in data[kind]:
        try:
            years.add(core.effective_date(r).year)
        except (ValueError, KeyError, TypeError):
            continue
    years.add(date.today().year)
    return sorted(years, reverse=True)


def filter_label(year, month):
    # Même texte que InvoiceTab._filter_label
    if year is None and month is None:
        return "(toutes les factures)"
    if year is None:
        return f"{core.MOIS_FR[month - 1]} (toutes années)"
    if month is None:
        return str(year)
    return f"{core.MOIS_FR[month - 1]} {year}"


def invoices_list(data, kind, year_sel, month_sel):
    _check_kind(kind)

    def matches(r):
        try:
            d = core.effective_date(r)
        except (ValueError, KeyError, TypeError):
            return False
        if year_sel is not None and d.year != year_sel:
            return False
        if month_sel is not None and d.month != month_sel:
            return False
        return True

    filtered = [(i, r) for i, r in enumerate(data[kind]) if matches(r)]
    rows = []
    for idx, r in filtered:
        ttc = r["ht"] + r["tva"]
        date_display = r["date"]
        reaff = r.get("mois_reaffecte")
        if reaff:
            try:
                ry, rm = (int(x) for x in reaff.split("-"))
                date_display = f"{r['date']} → {core.MOIS_FR[rm - 1]} {ry}"
            except (ValueError, IndexError):
                pass
        rows.append({
            "idx": idx,
            "sig": row_sig(r),
            "numero": r.get("numero", ""),
            "date": date_display,
            "statut": r.get("statut", ""),
            "tiers": r["tiers"],
            "zone": r["zone"],
            "ht": core.fmt_amount(r["ht"], suffix=""),
            "rate": f"{r['rate']:g}%".replace(".", ","),
            "tva": core.fmt_amount(r["tva"], suffix=""),
            "ttc": core.fmt_amount(ttc, suffix=""),
            "mois_reaffecte": r.get("mois_reaffecte"),
        })
    label = filter_label(year_sel, month_sel)
    stats = [
        {"label": f"Total HT {label}", "value": core.fmt_amount(sum(r.get("ht", 0.0) for _, r in filtered)),
         "color": core.ACCENT_BLUE if kind == "sales" else core.ACCENT_INDIGO},
        {"label": f"Nombre de factures {label}", "value": str(len(filtered)),
         "color": core.ACCENT_BLUE if kind == "sales" else core.ACCENT_INDIGO},
    ]
    return {"rows": rows, "years": invoice_years(data, kind), "stats": stats,
            "reassign_months": [f"{date.today().year}-{m:02d}" for m in range(1, 13)]}


def _finite(value, label, lo=None, hi=None):
    """float() that refuses nan/inf and out-of-range numbers."""
    import math
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} invalide")
    if not math.isfinite(v) or (lo is not None and v < lo) or (hi is not None and v > hi):
        raise ValueError(f"{label} invalide")
    return v


def row_sig(r):
    """Fingerprint of an invoice row: sent back by the UI with a delete /
    reassign so the action only applies if the row at that index is still the
    one the person was looking at (two tabs, or the desktop app, may have
    changed the list meanwhile)."""
    import hashlib
    raw = "|".join(str(r.get(k, "")) for k in ("numero", "date", "tiers", "zone", "ht", "rate", "tva"))
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def _check_sig(row, sig):
    if sig and sig != row_sig(row):
        raise ValueError("La liste a changé entre-temps : rechargez la page avant de recommencer.")


def add_invoice(data, kind, payload):
    """Équivalent d'InvoiceTab.add_row."""
    _check_kind(kind)
    if not isinstance(payload, dict):
        raise ValueError("Requête invalide")
    date.fromisoformat(payload["date"])
    zone = payload["zone"]
    if zone not in ("FR", "UE", "HORS-UE"):
        raise ValueError("Catégorie invalide")
    ht = _finite(payload["ht"], "Montant HT", -1e9, 1e9)
    rate = _finite(payload.get("rate", 0.0), "Taux de TVA", 0, 100) if zone == "FR" else 0.0
    tiers = str(payload.get("tiers") or "").strip()[:200]
    row = {
        "numero": "",
        "date": payload["date"],
        "statut": "",
        "tiers": tiers,
        "zone": zone,
        "ht": ht,
        "rate": rate,
        "tva": round(ht * rate / 100, 2),
    }
    data[kind].append(row)
    core.remember_client(data, tiers, zone, rate)


def delete_invoice(data, kind, idx, sig=None):
    _check_kind(kind)
    _check_sig(data[kind][idx], sig)
    del data[kind][idx]


def clear_invoices(data, kind):
    _check_kind(kind)
    data[kind] = []


def reassign_invoice(data, idx, mois, sig=None):
    """Réaffectation d'une facture émise à un mois de l'année en cours
    (champ mois_reaffecte, comme InvoiceTab._open_reassign_dialog)."""
    r = data["sales"][idx]
    _check_sig(r, sig)
    if mois:
        y, m = (int(x) for x in mois.split("-"))
        if y != date.today().year or not 1 <= m <= 12:
            raise ValueError("Le mois doit appartenir à l'année en cours")
        r["mois_reaffecte"] = f"{y}-{m:02d}"
    else:
        r.pop("mois_reaffecte", None)


def import_rows(data, kind, rows):
    """Équivalent d'InvoiceTab.import_rows (déduplication par ocr_id)."""
    existing_ids = set()
    for r in data[kind]:
        for k in core.InvoiceTab.ID_KEYS:
            if r.get(k):
                existing_ids.add(r[k])
    added = 0
    for row in rows:
        ids = [row.get(k) for k in core.InvoiceTab.ID_KEYS if row.get(k)]
        if any(i in existing_ids for i in ids):
            continue
        data[kind].append(row)
        core.remember_client(data, row.get("tiers", ""), row.get("zone", "FR"), row.get("rate", 0.0))
        existing_ids.update(ids)
        added += 1
    return added


# --------------------------------------------------------------------------- #
# TVA : affectation des clients, rapprochement bancaire
# --------------------------------------------------------------------------- #
def tva_clients(data):
    clients = sorted({r.get("tiers") for r in data["sales"] if r.get("tiers")}, key=str.lower)
    overrides = data.get("client_zone_override", {})
    return [{"nom": c, "zone": overrides.get(c)} for c in clients]


def set_client_override(data, client, zone):
    overrides = data.setdefault("client_zone_override", {})
    if zone in (None, ""):
        overrides.pop(client, None)
    elif zone in ("FR", "UE", "HORS-UE"):
        overrides[client] = zone
    else:
        raise ValueError("Zone invalide")


def parse_releve(xlsx_bytes):
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        f.write(xlsx_bytes)
        path = f.name
    try:
        return core.parse_releve_bancaire(path)
    finally:
        os.unlink(path)


def tva_review(data, mouvements, year, month):
    """Équivalent de TvaTab._build_review_table : pour chaque encaissement du
    mois, les factures candidates (exactes, sinon approchées « ≈ »)."""
    current = f"{year:04d}-{month:02d}"
    previous = f"{year - 1:04d}-12" if month == 1 else f"{year:04d}-{month - 1:02d}"
    months = {current, previous}
    deja_traites = set(data.get("mouvements_traites", []))
    rows = [
        m for m in mouvements
        if m["date"][:7] == current and m["sens"] == "credit"
        and core.mouvement_signature(m) not in deja_traites
    ]
    rows.sort(key=lambda m: m["date"])
    out = []
    deja_proposees = set()
    kind = "sales"
    for mv in rows:
        candidates = [i for i in core.find_invoice_matches(data, kind, mv, months) if i not in deja_proposees]
        approx = False
        if not candidates:
            candidates = [i for i in core.find_invoice_matches_approx(data, kind, mv, months)
                          if i not in deja_proposees]
            approx = bool(candidates)
        options = []
        for idx in candidates:
            r = data[kind][idx]
            ttc = r["ht"] + r.get("tva", 0.0)
            prefix = "≈ " if approx else ""
            options.append({
                "idx": idx,
                "label": f"{prefix}{r.get('numero') or '(sans n°)'} — {r['tiers']} — {core.fmt_amount(ttc)}",
            })
        if candidates:
            deja_proposees.add(candidates[0])
        out.append({
            "mouvement": mv,
            "date": mv["date"],
            "libelle": mv["libelle"],
            "montant": core.fmt_amount(mv["montant"]),
            "options": options,
        })
    return out


def tva_validate(data, entries):
    """Équivalent de TvaTab.validate_matches. entries = [{mouvement, idx|None}]."""
    n = 0
    deja_traites = set(data.get("mouvements_traites", []))
    for entry in entries:
        mv = entry["mouvement"]
        idx = entry.get("idx")
        if idx is not None:
            row = data["sales"][idx]
            row["date_encaissement"] = mv["date"]
            row["statut"] = "Encaissée"
            core.remember_client(data, row["tiers"], row["zone"], row.get("rate", 0.0))
            n += 1
        deja_traites.add(core.mouvement_signature(mv))
    data["mouvements_traites"] = sorted(deja_traites)
    return n


# --------------------------------------------------------------------------- #
# Capture d'écran (OCR)
# --------------------------------------------------------------------------- #
def default_checked(kind, row):
    if kind != "sales":
        return True
    statut = (row.get("statut") or "").strip().lower()
    statut_norm = statut.replace("é", "e").replace("è", "e").replace("ê", "e")
    return not any(s.replace("é", "e") in statut_norm for s in core.ScreenshotTab.UNCHECKED_STATUSES)


def ocr_parse(image_bytes, kind, rate):
    """Équivalent de ScreenshotTab.pick_image (après le choix du fichier)."""
    _check_kind(kind)
    with tempfile.NamedTemporaryFile(suffix=".img", delete=False) as f:
        f.write(image_bytes)
        path = f.name
    try:
        lines = core.ocr_extract_lines(path)  # lève RuntimeError si OCR indisponible
    finally:
        os.unlink(path)
    parsed = []
    for i, line in enumerate(lines):
        row = core.parse_invoice_line(line, kind=kind)
        if not row:
            continue
        row["ocr_id"] = f"{row['ocr_id']}-{i}"
        if row.get("currency") == "USD":
            row["original_ht"] = row["ht"]
            row["original_tva"] = row["tva"]
            row["ht"] = round(row["ht"] * rate, 2)
            row["tva"] = round(row["tva"] * rate, 2)
            row["devise_note"] = f"$ → € ({rate:.4f})"
        else:
            row["devise_note"] = "€"
        parsed.append(row)
    out = []
    for row in parsed:
        out.append({
            "checked": default_checked(kind, row),
            "numero": row.get("numero", ""),
            "date": row["date"],
            "statut": row.get("statut", ""),
            "tiers": row["tiers"],
            "zone": row["zone"],
            "ht": core.fmt_amount(row["ht"], suffix=""),
            "rate": f"{row['rate']:g}",
            "tva": core.fmt_amount(row["tva"], suffix=""),
            "ttc": core.fmt_amount(row["ht"] + row["tva"], suffix=""),
            "devise": row.get("devise_note", "€"),
            "raw_line": row.get("raw_line", ""),
            "ocr_id": row.get("ocr_id"),
            "suspect": not core.is_plausible_rate(row["rate"]),
        })
    n_usd = sum(1 for r in parsed if r.get("currency") == "USD")
    n_uncheck = sum(1 for r in out if not r["checked"])
    n_suspect = sum(1 for r in out if r["suspect"])
    if not out:
        status = "Aucune ligne ressemblant à une facture n'a été détectée (ni date, ni montant reconnu)."
    else:
        extra = f" (dont {n_usd} en dollars, converti(s) en euros)" if n_usd else ""
        extra_uncheck = (f" ({n_uncheck} avoir(s)/facture(s) annulée(s) décoché(s) par défaut)"
                         if n_uncheck else "")
        extra_suspect = (f" ⚠ {n_suspect} ligne(s) surlignée(s) en orange à vérifier (taux de TVA "
                         "inhabituel, probablement un montant mal reconnu par l'OCR)."
                         if n_suspect else "")
        status = (f"{len(out)} ligne(s) détectée(s){extra}{extra_uncheck} — "
                  f"vérifiez et corrigez avant d'ajouter.{extra_suspect}")
    return {"rows": out, "status": status}


def row_from_edit(edit):
    """Équivalent de ScreenshotTab._row_from_table (valeurs éventuellement corrigées)."""
    try:
        date.fromisoformat((edit.get("date") or "").strip())
        d = edit["date"].strip()
    except ValueError:
        d = date.today().isoformat()
    tiers = (edit.get("tiers") or "").strip()
    try:
        ht = core.parse_french_number(str(edit.get("ht", "")))
    except ValueError:
        ht = 0.0
    try:
        rate = _finite(str(edit.get("rate", "")).replace(",", ".").strip(), "taux", 0, 100)
    except ValueError:
        rate = 0.0
    zone = (edit.get("zone") or "").strip().upper()
    if zone not in ("FR", "UE", "HORS-UE"):
        zone = "FR"
    if zone != "FR":
        rate = 0.0
    return {
        "numero": (edit.get("numero") or "").strip(),
        "date": d,
        "statut": (edit.get("statut") or "").strip(),
        "tiers": tiers,
        "zone": zone,
        "ht": round(ht, 2),
        "rate": rate,
        "tva": round(ht * rate / 100, 2),
        "ocr_id": edit.get("ocr_id"),
    }


# --------------------------------------------------------------------------- #
# Graphique : mêmes calculs que ChartTab, renvoyés sous forme de séries
# --------------------------------------------------------------------------- #
def _pt(i, v, label=True):
    return {"x": i, "y": v, "label": core.fmt_amount(v, 0) if label else None}


def _line(name, color, points, dashed=False):
    return {"name": name, "color": color, "dashed": dashed, "points": points}


def _axis(values):
    mx, mn = max(values), min(values)
    return {"ymin": min(0, mn * 1.15), "ymax": mx * 1.15 if mx > 0 else 1}


def chart_report(data, mode, year, show_forecast=True):
    s = get_settings(data)
    taux_urssaf_graph = s["urssaf_taux"]

    def ir_monthly(y):
        annual = core.annual_ir_forecast(data, y, s["ir_taux_urssaf"], s["ir_autres_revenus"], s["ir_parts"])
        return round(annual / 12, 2)

    if mode == "compare":
        return _chart_compare(data, year, taux_urssaf_graph, ir_monthly(year))
    if mode == "par_type":
        return _chart_par_type(data, year)

    # --- Vue « Année en cours » (ChartTab.compute) ---
    revenus_reels = core.monthly_totals_for_year(data["sales"], year)
    depenses_reelles = core.monthly_totals_for_year(data["purchases"], year)
    revenus_reels = core.chart_spread_patreon_2025(data["sales"], year, revenus_reels)
    if show_forecast:
        revenus, premier_mois_estime = core.forecast_monthly_series(data["sales"], year)
        depenses, _ = core.forecast_monthly_series(data["purchases"], year)
        revenus = core.chart_spread_patreon_2025(data["sales"], year, revenus)
    else:
        revenus, premier_mois_estime = revenus_reels, 12
        depenses = depenses_reelles
    last_active = premier_mois_estime - 1

    urssaf_mensuel = [
        round(max(revenus[i] - depenses[i], 0) * taux_urssaf_graph / 100, 2) for i in range(12)
    ]
    ir_mensuel = ir_monthly(year)
    benefice_net = [
        round(revenus[i] - depenses[i] - urssaf_mensuel[i] - ir_mensuel, 2) for i in range(12)
    ]

    cards = [
        _Card("CA prévisionnel", core.ACCENT_BLUE),
        _Card("Dépenses prévisionnelles", core.ACCENT_INDIGO),
        _Card("Charges prévisionnelles", core.ACCENT_ORANGE),
        _Card("Bénéfice net prévisionnel", core.ACCENT_VIOLET),
    ]
    cards[0].set_value(f"{core.fmt_amount(sum(revenus))}")
    cards[1].set_value(f"{core.fmt_amount(sum(depenses))}")
    charges_prev = sum(urssaf_mensuel) + ir_mensuel * 12
    cards[2].set_value(f"{core.fmt_amount(charges_prev)}")
    total_benefice = sum(benefice_net)
    cards[3].set_value(
        f"{core.fmt_amount(total_benefice)}",
        color=core.ACCENT_VIOLET if total_benefice >= 0 else core.ACCENT_RED,
    )

    series = []

    def add_split_line(name, color, values_reel, values_complet, forecast_suffix):
        if last_active >= 0:
            pts = []
            for i in range(last_active + 1):
                pts.append(_pt(i, round(values_reel[i])))
            series.append(_line(name, color, pts))
        if premier_mois_estime < 12:
            pts = []
            if last_active >= 0:
                pts.append(_pt(last_active, round(values_reel[last_active]), label=False))
            for i in range(premier_mois_estime, 12):
                pts.append(_pt(i, round(values_complet[i])))
            series.append(_line(f"{name} {forecast_suffix}", color, pts, dashed=True))

    add_split_line("Revenus (HT)", core.CHART_BLUE, revenus_reels, revenus, "(prévus)")
    add_split_line("Dépenses (HT)", core.CHART_INDIGO, depenses_reelles, depenses, "(prévues)")
    urssaf_reel = [
        round(max(revenus_reels[i] - depenses_reelles[i], 0) * taux_urssaf_graph / 100, 2)
        for i in range(12)
    ]
    add_split_line("Provision URSSAF (mensuelle)", core.CHART_ORANGE, urssaf_reel, urssaf_mensuel, "(prévue)")
    benefice_net_reel = [
        round(revenus_reels[i] - depenses_reelles[i] - urssaf_reel[i] - ir_mensuel, 2) for i in range(12)
    ]
    add_split_line("Bénéfice net", core.CHART_VIOLET, benefice_net_reel, benefice_net, "(prévu)")
    series.append(_line(
        "Provision impôt sur le revenu (mensuelle, prévisionnelle)", core.CHART_RED,
        [_pt(i, round(ir_mensuel)) for i in range(12)], dashed=True,
    ))

    all_values = revenus + depenses + urssaf_mensuel + benefice_net + [ir_mensuel, 0]
    return {
        "title": f"Suivi financier par mois — {year}",
        "categories": core.MONTH_LABELS,
        "series": series,
        "stats": [c.as_dict() for c in cards],
        **_axis(all_values),
    }


def _chart_compare(data, year, taux_urssaf_graph, ir_mensuel):
    year_prev = year - 1
    revenus = core.monthly_totals_for_year(data["sales"], year)
    revenus = core.chart_spread_patreon_2025(data["sales"], year, revenus)
    revenus_prev = core.monthly_totals_for_year(data["sales"], year_prev)
    revenus_prev = core.chart_spread_patreon_2025(data["sales"], year_prev, revenus_prev)
    depenses = core.monthly_totals_for_year(data["purchases"], year)
    depenses_prev = core.monthly_totals_for_year(data["purchases"], year_prev)

    def urssaf_mensuel_pour(revs, deps):
        return [round(max(revs[i] - deps[i], 0) * taux_urssaf_graph / 100, 2) for i in range(12)]

    urssaf_mensuel = urssaf_mensuel_pour(revenus, depenses)
    urssaf_mensuel_prev = urssaf_mensuel_pour(revenus_prev, depenses_prev)
    benefice = [round(revenus[i] - depenses[i] - urssaf_mensuel[i] - ir_mensuel, 2) for i in range(12)]
    benefice_prev = [
        round(revenus_prev[i] - depenses_prev[i] - urssaf_mensuel_prev[i] - ir_mensuel, 2)
        for i in range(12)
    ]

    def add_line(name, color, values, dashed=False):
        return _line(name, color, [_pt(i, round(values[i])) for i in range(12)], dashed)

    series = [
        add_line(f"Revenus HT {year}", core.CHART_BLUE, revenus),
        add_line(f"Revenus HT {year_prev}", core.CHART_TEAL, revenus_prev, dashed=True),
        add_line(f"Bénéfice net {year}", core.CHART_VIOLET, benefice),
        add_line(f"Bénéfice net {year_prev}", core.CHART_RED, benefice_prev, dashed=True),
    ]
    all_values = revenus + revenus_prev + benefice + benefice_prev + [0]
    return {
        "title": f"Comparatif {year_prev} / {year} — revenus et bénéfice net par mois",
        "categories": core.MONTH_LABELS, "series": series, "stats": None, **_axis(all_values),
    }


def _chart_par_type(data, year):
    par_categorie = {}
    for cat in core.REVENU_CATEGORIES:
        records = [r for r in data["sales"] if core.categorize_revenu(r.get("tiers")) == cat]
        totals = core.monthly_totals_for_year(records, year)
        if cat == "Abonnements":
            totals = core.chart_spread_patreon_2025(records, year, totals)
        par_categorie[cat] = totals
    colors = [core.CHART_BLUE, core.CHART_VIOLET, core.CHART_ORANGE, core.CHART_GREEN]
    series = [
        _line(cat, color, [_pt(i, round(par_categorie[cat][i])) for i in range(12)])
        for cat, color in zip(core.REVENU_CATEGORIES, colors)
    ]
    all_values = [v for values in par_categorie.values() for v in values] + [0]
    return {
        "title": f"Revenus par catégorie — {year}",
        "categories": core.MONTH_LABELS, "series": series, "stats": None, **_axis(all_values),
    }
