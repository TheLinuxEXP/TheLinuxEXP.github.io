"""Onglet « Facture Nico » : saisie mensuelle et calcul de la part de revenu de Nico.

Les données vivent dans nico.json, À CÔTÉ de data.json (même dossier), pour ne jamais toucher aux données
fiscales ni au fichier partagé avec l'application KDE. Les montants sont gérés en Decimal (arrondi au centime,
demi vers le haut) ; les vues sont des entiers.

    Part Revenu Nico = Revenu Playlist Nico × 0,5
                     + (Vues Playlist Nico ÷ Vues Totales Mois) × Revenu MyHobbyPlace × 0,5
                     + Tipee Mensuel × 0,5
    Revenu Total Chaîne = Revenu MyHobbyPlace + Tipee Mensuel + Revenu Total Mois
"""
from __future__ import annotations
import json
import os
import re
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path

MONEY = ("rev_playlist", "rev_total", "rev_mhp", "tipee")
VIEWS = ("views_playlist", "views_total")
FIELDS = ("rev_playlist", "rev_total", "views_playlist", "views_total", "rev_mhp", "tipee")
LABELS = {
    "rev_playlist": "Revenu Playlist Nico", "rev_total": "Revenu Total Mois",
    "views_playlist": "Vues Playlist Nico", "views_total": "Vues Totales Mois",
    "rev_mhp": "Revenu MyHobbyPlace", "tipee": "Tipee Mensuel",
}
MONTHS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août",
             "Septembre", "Octobre", "Novembre", "Décembre"]
_MONTH = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
CENT = Decimal("0.01")


def file_path(data_dir) -> Path:
    return Path(data_dir) / "nico.json"


def check_month(m) -> str:
    if not isinstance(m, str) or not _MONTH.match(m):
        raise ValueError("Mois invalide (attendu : AAAA-MM).")
    return m


def load(data_dir) -> dict:
    f = file_path(data_dir)
    if not f.exists():
        return {}
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise RuntimeError(f"nico.json est illisible ({e}). Rien n'a été modifié.")
    return d.get("months", {}) if isinstance(d, dict) else {}


def save(data_dir, months: dict) -> None:
    f = file_path(data_dir)
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".json.tmp")
    tmp.write_text(json.dumps({"months": months}, indent=2, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    os.replace(tmp, f)


def _dec(v, field) -> Decimal:
    if v is None or (isinstance(v, str) and not v.strip()):
        return Decimal(0)
    try:
        d = Decimal(str(v).replace(" ", "").replace("\xa0", "").replace(" ", "").replace(",", "."))
    except InvalidOperation:
        raise ValueError(f"« {LABELS[field]} » : nombre invalide.")
    if not d.is_finite() or d < 0:
        raise ValueError(f"« {LABELS[field]} » : un nombre positif est attendu.")
    if d > Decimal("1e12"):
        raise ValueError(f"« {LABELS[field]} » : valeur trop grande.")
    return d


def clean(body: dict) -> dict:
    """Valide les 6 champs saisis : montants arrondis au centime, vues entières."""
    out = {}
    for f in FIELDS:
        d = _dec((body or {}).get(f), f)
        if f in VIEWS:
            if d != d.to_integral_value():
                raise ValueError(f"« {LABELS[f]} » : un nombre entier est attendu.")
            out[f] = int(d)
        else:
            out[f] = float(d.quantize(CENT, ROUND_HALF_UP))
    if out["views_playlist"] > out["views_total"]:
        raise ValueError("« Vues Playlist Nico » ne peut pas dépasser « Vues Totales Mois ».")
    return out


def _c(x: Decimal) -> float:
    return float(x.quantize(CENT, ROUND_HALF_UP))


def compute(v: dict) -> dict:
    rp, rt, rm, tp = (Decimal(str(v.get(k) or 0)) for k in ("rev_playlist", "rev_total", "rev_mhp", "tipee"))
    vp, vt = Decimal(str(v.get("views_playlist") or 0)), Decimal(str(v.get("views_total") or 0))
    ratio = (vp / vt) if vt > 0 else Decimal(0)
    part = (rp + ratio * rm + tp) * Decimal("0.5")
    chain = rm + tp + rt
    return {"part_nico": _c(part), "total_chaine": _c(chain),
            "pct": _c(part / chain * 100) if chain > 0 else 0.0,
            "part_playlist": _c(rp * Decimal("0.5")), "part_mhp": _c(ratio * rm * Decimal("0.5")),
            "part_tipee": _c(tp * Decimal("0.5"))}


def month_view(months: dict, month: str) -> dict:
    check_month(month)
    v = months.get(month)
    return {"month": month, "values": v, "computed": compute(v) if v else None,
            "months_with_data": sorted(months)}


def year_rows(months: dict, year: int) -> list:
    rows = []
    for m in range(1, 13):
        key = f"{year:04d}-{m:02d}"
        if key in months:
            c = compute(months[key])
            rows.append({"month": key, "label": MONTHS_FR[m - 1], "part_nico": c["part_nico"], "total_chaine": c["total_chaine"]})
    return rows


def chart(months: dict, year: int, accent_a="#8d5fd3", accent_b="#3daee9") -> dict:
    nf = lambda x: f"{x:,.0f}".replace(",", " ")
    pn, tc, vals = [], [], [0.0]
    for r in year_rows(months, year):
        i = int(r["month"][5:]) - 1
        pn.append({"x": i, "y": r["part_nico"], "label": nf(r["part_nico"])})
        tc.append({"x": i, "y": r["total_chaine"], "label": nf(r["total_chaine"])})
        vals += [r["part_nico"], r["total_chaine"]]
    mx = max(vals)
    return {"title": f"Part de Nico vs revenu total de la chaîne — {year}",
            "categories": ["Janv.", "Févr.", "Mars", "Avr.", "Mai", "Juin", "Juil.", "Août", "Sept.", "Oct.", "Nov.", "Déc."],
            "series": [{"name": "Revenu total chaîne", "color": accent_b, "dashed": False, "points": tc},
                       {"name": "Part Revenu Nico", "color": accent_a, "dashed": False, "points": pn}],
            "ymin": 0, "ymax": mx * 1.15 if mx > 0 else 1}
