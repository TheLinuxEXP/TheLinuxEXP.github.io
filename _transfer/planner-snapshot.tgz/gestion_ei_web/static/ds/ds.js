/*
 * Planner Design System — comportements (v1)
 * ------------------------------------------------------------------------
 * Complète ds.css. Un seul fichier, sans dépendance, qui s'applique tout seul à la page :
 *
 *   • Listes déroulantes : tout <select> s'ouvre dans un menu au style .ds-menu (celui du menu « ⋯ »
 *     de l'éditeur de notes) au lieu de la liste native du navigateur. La valeur, les événements
 *     « input » / « change » et le clavier (Espace, Alt+↓, F4, flèches, Entrée, Échap, lettres)
 *     fonctionnent comme d'habitude. Garder la liste native pour un <select> : lui ajouter data-native.
 *   • Infobulles : tout attribut title (et tout <title> enfant d'un élément SVG) s'affiche dans une
 *     infobulle .ds-tip au lieu de l'infobulle native. Le title est retiré pendant le survol puis
 *     remis : le DOM reste intact. Pas d'infobulle dans les zones contenteditable. data-tip="…"
 *     fonctionne comme title ; data-ds-notip sur un élément ou un parent désactive les infobulles.
 *   • DS.menu(ancre, éléments, options) : menu flottant réutilisable.
 *       éléments : [{ label, run, active, danger, disabled, indent }, { group: true, label }]
 *       options  : { minWidth, align: "left" | "right", role }
 *     DS.closeMenu() le ferme ; DS.hideTip() masque l'infobulle.
 */
(function () {
  "use strict";
  if (window.DS && window.DS.menu) return;
  const DS = (window.DS = window.DS || {});
  const SVG_NS = "http://www.w3.org/2000/svg";

  /* ------------------------------------------------------------------ *
   * Menu flottant
   * ------------------------------------------------------------------ */
  let current = null;                       // { close, anchor }

  function closeMenu() { if (current) current.close(false); }

  DS.menu = function (anchor, items, opts) {
    opts = opts || {};
    closeMenu();
    hideTip();
    const pop = document.createElement("div");
    pop.className = "ds-menu";
    pop.setAttribute("role", opts.role === "option" ? "listbox" : "menu");
    const openedAt = performance.now();
    const buttons = [];
    for (const it of items) {
      if (it.group) {
        const label = document.createElement("div");
        label.className = "ds-menu-label";
        label.textContent = it.label;
        pop.appendChild(label);
        continue;
      }
      const b = document.createElement("button");
      b.type = "button";
      b.className = "ds-menu-item" + (it.active ? " is-active" : "") + (it.danger ? " danger" : "") + (it.indent ? " indent" : "");
      b.textContent = it.label;
      b.disabled = !!it.disabled;
      b.setAttribute("role", opts.role || "menuitem");
      if (opts.role === "option") b.setAttribute("aria-selected", it.active ? "true" : "false");
      b.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.detail === 0 && performance.now() - openedAt < 300) return;     // the key press that opened the menu
        close(true);
        if (it.run) it.run();
      });
      pop.appendChild(b);
      buttons.push(b);
    }
    document.body.appendChild(pop);

    // position: under the anchor (above when there is no room), kept inside the window
    const r = anchor.getBoundingClientRect();
    if (opts.minWidth) pop.style.minWidth = Math.round(opts.minWidth) + "px";
    const w = pop.offsetWidth, h = pop.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
    let top = r.bottom + 4;
    if (top + h > vh - 8 && r.top - 4 - h >= 8) top = r.top - 4 - h;
    if (top + h > vh - 8) { top = Math.max(8, vh - 8 - h); pop.style.maxHeight = (vh - 16) + "px"; }
    let left = opts.align === "right" ? r.right - w : r.left;
    left = Math.min(Math.max(8, left), Math.max(8, vw - w - 8));
    pop.style.top = Math.round(top) + "px";
    pop.style.left = Math.round(left) + "px";

    const active = pop.querySelector(".is-active") || buttons.find((b) => !b.disabled);
    if (active) { try { active.focus({ preventScroll: true }); } catch (e) { /* ignore */ } active.scrollIntoView({ block: "nearest" }); }

    const enabled = () => buttons.filter((b) => !b.disabled);
    const onDown = (e) => { if (!pop.contains(e.target)) close(false); };
    const onScroll = (e) => { if (!pop.contains(e.target)) close(false); };
    const onResize = () => close(false);
    let typed = "", typedAt = 0;
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(true); return; }
      if (e.key === "Tab") { close(false); return; }
      const list = enabled();
      if (!list.length) return;
      const at = list.indexOf(document.activeElement);
      let next = null;
      if (e.key === "ArrowDown") next = list[(at + 1) % list.length];
      else if (e.key === "ArrowUp") next = list[(at - 1 + list.length) % list.length];
      else if (e.key === "Home") next = list[0];
      else if (e.key === "End") next = list[list.length - 1];
      else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey && e.key !== " ") {       // type-ahead
        const now = performance.now();
        typed = (now - typedAt > 700 ? "" : typed) + e.key.toLowerCase();
        typedAt = now;
        const from = typed.length === 1 ? at + 1 : at;
        next = list.slice(from).concat(list.slice(0, from)).find((b) => b.textContent.trim().toLowerCase().startsWith(typed)) || null;
      } else return;
      e.preventDefault();
      e.stopPropagation();
      if (next) next.focus({ preventScroll: true }), next.scrollIntoView({ block: "nearest" });
    };
    document.addEventListener("mousedown", onDown, true);
    document.addEventListener("keydown", onKey, true);
    window.addEventListener("scroll", onScroll, true);
    window.addEventListener("resize", onResize);

    function close(refocus) {
      document.removeEventListener("mousedown", onDown, true);
      document.removeEventListener("keydown", onKey, true);
      window.removeEventListener("scroll", onScroll, true);
      window.removeEventListener("resize", onResize);
      pop.remove();
      if (current && current.pop === pop) current = null;
      if (refocus && anchor.isConnected) { try { anchor.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
    }
    current = { close, anchor, pop };
    return { pop, close: () => close(false) };
  };
  DS.closeMenu = closeMenu;

  /* ------------------------------------------------------------------ *
   * Listes déroulantes (<select>)
   * ------------------------------------------------------------------ */
  const skinnable = (sel) => !sel.disabled && !sel.multiple && !(sel.size > 1) && !sel.hasAttribute("data-native");

  function choose(sel, index) {
    if (sel.selectedIndex === index) return;
    sel.selectedIndex = index;
    sel.dispatchEvent(new Event("input", { bubbles: true }));
    sel.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function openSelect(sel) {
    if (current && current.anchor === sel) { closeMenu(); return; }
    const items = [];
    const walk = (node, indent) => {
      for (const c of node.children) {
        if (c.hidden) continue;
        if (c.tagName === "OPTGROUP") { items.push({ group: true, label: c.label }); walk(c, true); }
        else if (c.tagName === "OPTION") {
          items.push({
            label: c.textContent.replace(/\s+/g, " ").trim() || " ",
            active: c.selected, disabled: c.disabled || (c.parentNode.tagName === "OPTGROUP" && c.parentNode.disabled),
            indent, run: () => choose(sel, c.index),
          });
        }
      }
    };
    walk(sel, false);
    DS.menu(sel, items, { role: "option", minWidth: sel.getBoundingClientRect().width, align: "left" });
  }

  document.addEventListener("mousedown", (e) => {
    const sel = e.target instanceof Element ? e.target.closest("select") : null;
    if (!sel || e.button !== 0 || !skinnable(sel)) return;
    e.preventDefault();                                   // no native list
    try { sel.focus({ preventScroll: true }); } catch (err) { /* ignore */ }
    openSelect(sel);
  }, true);

  document.addEventListener("keydown", (e) => {
    const sel = e.target instanceof Element && e.target.tagName === "SELECT" ? e.target : null;
    if (!sel || current || !skinnable(sel)) return;
    if (e.key === " " || e.key === "F4" || (e.altKey && (e.key === "ArrowDown" || e.key === "ArrowUp"))) {
      e.preventDefault();
      openSelect(sel);
    }
  }, true);

  /* ------------------------------------------------------------------ *
   * Infobulles
   * ------------------------------------------------------------------ */
  const noHover = window.matchMedia && matchMedia("(hover: none)").matches;
  let tip = null;                       // the .ds-tip element while shown
  let state = null;                     // { el, text, restore, timer, watch }

  function holderOf(start) {
    for (let n = start; n && n.nodeType === 1; n = n.parentElement) {
      if (n.hasAttribute("data-ds-notip")) return null;
      if (n.isContentEditable || n.getAttribute("contenteditable") === "true") return null;
      if (n.hasAttribute("title")) {
        const text = n.getAttribute("title");
        if (!text.trim()) return null;                    // title="" switches the tooltip off, as in browsers
        return { el: n, text, restore: () => { if (!n.hasAttribute("title")) n.setAttribute("title", text); } };
      }
      if (n.hasAttribute("data-tip") && n.getAttribute("data-tip").trim()) return { el: n, text: n.getAttribute("data-tip"), restore: () => {} };
      if (n.namespaceURI === SVG_NS) {
        const t = Array.prototype.find.call(n.children, (c) => c.localName === "title");
        if (t && t.textContent.trim()) return { el: n, text: t.textContent, svgTitle: t, restore: () => { if (!t.parentNode) n.insertBefore(t, n.firstChild); } };
      }
    }
    return null;
  }

  function arm(h, delay) {
    hideTip();
    state = h;
    h.el.removeAttribute("title");                          // no native tooltip: ours replaces it
    if (h.svgTitle) h.svgTitle.remove();
    if (!h.el.hasAttribute("aria-label") && !h.el.textContent.trim() && h.el.namespaceURI !== SVG_NS) h.el.setAttribute("aria-label", h.text);
    h.timer = setTimeout(() => show(h), delay);
  }

  function show(h) {
    if (state !== h || !h.el.isConnected) return hideTip();
    tip = document.createElement("div");
    tip.className = "ds-tip";
    tip.setAttribute("role", "tooltip");
    tip.textContent = h.text;
    document.body.appendChild(tip);
    const r = h.el.getBoundingClientRect();
    const w = tip.offsetWidth, ht = tip.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
    const below = r.bottom + 8 + ht <= vh - 6 || r.top - 8 - ht < 6;
    const top = below ? r.bottom + 8 : r.top - 8 - ht;
    const left = Math.min(Math.max(6, r.left + r.width / 2 - w / 2), Math.max(6, vw - w - 6));
    tip.style.top = Math.round(top) + "px";
    tip.style.left = Math.round(left) + "px";
    tip.style.setProperty("--ds-tip-arrow", Math.round(Math.min(Math.max(12, r.left + r.width / 2 - left), w - 12)) + "px");
    tip.classList.add(below ? "below" : "above");
    requestAnimationFrame(() => { if (tip) tip.classList.add("show"); });
    h.watch = setInterval(() => {
      if (!h.el.isConnected || !(h.el.matches(":hover") || h.el.matches(":focus-visible"))) hideTip();
    }, 250);
  }

  function hideTip() {
    if (state) {
      clearTimeout(state.timer);
      clearInterval(state.watch);
      state.restore();
      state = null;
    }
    if (tip) { tip.remove(); tip = null; }
  }
  DS.hideTip = hideTip;

  if (!noHover) {
    document.addEventListener("mouseover", (e) => {
      if (!(e.target instanceof Element)) return;
      if (state && state.el.contains(e.target)) return;      // still on the same element
      const h = holderOf(e.target);
      if (!h) { hideTip(); return; }
      arm(h, tip ? 60 : 450);
    });
    document.addEventListener("mouseout", (e) => {
      if (state && !(e.relatedTarget instanceof Node && state.el.contains(e.relatedTarget))) hideTip();
    });
  }
  document.addEventListener("focusin", (e) => {
    if (!(e.target instanceof Element) || !e.target.matches(":focus-visible")) return;
    const h = holderOf(e.target);
    if (h) arm(h, 250);
  });
  document.addEventListener("focusout", hideTip);
  document.addEventListener("mousedown", hideTip, true);
  document.addEventListener("keydown", (e) => { if (e.key !== "Tab") hideTip(); }, true);
  document.addEventListener("dragstart", hideTip, true);
  window.addEventListener("scroll", hideTip, true);
  window.addEventListener("blur", hideTip);
})();
