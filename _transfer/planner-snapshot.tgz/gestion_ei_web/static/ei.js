/*
 * Gestion fiscale EI — interface web.
 *
 * Reproduit l'application KDE (mêmes 7 onglets, mêmes barres d'outils, mêmes
 * pavés de synthèse, mêmes tableaux et boîtes de dialogue). Tous les calculs
 * sont faits côté serveur, par le code de l'application KDE elle-même ; ce
 * fichier ne fait qu'afficher et envoyer des actions.
 *
 * Un seul objet global : window.GestionEI.
 *   GestionEI.mount(element, { base: "/fiscal", layout: "sidebar" | "tabs",
 *                              themeToggle: true | false })
 * (aucune dépendance, aucun outil de build — comme le Task Planner.)
 */
(function () {
  "use strict";

  /* ------------------------------------------------------------------ */
  /* Utilitaires                                                         */
  /* ------------------------------------------------------------------ */
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (v == null || v === false) continue;
        if (k === "class") el.className = v;
        else if (k === "text") el.textContent = v;
        else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
        else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
        else if (k === "value" || k === "checked" || k === "disabled" || k === "type" || k === "multiple") el[k] = v;
        else el.setAttribute(k, v === true ? "" : v);
      }
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  const ICONS = {
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
    export: '<path d="M12 15V4M8 8l4-4 4 4M4 14v6h16v-6"/>',
    import: '<path d="M12 4v11M8 11l4 4 4-4M4 17v3h16v-3"/>',
    bar: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    bank: '<path d="M3 10 12 4l9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18"/>',
    chartline: '<path d="M3 3v18h18M6 16l4-5 3 3 5-7"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    finance: '<circle cx="12" cy="12" r="9"/><path d="M15.5 9.2a3.6 3.6 0 1 0 0 5.6M8 11h6M8 13h6"/>',
    transfer: '<path d="M4 8h14M14 4l4 4-4 4M20 16H6M10 12l-4 4 4 4"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
    arrow: '<path d="M5 12h13M13 7l5 5-5 5"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.5 3.2-5.5 6.5-5.5s5.9 2 6.5 5.5M16 5a3.5 3.5 0 0 1 0 7M18 14.8c2 .7 3.3 2.5 3.7 5.2"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14-4M4 5v4h4M4 13a8 8 0 0 0 14 4M20 19v-4h-4"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    eye: '<path d="M2.5 12C3.5 10 7 6 12 6s8.5 4 9.5 6c-1 2-4.5 6-9.5 6s-8.5-4-9.5-6z"/><circle cx="12" cy="12" r="3"/>',
    eyeoff: '<path d="M3 3l18 18M10.6 6.2A9.6 9.6 0 0 1 12 6c5 0 8.5 4.2 9.5 6a12 12 0 0 1-2.6 3.1M6.5 7.7C4.4 9 3 11 2.5 12c1 1.9 4.5 6 9.5 6 1.4 0 2.6-.3 3.7-.8"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
    euro: '<path d="M18 6.5A7 7 0 1 0 18 17.5M4 10h10M4 14h10"/>',
    playlist: '<path d="M3 6h13M3 11h13M3 16h7"/><path d="M15 14v6l5-3z"/>',
    heart: '<path d="M12 20s-7-4.4-9-9.2C1.8 7.6 3.7 4.5 7 4.5c2 0 3.4 1 5 3 1.6-2 3-3 5-3 3.3 0 5.2 3.1 4 6.3-2 4.8-9 9.2-9 9.2z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4 4-6 8-6s7.2 2 8 6"/>',
    channel: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="m10 9.5 5 2.5-5 2.5z"/>',
    shop: '<path d="M3 9l1.5-5h15L21 9M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0M5 12v8h14v-8"/>',
    prev: '<path d="M15 5l-7 7 7 7"/>',
    next: '<path d="M9 5l7 7-7 7"/>',
    save: '<path d="M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6"/>',
  };

  function icon(name, size = 16) {
    const span = h("span", { class: "ds-ico" });
    span.innerHTML =
      `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" ` +
      `stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ""}</svg>`;
    return span;
  }

  function btn(label, iconName, onclick, extra) {
    return h("button", Object.assign({ class: "ds-btn", type: "button", onclick }, extra || {}),
      iconName ? icon(iconName) : null, label ? h("span", { text: label }) : null);
  }

  function btnP(...a) { const b = btn(...a); b.classList.add("primary"); return b; }

  function select(options, value, onchange) {
    const sel = h("select", { class: "ds-select" },
      options.map(([val, label]) => h("option", { value: String(val), text: label })));
    if (value !== undefined && value !== null) sel.value = String(value);
    if (onchange) sel.addEventListener("change", () => onchange(sel.value));
    return sel;
  }

  function group(title, ...kids) {
    return h("fieldset", { class: "ds-group" }, h("legend", { text: title }), kids);
  }

  function field(label, control) {
    return h("label", { class: "ds-field" }, h("span", { text: label }), control);
  }

  /* Habillage des rapports HTML produits par le code de l'application KDE :
     les bandeaux de section (aplat de couleur, texte blanc) deviennent des
     tuiles teintées du Design System. Seule la présentation change ; les
     textes et les montants ne sont pas touchés. */
  function restyleReport(html) {
    return html.replace(
      /<table([^>]*?)style='background-color:(#[0-9a-fA-F]{6});border-radius:6px;'>([\s\S]*?)<\/table>/g,
      (_, attrs, tone, inner) => {
        inner = inner.replace(/color:white;/g, "").replace(/src='data:image\/svg\+xml;base64,([^']+)'/g, (m, b64) => {
          try { return `src='data:image/svg+xml;base64,${btoa(atob(b64).replace(/white/g, tone))}'`; } catch (_) { return m; }
        });
        return `<table${attrs}class='ei-banner' style='--tone:${tone};'>${inner}</table>`;
      });
  }

  function debounce(fn, ms) {
    let t;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  }

  const fmtRate = (r) => `${r}%`.replace(".0%", "%").replace(".", ",");

  /* ------------------------------------------------------------------ */
  /* Pavés de synthèse                                                   */
  /* ------------------------------------------------------------------ */
  function statRow(iconNames) {
    const cards = iconNames.map((ic) => {
      const caption = h("span", { class: "ds-tile-label" });
      const value = h("div", { class: "ds-tile-value", text: "…" });
      const el = h("div", { class: "ds-tile" },
        h("div", { class: "ds-tile-top" }, ic ? icon(ic) : null, caption), value);
      return { el, caption, value };
    });
    const el = h("div", { class: "ei-statrow" }, cards.map((c) => c.el));
    return {
      el,
      set(stats) {
        stats.forEach((s, i) => {
          if (!cards[i]) return;
          cards[i].caption.textContent = s.label;
          cards[i].value.textContent = s.value;
          cards[i].el.style.setProperty("--tone", s.color);
        });
      },
    };
  }

  /* ------------------------------------------------------------------ */
  /* Graphique SVG (reprend l'aspect du QChart sombre de l'application)  */
  /* ------------------------------------------------------------------ */
  const SVGNS = "http://www.w3.org/2000/svg";
  function svg(tag, attrs, text) {
    const el = document.createElementNS(SVGNS, tag);
    for (const [k, v] of Object.entries(attrs || {})) el.setAttribute(k, v);
    if (text !== undefined) el.textContent = text;
    return el;
  }

  function niceTicks(min, max, n = 5) {
    const span = max - min || 1;
    const raw = span / n;
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const norm = raw / mag;
    const step = (norm < 1.5 ? 1 : norm < 3 ? 2 : norm < 7 ? 5 : 10) * mag;
    const ticks = [];
    for (let v = Math.ceil(min / step) * step; v <= max + step * 1e-9; v += step) ticks.push(Math.round(v / step) * step);
    return ticks;
  }

  const nf0 = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 });

  function drawChart(host, data, hidden, onToggle) {
    host.textContent = "";
    const W = Math.max(host.clientWidth, 480);
    const H = Math.max(Math.min(window.innerHeight - 300, 640), 380);
    const m = { top: 46, right: 24, bottom: 34, left: 72 };
    const pw = W - m.left - m.right, ph = H - m.top - m.bottom;
    const s = svg("svg", { width: W, height: H, viewBox: `0 0 ${W} ${H}`, class: "ds-chart-svg" });
    s.append(svg("text", { x: W / 2, y: 28, "text-anchor": "middle", class: "title" }, data.title));

    const y = (v) => m.top + ph - ((v - data.ymin) / (data.ymax - data.ymin)) * ph;
    const band = pw / data.categories.length;
    const x = (i) => m.left + (i + 0.5) * band;

    for (const t of niceTicks(data.ymin, data.ymax)) {
      s.append(svg("line", { x1: m.left, x2: m.left + pw, y1: y(t), y2: y(t), class: "grid" }));
      s.append(svg("text", { x: m.left - 8, y: y(t) + 4, "text-anchor": "end", class: "axis" }, nf0.format(t)));
    }
    s.append(svg("text", {
      x: 16, y: m.top + ph / 2, class: "axis", "text-anchor": "middle",
      transform: `rotate(-90 16 ${m.top + ph / 2})`,
    }, "Montant (€)"));
    data.categories.forEach((c, i) => {
      s.append(svg("line", { x1: m.left + i * band, x2: m.left + i * band, y1: m.top, y2: m.top + ph, class: "grid", opacity: 0.6 }));
      s.append(svg("text", { x: x(i), y: m.top + ph + 20, "text-anchor": "middle", class: "axis" }, c));
    });
    s.append(svg("line", { x1: m.left + 12 * band, x2: m.left + 12 * band, y1: m.top, y2: m.top + ph, class: "grid", opacity: 0.6 }));

    data.series.forEach((ser, si) => {
      if (hidden.has(si)) return;
      const g = svg("g");
      const pts = ser.points.map((p) => `${x(p.x)},${y(p.y)}`).join(" ");
      g.append(svg("polyline", {
        points: pts, fill: "none", stroke: ser.color, "stroke-width": 3,
        "stroke-linejoin": "round", "stroke-linecap": "round", "stroke-dasharray": ser.dashed ? "9 6" : "",
      }));
      ser.points.forEach((p) => {
        g.append(svg("circle", { cx: x(p.x), cy: y(p.y), r: 3.6, fill: ser.color }));
        if (p.label) {
          g.append(svg("text", { x: x(p.x), y: y(p.y) - 10, "text-anchor": "middle", fill: ser.color, "font-size": 10.5 }, p.label));
        }
      });
      s.append(g);
    });
    host.append(s);

    const legend = h("div", { class: "ds-legend" }, data.series.map((ser, si) =>
      h("button", {
        type: "button", class: "ds-legend-item" + (hidden.has(si) ? " off" : ""),
        title: "Cliquer pour afficher/masquer cette courbe", onclick: () => onToggle(si),
      }, h("span", {
        class: "ds-legend-swatch",
        style: { background: ser.dashed ? `repeating-linear-gradient(90deg, ${ser.color} 0 6px, transparent 6px 10px)` : ser.color },
      }), ser.name)));
    host.append(legend);
  }

  /* ------------------------------------------------------------------ */
  /* Application                                                         */
  /* ------------------------------------------------------------------ */
  class App {
    constructor(root, opts) {
      this.root = root;
      this.opts = Object.assign({ base: "/fiscal", layout: "sidebar", themeToggle: false }, opts || {});
      this.tabs = [];
      this.current = -1;
    }

    async api(path, o = {}) {
      const url = new URL(this.opts.base + "/api" + path, location.origin);
      for (const [k, v] of Object.entries(o.query || {})) if (v !== null && v !== undefined) url.searchParams.set(k, v);
      const init = { method: o.method || "GET", headers: { "X-Requested-With": "gestion-ei" } };
      if (o.json !== undefined) { init.body = JSON.stringify(o.json); init.headers["Content-Type"] = "application/json"; }
      else if (o.body !== undefined) { init.body = o.body; init.headers["Content-Type"] = "application/octet-stream"; }
      const resp = await fetch(url, init);
      let data = null;
      try { data = await resp.json(); } catch (_) { /* corps vide */ }
      if (!resp.ok) throw new Error((data && data.error) || `Erreur ${resp.status}`);
      return data;
    }

    /* --- boîtes de dialogue --- */
    dialog(title, content, o = {}) {
      const dlg = h("dialog", { class: "ds-modal" },
        h("div", { class: "ds-modal-head" }, h("h2", { text: title }),
          h("button", { class: "ds-icon-btn", type: "button", title: "Fermer", onclick: () => dlg.close() }, icon("close"))),
        h("div", { class: "ds-modal-body" }, content),
        o.actions && o.actions.length ? h("div", { class: "ds-modal-foot" }, o.actions) : null);
      if (o.width) dlg.style.width = o.width;
      dlg.addEventListener("close", () => { dlg.remove(); if (o.onclose) o.onclose(); });
      this.shell.append(dlg);
      dlg.showModal();
      return dlg;
    }

    message(text, title = "Information") {
      let dlg;
      const ok = btn("OK", "check", () => dlg.close(), { class: "ds-btn primary" });
      dlg = this.dialog(title, h("p", { text }), { actions: [ok], width: "min(460px, 92vw)" });
    }

    error(err) {
      this.message(err && err.message ? err.message : String(err), "Erreur");
    }

    async guard(fn) {
      try { return await fn(); } catch (e) { this.error(e); return undefined; }
    }

    /* --- construction --- */
    async start() {
      this.root.classList.add("ei-root", "ds-root");
      this.root.textContent = "Chargement…";
      try {
        this.state = await this.api("/state");
      } catch (e) {
        this.root.textContent = "Impossible de joindre le serveur : " + e.message;
        return;
      }
      this.root.textContent = "";
      if (this.opts.layout === "embedded") { this.startEmbedded(); return; }

      this.nav = h("nav", { class: "ds-sidebar ei-nav" });
      this.titleEl = h("h1");
      this.subtitleEl = h("div", { class: "ds-subtitle" });
      this.toolbar = h("div", { class: "ds-actions ei-toolbar" });
      this.pages = h("div", { class: "ds-content ei-pages" });
      this.shell = h("div", { class: "ds-shell ei-shell ei-layout-" + this.opts.layout },
        this.nav,
        h("div", { class: "ds-main ei-main" },
          h("header", { class: "ds-header ei-head" },
            h("div", { class: "ds-title-block" }, this.titleEl, this.subtitleEl)),
          this.toolbar, this.pages,
          h("div", { class: "ds-footnote", text:
            "⚠ Outil d'estimation, pas un logiciel de télédéclaration officiel. " +
            "Vérifiez les montants avec votre expert-comptable avant toute déclaration." })));
      this.root.append(this.shell);

      const sidebarHead = h("div", { class: "ds-sidebar-head ei-sidebar-head" },
        h("span", { class: "ds-brand" }, icon("finance", 18), "Gestion fiscale"));
      this.nav.append(sidebarHead);
      this.themeBtn = null;

      tabDefs().forEach((d, i) => {
        if (d.group) this.nav.append(h("span", { class: "ds-section-label", text: d.group }));
        const tab = this.addTab(d);
        const item = h("button", { class: "ds-row-item", type: "button", onclick: () => this.select(i) },
          icon(d.icon, 16), h("span", { class: "ds-label", text: d.label }));
        this.nav.append(item);
        tab.navItem = item;
      });
      this.finishTabs();

      if (this.opts.themeToggle) {
        sidebarHead.append(h("button", {
          class: "ds-icon-btn ei-nav-theme", type: "button", title: "Changer de thème",
          onclick: () => {
            const cur = document.documentElement.getAttribute("data-theme") ||
              (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
            const next = cur === "dark" ? "light" : "dark";
            document.documentElement.setAttribute("data-theme", next);
            try { localStorage.setItem("taskplanner-theme", next); } catch (_) { /* ignoré */ }
            const t = this.tabs[this.current];
            if (t && t.onResize) t.onResize();
          },
        }, icon("moon", 16)));
      }

    }

    /* Crée un onglet : barre d'outils + page (le bouton de navigation est ajouté par l'appelant). */
    addTab(d) {
      const make = d.make;
      const tab = make.prototype ? new make(this) : make(this);
      tab.id = d.id;
      tab.label = d.label;
      tab.subtitle = d.subtitle;
      tab.toolbarEl = tab.buildToolbar ? tab.buildToolbar() : h("div");
      tab.toolbarEl.classList.add("ei-toolbar-page");
      tab.pageEl = tab.buildPage();
      tab.pageEl.classList.add("ei-page");
      this.toolbar.append(tab.toolbarEl);
      this.pages.append(tab.pageEl);
      this.tabs.push(tab);
      return tab;
    }

    finishTabs() {
      window.addEventListener("resize", debounce(() => {
        const t = this.tabs[this.current];
        if (t && t.onResize && this.root.isConnected) t.onResize();
      }, 150));
      this.select(0);
    }

    /* Variante « embarquée » : une section (Factures, Graphique, Déclarations) dans la page d'une
       application hôte (le Task Planner), sans barre latérale ni titre : l'hôte fournit les siens et
       reçoit le sous-titre via opts.onTitle(titre, sous-titre). */
    startEmbedded() {
      const sec = SECTIONS[this.opts.section] || SECTIONS.factures;
      this.section = sec;
      this.root.classList.add("ei-embedded-root");
      this.toolbar = h("div", { class: "ei-toolbar ei-emb-toolbar" });
      this.pages = h("div", { class: "ei-pages ei-emb-pages" });
      const seg = h("div", { class: "ds-seg" });
      this.shell = h("div", { class: "ds-shell ei-shell ei-layout-embedded" },
        h("div", { class: "ei-emb-bar" }, sec.ids.length > 1 ? seg : null, this.toolbar),
        this.pages,
        h("div", { class: "ds-footnote ei-emb-note", text:
          "⚠ Outil d'estimation, pas un logiciel de télédéclaration officiel. " +
          "Vérifiez les montants avec votre expert-comptable avant toute déclaration." }));
      this.root.append(this.shell);
      sec.ids.map((id) => tabDefs().find((d) => d.id === id)).forEach((d, i) => {
        const tab = this.addTab(d);
        const item = h("button", { type: "button", text: d.short || d.label, onclick: () => this.select(i) });
        seg.append(item);
        tab.navItem = item;
      });
      this.finishTabs();
    }

    /* Rafraîchit l'onglet affiché (données relues sur le serveur). */
    refreshCurrent() {
      const t = this.tabs[this.current];
      if (t && t.refresh) return this.guard(() => t.refresh());
      return undefined;
    }

    select(i) {
      this.current = i;
      this.tabs.forEach((t, j) => {
        t.navItem.classList.toggle("active", i === j);
        t.pageEl.hidden = i !== j;
        t.toolbarEl.hidden = i !== j;
      });
      const t = this.tabs[i];
      if (this.titleEl) {
        this.titleEl.textContent = t.label;
        this.subtitleEl.textContent = t.subtitle || "";
      }
      if (this.opts.onTitle) this.opts.onTitle(this.section ? this.section.title : t.label, t.subtitle || "");
      if (t.refresh) this.guard(() => t.refresh());
    }

    yearOptions() {
      return this.state.years.map((y) => [y, String(y)]);
    }

    async saveSettings(patch) {
      Object.assign(this.state.settings, patch);
      this.state.settings = await this.api("/settings", { method: "POST", json: this.state.settings });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Onglet : Capture d'écran                                            */
  /* ------------------------------------------------------------------ */
  class ScreenshotTab {
    constructor(app) { this.app = app; this.rows = []; this.kind = "sales"; }

    buildToolbar() {
      this.fileInput = h("input", { type: "file", accept: "image/png,image/jpeg,image/bmp,image/webp", hidden: true });
      this.fileInput.addEventListener("change", () => {
        const f = this.fileInput.files[0];
        this.fileInput.value = "";
        if (f) this.app.guard(() => this.parse(f));
      });
      return h("div", { class: "ei-tb" }, h("span", { class: "ds-grow" }),
        btn("Choisir une image…", "image", () => this.fileInput.click()), this.fileInput);
    }

    buildPage() {
      this.kindSel = select([
        ["sales", "Factures émises (ventes) — colonnes : N° facture, Statut, Date d'émission, Client, Montant TTC, Montant HT"],
        ["purchases", "Factures d'achat — colonnes : N° facture, Statut, Date d'émission, Fournisseur, Montant HT, Montant TTC"],
      ], "sales", (v) => { this.kind = v; this.updateAddLabel(); });
      this.rateInput = h("input", { class: "ds-input", type: "number", min: "0.1", max: "5", step: "0.0001", value: "0.92" });
      this.rateStatus = h("div", { class: "ds-muted" });
      this.fileLabel = h("div", { class: "ds-muted", text: "Aucune image sélectionnée" });
      this.tbody = h("tbody");
      this.status = h("div", { class: "ds-muted" });
      this.addBtn = btnP("", "plus", () => this.app.guard(() => this.addChecked()));
      this.rawBtn = btn("Copier les lignes détectées (diagnostic)", "copy", () => this.copyRaw(),
        { title: "Copie dans le presse-papiers le texte brut reconnu par l'OCR pour chaque ligne." });
      this.updateAddLabel();

      return h("div", {},
        h("p", { class: "ei-intro", text:
          "Importez une capture d'écran de votre liste de factures : le texte est reconnu localement par OCR, " +
          "sans envoyer l'image sur Internet. Vérifiez et corrigez chaque ligne avant de l'ajouter — la " +
          "reconnaissance n'est pas toujours parfaite." }),
        group("Type de capture", field("Ces captures contiennent des :", this.kindSel)),
        group("Taux de change USD → EUR (pour les factures en dollars)",
          h("div", { class: "ds-row" }, this.rateInput, h("span", { text: "€ pour 1 $" }),
            btn("Actualiser en ligne", "refresh", () => this.refreshRate())),
          this.rateStatus),
        this.fileLabel,
        h("div", { class: "ds-tablewrap" }, h("table", { class: "ds-table" },
          h("thead", {}, h("tr", {}, ["", "Numéro", "Date", "Statut", "Client / Fournisseur", "Zone",
            "HT (€)", "Taux (%)", "TVA (€)", "TTC (€)", "Devise", "Ligne détectée"].map((c) => h("th", { text: c })))),
          this.tbody)),
        h("div", { class: "ds-row" }, this.rawBtn, h("span", { class: "ds-grow" }), this.addBtn),
        this.status,
        h("p", { class: "ds-muted", text:
          "Nécessite les paquets Python 'Pillow' et 'pytesseract', ainsi que le programme 'tesseract' (avec le " +
          "paquet de langue française) installé sur le système — voir le README. Les montants HT/taux sont une " +
          "estimation à partir des chiffres détectés sur chaque ligne : corrigez-les directement dans le tableau " +
          "si besoin, ainsi que la zone (France/UE/Hors UE). Une fois des lignes ajoutées, la liste ci-dessous " +
          "est vidée pour éviter tout import en double." }));
    }

    updateAddLabel() {
      this.addBtn.querySelector("span:last-child").textContent =
        this.kind === "sales" ? "Ajouter aux factures émises" : "Ajouter aux factures d'achat";
    }

    async refreshRate() {
      this.rateStatus.textContent = "Récupération du taux en cours…";
      const r = await this.app.api("/screenshot/rate");
      if (r.rate) {
        this.rateInput.value = r.rate.toFixed(4);
        this.rateStatus.textContent = `Taux actualisé en ligne : 1 $ = ${r.rate.toFixed(4)} €.`;
      } else {
        this.rateStatus.textContent = "Impossible de récupérer le taux en ligne (pas de connexion ?). Valeur manuelle conservée.";
      }
    }

    refresh() {
      if (!this.rateStatus.textContent) this.rateStatus.textContent = "Valeur par défaut (0.92) — à vérifier ou actualiser.";
    }

    async parse(file) {
      this.fileLabel.textContent = file.name;
      this.status.textContent = "Analyse de l'image en cours…";
      try {
        const res = await this.app.api("/screenshot/parse", {
          method: "POST", body: await file.arrayBuffer(),
          query: { kind: this.kind, rate: this.rateInput.value },
        });
        this.rows = res.rows;
        this.status.textContent = res.status;
        this.renderRows();
      } catch (e) {
        this.status.textContent = "";
        throw e;
      }
    }

    renderRows() {
      this.tbody.textContent = "";
      this.rows.forEach((r) => {
        const chk = h("input", { type: "checkbox", checked: r.checked });
        r.el = {};
        const edit = (key, cls) => {
          const inp = h("input", { class: "ei-cell-input " + (cls || ""), value: r[key] });
          inp.addEventListener("input", () => { r[key] = inp.value; });
          r.el[key] = inp;
          return inp;
        };
        const zoneSel = select([["FR", "FR"], ["UE", "UE"], ["HORS-UE", "HORS-UE"]], r.zone, (v) => { r.zone = v; });
        const warn = r.suspect ? "ei-warn" : "";
        const tip = r.suspect ? "Taux de TVA inhabituel — probablement un montant mal reconnu par l'OCR sur cette ligne. Vérifiez la colonne « Ligne détectée » avant d'ajouter." : "";
        const ro = (txt) => h("td", { class: "ei-ro " + warn, title: tip, text: txt });
        const tr = h("tr", {},
          h("td", {}, chk),
          h("td", {}, edit("numero")), h("td", {}, edit("date")), h("td", {}, edit("statut")),
          h("td", {}, edit("tiers")), h("td", {}, zoneSel),
          h("td", { class: warn, title: tip }, edit("ht", "num")), h("td", { class: warn, title: tip }, edit("rate", "num")),
          ro(r.tva), ro(r.ttc), h("td", { class: "ei-ro", text: r.devise }),
          h("td", { class: "ei-ro ds-muted", title: r.raw_line, text: r.raw_line }));
        chk.addEventListener("change", () => { r.checked = chk.checked; });
        this.tbody.append(tr);
      });
    }

    copyRaw() {
      if (!this.rows.length) {
        this.status.textContent = "Aucune ligne à copier : importez d'abord une capture d'écran.";
        return;
      }
      const text = this.rows.map((r) => r.raw_line || "").join("\n");
      navigator.clipboard.writeText(text).then(() => {
        this.status.textContent = `${this.rows.length} ligne(s) brute(s) copiée(s) dans le presse-papiers.`;
      }, () => { this.status.textContent = "Copie impossible (autorisation du navigateur refusée)."; });
    }

    async addChecked() {
      const rows = this.rows.filter((r) => r.checked);
      if (!rows.length) { this.status.textContent = "Aucune ligne cochée."; return; }
      const res = await this.app.api("/screenshot/add", { method: "POST", json: { kind: this.kind, rows } });
      this.status.textContent = res.status;
      if (res.added !== undefined && rows.length) {
        this.rows = [];
        this.renderRows();
        this.fileLabel.textContent = "Aucune image sélectionnée";
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* Onglet : Factures émises / achats                                   */
  /* ------------------------------------------------------------------ */
  class InvoiceTab {
    constructor(app, kind) {
      this.app = app; this.kind = kind;
      this.year = String(new Date().getFullYear()); // « all » ou une année ; année en cours au départ
      this.month = String(new Date().getMonth() + 1);  // par défaut : mois en cours
    }

    get tiersLabel() { return this.kind === "sales" ? "Client" : "Fournisseur"; }

    buildToolbar() {
      return h("div", { class: "ei-tb" }, h("span", { class: "ds-grow" }),
        btnP("Ajouter une facture", "plus", () => this.openAddDialog()));
    }

    buildPage() {
      this.stats = statRow([this.kind === "sales" ? "export" : "import", null]);
      this.yearSel = select([["all", "Toutes les années"]], this.year, (v) => { this.year = v; this.app.guard(() => this.refresh()); });
      this.monthSel = select([["all", "Tous les mois"], ...this.app.state.mois.map((m, i) => [i + 1, m])], this.month,
        (v) => { this.month = v; this.app.guard(() => this.refresh()); });
      this.tbody = h("tbody");
      const cols = ["Numéro", "Date", "Statut", this.tiersLabel, "Zone", "HT (€)", "Taux", "TVA (€)", "TTC (€)", ""];
      if (this.kind === "sales") cols.push("");
      const label = this.kind === "sales" ? "Factures émises" : "Factures d'achat";
      return h("div", {}, this.stats.el,
        group(label,
          h("div", { class: "ds-row" }, h("span", { text: "Filtrer :" }), this.yearSel, this.monthSel,
            h("span", { class: "ds-grow" }),
            btn("Tout supprimer", "trash", () => this.clearAll())),
          h("div", { class: "ds-tablewrap" }, h("table", { class: "ds-table ds-striped" },
            h("thead", {}, h("tr", {}, cols.map((c) => h("th", { text: c })))), this.tbody))));
    }

    async refresh() {
      const res = await this.app.api("/invoices/" + this.kind, { query: { year: this.year, month: this.month } });
      // Même logique que le filtre Qt : on garde la sélection si elle existe encore, sinon l'année la plus récente.
      const years = res.years.map(String);
      this.yearSel.textContent = "";
      this.yearSel.append(h("option", { value: "all", text: "Toutes les années" }),
        ...years.map((y) => h("option", { value: y, text: y })));
      if (this.year !== "all" && !years.includes(this.year)) {
        this.year = years[0];
        this.month = "all";            // l'année en cours n'a aucune facture : on montre l'année la plus récente en entier
        this.monthSel.value = "all";
        return this.refresh();
      }
      this.yearSel.value = this.year;
      this.stats.set(res.stats);
      this.tbody.textContent = "";
      for (const r of res.rows) {
        const cells = [r.numero, r.date, r.statut, r.tiers, r.zone, r.ht, r.rate, r.tva, r.ttc].map((v, i) =>
          h("td", { class: i >= 5 ? "num" : "", text: v }));
        const actions = [];
        if (this.kind === "sales") {
          actions.push(h("td", { class: "ei-act" }, h("button", {
            class: "ds-icon-btn" + (r.mois_reaffecte ? " on" : ""), type: "button",
            title: "Réaffecter cette facture à un autre mois", onclick: () => this.openReassignDialog(r),
          }, icon("arrow"))));
        }
        actions.push(h("td", { class: "ei-act" }, h("button", {
          class: "ds-icon-btn danger", type: "button", title: "Supprimer",
          onclick: () => this.app.guard(async () => {
            await this.app.api(`/invoices/${this.kind}/${r.idx}`, { method: "DELETE", query: { sig: r.sig } });
            await this.refresh();
          }),
        }, icon("trash"))));
        this.tbody.append(h("tr", {}, cells, actions));
      }
    }

    async clearAll() {
      const res = await this.app.api("/invoices/" + this.kind, { query: { year: "all", month: "all" } });
      const count = res.rows.length;
      if (!count) return;
      const label = this.kind === "sales" ? "factures émises" : "factures d'achat";
      if (!confirm(`Supprimer définitivement les ${count} ${label} ? Cette action est irréversible.`)) return;
      await this.app.api("/invoices/" + this.kind, { method: "DELETE", query: { confirm: 1 } });
      await this.refresh();
    }

    openAddDialog() {
      const st = this.app.state;
      const today = st.today;
      const date = h("input", { class: "ds-input", type: "date", value: today });
      const tiers = h("input", { class: "ds-input", placeholder: "Nom" });
      const zone = select([["FR", "France (TVA applicable)"], ["UE", "Intra UE (exonéré, autoliquidation)"],
        ["HORS-UE", "Hors UE (exonéré / export-import)"]], "FR", () => toggleRate());
      const ht = h("input", { class: "ds-input", type: "number", min: "0", step: "0.01", value: "0" });
      const rate = select(st.rates.map((r) => [r, fmtRate(r)]), st.rates[0]);
      const toggleRate = () => { rate.disabled = zone.value !== "FR"; };
      toggleRate();
      tiers.addEventListener("change", () => this.app.guard(async () => {
        const info = await this.app.api("/client-default", { query: { tiers: tiers.value } });
        if (!info || !info.zone) return;
        zone.value = info.zone;
        toggleRate();
        if (info.zone === "FR") rate.value = String(info.rate);
      }));
      const add = btnP("Ajouter", "plus", () => this.app.guard(async () => {
        await this.app.api("/invoices/" + this.kind, { method: "POST", json: {
          date: date.value, tiers: tiers.value, zone: zone.value, ht: ht.value, rate: rate.value,
        } });
        tiers.value = ""; ht.value = "0";
        await this.refresh();
      }));
      const form = group("Ajouter une facture " + (this.kind === "sales" ? "émise" : "d’achat"),
        field("Date :", date), field(this.tiersLabel + " :", tiers), field("Catégorie :", zone),
        field("Montant HT :", h("span", { class: "ds-row" }, ht, h("span", { text: "€" }))),
        field("Taux de TVA :", rate), add);
      let dlg;
      dlg = this.app.dialog("Ajouter une facture " + (this.kind === "sales" ? "émise" : "d’achat"), form, {
        actions: [btn("Fermer", "close", () => dlg.close())], width: "min(520px, 94vw)",
      });
    }

    openReassignDialog(r) {
      const year = this.app.state.today.slice(0, 4);
      const mois = this.app.state.mois;
      const opts = [["", "Aucune (utiliser la date de la facture)"],
        ...mois.map((m, i) => [`${year}-${String(i + 1).padStart(2, "0")}`, `${m} ${year}`])];
      const sel = select(opts, r.mois_reaffecte || "");
      let dlg;
      const ok = btnP("Valider", "check", () => this.app.guard(async () => {
        await this.app.api(`/invoices/sales/${r.idx}/reassign`, { method: "POST", json: { mois: sel.value || null, sig: r.sig } });
        dlg.close();
        await this.refresh();
      }));
      dlg = this.app.dialog("Réaffectation de facture", h("div", { class: "ds-col" },
        h("p", {}, h("b", { text: r.numero || "(sans numéro)" }), ` — ${r.tiers}`, h("br"),
          `${r.ht} € HT — ${r.date}`),
        h("p", { class: "ds-muted", text:
          "Choisissez le mois de l'année en cours auquel cette facture doit être rattachée pour tous les calculs " +
          "et graphiques (au lieu de sa date de facturation réelle). Ce réglage n'affecte pas la déclaration de " +
          "TVA, basée sur la date d'encaissement." }),
        sel), { actions: [ok], width: "min(520px, 94vw)" });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Onglet : Graphique                                                  */
  /* ------------------------------------------------------------------ */
  class ChartTab {
    constructor(app) {
      this.app = app; this.mode = "current"; this.showForecast = true;
      this.year = app.state.years[app.state.years.length - 1];
      this.hidden = new Set(); this.data = null;
    }

    buildToolbar() {
      this.yearSel = select(this.app.yearOptions(), this.year, (v) => { this.year = +v; this.hidden.clear(); this.app.guard(() => this.refresh()); });
      this.modeSel = select([["current", "Année en cours"], ["compare", "Comparatif"], ["par_type", "Type de revenu"]], this.mode, (v) => {
        this.mode = v; this.hidden.clear();
        this.forecastBtn.hidden = v !== "current";
        this.stats.el.hidden = v !== "current";
        this.app.guard(() => this.refresh());
      });
      this.forecastBtn = btn("Masquer prévisions", "eyeoff", () => {
        this.showForecast = !this.showForecast;
        this.setForecastLabel();
        this.hidden.clear();
        this.app.guard(() => this.refresh());
      });
      return h("div", { class: "ei-tb" }, h("span", {}, "Année : "), this.yearSel, h("span", { class: "ds-grow" }),
        h("span", {}, "Vue : "), this.modeSel, h("span", { class: "ds-grow" }), this.forecastBtn);
    }

    setForecastLabel() {
      this.forecastBtn.textContent = "";
      this.forecastBtn.append(icon(this.showForecast ? "eyeoff" : "eye"),
        h("span", { text: this.showForecast ? "Masquer prévisions" : "Afficher prévisions" }));
    }

    buildPage() {
      this.stats = statRow(["finance", "transfer", "bank", "chartline"]);
      this.host = h("div", { class: "ds-chart-box ei-chart" });
      return h("div", {}, this.stats.el, this.host);
    }

    async refresh() {
      this.data = await this.app.api("/chart", { query: { mode: this.mode, year: this.year, forecast: this.showForecast ? 1 : 0 } });
      if (this.data.stats) this.stats.set(this.data.stats);
      this.draw();
    }

    draw() {
      if (!this.data) return;
      drawChart(this.host, this.data, this.hidden, (si) => {
        if (this.hidden.has(si)) this.hidden.delete(si); else this.hidden.add(si);
        this.draw();
      });
    }

    onResize() { this.draw(); }
  }


  /* ------------------------------------------------------------------ */
  /* Onglet : Facture Nico                                               */
  /* ------------------------------------------------------------------ */
  const eurFmt = new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const numFmt = new Intl.NumberFormat("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const intFmt = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 });
  const NICO_FIELDS = [
    { key: "rev_playlist", label: "Revenu Playlist Nico", icon: "playlist", kind: "eur" },
    { key: "rev_total", label: "Revenu Total Mois", icon: "channel", kind: "eur" },
    { key: "views_playlist", label: "Vues Playlist Nico", icon: "eye", kind: "views" },
    { key: "views_total", label: "Vues Totales Mois", icon: "eye", kind: "views" },
    { key: "rev_mhp", label: "Revenu MyHobbyPlace", icon: "shop", kind: "eur" },
    { key: "tipee", label: "Tipee Mensuel", icon: "heart", kind: "eur" },
  ];

  // « 1 234,56 », « 1234.56 », « 1 234,56 € » -> nombre ; chaîne vide -> 0 ; illisible -> null
  function parseNum(txt) {
    const t = String(txt == null ? "" : txt).replace(/[\s  €]/g, "").replace(",", ".");
    if (t === "") return 0;
    return /^\d*\.?\d+$|^\d+\.$/.test(t) ? Number(t) : null;
  }
  const cents = (x) => Math.round((x + Number.EPSILON) * 100) / 100;

  const NICO_MONTHS = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];

  class NicoTab {
    constructor(app) {
      this.app = app;
      const now = new Date();
      this.month = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
      this.inputs = {};
      this.hidden = new Set();
      this.chartData = null;
      this.hasData = false;
    }

    get year() { return +this.month.slice(0, 4); }

    buildToolbar() {
      // même sélecteur que la page « Revenue » : ‹ Mois Année › + « Aujourd'hui »
      this.monthLabel = h("strong", { class: "ei-nico-monthlabel" });
      const shift = (d) => {
        const [y, m] = this.month.split("-").map(Number);
        const dt = new Date(y, m - 1 + d, 1);
        this.go(`${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}`);
      };
      this.todayBtn = h("button", { type: "button", class: "ds-btn ei-nico-today", onclick: () => this.go(this.nowMonth()) }, h("span", { text: "Aujourd'hui" }));
      this.paintMonth();
      this.deleteBtn = btn("Effacer ce mois", "trash", () => this.app.guard(() => this.remove()));
      return h("div", { class: "ei-tb" },
        h("div", { class: "ei-nico-nav" },
          h("button", { type: "button", class: "ds-icon-btn", title: "Mois précédent", onclick: () => shift(-1) }, "‹"),
          this.monthLabel,
          h("button", { type: "button", class: "ds-icon-btn", title: "Mois suivant", onclick: () => shift(1) }, "›"),
          this.todayBtn),
        h("span", { class: "ds-grow" }), this.deleteBtn,
        btnP("Enregistrer", "save", () => this.app.guard(() => this.save())));
    }

    nowMonth() {
      const n = new Date();
      return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}`;
    }

    paintMonth() {
      const [y, m] = this.month.split("-").map(Number);
      this.monthLabel.textContent = `${NICO_MONTHS[m - 1]} ${y}`;
      const isNow = this.month === this.nowMonth();
      this.todayBtn.style.visibility = isNow ? "hidden" : "";
      this.todayBtn.tabIndex = isNow ? -1 : 0;
    }

    buildPage() {
      this.stats = statRow(["user", "channel", "chartline"]);
      const fields = NICO_FIELDS.map((f) => {
        const inp = h("input", { type: "text", class: "ds-input num ei-nico-input", inputmode: f.kind === "eur" ? "decimal" : "numeric",
          placeholder: f.kind === "eur" ? "0,00" : "0", autocomplete: "off" });
        inp.addEventListener("input", () => this.preview());
        inp.addEventListener("blur", () => this.tidy(f));
        this.inputs[f.key] = inp;
        return h("label", { class: "ds-field ei-nico-field" },
          h("span", { class: "ei-nico-lab" }, icon(f.icon, 15), f.label),
          h("div", { class: "ei-nico-wrap" }, inp, h("em", { text: f.kind === "eur" ? "€" : "vues" })));
      });
      this.note = h("div", { class: "ei-nico-note" });
      this.tbody = h("tbody");
      this.chartHost = h("div", { class: "ds-chart-box ei-chart" });
      return h("div", {},
        this.stats.el,
        group("Saisie du mois", h("div", { class: "ei-nico-grid" }, fields), this.note),
        group("Évolution", this.chartHost),
        group("Historique de l'année", h("div", { class: "ds-tablewrap" }, h("table", { class: "ds-table ds-striped" },
          h("thead", {}, h("tr", {}, [["Mois", ""], ["Part Revenu Nico", "num"], ["Revenu Total Chaîne", "num"]].map(([c, k]) => h("th", { class: k, text: c })))),
          this.tbody))));
    }

    go(month) {
      this.month = month;
      this.paintMonth();
      return this.app.guard(() => this.refresh());
    }

    values() {
      const out = {};
      for (const f of NICO_FIELDS) out[f.key] = parseNum(this.inputs[f.key].value);
      return out;
    }

    tidy(f) {   // remet en forme (séparateurs de milliers, centimes) quand on quitte le champ
      const n = parseNum(this.inputs[f.key].value);
      if (n == null) return;
      if (this.inputs[f.key].value.trim() === "") return;
      this.inputs[f.key].value = f.kind === "eur" ? numFmt.format(cents(n)) : intFmt.format(Math.round(n));
    }

    fill(values) {
      for (const f of NICO_FIELDS) {
        const v = values ? values[f.key] : null;
        this.inputs[f.key].value = v == null ? "" : (f.kind === "eur" ? numFmt.format(v) : intFmt.format(v));
      }
    }

    // Même formule que le serveur (qui fait foi à l'enregistrement) : aperçu en direct pendant la saisie.
    calc(v) {
      const ratio = v.views_total > 0 ? v.views_playlist / v.views_total : 0;
      const part = cents((v.rev_playlist + ratio * v.rev_mhp + v.tipee) * 0.5);
      const chain = cents(v.rev_mhp + v.tipee + v.rev_total);
      return { part_nico: part, total_chaine: chain, pct: chain > 0 ? cents(part / chain * 100) : 0 };
    }

    preview() {
      const v = this.values();
      if (Object.values(v).some((x) => x == null)) { this.note.textContent = "Un des champs n'est pas un nombre valide."; this.note.className = "ei-nico-note bad"; return; }
      const bad = v.views_playlist > v.views_total;
      this.note.textContent = bad ? "Les vues de la playlist dépassent les vues totales du mois." : "";
      this.note.className = "ei-nico-note" + (bad ? " bad" : "");
      this.showStats(this.calc(v), false);
    }

    showStats(c, saved) {
      this.stats.set([
        { label: "Part Revenu Nico", value: eurFmt.format(c.part_nico), color: "#8d5fd3" },
        { label: "Revenu Total Chaîne", value: eurFmt.format(c.total_chaine), color: "#3daee9" },
        { label: saved ? "Part de Nico dans la chaîne" : "Part de Nico (aperçu non enregistré)",
          value: `${numFmt.format(c.pct)} %`, color: "#6c6bcf" },
      ]);
    }

    async refresh() {
      const res = await this.app.api("/nico", { query: { month: this.month } });
      this.hasData = !!res.values;
      this.fill(res.values);
      this.deleteBtn.disabled = !this.hasData;
      this.note.textContent = this.hasData ? "" : "Aucune donnée enregistrée pour ce mois.";
      this.note.className = "ei-nico-note";
      this.showStats(res.computed || this.calc(this.values()), this.hasData);
      await this.loadYear();
    }

    async loadYear() {
      const res = await this.app.api("/nico/year", { query: { year: this.year } });
      this.chartData = res.chart;
      this.tbody.textContent = "";
      if (!res.rows.length) {
        this.tbody.append(h("tr", {}, h("td", { colspan: 3, class: "ei-nico-empty", text: "Rien d'enregistré cette année." })));
      }
      for (const r of res.rows) {
        const tr = h("tr", { class: "ei-nico-row" + (r.month === this.month ? " current" : ""), title: "Afficher ce mois", onclick: () => this.go(r.month) },
          h("td", { text: `${r.label} ${r.month.slice(0, 4)}` }),
          h("td", { class: "num", text: eurFmt.format(r.part_nico) }),
          h("td", { class: "num", text: eurFmt.format(r.total_chaine) }));
        this.tbody.append(tr);
      }
      this.draw();
    }

    draw() {
      if (!this.chartData) return;
      const hasPoints = this.chartData.series.some((s) => s.points.length);
      if (!hasPoints) { this.chartHost.textContent = ""; this.chartHost.append(h("div", { class: "ei-nico-empty", text: "Pas encore de données à tracer pour cette année." })); return; }
      drawChart(this.chartHost, this.chartData, this.hidden, (si) => {
        if (this.hidden.has(si)) this.hidden.delete(si); else this.hidden.add(si);
        this.draw();
      });
    }

    async save() {
      const v = this.values();
      if (Object.values(v).some((x) => x == null)) throw new Error("Un des champs n'est pas un nombre valide.");
      const res = await this.app.api("/nico/" + this.month, { method: "PUT", json: v });
      this.hasData = true;
      this.deleteBtn.disabled = false;
      this.fill(res.values);
      this.note.textContent = "Enregistré.";
      this.note.className = "ei-nico-note ok";
      this.showStats(res.computed, true);
      await this.loadYear();
    }

    async remove() {
      if (!this.hasData) return;
      if (!confirm(`Effacer les données de ${this.month} ?`)) return;
      await this.app.api("/nico/" + this.month, { method: "DELETE" });
      await this.refresh();
    }

    onResize() { this.draw(); }
  }

  /* ------------------------------------------------------------------ */
  /* Onglets : URSSAF et Impôt sur le revenu                             */
  /* ------------------------------------------------------------------ */
  class ReportTab {
    constructor(app, endpoint, icons) {
      this.app = app; this.endpoint = endpoint; this.icons = icons;
      this.year = app.state.years[app.state.years.length - 1];
    }

    buildToolbar() {
      this.yearSel = select(this.app.yearOptions(), this.year, (v) => { this.year = +v; this.app.guard(() => this.refresh()); });
      return h("div", { class: "ei-tb" }, h("span", {}, "Année : "), this.yearSel, h("span", { class: "ds-grow" }),
        btn("Ajuster les valeurs", "gear", () => this.openSettings()));
    }

    buildPage() {
      this.stats = statRow(this.icons);
      this.report = h("div", { class: "ei-report" });
      return h("div", {}, this.stats.el, this.report);
    }

    async refresh() {
      const res = await this.app.api("/" + this.endpoint, { query: { year: this.year } });
      this.stats.set(res.stats);
      this.report.innerHTML = restyleReport(res.html); // HTML produit par le serveur (données saisies échappées côté serveur)
    }

    numberInput(key, min, max, step) {
      const inp = h("input", { class: "ds-input", type: "number", min, max, step, value: this.app.state.settings[key] });
      const save = debounce(() => this.app.guard(async () => {
        const v = parseFloat(inp.value);
        if (Number.isNaN(v)) return;
        await this.app.saveSettings({ [key]: v });
        await this.refresh();
      }), 350);
      inp.addEventListener("input", save);
      inp.addEventListener("change", save);
      return inp;
    }
  }

  class UrssafTab extends ReportTab {
    constructor(app) { super(app, "urssaf", ["finance", "transfer", "chartline", "bank"]); }
    openSettings() {
      let dlg;
      dlg = this.app.dialog("Ajuster les valeurs — URSSAF", h("div", { class: "ds-col" },
        field("Taux global de cotisations sociales (%) :", this.numberInput("urssaf_taux", 0, 100, 1)),
        field("Épargne retraite versée (loi Madelin, annuel) (€) :", this.numberInput("urssaf_epargne_retraite", 0, 1000000, 1))),
      { actions: [btn("Fermer", "close", () => dlg.close())], width: "min(540px, 94vw)" });
    }
  }

  class IrTab extends ReportTab {
    constructor(app) { super(app, "ir", ["chartline", "finance", "calendar", "bank"]); }
    openSettings() {
      let dlg;
      dlg = this.app.dialog("Ajuster les valeurs — Impôt sur le revenu", h("div", { class: "ds-col" },
        field("Taux de cotisations sociales (déduites du bénéfice) (%) :", this.numberInput("ir_taux_urssaf", 0, 100, 1)),
        field("Revenus du conjoint/partenaire pacsé (foyer) (€) :", this.numberInput("ir_autres_revenus", 0, 10000000, 1)),
        field("Nombre de parts fiscales :", this.numberInput("ir_parts", 1, 20, 0.5))),
      { actions: [btn("Fermer", "close", () => dlg.close())], width: "min(560px, 94vw)" });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Onglet : TVA                                                        */
  /* ------------------------------------------------------------------ */
  class TvaTab {
    constructor(app) {
      this.app = app;
      this.month = new Date().getMonth() + 1;
      this.year = app.state.years[app.state.years.length - 1];
      this.review = [];
    }

    buildToolbar() {
      this.monthSel = select(this.app.state.mois.map((m, i) => [i + 1, m]), this.month, (v) => { this.month = +v; this.onPeriod(); });
      this.yearSel = select(this.app.yearOptions(), this.year, (v) => { this.year = +v; this.onPeriod(); });
      this.fileInput = h("input", { type: "file", accept: ".xlsx", hidden: true });
      this.fileInput.addEventListener("change", () => {
        const f = this.fileInput.files[0];
        this.fileInput.value = "";
        if (f) this.app.guard(() => this.importReleve(f));
      });
      return h("div", { class: "ei-tb" }, h("span", {}, "Mois à déclarer : "), this.monthSel, this.yearSel,
        h("span", { class: "ds-grow" }),
        btn("Affectation clients", "users", () => this.app.guard(() => this.openAffectation())),
        btn("Importer un relevé bancaire (.xlsx)", "folder", () => this.fileInput.click()), this.fileInput);
    }

    buildPage() {
      this.stats = statRow(["finance", "transfer", "chartline", "bank"]);
      this.reviewBody = h("tbody");
      this.reviewBox = group("Rapprochement du relevé importé",
        h("p", { class: "ei-intro", text:
          "Une facture est proposée pour chaque mouvement du mois, quand une correspondance a été trouvée (numéro de " +
          "facture cité dans le libellé, ou montant et nom du tiers proches — à défaut, des factures dont le montant " +
          "est simplement proche, sans être identique, sont proposées en repli et repérées par « ≈ »). Vérifiez et " +
          "corrigez chaque ligne avant de valider." }),
        h("div", { class: "ds-tablewrap" }, h("table", { class: "ds-table ds-striped" },
          h("thead", {}, h("tr", {}, ["Date", "Libellé", "Montant", "Facture proposée"].map((c) => h("th", { text: c })))),
          this.reviewBody)),
        btnP("Valider les rapprochements", "check", () => this.app.guard(() => this.validate())));
      this.reviewBox.hidden = true;
      this.report = h("div", { class: "ei-report" });
      return h("div", {},
        h("p", { class: "ei-intro", text:
          "Chaque mois, importez le relevé de votre compte bancaire professionnel (export .xlsx) pour confirmer " +
          "quelles factures émises ont été réellement encaissées (seules les rentrées d'argent sont rapprochées — " +
          "les dépenses/factures d'achat ne sont jamais concernées), puis retrouvez ici le montant à déclarer par " +
          "catégorie de TVA." }),
        this.stats.el, this.reviewBox, this.report);
    }

    onPeriod() { this.reviewBox.hidden = true; this.app.guard(() => this.refresh()); }

    async refresh() {
      const res = await this.app.api("/tva", { query: { year: this.year, month: this.month } });
      this.stats.set(res.stats);
      this.report.innerHTML = restyleReport(res.html);
    }

    async importReleve(file) {
      const res = await this.app.api("/tva/releve", {
        method: "POST", body: await file.arrayBuffer(), query: { year: this.year, month: this.month },
      });
      if (res.empty) { this.app.message("Aucun mouvement trouvé dans ce fichier.", "Import"); return; }
      this.review = res.rows.map((r) => ({ mouvement: r.mouvement, sel: null }));
      this.reviewBody.textContent = "";
      res.rows.forEach((r, i) => {
        const opts = [...r.options.map((o) => [o.idx, o.label]), ["", "Ignorer (hors périmètre)"]];
        const sel = select(opts, r.options.length ? r.options[0].idx : "");
        this.review[i].sel = sel;
        this.reviewBody.append(h("tr", {},
          h("td", { text: r.date }), h("td", { title: r.libelle, text: r.libelle.slice(0, 90) }),
          h("td", { class: "num", text: r.montant }), h("td", {}, sel)));
      });
      this.reviewBox.hidden = false;
    }

    async validate() {
      const entries = this.review.map((e) => ({ mouvement: e.mouvement, idx: e.sel.value === "" ? null : +e.sel.value }));
      const res = await this.app.api("/tva/validate", { method: "POST", json: { entries } });
      this.review = [];
      this.reviewBody.textContent = "";
      this.reviewBox.hidden = true;
      await this.refresh();
      this.app.message(`${res.matched} facture(s) marquée(s) comme encaissée(s) pour ce mois.`, "Rapprochement");
    }

    async openAffectation() {
      const clients = await this.app.api("/tva/clients");
      const body = h("div", { class: "ds-col" },
        h("p", { class: "ds-muted", text:
          "Forcez ici la zone de TVA d'un client pour le calcul de la déclaration (bloc France / Intra UE / Hors UE), " +
          "pour toutes ses factures — cette affectation prend le pas sur la zone enregistrée facture par facture. " +
          "Laissez « Automatique » pour ne rien changer." }));
      const list = h("div", { class: "ei-clientlist" });
      if (!clients.length) list.append(h("p", { text: "Aucun client trouvé dans les factures émises." }));
      for (const c of clients) {
        const sel = select([["", "Automatique (zone de la facture)"], ["FR", "France"], ["UE", "Intra UE"], ["HORS-UE", "Hors UE"]],
          c.zone || "", (v) => this.app.guard(async () => {
            await this.app.api("/tva/clients", { method: "POST", json: { client: c.nom, zone: v || null } });
            await this.refresh();
          }));
        list.append(h("div", { class: "ei-clientrow" }, h("span", { text: c.nom }), sel));
      }
      body.append(list);
      let dlg;
      dlg = this.app.dialog("Affectation clients — zone de TVA", body, {
        actions: [btn("Fermer", "close", () => dlg.close())], width: "min(560px, 94vw)",
      });
    }
  }

  /* Onglets de l'application, dans l'ordre de la version KDE. `group` = étiquette de section de la
     barre latérale autonome ; `short` = libellé dans le contrôle segmenté de la variante embarquée. */
  function tabDefs() {
    return [
      { id: "capture", group: "Saisie", label: "Capture d'écran", short: "Importer (capture)", icon: "image",
        subtitle: "Extraire des factures depuis une capture d'écran (OCR)", make: ScreenshotTab },
      { id: "nico", label: "Facture Nico", short: "Facture Nico", icon: "user",
        subtitle: "Part de revenu de Nico, mois par mois", make: NicoTab },
      { id: "sales", label: "Factures émises", short: "Émises", icon: "export",
        subtitle: "Ventes, encaissements et réaffectation de mois", make: (a) => new InvoiceTab(a, "sales") },
      { id: "purchases", label: "Factures achats", short: "Achats", icon: "import",
        subtitle: "Achats et TVA déductible", make: (a) => new InvoiceTab(a, "purchases") },
      { id: "chart", group: "Analyse", label: "Graphique", icon: "bar",
        subtitle: "Évolution du chiffre d'affaires et des prévisions", make: ChartTab },
      { id: "urssaf", group: "Déclarations", label: "URSSAF", icon: "bank",
        subtitle: "Cotisations sociales estimées", make: UrssafTab },
      { id: "ir", label: "Impôt/revenu", icon: "chartline",
        subtitle: "Estimation de l'impôt sur le revenu", make: IrTab },
      { id: "tva", label: "TVA", icon: "transfer",
        subtitle: "Déclaration de TVA et rapprochement bancaire", make: TvaTab },
    ];
  }

  /* Sections de la variante embarquée (ordre des onglets = ordre du contrôle segmenté). */
  const SECTIONS = {
    factures: { title: "Factures", ids: ["sales", "purchases", "nico", "capture"] },
    graphique: { title: "Graphique", ids: ["chart"] },
    declarations: { title: "Déclarations", ids: ["urssaf", "ir", "tva"] },
  };

  window.GestionEI = {
    sections: SECTIONS,
    mount(el, opts) {
      const app = new App(el, opts);
      app.ready = app.start();
      return app;
    },
  };
})();
