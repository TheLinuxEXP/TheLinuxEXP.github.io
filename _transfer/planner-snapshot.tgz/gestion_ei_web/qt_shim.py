"""
Mini-substitut de PySide6, pour pouvoir IMPORTER gestion_fiscale_ei.py (le
code de l'application KDE, laissé strictement intact) sur un serveur qui n'a
ni Qt ni écran — par exemple dans un conteneur Docker.

Pourquoi : l'interface web réutilise les fonctions et les méthodes de calcul de
l'application plutôt que d'en recopier le contenu (voir adapter.py). Or ce
fichier commence par « from PySide6... import ... » et définit des classes qui
héritent de widgets Qt. Les parties réutilisées ne touchent jamais à Qt à
l'exécution : il suffit donc que ces noms existent pour que le module se
charge. Ce shim les fournit (classes « vides » qui acceptent tout).

Ce n'est PAS utilisé par l'application KDE elle-même, qui garde le vrai PySide6.
"""
import sys
import types


class _Meta(type):
    def __getattr__(cls, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return _Dummy()


class _Dummy(metaclass=_Meta):
    def __init__(self, *args, **kwargs):
        pass

    def __call__(self, *args, **kwargs):
        return _Dummy()

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return _Dummy()

    def __or__(self, other):
        return self

    __ror__ = __or__


class _ShimModule(types.ModuleType):
    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        cls = _Meta(name, (_Dummy,), {})
        setattr(self, name, cls)
        return cls


_NAMES = ("PySide6", "PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets", "PySide6.QtCharts")


def install():
    """Installe le shim (sauf si EI_USE_REAL_QT=1 ou si PySide6 est déjà chargé)."""
    import os
    if os.environ.get("EI_USE_REAL_QT") == "1" or "PySide6" in sys.modules:
        return False
    for name in _NAMES:
        sys.modules[name] = _ShimModule(name)
    # openpyxl n'est utilisé que pour lire un relevé bancaire : s'il manque, le
    # module se charge quand même et l'import d'un relevé affichera une erreur claire.
    try:
        import openpyxl  # noqa: F401
    except ImportError:
        class _Missing(types.ModuleType):
            def __getattr__(self, name):
                if name.startswith("__"):
                    raise AttributeError(name)
                raise RuntimeError("Le paquet Python 'openpyxl' est requis pour importer un relevé bancaire.")
        sys.modules["openpyxl"] = _Missing("openpyxl")
    return True
