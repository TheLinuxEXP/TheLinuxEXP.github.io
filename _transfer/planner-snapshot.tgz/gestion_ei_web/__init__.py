"""
Interface web de « Gestion fiscale EI ».

Conçue pour être branchée dans un serveur Flask existant (ex. le Task
Planner) en une ligne :

    import gestion_ei_web
    gestion_ei_web.register(app, url_prefix="/fiscal")

ou lancée seule : `python3 run.py` (voir run.py).

Contrat d'intégration (pour la future unification des deux applications) :
  * un seul blueprint Flask, nommé « gestion_ei », monté sous un préfixe ;
  * tout est servi sous ce préfixe : page (/fiscal/), API (/fiscal/api/...),
    fichiers statiques (/fiscal/static/ei.css, ei.js) ;
  * le JavaScript est isolé (un seul objet global : window.GestionEI) et peut
    être monté dans n'importe quel conteneur de la page hôte :
        GestionEI.mount(element, {base: "/fiscal", layout: "sidebar" | "tabs"})
  * l'apparence vient du Planner Design System (static/ds/ds.css : jetons aux
    noms du Task Planner --bg, --fg, --border, --accent… + composants « ds- »,
    démo : static/ds/ds.html) ; ei.css ne contient que la mise en page (« ei- ») ;
  * les données restent dans ~/.local/share/gestion-fiscale-ei/data.json
    (partagées avec l'application KDE) — aucune base de données ajoutée.
"""
MODULE_INFO = {
    "id": "gestion_ei",
    "label": "Gestion fiscale",
    "default_prefix": "/fiscal",
    "script": "static/ei.js",
    "style": ["static/ds/ds.css", "static/ei.css"],
    "design_system": "static/ds/ds.css",
    "mount": "GestionEI.mount",
}


def __getattr__(name):
    # Flask n'est chargé qu'à la première utilisation du blueprint : le calcul
    # (adapter.py) et les tests fonctionnent sans Flask installé.
    if name == "blueprint":
        from .api import bp
        return bp
    raise AttributeError(name)


def register(app, url_prefix=None):
    """Monte l'interface dans une application Flask existante."""
    from .api import bp
    app.register_blueprint(bp, url_prefix=url_prefix or MODULE_INFO["default_prefix"])
    return app
