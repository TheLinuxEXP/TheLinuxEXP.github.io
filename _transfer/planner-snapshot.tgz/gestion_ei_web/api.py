"""
Blueprint Flask « Gestion fiscale EI » : API JSON + page.

Conçu pour être monté tel quel dans un autre serveur Flask (ex. le Task
Planner) : voir __init__.py (register). Toutes les routes, fichiers statiques
et noms de blueprint sont isolés derrière un préfixe (par défaut /fiscal), et
rien n'est ajouté à l'application hôte en dehors de ce blueprint.
"""
import contextlib
import shutil
import threading
from datetime import datetime, date

from flask import Blueprint, jsonify, request, render_template, abort, url_for

from . import adapter as ad
from . import nico

bp = Blueprint(
    "gestion_ei", __name__,
    static_folder="static", static_url_path="/static", template_folder="templates",
)

_LOCK = threading.RLock()


@contextlib.contextmanager
def _data(write=False):
    """Relit data.json à chaque requête (il est partagé avec l'application
    KDE) ; réécrit de façon atomique si `write`."""
    with _LOCK:
        data = ad.load()
        yield data
        if write:
            ad.save(data)


def _int_arg(name, default=None):
    raw = request.args.get(name)
    if raw in (None, "", "all", "null"):
        return default
    return int(raw)


@bp.before_request
def _csrf_guard():
    # Un site tiers ouvert dans le navigateur ne peut pas ajouter cet en-tête
    # personnalisé sans autorisation CORS (que ce serveur n'accorde jamais) :
    # toute modification doit donc venir de notre propre page.
    if request.method not in ("GET", "HEAD", "OPTIONS") and request.headers.get("X-Requested-With") != "gestion-ei":
        abort(403)


@bp.errorhandler(ValueError)
def _bad_value(e):
    return jsonify({"error": str(e)}), 400


@bp.errorhandler(KeyError)
def _bad_key(e):
    return jsonify({"error": f"Champ manquant : {e}"}), 400


@bp.errorhandler(IndexError)
def _bad_index(e):
    return jsonify({"error": "Facture introuvable (liste modifiée entre-temps ?)"}), 404


@bp.errorhandler(ad.DataFileError)
def _datafile(e):
    return jsonify({"error": str(e)}), 503


@bp.errorhandler(RuntimeError)
def _runtime(e):
    return jsonify({"error": str(e)}), 422


# --- Page ---------------------------------------------------------------- #
@bp.get("/")
def page():
    return render_template("ei_page.html", base=url_for("gestion_ei.page").rstrip("/"))


# --- État / réglages ------------------------------------------------------ #
@bp.get("/api/state")
def state():
    with _data() as d:
        return jsonify(ad.app_state(d))


@bp.post("/api/settings")
def settings():
    with _data(write=True) as d:
        return jsonify(ad.set_settings(d, request.get_json(force=True)))


# --- Factures ------------------------------------------------------------- #
@bp.get("/api/invoices/<kind>")
def invoices(kind):
    with _data() as d:
        return jsonify(ad.invoices_list(d, kind, _int_arg("year"), _int_arg("month")))


@bp.post("/api/invoices/<kind>")
def invoice_add(kind):
    with _data(write=True) as d:
        ad.add_invoice(d, kind, request.get_json(force=True))
    return jsonify({"ok": True})


@bp.delete("/api/invoices/<kind>/<int:idx>")
def invoice_delete(kind, idx):
    with _data(write=True) as d:
        ad.delete_invoice(d, kind, idx, request.args.get("sig"))
    return jsonify({"ok": True})


@bp.delete("/api/invoices/<kind>")
def invoice_clear(kind):
    if request.args.get("confirm") != "1":
        abort(400)
    with _data(write=True) as d:
        ad.clear_invoices(d, kind)
    return jsonify({"ok": True})


@bp.post("/api/invoices/sales/<int:idx>/reassign")
def invoice_reassign(idx):
    with _data(write=True) as d:
        body = request.get_json(force=True) or {}
        ad.reassign_invoice(d, idx, body.get("mois"), body.get("sig"))
    return jsonify({"ok": True})


@bp.get("/api/client-default")
def client_default():
    with _data() as d:
        return jsonify(ad.core.client_default(d, request.args.get("tiers", "")) or {})


# --- Facture Nico (nico.json, à côté de data.json) --------------------------- #
@bp.get("/api/nico")
def nico_get():
    month = request.args.get("month") or date.today().strftime("%Y-%m")
    with _LOCK:
        return jsonify(nico.month_view(nico.load(ad.core.DATA_DIR), month))


@bp.put("/api/nico/<month>")
def nico_put(month):
    nico.check_month(month)
    values = nico.clean(request.get_json(force=True))
    with _LOCK:
        months = nico.load(ad.core.DATA_DIR)
        months[month] = values
        nico.save(ad.core.DATA_DIR, months)
        return jsonify(nico.month_view(months, month))


@bp.delete("/api/nico/<month>")
def nico_delete(month):
    nico.check_month(month)
    with _LOCK:
        months = nico.load(ad.core.DATA_DIR)
        months.pop(month, None)
        nico.save(ad.core.DATA_DIR, months)
        return jsonify(nico.month_view(months, month))


@bp.get("/api/nico/year")
def nico_year():
    year = _int_arg("year", date.today().year)
    with _LOCK:
        months = nico.load(ad.core.DATA_DIR)
    return jsonify({"year": year, "rows": nico.year_rows(months, year),
                    "chart": nico.chart(months, year, ad.core.ACCENT_VIOLET, ad.core.ACCENT_BLUE)})


# --- Rapports ------------------------------------------------------------- #
@bp.get("/api/urssaf")
def urssaf():
    with _data() as d:
        return jsonify(ad.urssaf_report(d, _int_arg("year", date.today().year)))


@bp.get("/api/ir")
def ir():
    with _data() as d:
        return jsonify(ad.ir_report(d, _int_arg("year", date.today().year)))


@bp.get("/api/tva")
def tva():
    with _data() as d:
        return jsonify(ad.tva_report(d, _int_arg("year", date.today().year), _int_arg("month", date.today().month)))


@bp.get("/api/chart")
def chart():
    mode = request.args.get("mode", "current")
    if mode not in ("current", "compare", "par_type"):
        abort(400)
    with _data() as d:
        return jsonify(ad.chart_report(
            d, mode, _int_arg("year", date.today().year), request.args.get("forecast", "1") == "1"))


# --- TVA : affectation des clients et rapprochement ------------------------ #
@bp.get("/api/tva/clients")
def tva_clients():
    with _data() as d:
        return jsonify(ad.tva_clients(d))


@bp.post("/api/tva/clients")
def tva_client_set():
    body = request.get_json(force=True)
    with _data(write=True) as d:
        ad.set_client_override(d, body["client"], body.get("zone"))
    return jsonify({"ok": True})


@bp.post("/api/tva/releve")
def tva_releve():
    body = request.get_data()
    if not body:
        raise ValueError("Fichier vide")
    try:
        mouvements = ad.parse_releve(body)
    except Exception as e:  # format de relevé non reconnu, fichier illisible…
        raise ValueError(f"Impossible de lire ce fichier : {e}")
    if not mouvements:
        return jsonify({"empty": True, "rows": []})
    with _data() as d:
        rows = ad.tva_review(d, mouvements, _int_arg("year"), _int_arg("month"))
    return jsonify({"empty": False, "rows": rows})


@bp.post("/api/tva/validate")
def tva_validate():
    entries = request.get_json(force=True)["entries"]
    with _data(write=True) as d:
        n = ad.tva_validate(d, entries)
    return jsonify({"matched": n})


# --- Capture d'écran (OCR) -------------------------------------------------- #
@bp.get("/api/screenshot/rate")
def usd_rate():
    rate = ad.core.fetch_usd_eur_rate()
    return jsonify({"rate": rate, "default": ad.core.DEFAULT_USD_EUR_RATE})


@bp.post("/api/screenshot/parse")
def screenshot_parse():
    body = request.get_data()
    if not body:
        raise ValueError("Image vide")
    rate = float(request.args.get("rate") or ad.core.DEFAULT_USD_EUR_RATE)
    return jsonify(ad.ocr_parse(body, request.args.get("kind", "sales"), rate))


@bp.post("/api/screenshot/add")
def screenshot_add():
    body = request.get_json(force=True)
    kind = body["kind"]
    rows, skipped = [], 0
    for edit in body["rows"]:
        try:
            rows.append(ad.row_from_edit(edit))
        except ValueError:
            skipped += 1
    if not rows:
        return jsonify({"added": 0, "status": "Aucune ligne cochée n'a pu être ajoutée." if skipped else "Aucune ligne cochée."})
    with _data(write=True) as d:
        added = ad.import_rows(d, kind, rows)
    label = "factures émises" if kind == "sales" else "factures d'achat"
    msg = f"{added} ligne(s) ajoutée(s) sur {len(rows)} cochée(s) ({label})."
    if skipped:
        msg += f" {skipped} ligne(s) ignorée(s) (données invalides)."
    return jsonify({"added": added, "status": msg})


# --- Sauvegarde ------------------------------------------------------------- #
@bp.post("/api/backup")
def backup():
    """Copie horodatée de data.json dans le sous-dossier backups/ de son dossier."""
    with _LOCK:
        src = ad.core.DATA_FILE
        if not src.exists():
            raise ValueError("Aucune donnée à sauvegarder")
        dst_dir = src.parent / "backups"
        dst_dir.mkdir(exist_ok=True)
        dst = dst_dir / f"data-{datetime.now():%Y%m%d-%H%M%S}.json"
        shutil.copy2(src, dst)
    return jsonify({"file": str(dst)})
