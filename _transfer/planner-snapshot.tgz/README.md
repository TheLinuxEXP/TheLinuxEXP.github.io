# Task Planner (web app) + Gestion fiscale EI

> **Serveur unique.** Cette version regroupe le Task Planner et l'interface web de
> « Gestion fiscale EI » (section **FINANCES** de la barre latérale : Factures,
> Graphique, Déclarations). Le module fiscal est un blueprint Flask monté sous
> `/fiscal` ; ses fichiers sont `gestion_ei_web/` et `gestion_fiscale_ei.py` (le code
> de l'application KDE, réutilisé tel quel). Voir `UNIFIED.md` (fonctionnement,
> données, Docker) et `ROADMAP.md` (idées d'intégration à venir).
> Sans ces deux éléments, le Task Planner démarre normalement et masque la section.


A local, self-hosted task manager: **projects** that hold one or more **todo
lists**, tasks with tags/due date/urgency/notes/attachment/recurrence/
duration/video flag, and a **calendar** month view.

## Running it

```
cd "Video Planner/webapp"
pip install -r requirements.txt   # pinned versions (Flask + the PowerPoint/PDF helpers)
python3 run.py
```

The AI-powered buttons (see "AI content-generation buttons" below) run your
own **Claude Code CLI** in the background (`claude -p "..."`), so they use
your existing Claude.ai subscription and its included usage — not a
separate, pay-per-call API key. One-time setup on this machine:

```
# 1. Install Claude Code: https://code.claude.com
# 2. Sign in with your subscription (not --console, which is for API billing):
claude auth login
```

That's it — once `claude` is installed and logged in, the four AI buttons
work with no extra configuration. The app works fully without this too;
the buttons will just show a clear error telling you to install/log in
until you do.

**The planner is not tied to Claude.** Sidebar → Utilities → **AI settings** lets you send every AI button to
another model instead: the Anthropic API (key), a **local model** (Ollama, LM Studio, llama.cpp / vLLM, any
OpenAI-compatible server) or a **cloud provider** (OpenAI, Mistral, Gemini, Groq, OpenRouter...). The buttons send
exactly the same prompt and system instructions to whichever model is selected. Pick the provider, model and (for
clouds) the API key, press **Test**, then **Save**. Settings are stored in `ai_settings.json` in the data folder
(owner-only permissions; keys are never sent back to the browser). The Claude subscription stays the default. Only
that provider has built-in web search and image reading; with the others, tick "can read images" if the model is
multimodal (needed for PDF page analysis). The old `TASKPLANNER_AI_BACKEND=api` / `ANTHROPIC_API_KEY` variables
still work until the window is used. No extra Python package is needed (plain HTTP).

## Login

The planner asks for an identifier (an email or a name) and a password. First run: **`nicolas` / `1234`** — a browser
signing in with it is sent to a page that forces you to choose a new password before anything else opens. Later, change
it in Utilities → **Account** (new password: 8 characters minimum; changing it signs out every other browser).
Credentials are stored hashed (scrypt) in `auth.json` in the data folder. After 5 wrong attempts the address is
locked out for a while (30 s, doubling up to 15 min). Forgotten password: run `python3 -m app.auth reset` on the
machine (back to `nicolas` / `1234`). Programs on the same machine that are not browsers (the Plasma widget, the
Resolve scripts, `curl`) don't need to log in; set `TASKPLANNER_AUTH_TRUST_LOCAL=0` to require it for them too, or
`TASKPLANNER_AUTH=0` to turn the login off entirely.

This starts a local server on `http://127.0.0.1:8765/` and opens it in your
default browser. Everything runs on your machine — nothing talks to the
network except your own browser talking to `localhost`.

Useful flags:

```
python3 run.py --port 9000        # use a different port
python3 run.py --no-browser       # don't auto-open a browser tab
```

Data is stored in SQLite at `~/.local/share/taskplanner/taskplanner.db`, and
the one attachment a task can have under
`~/.local/share/taskplanner/attachments/`. Nothing is written inside the
project folder itself, so you can update the app's files without touching
your data.

## Data safety

Several layers keep a mistake or a bug from costing you work (all in the data folder, `~/.local/share/taskplanner/`):

- **Database backups** (`backups/`): a full copy after every change to tasks, subtasks, lists, projects, templates... The same
  change repeated within a minute (typing in a task's Notes) replaces the previous copy instead of piling up. The newest 500
  are kept as they are (`TASKPLANNER_MAX_BACKUPS`); beyond those, the last copy of each day is kept for a year
  (`TASKPLANNER_KEEP_DAILY_DAYS`). Restoring takes a backup first, so a restore can be undone.
- **Note versions** (`notes_backups/<folder>/<note>.versions/`): before a note is overwritten, the previous text is copied
  (at most one copy every two minutes while typing - and always when the new text is much shorter, which is what a bad save
  looks like). The newest 10 are kept, then one per hour for 3 days and one per day for 90 days. The Notes & Scripts editor also
  refuses to save a note when what is on screen could not be written back to Markdown without losing text: a red bar
  explains it, the file on disk stays untouched, and you can save the visible text as a new note or save anyway.
- **Trash** (`trash/<day>/`): attachments and sponsor contracts that are deleted or replaced are moved there for 90 days
  (`TASKPLANNER_TRASH_DAYS`) instead of being erased; deleting the *row* of a task can be undone from a backup, and now its
  document survives too. Notes deleted from the editor go to `.trash/` inside the notes folder.
- **Task fields** (Notes, title) are saved while you type and when the page is closed or hidden; if your session ends mid-typing a
  banner appears instead of the page being thrown away.
- Finance data: `gestion-fiscale-ei/backups/` keeps the newest 40 copies (one per 10 minutes at most) plus the last copy of each
  day for a year.

## Feature coverage

- **Projects** — create any number of them, each with its own color shown
  as a dot next to its name; each one holds one or more **todo lists** (add
  from the sidebar's "+" next to a project). A list's ⋮ menu lets you rename
  or delete it.
- **Notes & Scripts** — a rich-text Markdown editor over your notes folder
  (`~/Documents/Notes` by default, or `NOTES_DIR`). Every note stays a plain
  `.md` file in the existing folder structure, so Obsidian/QOwnNotes keep
  working on the same files. Toolbar + shortcuts for headings, bold/italic/
  strikethrough, inline code, links, `[[wikilinks]]`, images (pasted or
  uploaded to `media/`), bullet/numbered/task lists, quotes, code blocks,
  tables and rules; typing `# `, `- `, `1. `, `> `, `[ ] `, ``` or `---`
  formats as you type. A "Markdown" switch shows the raw text. Saving is
  block-level: only the paragraphs/lists/tables you actually edited are
  rewritten, the rest of the file stays byte-identical. Autosave (and Ctrl+S);
  the previous version of a note is kept in `<data dir>/notes_backups/` (last
  10), deleted notes go to the notes folder's `.trash/`. New notes created in
  `Scripts/` start with the Titles / Timestamps / Content skeleton.
  The sidebar lists your **pinned** notes and the 5 most **recent** ones above
  the folders. In a task's panel, "Note / script" replaces the old path field:
  pick the note from the notes folder (notes whose title shares keywords with
  the task title are suggested automatically); the link is stored as the
  file's path, so the AI buttons keep reading it.
- **Tasks**, each with:
  - **Tags** — user-managed (create/rename/recolor/delete from the task
    panel's tag picker), many-to-many.
  - **Due date** — set via a small popup calendar (click the date button in
    the task panel), with quick "Today"/"Clear" actions.
  - **Urgency** — a yes/no flag (🚩), shown on the task row and on the
    calendar.
  - **Notes** — free text.
  - **Attached file** — one per task, upload/download/remove.
  - **Recurrence** — every N days/weeks/months/years, with specific
    weekdays for the weekly case; completing a recurring task rolls its due
    date forward instead of finishing it for good. A recurring task's future
    occurrences also appear (dashed/with a 🔁 flag) on every date they land
    on in the **calendar** view, not just the next one — those projected
    occurrences are read-only (open the task to manage its real status).
  - **Duration** — an estimated duration in hours (e.g. `2.5`), shown as
    e.g. "2h 30m".
  - **Video** — a yes/no flag (🎥) with its own icon on task rows and the
    calendar.
  - **Subtasks** — each task can have any number of subtasks, shown nested
    underneath it. Each subtask has its own due date, its own start time, its
    own estimated duration (hours), and its own urgency flag (click the 🚩 to
    toggle it); it inherits the video flag from its parent task rather than
    having its own. Subtasks show up in the **calendar** as their own
    entries (prefixed "↳"), on their own due date, counting separately
    toward that day's total-hours badge. There's no separate subtask detail
    view — clicking a subtask anywhere opens its parent task. In any task
    list, a task with subtasks shows a ▸/▾ fold arrow to its left; subtasks
    are **folded (hidden) by default** and expand in place when you click
    the arrow.
  - **Start time** — an optional time-of-day for a task or subtask, used by
    the calendar's week view (see below).
  - **Linked notes file** — a task (and each of its subtasks, independently)
    can point at a markdown file on your own disk (just type/paste its
    path). This is what the AI buttons below read from.
- **Show/hide completed tasks** — a checkbox at the top of any task list
  view toggles whether finished tasks are included.
- **Smart views**, listed at the top of the sidebar with live counts:
  - **Inbox** — every task (any project) with no due date.
  - **Today** / **Tomorrow** — tasks due that day, with an estimated total
    duration for the day shown at the top.
  - **Urgent** — every task with the urgent flag set.
  - Each of these groups its tasks into collapsible per-project sections.
- **"+" button templates** — the ＋ button now opens a small menu:
  - **Task** — the plain "add a task" dialog, as before.
  - **Weekly News Video** — creates a "Weekly News Video" task (video flag
    on) due the next Saturday that doesn't already have one, plus its usual
    subtasks (order topics & record A-roll on the Friday before; edit,
    thumbnails and publish on the Saturday itself).
  - **Normal Video** — creates a "New video" task (video flag on) due the
    next Wednesday that doesn't already have one, plus its usual subtasks
    (script on the Monday before, A-roll on the Tuesday before; edit,
    thumbnails and publish on the Wednesday itself).
  - Both templates ask which list to file the new task under, then do all
    the date math and subtask creation for you.
- **Calendar** — switch between **Month** and **Week** with the tab
  selector at the top of the page.
  - **Month** view: a real month grid. Every task with a due date shows up
    on its day (including every occurrence of a recurring task within the
    month, and every subtask on its own due date); video tasks get a
    distinct tinted background, urgent tasks show the 🚩 flag inline, and
    each day with any time-estimated tasks/subtasks shows a total "⏱ Nh"
    badge (highlighted when a day's load reaches 8h+). Click a day number to
    see the full day (if more than 3 entries land on one day) and add a
    task straight onto that date.
  - **Week** view: an hourly grid (untimed tasks/subtasks sit in an all-day
    strip above it). Any task or subtask with a start time shows as a block
    at that time; **drag a block to a new day/time** to move it — dropping
    it sets its new due date and start time. If the new slot overlaps
    another timed entry on that day, that entry (and anything it in turn
    overlaps) is pushed later, immediately after the dragged entry ends;
    all of the moves are only saved once you drop.
- **AI content-generation buttons** — powered by your Claude Code CLI /
  Claude subscription (see "Running it" above); each reads from a task's
  **linked notes file** (a markdown file on your disk) and shows its result
  in a copyable pop-up:
  - **"Order topics"** (on the "Order topics" subtask of a Weekly News
    Video) — reads the parent task's linked notes file's "Timestamps",
    "Links" and "Content" sections, reorders all three consistently by what
    would most interest The Linux Experiment's audience (grouping related
    nearby topics), and shows the reordered markdown to paste back into
    your own note.
  - **"Generate tags"** (on the "Publish video..." subtask) — reads the
    linked notes file's "Content" section and generates a list of YouTube
    tags.
  - **"Generate ideas"** (on the "Make 3 thumbnails" subtask) — reads the
    linked notes file's "Content" section and generates 3 title + thumbnail
    concept pairs.
  - **"Plan out this script"** (on the "Write script" subtask) — uses the
    parent task's own **Notes** field (not the linked file) to generate a
    script structure: main points, with links and on-screen ideas for each.
- **Theme** — follows your OS light/dark preference automatically, with a
  manual override toggle (🌓) in the sidebar header.
- **Reload server** — a link at the bottom of the sidebar that restarts the
  Flask process in place and reloads the page, so a code update doesn't
  need a manual Ctrl+C/rerun from the terminal.

## Known limitations

- No drag-and-drop reordering of tasks/lists/projects yet.
- No desktop notifications/reminders — none were in this spec; say the word
  if you'd like due-date reminders added.
- No sync backend — everything is local SQLite, single-user, single
  machine.

## Project layout

```
webapp/
  run.py                  entry point
  requirements.txt
  app/
    __init__.py            create_app(): guards (LAN-only, Host / Origin checks, CSP), upload cap, blueprints
    api/                   REST endpoints (JSON), one module per topic; they share api/common.py
      organize.py tasks.py templates_routes.py schedule.py admin.py
      ai_routes.py           text AI buttons (prompts, chapters, timestamps, thumbnails) + AI settings endpoints
      ppt_routes.py          PowerPoint buttons (Generate, List to PPT)
    database.py            Database class (assembled from the mixins in dbparts/)
    dbparts/               schema + helpers (core.py), then one mixin per topic (tasks, subtasks, time tracking...)
    recurrence.py           recurrence rule engine
    templates/index.html    the single page
    static/app.css
    static/js/              all UI logic (vanilla JS, no build step): classic scripts sharing one global scope,
                            loaded in the order listed in index.html -- boot.js must stay last, and code that runs
                            at load time may only use what the files before it define
    notes_api.py            Notes & Scripts REST endpoints (Markdown folder)
    static/notes.js         Notes & Scripts editor; notes.css its styles
    static/vendor/          markdown-it (MIT), used by the editor
  tests/                   python3 -m unittest discover -s tests -t .   (API, notes, security, List to PPT)
                           python3 -m tests.ui_smoke                    (browser smoke test, needs Playwright + Chromium)
                           python3 -m tests.bench [n_tasks]             (timings on a synthetic database)
```

## Hosting on a Synology NAS (local network only)

The app ships as a Docker project (`Dockerfile` + `docker-compose.yml`) for
**Container Manager** (DSM 7.2+; on older DSM it's called "Docker"). It is
built on the NAS itself, so it works on both Intel and ARM models. Not every
entry-level Synology supports Container Manager — check the package list for
your model.

1. **Copy the project to the NAS.** In File Station create
   `/docker/taskplanner` and copy into it: `Dockerfile`, `docker-compose.yml`,
   `.dockerignore`, `docker-entrypoint.sh`, `requirements.txt`, `run.py`, `gestion_fiscale_ei.py` and the `app/` and `gestion_ei_web/` folders
   (not `server.log`, not `__pycache__`, not `tests/`).
2. **Move your data** (optional but you'll want it). On the laptop, stop the
   server, then copy the *contents* of `~/.local/share/taskplanner/` (the
   `taskplanner.db` file, `backups/`, `attachments/`, `generated/`) into
   `/docker/taskplanner/data/taskplanner/` on the NAS. Keep the laptop copy as
   a safety net, but don't keep using it afterwards — two copies would drift.
3. **Create the project.** Container Manager → Project → Create → name it
   `taskplanner`, path `/docker/taskplanner`, use the existing
   `docker-compose.yml` → Next → Done. The first build takes a few minutes.
4. **Open it** at `http://<nas-ip>:8765/`. Give the NAS a fixed IP (DHCP
   reservation in your router) so the address never changes. Point the KDE
   widget at it (widget settings → server URL), and edit the URL in
   `desktop-launcher/start-task-planner.sh` if you still use the launcher.

### Keeping it off the internet

- The app itself answers **403 to any request that doesn't come from a
  private (LAN) address** (`TASKPLANNER_LAN_ONLY=1`, set in the compose file).
- Do **not** forward port 8765 on your router, and do not publish it through
  QuickConnect, DDNS or the DSM reverse proxy.
- Add a DSM firewall rule: Control Panel → Security → Firewall → create a rule
  for port 8765 that **allows only your LAN subnet** (e.g. `192.168.1.0/24`),
  followed by a deny-all rule for that port.
- There is **no login**: anyone on your local network (including guest Wi-Fi
  if it isn't isolated) can open it. Keep the NAS on your trusted network.

### Good to know

- **Time zone** is set to `Europe/Paris` in the compose file (the server's date
  decides "today", recurring tasks and backup times). Change `TZ` if needed.
- **Updating the app:** copy the changed files over the NAS copies, then
  Container Manager → Project → `taskplanner` → Action → *Build* (rebuild).
  The sidebar's "Reload server" only restarts the process inside the running
  container; code changes need a rebuild.
- **Backups:** the app's own backups are in `data/taskplanner/backups/` on the
  NAS. Add the `data` folder to a Hyper Backup task too.
- **Notes files** linked to tasks (markdown paths) must exist inside the
  container: mount that folder in `docker-compose.yml` (see the commented
  `/notes` line) and use the in-container path (`/notes/...`) in the task. The server runs as an unprivileged user
  (uid 1000 by default; `PUID`/`PGID` build args): that folder must be writable by it, e.g. `chown -R 1000:1000` on the NAS.
- **AI buttons / PDF reading with images** need the Claude Code CLI, which is
  not in the image by default. Either set `INSTALL_CLAUDE_CLI: "1"` in the
  compose file, rebuild, then sign in once with
  `docker exec -it -u planner taskplanner claude` and `/login` (the server
  itself runs as the unprivileged `planner` user, never as root; the login is
  stored in the data volume); or use another provider from the sidebar's
  **AI settings** (API key, local model...).
  Without either, everything else works and those buttons show a clear error.
