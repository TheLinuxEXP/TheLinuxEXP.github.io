"""SEO helpers for the editor's SEO tab.

Everything here is plain text analysis that runs on this computer: no network,
no AI. It looks at the Markdown of the article being edited and proposes

  * the meta tags the site's <head> uses (description, featured image) when they are missing,
  * alt text for images that have none,
  * links from phrases in the text to other pages and articles of the site.

Nothing is changed here. The editor shows the proposals and applies the ones
the person accepts.
"""

import re
from collections import Counter
from math import log

DESCRIPTION_MIN, DESCRIPTION_MAX = 70, 160
TITLE_MIN, TITLE_MAX = 25, 65
MAX_LINK_SUGGESTIONS = 12

STOP_WORDS = frozenset("""
a about above after again all also am an and any are as at be because been before being below between both but by
can could did do does doing down during each few for from further had has have having he her here hers him his how
i if in into is it its just me more most my no nor not now of off on once only or other our out over own same she
should so some such than that the their them then there these they this those through to too under until up very
was we were what when where which while who whom why will with would you your yours
""".split())

IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".avif")

FENCE_RE = re.compile(r"^(?P<fence>`{3,}|~{3,}).*?^(?P=fence)[ \t]*$", re.S | re.M)
INLINE_CODE_RE = re.compile(r"(`+)(?:(?!\1).)+?\1", re.S)
MD_IMAGE_RE = re.compile(r"!\[(?P<alt>[^\]\n]*)\]\((?P<src>[^)\s]+)(?:\s+\"[^\"]*\")?\)")
MD_LINK_RE = re.compile(r"\[(?:[^\]\n]|\\\])*\]\([^)\n]*\)")
REF_LINK_RE = re.compile(r"\[[^\]\n]*\]\[[^\]\n]*\]|^\[[^\]\n]+\]:.*$", re.M)
AUTOLINK_RE = re.compile(r"<(?:https?://|mailto:)[^>\s]+>|https?://[^\s<>\")]+")
HTML_TAG_RE = re.compile(r"<[A-Za-z/!][^>]*>")
LIQUID_RE = re.compile(r"\{%.*?%\}|\{\{.*?\}\}", re.S)
HTML_IMG_RE = re.compile(r"<img\b[^>]*>", re.I)
ATTR_RE = r"""(?:\s|^){name}\s*=\s*(?:"([^"]*)"|'([^']*)')"""
HEADING_LINE_RE = re.compile(r"^ {0,3}#{1,6}[ \t].*$", re.M)
HTML_LINE_RE = re.compile(r"^[ \t]*<.*$", re.M)
WORD_RE = re.compile(r"[\w'’]+", re.U)


# --------------------------------------------------------------------------
# text helpers
# --------------------------------------------------------------------------
def _mask(text: str, pattern: re.Pattern, mask: bytearray) -> None:
    for match in pattern.finditer(text):
        mask[match.start():match.end()] = b"\x01" * (match.end() - match.start())


def protected_mask(text: str) -> bytearray:
    """1 where the text must never be turned into a link (code, links, HTML, headings...)."""
    mask = bytearray(len(text))
    for pattern in (FENCE_RE, INLINE_CODE_RE, MD_IMAGE_RE, MD_LINK_RE, REF_LINK_RE, AUTOLINK_RE,
                    HTML_TAG_RE, LIQUID_RE, HEADING_LINE_RE, HTML_LINE_RE):
        _mask(text, pattern, mask)
    return mask


def plain_text(markdown: str) -> str:
    """The readable text of a Markdown body, for summaries."""
    text = FENCE_RE.sub(" ", markdown)
    text = LIQUID_RE.sub(" ", text)
    text = MD_IMAGE_RE.sub(" ", text)
    text = re.sub(r"<(script|style|iframe)\b.*?</\1>", " ", text, flags=re.S | re.I)
    text = HTML_TAG_RE.sub(" ", text)
    text = re.sub(r"\[([^\]\n]*)\]\([^)\n]*\)", r"\1", text)
    text = AUTOLINK_RE.sub(" ", text)
    text = re.sub(r"^ {0,3}#{1,6}[ \t]+", "", text, flags=re.M)
    text = re.sub(r"^[ \t]*(?:[-*+]|\d+[.)])[ \t]+", "", text, flags=re.M)
    text = re.sub(r"^[ \t]*>+[ \t]?", "", text, flags=re.M)
    text = re.sub(r"[*_`~]+", "", text)
    text = re.sub(r"^\s*\|.*\|\s*$", " ", text, flags=re.M)
    return re.sub(r"\s+", " ", text).strip()


def _sentences(text: str) -> list:
    parts = re.split(r"(?<=[.!?…])\s+(?=[A-Z0-9\"“‘(])", text)
    return [part.strip() for part in parts if part.strip()]


def _words(text: str) -> list:
    return [w.lower().strip("'’") for w in WORD_RE.findall(text)]


def _keywords(text: str) -> list:
    return [w for w in _words(text) if len(w) > 2 and w not in STOP_WORDS and not w.isdigit()]


def _humanize(filename: str) -> str:
    stem = re.sub(r"\.[A-Za-z0-9]+$", "", filename.rsplit("/", 1)[-1])
    stem = re.sub(r"[-_.]+", " ", stem)
    stem = re.sub(r"\b(?:img|image|screenshot|screen shot|dsc|pxl|photo)\b|\b\d{6,}\b", " ", stem, flags=re.I)
    return re.sub(r"\s+", " ", stem).strip()


def _looks_generic(name: str) -> bool:
    words = name.split()
    return len(name) < 4 or not words or all(w.isdigit() for w in words)


# --------------------------------------------------------------------------
# meta tags
# --------------------------------------------------------------------------
def suggest_description(title: str, body: str) -> str:
    """About 150 characters made of whole sentences from the start of the text."""
    paragraphs = []
    for block in re.split(r"\n\s*\n", body):
        block = block.strip()
        if not block or re.match(r"^(?:#|>|\||[-*+]\s|\d+[.)]\s|<|\{%|\{\{|!\[|```|~~~|\[[^\]]+\]:)", block):
            continue                       # headings, lists, quotes, tables, HTML, images and code are not the opening text
        paragraphs.append(block)
    marked = AUTOLINK_RE.sub("\x00", "\n\n".join(paragraphs[:4]))      # sentences holding a web address are not used
    text = plain_text(marked)
    if not text:
        return ""
    chosen = ""
    for sentence in _sentences(text):
        if "\x00" in sentence or sentence.rstrip(".!?…").lower() == (title or "").rstrip(".!?…").lower():
            continue
        candidate = f"{chosen} {sentence}".strip()
        if len(candidate) > DESCRIPTION_MAX:
            if not chosen:
                cut = candidate[:DESCRIPTION_MAX - 1].rsplit(" ", 1)[0].rstrip(" ,;:-–—")
                return cut + "…"
            break
        chosen = candidate
        if len(chosen) >= 110:
            break
    return chosen


def images_in(body: str) -> list:
    """Every image of the body, in order: Markdown ones and <img> tags (not those inside code)."""
    code = bytearray(len(body))
    _mask(body, FENCE_RE, code)
    _mask(body, INLINE_CODE_RE, code)
    found = []
    for match in MD_IMAGE_RE.finditer(body):
        if code[match.start()]:
            continue
        found.append({"kind": "markdown", "start": match.start(), "end": match.end(),
                      "src": match.group("src"), "alt": match.group("alt").strip(),
                      "alt_span": match.span("alt")})
    for match in HTML_IMG_RE.finditer(body):
        if code[match.start()]:
            continue
        tag = match.group(0)
        src = re.search(ATTR_RE.format(name="src"), tag, re.I)
        alt = re.search(ATTR_RE.format(name="alt"), tag, re.I)
        found.append({"kind": "html", "start": match.start(), "end": match.end(),
                      "src": (src.group(1) or src.group(2) or "") if src else "",
                      "alt": ((alt.group(1) or alt.group(2) or "").strip() if alt else ""),
                      "has_alt_attr": bool(alt), "alt_span": None})
    found.sort(key=lambda item: item["start"])
    return found


def _context_for(body: str, image: dict) -> dict:
    """The caption and the nearest heading around an image."""
    after = body[image["end"]:image["end"] + 400]
    stop = re.search(r"!\[|<img\b|<figure\b|^ {0,3}#{1,6}[ \t]", after, re.M | re.I)
    after = after[:stop.start()] if stop else after          # a caption after the NEXT image is not ours
    caption = re.search(r"<figcaption[^>]*>(.*?)</figcaption>", after, re.S | re.I)
    before = body[:image["start"]]
    headings = re.findall(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*$", before, re.M)
    return {"caption": plain_text(caption.group(1)) if caption else "",
            "heading": re.sub(r"[*_`]", "", headings[-1]).strip() if headings else ""}


def suggest_alt(title: str, body: str, image: dict) -> dict:
    """A short description for the image from its caption, file name or surroundings."""
    context = _context_for(body, image)
    name = _humanize(image["src"])
    if context["caption"]:
        return {"text": _shorten(context["caption"], 125), "from": "its caption"}
    if not _looks_generic(name):
        words = name[0].upper() + name[1:] if name else name
        return {"text": _shorten(words, 125), "from": "its file name"}
    if context["heading"]:
        return {"text": _shorten(context["heading"], 125), "from": "the heading above it"}
    return {"text": _shorten(title or "", 125), "from": "the article title"}


def _shorten(text: str, limit: int) -> str:
    text = " ".join(text.split())
    if len(text) <= limit:
        return text
    return text[:limit - 1].rsplit(" ", 1)[0].rstrip(" ,;:-–—") + "…"


# --------------------------------------------------------------------------
# internal links
# --------------------------------------------------------------------------
def _ngrams(words: list, low: int = 1, high: int = 5):
    for size in range(high, low - 1, -1):
        for start in range(0, len(words) - size + 1):
            yield start, size, words[start:start + size]


def _anchor_candidates(page: dict, frequency: Counter, total: int, tag_uses: Counter) -> list:
    """Phrases that could point to this page: its title, the part of it before a colon,
    multi-word tags and runs of meaningful words from the title."""
    rare = max(2, round(total * 0.07))           # a single word is only an anchor when few pages use it
    phrases = {}

    def add(phrase: str, weight: float):
        phrase = " ".join(phrase.split()).strip(" -–—:,.?!()\"“”")
        if len(phrase) < 4:
            return
        words = phrase.split()
        if words[0].lower() in STOP_WORDS or words[-1].lower() in STOP_WORDS:
            return
        key = phrase.lower()
        if key not in phrases or phrases[key][1] < weight:
            phrases[key] = (phrase, weight)

    title = page["title"]
    add(title, 3.0)
    for part in re.split(r"\s[:\-–—|]\s|:\s", title):
        if part != title:
            add(part, 2.4)
    for tag in page.get("tags", []):
        if len(tag.split()) >= 2 and tag_uses[tag.lower()] <= 2:     # a tag many pages share is a topic, not one page
            add(tag, 1.0)
    words = title.split()
    for word in words[1:]:
        bare = re.sub(r"^\W+|\W+$", "", word)
        if len(bare) >= 3 and (bare.isupper() or re.search(r"[a-z][A-Z]", bare)):
            add(bare, 1.4)                        # acronyms and CamelCase names: KDE, GNOME, YouTube
    for _start, size, grams in _ngrams(words, 2, 4):
        clean = [re.sub(r"^\W+|\W+$", "", g) for g in grams]
        if any(not c or c.lower() in STOP_WORDS for c in clean):
            continue                              # runs of meaningful words only
        add(" ".join(clean), 0.8 + 0.2 * size)
    scored = []
    for phrase, weight in phrases.values():
        keywords = _keywords(phrase)
        if not keywords:
            continue
        if len(phrase.split()) == 1:
            # one word is only an anchor when it is a name (KDE, YouTube, Kdenlive) used by few pages, or the whole title
            name_like = phrase == title or bool(re.search(r"[A-Z].*[A-Z]|\d", phrase))
            if not name_like or len(phrase) < 3 or frequency.get(keywords[0], 0) > rare:
                continue
        rarity = sum(log(1 + total / max(1, frequency.get(k, 1))) for k in keywords)
        scored.append((phrase, weight * (1 + rarity / 4)))
    return scored


def suggest_links(body: str, pages: list, self_url: str = "", title: str = "") -> list:
    """Phrases of `body` that could link to other pages. Each suggestion carries the
    exact position of the phrase so the editor can turn it into a link in one click."""
    pages = [p for p in pages if p.get("url") and p["url"] != self_url and p.get("title")]
    if not pages or not body.strip():
        return []
    document_frequency = Counter()
    page_keywords = {}
    for page in pages:
        keywords = set(_keywords(page["title"]) + [w for t in page.get("tags", []) for w in _keywords(t)])
        page_keywords[page["url"]] = keywords
        document_frequency.update(keywords)
    total = len(pages)
    tag_uses = Counter(tag.lower() for page in pages for tag in set(page.get("tags", [])))
    body_words = Counter(_keywords(plain_text(body) + " " + title))
    mask = protected_mask(body)
    linked = {m.group(1).split("#")[0] for m in re.finditer(r"\]\(([^)\s]+)", body)}
    linked |= {m.group(1).split("#")[0] for m in re.finditer(r"href=[\"']([^\"']+)", body)}
    suggestions = []
    for page in pages:
        if page["url"] in linked or page["url"].rstrip("/") in linked:
            continue
        related = sum(1 for k in page_keywords[page["url"]] if body_words[k])
        best = None
        for phrase, weight in _anchor_candidates(page, document_frequency, total, tag_uses):
            pattern = re.compile(r"(?<![\w])" + re.escape(phrase).replace(r"\ ", r"\s+") + r"(?![\w])", re.I)
            for match in pattern.finditer(body):
                if any(mask[match.start():match.end()]):
                    continue
                # the phrase must not start or end inside a word-joining character such as a hyphen or slash
                before = body[match.start() - 1:match.start()]
                after = body[match.end():match.end() + 1]
                if (before and before in "-/_") or (after and after in "-/_"):
                    continue
                score = weight * (1 + 0.15 * related)
                if best is None or score > best["score"]:
                    best = {"start": match.start(), "end": match.end(), "phrase": match.group(0),
                            "score": round(score, 2)}
                break                       # first usable occurrence of this phrase
        if best:
            best.update(url=page["url"], title=page["title"], kind=page.get("kind", ""))
            suggestions.append(best)
    # strongest first; two suggestions may not overlap
    suggestions.sort(key=lambda s: -s["score"])
    chosen = []
    for s in suggestions:
        if any(s["start"] < c["end"] and c["start"] < s["end"] for c in chosen):
            continue
        chosen.append(s)
        if len(chosen) >= MAX_LINK_SUGGESTIONS:
            break
    chosen.sort(key=lambda s: s["start"])
    for s in chosen:
        s["context"] = _context_snippet(body, s["start"], s["end"])
    return chosen


def _context_snippet(body: str, start: int, end: int, width: int = 60) -> dict:
    """A few words around the phrase, never crossing into another line."""
    line_start = body.rfind("\n", 0, start) + 1
    line_end = body.find("\n", end)
    line_end = len(body) if line_end < 0 else line_end
    left, right = body[max(line_start, start - width):start], body[end:min(line_end, end + width)]
    cut_left, cut_right = start - width > line_start, end + width < line_end
    if cut_left:
        left = left.split(" ", 1)[-1]
    if cut_right:
        right = right.rsplit(" ", 1)[0]
    return {"before": ("…" if cut_left else "") + left, "after": right + ("…" if cut_right else "")}


def apply_link(body: str, start: int, end: int, phrase: str, url: str) -> str:
    """Turns body[start:end] into a Markdown link. Refuses if the text moved meanwhile."""
    if body[start:end] != phrase:
        raise ValueError("The text changed since the suggestion was made. Run the analysis again.")
    return body[:start] + f"[{phrase}]({url})" + body[end:]


# --------------------------------------------------------------------------
# the whole analysis
# --------------------------------------------------------------------------
def analyze(fields: dict, body: str, pages: list, self_url: str = "") -> dict:
    title = " ".join(str(fields.get("title") or "").split())
    description = " ".join(str(fields.get("description") or "").split())
    image = str(fields.get("image") or "").strip()
    kind = fields.get("kind", "article")
    imgs = images_in(body)

    meta = []
    if description:
        note = None
        if len(description) < DESCRIPTION_MIN:
            note = f"Short ({len(description)} characters). Search results show about {DESCRIPTION_MIN}–{DESCRIPTION_MAX}."
        elif len(description) > DESCRIPTION_MAX:
            note = f"Long ({len(description)} characters). Search results cut it after about {DESCRIPTION_MAX}."
        meta.append({"key": "description", "label": "Description", "state": "ok" if not note else "warn",
                     "current": description, "suggestion": "", "note": note})
    else:
        meta.append({"key": "description", "label": "Description", "state": "missing", "current": "",
                     "suggestion": suggest_description(title, body),
                     "note": "Without it, every search result and link preview shows the site's generic description."})
    if title and not (TITLE_MIN <= len(title) <= TITLE_MAX):
        meta.append({"key": "title", "label": "Title length", "state": "warn", "current": title, "suggestion": "",
                     "note": f"{len(title)} characters. Titles of {TITLE_MIN}–{TITLE_MAX} characters display fully in search results."})
    if kind == "article":
        if image:
            meta.append({"key": "image", "label": "Featured image", "state": "ok", "current": image, "suggestion": "", "note": None})
        else:
            first = next((i["src"] for i in imgs if i["src"].lower().split("?")[0].endswith(IMAGE_EXTENSIONS)), "")
            meta.append({"key": "image", "label": "Featured image", "state": "missing", "current": "",
                         "suggestion": first,
                         "note": "Shown on link previews (X, Discord, Mastodon...)." + ("" if first else " The text has no image to reuse yet.")})

    alts = []
    for number, item in enumerate(imgs):
        if item["alt"]:
            continue
        proposal = suggest_alt(title, body, item)
        alts.append({"index": number, "src": item["src"], "kind": item["kind"], "start": item["start"],
                     "end": item["end"], "text": proposal["text"], "from": proposal["from"],
                     "decorative_marked": item["kind"] == "html" and item.get("has_alt_attr", False)})

    return {"meta": meta, "alts": alts, "images": len(imgs),
            "links": suggest_links(body, pages, self_url, title)}


def apply_alt(body: str, index: int, src: str, alt: str) -> str:
    """Writes `alt` into the index-th image of `body` (checked against its source)."""
    alt = " ".join(alt.replace("[", "(").replace("]", ")").replace('"', "'").split())
    imgs = images_in(body)
    if index >= len(imgs) or imgs[index]["src"] != src:
        raise ValueError("The images changed since the analysis. Run it again.")
    item = imgs[index]
    if item["kind"] == "markdown":
        a, b = item["alt_span"]
        return body[:a] + alt + body[b:]
    tag = body[item["start"]:item["end"]]
    safe = alt.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    if re.search(ATTR_RE.format(name="alt"), tag, re.I):
        tag = re.sub(r"""(\salt\s*=\s*)(?:"[^"]*"|'[^']*')""", lambda m: f'{m.group(1)}"{safe}"', tag, count=1, flags=re.I)
    else:
        tag = re.sub(r"<img\b", f'<img alt="{safe}"', tag, count=1, flags=re.I)
    return body[:item["start"]] + tag + body[item["end"]:]
