import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import seo  # noqa: E402
from test_admin import BASE, AdminCase  # noqa: E402

PAGES = [
    {"title": "Davinci Resolve vs Kdenlive", "url": "/dr-vs-kdenlive/", "tags": ["Video editing"], "kind": "article"},
    {"title": "Why elementary OS Is Important", "url": "/eos/", "tags": [], "kind": "article"},
    {"title": "Kdenlive", "url": "/kdenlive/", "tags": [], "kind": "page"},
]


class DescriptionTests(unittest.TestCase):
    def test_uses_opening_paragraphs_not_headings_lists_or_links(self):
        body = ("## Heading\n\nI use Davinci Resolve for video editing, and it is great. See https://x.example/a now. "
                "A third sentence makes the text long enough to be useful.\n\n- bullet\n\nLater text.")
        text = seo.suggest_description("Title", body)
        self.assertTrue(text.startswith("I use Davinci Resolve"))
        self.assertNotIn("Heading", text)
        self.assertNotIn("bullet", text)
        self.assertNotIn("x.example", text)
        self.assertLessEqual(len(text), seo.DESCRIPTION_MAX)

    def test_long_single_sentence_is_cut_on_a_word(self):
        text = seo.suggest_description("T", "word " * 80)
        self.assertTrue(text.endswith("…"))
        self.assertLessEqual(len(text), seo.DESCRIPTION_MAX)

    def test_nothing_to_summarize(self):
        self.assertEqual(seo.suggest_description("T", "## only a heading\n\n![](/a.png)"), "")


class ImageTests(unittest.TestCase):
    BODY = ("## Setup\n\n![](/images/a/kde-plasma-desktop.png)\n\n<figure markdown=\"1\">\n\n![](/images/a/b.png)\n\n"
            "<figcaption>The *Plasma* panel</figcaption>\n</figure>\n\n<img src=\"/images/c.jpg\">\n\n"
            "![Has alt](/images/d.png)\n\n```\n![](/images/in-code.png)\n```\n")

    def test_finds_missing_alt_text_only(self):
        found = seo.analyze({"title": "T", "kind": "article"}, self.BODY, [])["alts"]
        self.assertEqual([a["src"] for a in found], ["/images/a/kde-plasma-desktop.png", "/images/a/b.png", "/images/c.jpg"])

    def test_alt_comes_from_the_caption_not_the_next_figure(self):
        found = {a["src"]: a for a in seo.analyze({"title": "T", "kind": "article"}, self.BODY, [])["alts"]}
        self.assertEqual(found["/images/a/b.png"]["text"], "The Plasma panel")
        self.assertEqual(found["/images/a/kde-plasma-desktop.png"]["from"], "its file name")
        self.assertEqual(found["/images/c.jpg"]["from"], "the heading above it")

    def test_apply_alt_to_markdown_and_html_images(self):
        out = seo.apply_alt(self.BODY, 1, "/images/a/b.png", 'A [panel] with "quotes"')
        self.assertIn("![A (panel) with 'quotes'](/images/a/b.png)", out)
        out = seo.apply_alt(self.BODY, 2, "/images/c.jpg", "Photo <of> things & more")
        self.assertIn('<img alt="Photo &lt;of&gt; things &amp; more" src="/images/c.jpg">', out)

    def test_apply_alt_refuses_when_images_moved(self):
        with self.assertRaises(ValueError):
            seo.apply_alt(self.BODY, 1, "/images/other.png", "x")


class MetaTests(unittest.TestCase):
    def test_missing_description_and_image_get_suggestions(self):
        body = "Plenty of words in this opening paragraph. And a second sentence follows it.\n\n![](/images/a/cover.png)\n"
        meta = {m["key"]: m for m in seo.analyze({"title": "A good title for the article", "kind": "article"}, body, [])["meta"]}
        self.assertEqual(meta["description"]["state"], "missing")
        self.assertTrue(meta["description"]["suggestion"])
        self.assertEqual(meta["image"]["state"], "missing")
        self.assertEqual(meta["image"]["suggestion"], "/images/a/cover.png")

    def test_existing_values_are_never_replaced(self):
        meta = {m["key"]: m for m in seo.analyze(
            {"title": "A good title for the article", "description": "Short", "image": "/images/x.png", "kind": "article"},
            "Body.", [])["meta"]}
        self.assertEqual(meta["description"]["suggestion"], "")
        self.assertEqual(meta["description"]["state"], "warn")
        self.assertEqual(meta["image"]["state"], "ok")

    def test_pages_have_no_featured_image_row(self):
        keys = [m["key"] for m in seo.analyze({"title": "A good title for the page", "kind": "page"}, "Body.", [])["meta"]]
        self.assertNotIn("image", keys)


class LinkTests(unittest.TestCase):
    def test_links_to_titles_but_not_inside_code_links_headings_or_html(self):
        body = ("## Davinci Resolve in a heading\n\nI like Davinci Resolve a lot.\n\n"
                "`Davinci Resolve` in code and [Davinci Resolve](/other/) already linked.\n\n"
                "<p>Davinci Resolve in html</p>\n\n```\nDavinci Resolve in a fence\n```\n")
        found = seo.suggest_links(body, PAGES)
        self.assertEqual(len(found), 1)
        link = found[0]
        self.assertEqual((link["phrase"], link["url"]), ("Davinci Resolve", "/dr-vs-kdenlive/"))
        self.assertEqual(body[link["start"]:link["end"]], "Davinci Resolve")
        self.assertEqual(body[:link["start"]].count("Davinci Resolve"), 1)      # the one in the second paragraph, not the heading

    def test_skips_the_page_itself_and_pages_already_linked(self):
        body = "Davinci Resolve and Kdenlive and [more](/kdenlive/)."
        urls = [s["url"] for s in seo.suggest_links(body, PAGES, self_url="/dr-vs-kdenlive/")]
        self.assertEqual(urls, [])

    def test_common_single_words_are_not_anchors(self):
        pages = [{"title": "Why Windows is slow", "url": "/w/", "tags": ["Windows"]}]
        self.assertEqual(seo.suggest_links("I use Windows every day and it is slow.", pages), [])

    def test_apply_link_checks_the_text_has_not_moved(self):
        body = "I like Davinci Resolve."
        out = seo.apply_link(body, 7, 22, "Davinci Resolve", "/dr/")
        self.assertEqual(out, "I like [Davinci Resolve](/dr/).")
        with self.assertRaises(ValueError):
            seo.apply_link("Totally different text here.", 7, 22, "Davinci Resolve", "/dr/")


class RouteTests(AdminCase):
    def setUp(self):
        super().setUp()
        self.token = self.login()

    def api(self, path, payload):
        return self.client.post(path, base_url=BASE, data=json.dumps(payload),
                                headers={"Content-Type": "application/json", "X-CSRF-Token": self.token})

    def test_analyze_returns_all_three_parts(self):
        response = self.api("/seo/analyze", {"kind": "article", "slug": "new-one", "title": "A good title for the article",
                                             "description": "", "image": "", "body": "Hello there, this is a body.\n\n![](/images/x/pic.png)\n"})
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(set(data), {"meta", "alts", "images", "links"})
        self.assertEqual(len(data["alts"]), 1)

    def test_apply_link_and_alt(self):
        body = "I like Davinci Resolve.\n\n![](/images/x/pic.png)\n"
        out = self.api("/seo/apply", {"op": "link", "body": body, "start": 7, "end": 22, "phrase": "Davinci Resolve", "url": "/dr/"})
        self.assertEqual(out.get_json()["body"].splitlines()[0], "I like [Davinci Resolve](/dr/).")
        out = self.api("/seo/apply", {"op": "alt", "body": body, "index": 0, "src": "/images/x/pic.png", "alt": "A picture"})
        self.assertIn("![A picture](/images/x/pic.png)", out.get_json()["body"])

    def test_apply_refuses_stale_or_foreign_links(self):
        stale = self.api("/seo/apply", {"op": "link", "body": "other", "start": 0, "end": 5, "phrase": "Davinci", "url": "/dr/"})
        self.assertEqual(stale.status_code, 409)
        for url in ("https://evil.example/", "//evil.example/", "/a)b", 'javascript:alert(1)'):
            bad = self.api("/seo/apply", {"op": "link", "body": "Davinci", "start": 0, "end": 7, "phrase": "Davinci", "url": url})
            self.assertEqual(bad.status_code, 409, url)

    def test_json_endpoints_need_the_csrf_header(self):
        response = self.client.post("/seo/analyze", base_url=BASE, data=json.dumps({"body": "x"}),
                                    headers={"Content-Type": "application/json"})
        self.assertEqual(response.status_code, 403)

    def test_pages_list_and_media(self):
        pages = self.get("/api/pages").get_json()["pages"]
        self.assertTrue(any(p["url"].startswith("/") and p["title"] for p in pages))
        image = next((p for p in (self.site / "images").rglob("*") if p.suffix == ".png" and p.is_file()), None)
        if image is None:
            image = self.site / "images" / "t.png"
            image.parent.mkdir(exist_ok=True)
            image.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
        relative = "/" + image.relative_to(self.site).as_posix()
        self.assertEqual(self.get("/media", query_string={"path": relative}).status_code, 200)
        for bad in ("/images/../_config.yaml", "/_config.yaml", "/images/x.md", "images/x.png"):
            self.assertEqual(self.get("/media", query_string={"path": bad}).status_code, 404, bad)

    def test_edit_page_loads_the_editor_and_seo_tab(self):
        page = self.get("/new/article").data
        for needle in (b"md-editor.js", b"markdown-it.min.js", b'data-tab="seo"', b"Generate SEO suggestions"):
            self.assertIn(needle, page)


if __name__ == "__main__":
    unittest.main()
