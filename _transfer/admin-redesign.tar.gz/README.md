# The Linux Experiment

A [Jekyll](https://jekyllrb.com) site (design adapted from the elementary OS blog),
built and hosted by GitHub Pages, with a **local-only admin** for editing it from your laptop.

```
_posts/      articles (Markdown)        pages/      standalone pages created in the admin
_data/       header.yml, footer.yml     _layouts/ _includes/ _sass/   the design
admin/       the local admin (Python)   _tools/     compare_builds.py
```

## Day to day

```bash
./admin/start.sh          # first run asks for an admin user name + password
```

Open <http://127.0.0.1:4001/>. From there you can create pages and articles, edit the header
and footer, upload images, insert YouTube videos, start a **private preview** of the whole site,
and **Publish** (git commit + push; GitHub then rebuilds the site).

The admin uses the **Planner Unifié** design system (`admin/static/design/`: `tokens.css` and `bundle.css`,
light and dark theme).

### Writing articles and pages

- **Visual editor**, adapted from the Planner's notes editor: format text, lists, quotes, code, tables, links,
  images and YouTube videos with the toolbar or Markdown shortcuts (`## `, `- `, `1. `, `> `, ` ``` `).
  The **Markdown** switch shows the raw text. A link button lists your other pages and articles.
- **Your Markdown stays as it is.** Only the blocks you touch are rewritten; everything else (including raw HTML,
  `<figure>` and Liquid blocks, shown as locked boxes) is saved byte for byte. If a change could ever lose text,
  the editor refuses to save and says why.
- **SEO tab**: *Generate SEO suggestions* reads the text as it is right now (saved or not) and proposes
  - the **meta tags** the site uses, only when missing: the description and the featured image;
  - **alt text** for images that have none (from the caption, the file name or the heading above);
  - **links to your other pages**, with the phrase in context and a one-click *Add link*.

  It is plain text analysis on this computer: no AI, no network. Nothing changes until you accept a suggestion
  (alt text is editable before you apply it).

### Why nobody else can reach the admin

- It listens on `127.0.0.1` only. The address is fixed in the code; there is no setting to change it.
- It is **not part of the website**: `admin/` is excluded from the Jekyll build, so it is never published.
- Requests whose `Host` header is not `127.0.0.1:4001` / `localhost:4001` are refused (blocks DNS-rebinding
  tricks from web pages), as are cross-site form posts (CSRF token + `Origin` check, `SameSite=Strict` cookie).
- Password stored as a salted scrypt hash in `admin/.data/` (git-ignored, mode 600); 5 wrong
  attempts lock the login for a minute.
- Do not forward port 4001 or run it behind a tunnel/reverse proxy; that would defeat the point.

## Updating the libraries

| What | Command |
|---|---|
| Jekyll and its plugins | `bundle update`, then `bundle exec jekyll build` to check |
| Admin libraries (Flask, PyYAML) | `./admin/update.sh` (upgrades, then runs the admin's tests) |
| Visual editor library (markdown-it) | Replace `admin/static/vendor/markdown-it.min.js` with the new release's `dist/markdown-it.min.js`, then run `node admin/tests/editor_roundtrip.js` (opens every article and checks the editor writes it back unchanged; needs `npm i playwright`) |
| Design system | Regenerate `admin/static/design/tokens.css` and copy `bundle.css` from the Planner Unifié design system |
| Both, automatically | Dependabot opens a weekly pull request (`.github/dependabot.yml`); the workflows build the site / run the admin tests on each one, so a failing update is visible before you merge it |

The old setup used the `github-pages` gem, which pins Jekyll 3.10. This one uses Jekyll 4.4
directly and is built by `.github/workflows/pages.yml`.

The SCSS still uses `@import`, which Dart Sass only warns about today (silenced in `_config.yaml`).
When a future Sass release removes it, replace the `@import` lines in `css/main.scss` with `@use`.

## One-time migration from the old repository

1. Unzip the overlay over your clone of `thelinuxexp.github.io`.
2. Remove what is no longer needed:
   ```bash
   git rm Gemfile.lock scripts/index.js     # old lockfile; unused script containing an API key
   git rm -r --cached _site                 # build output no longer belongs in git
   ```
3. `bundle install` and commit the new `Gemfile.lock`.
4. **Check nothing changed on the public pages** (recommended before switching):
   ```bash
   git stash -u                              # or use a second checkout of the old repo
   bundle exec jekyll build --destination /tmp/site-old
   git stash pop && bundle install
   bundle exec jekyll build --destination /tmp/site-new
   python3 _tools/compare_builds.py /tmp/site-old /tmp/site-new
   ```
   Expected differences: the `Jekyll v…` generator line in the feeds and tiny CSS formatting
   (new Sass compiler). Anything else is worth a look.
5. On GitHub: **Settings → Pages → Source: GitHub Actions**. The custom domain stays configured there.
6. Push to `main`.
7. In the Google Cloud console, delete or rotate the YouTube API key that was in `scripts/index.js`
   (it has been public in the repository).
