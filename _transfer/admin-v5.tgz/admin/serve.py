"""Local-only admin for the site. Runs on this laptop, reachable only from this laptop.

    python3 admin/serve.py set-password     choose the admin user name and password
    python3 admin/serve.py                  start the admin on http://127.0.0.1:4001/

The admin itself is the `siteadmin` package next to this file (it can also be mounted inside the Planner:
see INTEGRATION.md). This file only starts it on its own.
"""

import getpass
import os
import sys
from pathlib import Path

from werkzeug.serving import make_server

from siteadmin import create_app
from siteadmin.auth import Credentials

HOST = "127.0.0.1"  # fixed on purpose: there is no setting that exposes the admin to a network
DEFAULT_PORT = 4001


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    site_root = Path(__file__).resolve().parent.parent
    data_dir = Path(__file__).resolve().parent / ".data"
    if argv[:1] == ["set-password"]:
        username = input("Admin user name [admin]: ").strip() or "admin"
        password = getpass.getpass("Password (10+ characters): ")
        if password != getpass.getpass("Repeat password: "):
            sys.exit("The two passwords differ; nothing was saved.")
        try:
            Credentials(data_dir).set(username, password)
        except ValueError as error:
            sys.exit(str(error))
        print("Saved. Start the admin with: python3 admin/serve.py")
        return
    port = int(os.environ.get("TLE_ADMIN_PORT", DEFAULT_PORT))
    app = create_app(site_root, data_dir, port)
    if not Credentials(data_dir).exists():
        sys.exit("No password yet. Run first: python3 admin/serve.py set-password")
    print(f"Admin: http://{HOST}:{port}/   (only reachable from this computer; Ctrl+C to stop)")
    server = make_server(HOST, port, app, threaded=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
