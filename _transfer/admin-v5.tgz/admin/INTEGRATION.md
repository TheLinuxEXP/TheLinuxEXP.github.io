# Integrating the site admin into the Planner Unifié

The admin is a self-contained Flask package, `admin/siteadmin/`. It runs in two modes:

- **Standalone** (today): `admin/start.sh` → `admin/serve.py`, port 4001, its own login.
- **Hosted**: the Planner calls `siteadmin.register(app, site_root, data_dir, url_prefix="/site")`. The admin then has no login of its own, lives under `/site`, and is shown in the Planner inside a persistent iframe.

Nothing in your real Planner folder has been changed. `integration/planner.patch` is a diff against a snapshot of `webapp/`.

## Steps

1. `admin/integration/apply.sh "/home/nick/Projects/Planner Unifié/webapp"` (dry-runs first, refuses if the patch doesn't fit).
2. `pip install PyYAML Pillow` in the Planner's environment (the patch also adds them to `requirements.txt`).
3. Set `TASKPLANNER_SITE_ROOT=/home/nick/Projects/Website` in `lancer-planner.sh`. Without it the "Site web" section does not appear at all.
4. Restart the Planner. A "Site web" block appears in the sidebar (Articles, Pages, Header, Footer, SEO…).

What the patch touches: `app/__init__.py` (register block), `templates/index.html` (sidebar block, `data-siteadmin`), `js/render.js` (`site` view hands off to the iframe), `js/boot.js` and `js/status.js` (sidebar hooks), new `js/siteadmin.js`, `requirements.txt`.

## Issues found, and what was done about each

| # | Issue | Status |
|---|-------|--------|
| 1 | **Module names collide.** The admin had top-level `app`, `auth`, `store`, `images`, `tests`; the Planner has its own `app` package. | Fixed: everything lives in the `siteadmin` package; the launcher is `serve.py`. The register block uses `sys.path.append` so the Planner's modules always win. |
| 2 | **Template names collide** (`login.html`, `index.html`, `base.html`, `edit.html`). | Fixed: templates are namespaced `siteadmin/…`; tested against a host that has same-named templates. |
| 3 | **Planner CSP and `X-Frame-Options: DENY`** block an iframe. | Fixed: the blueprint sets its own headers (`frame-ancestors 'self'`, `SAMEORIGIN`), and only on its own responses. The Planner's pages are untouched. |
| 4 | **Planner "trusted local" auth bypass.** Scripts on this machine without browser headers skip the Planner login. The admin writes files, runs Jekyll and pushes to GitHub. | Fixed: in hosted mode the admin requires `Sec-Fetch-Site: same-origin/none`, loopback client address, loopback Host, local Origin, and its own CSRF token. |
| 5 | **Threat model: the Planner is LAN-reachable and Docker/Synology-deployable.** The admin must never be. | Guarded: loopback-only checks above, and it only mounts when `TASKPLANNER_SITE_ROOT` is set. The Docker image has no Ruby, git or GitHub credentials, so do not set it there. |
| 6 | **Bug found by the new host tests:** the "Log out" form was rendered in hosted mode (no such route → 500 on every page). | Fixed. |
| 7 | **Bug found by the new host tests:** an empty CSRF token matched an empty session token, so a first POST with no token passed. | Fixed (affects standalone too). |
| 8 | **Session / secret sharing.** Both apps use one Flask session cookie. | The admin uses its own key (`siteadmin_csrf`) and never touches the Planner's keys (tested). |
| 9 | **Upload limits.** Planner allows 100 MB, the admin 25 MB. | Enforced by hand in the admin's guard. |
| 10 | **New dependencies** (PyYAML, Pillow) in a pinned requirements file. | Added to `requirements.txt`; Pillow needs wheels for the Synology/Docker arch if you ever ship it there. |
| 11 | **Jekyll preview subprocess** outlives requests; the Planner's `/api/restart` would orphan it. | Open: stop the preview from the SEO/Publish page before restarting the Planner. A shutdown hook would fix it properly. |
| 12 | **iframe state loss** on every Planner re-render. | Fixed: the iframe lives outside `#viewRoot`, is only hidden/shown, and reloads only when the section changes. |
| 13 | **Theme sync.** | Shared `taskplanner-theme` key plus the `storage` event; the toggle in the Planner header drives the iframe. |
| 14 | **Session expiry inside the iframe.** The Planner login page is `X-Frame-Options: DENY`, so the iframe would show a blank/blocked frame. | Open: reload the whole Planner tab to log in again. `siteadmin.js` could detect it and reload the top window. |
| 15 | **Two markdown editors** (Planner `notes.js`, admin `md-editor.js`). They will drift. | Open: the admin's is adapted from the Planner's; a shared module would remove the duplication. |
| 16 | **Planner has a leftover `app/static/app.js` monolith** duplicating `js/*.js`. | Not touched; worth deleting separately. |
| 17 | **Data location.** | `data_dir()/"site-admin"` in the Planner (drafts, image originals, state). Make sure it is git-ignored and backed up. |
| 18 | **Python 3.10 compatibility.** | Checked. |
| 19 | **Integration style.** `gestion_ei_web` is mounted as a blueprint with native pages; the admin uses an iframe. | Deliberate: its own CSS, CSP and JS globals would otherwise clash with the SPA's single global scope. Converting to native views later is possible but a large rewrite. |

## Known limits

- The Jekyll `_includes/head.html` SEO template has not been built anywhere with Jekyll yet. Run `bundle exec jekyll build && python3 _tools/check_seo.py` once.
- Tested in a scratch copy of the Planner with a minimal host app; not yet run against your live Planner with real data.
