// Applies the saved theme before the page is drawn (same key as the Planner).
try {
  var saved = localStorage.getItem("taskplanner-theme");
  if (saved === "light" || saved === "dark") document.documentElement.setAttribute("data-theme", saved);
} catch (e) { /* storage blocked: follow the system theme */ }

// Inside the Planner's iframe the toggle lives in the Planner: follow it when it changes the saved theme.
window.addEventListener("storage", function (e) {
  if (e.key !== "taskplanner-theme") return;
  if (e.newValue === "light" || e.newValue === "dark") document.documentElement.setAttribute("data-theme", e.newValue);
  else document.documentElement.removeAttribute("data-theme");
});
