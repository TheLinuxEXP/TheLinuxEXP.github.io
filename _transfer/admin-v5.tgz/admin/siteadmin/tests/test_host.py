"""The admin mounted inside another Flask app (what the Planner does): prefix, namespacing, and the checks
the admin keeps even though the host app has its own login."""
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from flask import Flask, render_template_string, session  # noqa: E402

import siteadmin  # noqa: E402

REPO = Path(__file__).resolve().parents[3]
BROWSER = {"Sec-Fetch-Site": "same-origin"}


class HostCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.site = self.tmp / "site"
        self.site.mkdir()
        for name in ("_posts", "_data", "images"):
            shutil.copytree(REPO / name, self.site / name, ignore=shutil.ignore_patterns("*.png", "*.jpg", "*.webp", "*.gif"))
        shutil.copytree(REPO / "_includes" / "svg", self.site / "_includes" / "svg")
        for name in ("_config.yaml", "index.html", "authors.md", "tags.md", "404.md"):
            shutil.copy(REPO / name, self.site / name)
        # a host app that has templates with the same names as the admin's, a login, and its own session
        self.host = Flask("host", template_folder=str(self.tmp / "host-templates"))
        (self.tmp / "host-templates").mkdir()
        for name in ("login.html", "base.html", "index.html", "edit.html", "dashboard.html"):
            (self.tmp / "host-templates" / name).write_text("HOST TEMPLATE " + name)
        self.host.secret_key = "host-secret"
        self.host.config["TESTING"] = True
        siteadmin.register(self.host, self.site, self.tmp / "data", url_prefix="/site")
        self.client = self.host.test_client()

    def get(self, path, **kw):
        return self.client.get(path, base_url="http://127.0.0.1:8765", headers={**BROWSER, **kw.pop("headers", {})}, **kw)

    def token(self):
        page = self.get("/site/").data.decode()
        return page.split('name="csrf_token" value="')[1].split('"')[0]

    def post_json(self, path, payload, **kw):
        return self.client.post(path, base_url="http://127.0.0.1:8765", data=json.dumps(payload),
                                headers={**BROWSER, "Content-Type": "application/json", "X-CSRF-Token": self.token(), **kw.pop("headers", {})})


class HostModeTests(HostCase):
    def test_pages_live_under_the_prefix_and_use_their_own_templates(self):
        page = self.get("/site/").data.decode()
        self.assertNotIn("HOST TEMPLATE", page)                      # not shadowed by the host's dashboard.html/base.html
        self.assertIn('data-base="/site"', page)
        self.assertIn("/site/static/admin.css", page)
        self.assertNotIn('href="/static/', page)
        self.assertEqual(self.get("/site/header").status_code, 200)
        self.assertEqual(self.get("/site/edit/article/" + next((self.site / "_posts").glob("*.md")).stem).status_code, 200)
        self.assertEqual(self.get("/site/static/edit-page.js").status_code, 200)

    def test_host_login_pages_are_not_replaced_and_admin_has_no_login_of_its_own(self):
        self.assertEqual(self.get("/site/login").status_code, 404)
        self.assertEqual(self.client.post("/site/logout", base_url="http://127.0.0.1:8765", headers=BROWSER).status_code, 404)
        self.assertNotIn("/site/login", [r.rule for r in self.host.url_map.iter_rules()])

    def test_embed_layout_keeps_itself_on_every_link_and_redirect(self):
        page = self.get("/site/?embed=1").data.decode()
        self.assertIn("embed-nav", page)
        self.assertNotIn('class="sidebar"', page)
        self.assertNotIn("data-theme-toggle", page)
        self.assertIn("/site/header?embed=1", page)
        entry = next((self.site / "_posts").glob("*.md")).stem
        edit = self.get(f"/site/edit/article/{entry}?embed=1").data.decode()
        self.assertIn("/site/?embed=1", edit)                          # the Back button
        self.assertNotIn("/site/static/edit-page.js?embed", edit)      # static files are left alone
        plain = self.get("/site/").data.decode()
        self.assertNotIn("embed-nav", plain)
        self.assertIn('class="sidebar"', plain)

    def test_scripts_without_browser_headers_are_refused(self):
        # the Planner lets scripts on this computer through its own login; this admin writes files and pushes to GitHub
        self.assertEqual(self.client.get("/site/", base_url="http://127.0.0.1:8765").status_code, 403)
        self.assertEqual(self.client.get("/site/", base_url="http://127.0.0.1:8765", headers={"Sec-Fetch-Site": "cross-site"}).status_code, 403)
        self.assertEqual(self.client.post("/site/seo/analyze", base_url="http://127.0.0.1:8765", data="{}").status_code, 403)

    def test_only_loopback_names_and_addresses(self):
        for host in ("http://nas.local:8765", "http://192.168.1.20:8765", "http://evil.example"):
            self.assertEqual(self.client.get("/site/", base_url=host, headers=BROWSER).status_code, 400, host)
        self.assertEqual(self.client.get("/site/", base_url="http://localhost:9000", headers=BROWSER).status_code, 200)   # any port
        self.assertEqual(self.client.get("/site/", base_url="http://127.0.0.1:8765", headers=BROWSER,
                                         environ_overrides={"REMOTE_ADDR": "192.168.1.20"}).status_code, 403)

    def test_writes_need_the_token_and_a_local_origin(self):
        self.assertEqual(self.client.post("/site/seo/analyze", base_url="http://127.0.0.1:8765", data=json.dumps({"body": "x"}),
                                          headers={**BROWSER, "Content-Type": "application/json"}).status_code, 403)
        ok = self.post_json("/site/seo/analyze", {"kind": "article", "slug": "x", "title": "T", "body": "hello"})
        self.assertEqual(ok.status_code, 200)
        evil = self.post_json("/site/seo/analyze", {"body": "x"}, headers={"Origin": "http://evil.example"})
        self.assertEqual(evil.status_code, 403)

    def test_headers_belong_to_the_admin_only_and_allow_the_hosts_iframe(self):
        @self.host.get("/other")
        def other():
            return "planner page"
        admin = self.get("/site/")
        self.assertEqual(admin.headers["X-Frame-Options"], "SAMEORIGIN")
        self.assertIn("frame-ancestors 'self'", admin.headers["Content-Security-Policy"])
        self.assertIn("script-src 'self'", admin.headers["Content-Security-Policy"])
        self.assertNotIn("unsafe-inline", admin.headers["Content-Security-Policy"])
        planner = self.client.get("/other")
        self.assertNotIn("Content-Security-Policy", planner.headers)          # the host's pages are untouched
        self.assertNotIn("Cache-Control", planner.headers)

    def test_host_session_is_shared_without_key_collisions(self):
        self.token()
        with self.client.session_transaction(base_url="http://127.0.0.1:8765") as s:
            self.assertIn("siteadmin_csrf", s)
            s["v"] = 7                                                       # the Planner's own login marker
        self.token()
        with self.client.session_transaction(base_url="http://127.0.0.1:8765") as s:
            self.assertEqual(s["v"], 7)

    def test_image_routes_work_under_the_prefix(self):
        folder = self.site / "images" / "posts" / "t"
        folder.mkdir(parents=True)
        from PIL import Image
        Image.effect_noise((1500, 800), 30).convert("RGB").save(folder / "a.png")
        data = self.post_json("/site/images/optimize", {"src": "/images/posts/t/a.png"}).get_json()
        self.assertTrue(data["changed"], data)
        self.assertEqual(self.get("/site/media", query_string={"path": data["src"]}).status_code, 200)


if __name__ == "__main__":
    unittest.main()
