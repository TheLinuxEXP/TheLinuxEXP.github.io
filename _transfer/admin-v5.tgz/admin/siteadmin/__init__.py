"""Site admin for thelinuxexp.com (Jekyll): articles, pages, header/footer, SEO tab, publishing.

Two ways to run it, same code:

    # on its own (./admin/start.sh): its own login, 127.0.0.1 only
    from siteadmin import create_app
    app = create_app(site_root, data_dir, port)

    # inside another Flask app, e.g. the Planner (see INTEGRATION.md)
    import siteadmin
    siteadmin.register(app, site_root=..., data_dir=..., url_prefix="/site")

Integration contract (same spirit as the Planner's gestion_ei_web):
  * one blueprint named "siteadmin", mounted under a prefix; pages, API and static files all live under it;
  * templates are namespaced (templates/siteadmin/...), CSS/JS only touch their own pages (every page of the
    admin is its own HTML document, meant to be shown in an <iframe src="/site/?embed=1"> of the host);
  * the host's login protects it; the admin adds loopback-only and browser-only checks of its own;
  * the design comes from the Planner Unifié tokens (static/design/), the same theme key (taskplanner-theme).
"""
from pathlib import Path

MODULE_INFO = {
    "id": "siteadmin",
    "label": "Site web",
    "default_prefix": "/site",
    "entry": "/site/?embed=1",          # what the host puts in its <iframe src>
    "requires": ["Flask", "PyYAML", "Pillow"],
    "needs_on_this_machine": ["git", "ruby/bundler/jekyll (for the preview)"],
}


def register(host_app, site_root, data_dir, url_prefix=None, preview_port=None):
    """Mounts the admin in a host Flask app. Returns the blueprint."""
    from .routes import PREVIEW_PORT, make_blueprint
    bp = make_blueprint(site_root, data_dir, mode="host", preview_port=preview_port or PREVIEW_PORT)
    host_app.register_blueprint(bp, url_prefix=url_prefix or MODULE_INFO["default_prefix"])
    return bp


def create_app(site_root, data_dir=None, port=4001, preview_port=4000):
    """The admin as an app of its own (own login, 127.0.0.1 only)."""
    from flask import Flask
    from .auth import load_secret_key
    from .routes import make_blueprint
    site_root = Path(site_root).resolve()
    data_dir = Path(data_dir) if data_dir else site_root / "admin" / ".data"
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=load_secret_key(data_dir),
        SESSION_COOKIE_NAME="tle_admin",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Strict",
        PERMANENT_SESSION_LIFETIME=8 * 3600,
        MAX_CONTENT_LENGTH=25 * 1024 * 1024,
    )
    app.register_blueprint(make_blueprint(site_root, data_dir, mode="standalone", port=port, preview_port=preview_port))
    return app
