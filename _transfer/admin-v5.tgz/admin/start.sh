#!/usr/bin/env bash
# Starts the local admin. First run: creates a virtualenv, installs the two
# libraries and asks you to choose a user name and password.
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
# (re)install when a library is missing, e.g. after an update that needs a new one
if ! .venv/bin/python -c "import flask, yaml, PIL" 2>/dev/null; then
  .venv/bin/pip install --quiet -r requirements.txt
fi
if [ ! -f .data/credentials.json ]; then
  .venv/bin/python serve.py set-password
fi
exec .venv/bin/python serve.py
