#!/usr/bin/env bash
# Applies the Site-admin patch to a copy of the Planner's webapp folder (dry run first).
# Usage: admin/integration/apply.sh "/path/to/Planner Unifié/webapp"
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
target="${1:?usage: apply.sh <path to the Planner's webapp folder>}"
[ -f "$target/app/__init__.py" ] || { echo "Not a Planner webapp folder: $target" >&2; exit 1; }
cd "$target"
patch -p1 --dry-run < "$here/planner.patch" >/dev/null || { echo "The patch does not apply cleanly (the Planner changed?). Nothing was modified." >&2; exit 1; }
patch -p1 < "$here/planner.patch"
echo
echo "Done. Next: export TASKPLANNER_SITE_ROOT=<path to the website repo> (e.g. in lancer-planner.sh) and pip install PyYAML Pillow."
