#!/usr/bin/env bash
# Upgrades the admin's libraries (Flask, PyYAML) and re-runs its tests.
set -euo pipefail
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
.venv/bin/pip install --upgrade -r requirements.txt
.venv/bin/python -m unittest discover -s siteadmin/tests
echo "Admin libraries updated and tests pass."
